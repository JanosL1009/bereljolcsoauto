
let domain = window.location.hostname;

$('#searchOthers').focus(function(){
    $.ajax({
        type:'POST',
        url: 'http://localhost/omr_nek/public/getusersfiltered',
        data:{_token: token, jszint:2},
        success:function(data) {
            if (data ==1 ) {
               /* selectedSzervezokArray.push(itemid);
                renderElements();*/
            }
            console.log(data);
        }
    });

});


