
var state = 0; /**states: 0 defualt, 1: change */
var stateRepo = {lasttimestamp:""}; 
var lst = "";

let a_token = a_s;


//let url = new URL("https://onkentes.iec2020.hu/api/MessageNotification");
//http://localhost/devomr/public/
let url = new URL("http://localhost/devomr/public/api/MessageNotification");
url.searchParams.set('api_token',a_token);

let FetchOptions = {
    method: "GET", // *GET, POST, PUT, DELETE, etc.
    credentials: "same-origin",// no-cors, *cors, same-origin
    cache: "no-cache"
  };

let  asyncNotification = async() => {
    let res = await response();  
}

let response = () => fetch(url,{FetchOptions})
    .then((response) => response.json())
    .then(function (data) {
     // console.log(data);
     // lst = data.message;
     if (data.notificationName !== "") {
      let existDivItem = document.getElementById('MainNotificationBox');
        if (existDivItem === null)
        {
          result_display(data.notificationName,'2021',data.id);
        }
        
      }
});
setInterval(asyncNotification,10000);

function result_display(msgTitle,msgDate,notid)
{
    let _body = document.body;
    console.log(_body.scrollHeight);
    let wrap = document.getElementById("c1123");
    wrap.style.position = "absolute";
    wrap.style.left = '0';
    wrap.style.right = '0';
    wrap.style.height = _body.scrollHeight+"px";
    wrap.style.width = '100%';
    wrap.style.background = "gray";
    wrap.style.zIndex = '10';
    wrap.style.opacity = '0.5';

    let domain = window.location.hostname;
    let DIVelement =  document.createElement("div");
    DIVelement.id = 'MainNotificationBox';
    DIVelement.style.height = '200px'; DIVelement.style.width = 'auto';
    DIVelement.style.position = 'fixed'; DIVelement.style.top = '50%';DIVelement.style.left = '50%';
    DIVelement.style.backgroundColor = '#FFF';
    DIVelement.style.zIndex = "10000000";
    let hTag = document.createElement("h4");
    hTag.innerText = 'Új értesítése érkezett!';
    let pTag = document.createElement('p');
    pTag.innerText = msgTitle;
    let btn = document.createElement("a"); btn.innerText = 'Megtekintés';
    btn.href = '/onkentes/ertesitesek/megtekintve/redirect/'+notid;
    btn.classList.add("btn");btn.classList.add("btn-primary");btn.classList.add("xtra");

    DIVelement.appendChild(hTag);

    DIVelement.appendChild(pTag);
    DIVelement.appendChild(btn);
    document.body.appendChild(DIVelement);
}