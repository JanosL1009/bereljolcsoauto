$(window).on('load', function () {
    interval();

});

function interval()
{
    setInterval(function(){ xhr(); }, 7000);

}

function xhr()
{

    $.ajax({
        method: "POST",
        url: "/onkentes/ertesitesek/xhr/friss",
        data: {_token:ptoken}
      })
    .done(function( notification) {
	let result = JSON.parse(notification);
	if(result != "empty")
	{result_display(result.nev,result.created_at,result.id);}

    });

}

function result_display(msgTitle,msgDate,notid)
{
    let domain = window.location.hostname;
    let DIVelement =  document.createElement("div");
    DIVelement.id = 'MainNotificationBox';
    DIVelement.style.height = '130px'; DIVelement.style.width = 'auto';
    DIVelement.style.position = 'fixed'; DIVelement.style.top = '50%';DIVelement.style.left = '50%';
    DIVelement.style.backgroundColor = '#FFF';
    let hTag = document.createElement("h4");
    hTag.innerText = 'Új értesítése érkezett!';
    let pTag = document.createElement('p');
    pTag.innerText = msgTitle;
    let btn = document.createElement("a"); btn.innerText = 'Megtekintés';
    btn.href = 'onkentes/ertesitesek/megtekintve/redirect/'+notid;
    btn.classList.add("btn");btn.classList.add("btn-primary");btn.classList.add("xtra");


    DIVelement.appendChild(hTag);

    DIVelement.appendChild(pTag);
    DIVelement.appendChild(btn);
    document.body.appendChild(DIVelement);
}
