<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ertesitesek extends Model
{
    protected $table = "ertesitesek";

}
