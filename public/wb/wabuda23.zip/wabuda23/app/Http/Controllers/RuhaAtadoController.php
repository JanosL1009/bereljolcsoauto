<?php

namespace App\Http\Controllers;
use Exception;
use App\Esemeny;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\DB_OMR_Operations;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Carbon;
use App\User;
use App\Ruha;
use App\RuhaAtadoAtvetel;
use App\Ajandekok;
use App\AjandekokAtadoAtvetel;
use App\RuhaEsemeny;
use App\Terulet;
use App\TeruletBeosztas;
use App\Model\Felhasznalo;
use App\FelhasznaloInfo;
use App\UserEgyhazmegye;
use App\SzemlyesAdatok;
use App\Http\Models\CustomProfileValidator;
use App\Support\Collection;
use App\Jogosultsag;
use App\FelhasznloSzintek;
use App\MyErrorLog;
class RuhaAtadoController extends Controller
{

    public function index(Request $request)
    {
        $felhasznalok = DB::table('users')->join('jogosultsag','users.id','=','jogosultsag.felhasznalo_id')->where('jogosultsag.felhasznaloszint_id',2)->select('jogosultsag.felhasznalo_id','users.name','users.email')->get();
        $ruhaAtadok = DB::table('users')->join('jogosultsag','users.id','=','jogosultsag.felhasznalo_id')->where('jogosultsag.felhasznaloszint_id',7)->select('jogosultsag.felhasznalo_id','users.name','users.email')->get();
        return view('adminisztratorok/ruha_atado/jogosultsagkezeles')->with('felhasznalok',$felhasznalok)->with('ruhaAtadok',$ruhaAtadok)->with('submenuitem',1);
    }

    public function DressControl(Request $request)
    {
        $dress = Ruha::orderBy('created_at','desc')->paginate(15);



        return view('adminisztratorok/ruha_atado/dresscontroll')->with('submenuitem',2)->with('dresses',$dress);
    }

    /**
     * creatingnewdress.blade
     */
    public function AddNewDress(Request $request)
    {
        $user = auth()->user();
        //dd($user->jogosultsag_data);
        $UserId = $user["id"];

        /**
         * submenuitem = 0 :: minden gomb/link secondary lesz
         */
        return view('adminisztratorok/ruha_atado/creatingnewdress')->with('submenuitem',0);
    }

    /**
     * POST method: creatingnewdress.blade
     */
    public function DressAdd(Request $request)
    {

        $user = auth()->user();
        $UserId = $user["id"];

        $dressName = $request->input('DressName');
        $dressStock = $request->input('DressStock');
        $dresStockOut = $request->input('DressStockOut');

        $dress = new Ruha;
        $dress->ruhaNeve = $dressName;
        $dress->keszlet = $dressStock;
        $dress->kiosztva = $dresStockOut;
        $dress->letrehozo = $UserId;
        $dress->save();

        return redirect()->route('ruha.reszletek',['id' => $dress->id]);
    }

    public function DressAllInfo(Request $request,$id)
    {
        $dress = Ruha::where('id',$id)->first();
        //dd($dress);
        $esemenyek = Esemeny::select('id','nev')->get();


        $dressProgram = RuhaEsemeny::where('ruha_id',$dress->id)->get();

        $selectedPrograms = array();

        foreach($dressProgram as $dp)
        {
            $prog = array();
            $prog['programID'] = $dp->programs->id;
            $prog['programName'] = $dp->programs->nev;
            array_push($selectedPrograms,$prog);
        }

        /**
         * @var array[array] azokat a terulet azonositokat tartalmazza, melyeknek le kell kérni a beosztottjait
         */
        $teruletJelentkezok = array();

        if(isset($selectedPrograms))
        {
            foreach($selectedPrograms as $program)
            {
                $result = $this->getTeruletJelentkezok($program['programID']);

                array_push($teruletJelentkezok,$result);
            }
        }

        $jelentkezoAzonositok = [];
        if(count($teruletJelentkezok) > 0)
        {
            foreach($teruletJelentkezok[0] as $user)
            {
                array_push($jelentkezoAzonositok,$user->id);
            }
        }
        else {$teruletJelentkezok[0] = null;}

       // dd($teruletJelentkezok[0]);

        $atadva = RuhaAtadoAtvetel::select('felhasznalo_id')->where('ruha_id','=',$id)->whereNull('visszaVetelezesIdeje')->get();
        ///dd($atadva);
        return view('adminisztratorok/ruha_atado/fulldresssetting')->with('dress',$dress)->with('submenuitem',0)
        ->with('esemenyek',$esemenyek)->with('selectedPrograms',$selectedPrograms)->
        with('jelentkezok',$teruletJelentkezok[0])->with('jelentkezoAzonositok',$jelentkezoAzonositok)
        ->with('atadva',$atadva);


    }



    /**
     * POST feldolgozo metudosok
     */

    public function UpdateNameModify(Request $request)
    {
        $user = auth()->user();
        $UserId = $user["id"];

        $newName = $request->input('NewDressName');
        $DressID = $request->input('dressCode');

        $dress = Ruha::where('id',$DressID)->first();
        $dress->ruhaNeve = $newName;
        $dress->modosito = $UserId;
        $dress->updated_at = Carbon::now();
        $dress->save();

        return redirect()->route('ruha.reszletek',['id' => $dress->id]);
    }

    public function UpdateDressStock(Request $request)
    {
        $user = auth()->user();
        $UserId = $user["id"];

        $stock = $request->input('NewDressStock');
        $DressID = $request->input('dressCode');

        $dress = Ruha::where('id',$DressID)->first();
        $dress->keszlet = $stock;
        $dress->modosito = $UserId;
        $dress->updated_at = Carbon::now();
        $dress->save();

        return redirect()->route('ruha.reszletek',['id' => $dress->id]);
    }

    public function UpdateDressOutStock(Request $request)
    {
        $user = auth()->user();
        $UserId = $user["id"];

        $stockout = $request->input('NewDressStockOut');
        $DressID = $request->input('dressCode');

        $dress = Ruha::where('id',$DressID)->first();
        $dress->kiosztva = $stockout;
        $dress->modosito = $UserId;
        $dress->updated_at = Carbon::now();
        $dress->save();

        return redirect()->route('ruha.reszletek',['id' => $dress->id]);
    }

    /**
     * visszater egy program jelentkezőivel, akik már be vannak osztva teruletre
     */
    private function getTeruletJelentkezok($programID)
    {
        $teruletID_List = Terulet::select('id')->where('esemeny_id',$programID)->get()->toArray();

        $teruletBeosztas = TeruletBeosztas::select('felhasznalo_id')->whereIn('terulet_id',$teruletID_List)->get()->toArray();
        unset($teruletID_List);

        $Users = User::whereIn('id',$teruletBeosztas)->orderBy('name')->get();
        unset($teruletBeosztas);

        return $Users;
    }


    public function XhrRuhaAtadiMailEll(Request $request)
    {
        /**
         * @var Array a front-endtol-> tartalmazza azokat az id-kat akiknek már kiosztásra kerult a ruha
         * */
        $userid = $request->input('uids'); $dressID = $request->input('did');
        $i=0;
        while($i < count($userid))
        {
            $userid[$i] = intval($userid[$i]);
            $i++;
        }
        $atadatvetel = RuhaAtadoAtvetel::whereIn('felhasznalo_id', $userid)->
        where('ruha_id',$dressID)->where('mailKuldve',1)
        ->get();
        return $atadatvetel->pluck('felhasznalo_id')->toArray();


    }

    public function validalas_atadas(Request $request,$rid)
    {
       
       
       $ruha = Ruha::find($rid); //parametersiteni kell!!!!!

       $talalat = null;

       $email = $request->input('volemail');

       if(isset($email))
       {
           $talalat = \App\User::where('email',$email)->get();
           $talalat = $this->getNewKeresoCollection($talalat)->paginate(10);
       }

       $name = $request->input('onkentes_neve');
       if(isset($name))
       {
            
            $talalat = User::where('name', 'like', '%'.$name.'%')->get();

            $talalat = $this->getNewKeresoCollection($talalat)->paginate(10);
       }
       //$ruhaID = $request->input('rid');
       //dd($ruhaID);
       $atadva = RuhaAtadoAtvetel::where("ruha_id",$rid)->paginate(25);

       $kiadva = array();

       foreach($atadva as $User)
       {
            $at = [];
            $at['id'] = $User->felhasznalo_id;
            $at["nev"] = $User->user->name??'';
            $at["atadasIdeje"] = $User->atadasIdeje;
            $at["visszaIdeje"] = $User->visszaVetelezesIdeje??'';
            array_push( $kiadva,$at);
       }
       $data = json_encode( $kiadva, true);
      /* if(isset($talalat))
       {
        dd($talalat);
       }*/
     //dd( $data);
      // dd( $profileValidator->isValidProfile(),$profileValidator->getErrorList());
       if(isset($talalat))
       {

        return view('adminisztratorok/ruha_atado/atadofelulet',['talalat' => $talalat->appends(Input::except('page')) ])->with('ruha',$ruha)->with('talalat',$talalat)
        ->with('atadva',$kiadva);
       }
       else
       {

        return view('adminisztratorok/ruha_atado/atadofelulet',[ ])->with('ruha',$ruha)->with('talalat',$talalat)
        ->with('atadva',$kiadva);
       }

    }

    public function DressSearching(Request $request)
    {
        $name = $request->input('onkentes_neve');
        $email = $request->input('volemail');

        $talalat = null;

        if(isset($email))
        {
            $talalat = \App\User::where('email',$email)->paginate(20);
            $talalat = $this->getNewKeresoCollection($talalat)->paginate(20);
        }
 
        if(isset($name))
        {
             
             $talalat = User::where('name', 'like', '%'.$name.'%')->get();
 
             $talalat = $this->getNewKeresoCollection($talalat)->paginate(20);
        }

        if(isset($talalat))
        {
            return view('adminisztratorok/ruha_atado/dresssearching', ['talalat' => $talalat->appends(Input::except('page')) ])->with('talalat',$talalat)->with('submenuitem',3);
        }
        else{
            return view('adminisztratorok/ruha_atado/dresssearching')
            ->with('talalat',$talalat)->with('submenuitem',3);
        }
       
    }

    public function ProfilNezo(Request $request,$UserId)
    {
        $user = User::find($UserId);
        $osszesRuha = Ruha::all();
        $ruhaLista = RuhaAtadoAtvetel::where('felhasznalo_id',$UserId)->get();
        $jsonRuhaLista = array();
        try{
            if(count($ruhaLista) > 0)
            {
                foreach($ruhaLista as $ruha)
                {
                    if(!isset($ruha->visszaVetelezesIdeje) )
                    {
                     $item["ruhaid"] = $ruha->Ruha->id;
                     array_push($jsonRuhaLista,$item);
                    }
                    
                }
            }
            else $ruhaLista = null;
        }
        catch(Exception $e)
        {
            $ruhaLista = null;
        }
        
        
        return view('adminisztratorok/ruha_atado/userinfo')->with('user',$user)->with('ruhaLista',$ruhaLista)
        ->with('osszesRuha',$osszesRuha)->with('jsonRuhaLista',json_encode($jsonRuhaLista));
    }

    public function UjRuhaAtadasa(Request $request)
    {/*
        $validate = $request->validate([
            'dress' => 'required',
            'pieces' => 'required',
            'unisexmodel' => 'required',
            'wmodel' => 'required'
        ]);
*/
       
        $dressID = (int)$request->input('dress')??0;
        $pieces = (int)$request->input('pieces')??0;

        $unisex_model = (int)$request->input('unisexmodel')??0;
        $wmodel = (int)$request->input('wmodel')??0;
        $UserID = (int)$request->input('userid')??0;
        
       

        

        $ruha = Ruha::find($dressID);
        $kiosztva = (int)$ruha->kiosztva;
        $keszlet = (int)$ruha->keszlet;

        $ujKiosztottKeszlet = $kiosztva + $pieces;
       
      try{
        if( (int)$ujKiosztottKeszlet <= $keszlet)
        {
            
            $ruha->kiosztva = $ujKiosztottKeszlet;
            
        }
        else throw new Exception();
      }
      catch(Exception $e)
      {
        return back()->withErrors('Hiba a készletezés során. A készlet elfogyott!','warning');
      }
      
      $ruhaKeszletMenteve = false;
      try{
        if($ruha->save())
        {
           
            $ruhaKeszletMenteve = true;
        }
    }
    catch(Exception $e)
    {
        return back()->withErrors('Hiba a ruha készlet mentésekor!','failed');
    }


        $new = new RuhaAtadoAtvetel();
        $new->ruha_id = $dressID;
        $new->darabszam = $pieces;
        $new->unisex_model = $unisex_model;
        $new->noi_model = $wmodel;
        $new->atadasIdeje = Carbon::now();
        $new->felhasznalo_id = $UserID;
       
        $AtadoAtvetelMentve = false;

        try{
            if($new->save())
            {
                
                $AtadoAtvetelMentve = true;
            }
        }
        catch(Exception $e)
        {
            return back()->withErrors('Nem sikerült a darabszámok mentése!','failed');
        }

        if($AtadoAtvetelMentve &&  $ruhaKeszletMenteve)
        {
            
            return back()->withErrors('Sikeres átadás!','success');
        }
        else 
        {
            return back()->withErrors('Sikertelen átadás!','failed');
        }

    }


     /**
     * Visszater egy collection-el, ami tartalmazza a kereso reszletes adatait. Tobb collectionbol keszit egy sajatot
     * collection tartalmat: id,nev,szuletesi ido, cim, profilkep, jogosultsag, vezetoi szintek
     *
     * @return Collection Kereso adatlapok eredmenyei
     */
    protected function getNewKeresoCollection($UserCollection, $FelhasznaloFeladatCollection = null)
    {
            $NewCollection = array();
            if(isset($FelhasznaloFeladatCollection)) //program szerinti keresesnel NEM null
            {

            }
            else //ha nem program szerint keres (kor,nev)
            {
                //dd($UserCollection[0]);
                foreach($UserCollection as $User)
                {


                    $NewUser = null;
                    $NewUser['id'] = $User->id;
                    $NewUser['nev'] = $User->name;
                        
                    $NewUser['email'] = $User->email;


try{
    if($User->felhasznalo_data->kepvalidalas == 3 || $User->felhasznalo_data->kepvalidalas == 2)
    {
        $NewUser['profilkepvalid'] = false;
    }
    else{
        $NewUser['profilkepvalid'] = true;
    } 
}
catch(Exception $e)
{
    $NewUser['profilkepvalid'] = false;
}

                       

                       // dd($cpv->getMessage());
                       $NewUser['atadva'] = false;
                     /*  $ruhak = $User->Ruha;
                       foreach($ruhak as $ruha)
                       {
                            if($ruha->ruha_id == 1)
                            {
                                $NewUser['atadva'] = true;
                            }
                            
                        }*/
                    

                    if(isset($User->felhasznalo_data))
                    {
                        $NewUser['profilkep'] = $User->felhasznalo_data->profilkep;
                    }
                    $NewUser['jogosultsag'] = null;
                    /**
                     * Lehet: Önkéntes, Önkéntes és Ruha átadó, Adminisztrátor
                     */
                    $jogok = Jogosultsag::where('felhasznalo_id',$User->id)->get();
                    if(isset($jogok))
                    {
                            foreach($jogok as $jog)
                            {
                                        $NewUser['jogosultsag'] = $NewUser['jogosultsag'].' '.FelhasznloSzintek::find($jog->felhasznaloszint_id)->SzintNeve;

                            }

                    }


                    array_push($NewCollection,$NewUser);

                }
            }
            //dd($NewCollection);
            return new Collection($NewCollection);
    }

    public function visszavetelezes(int $RuhaAtadoID)
    {

        /**nem számolja ruhát */

        $user = auth()->user();
        //dd($user->jogosultsag_data);
        $UserId = $user["id"];

        $atvettRuhaAdatok = RuhaAtadoAtvetel::find($RuhaAtadoID);
        $atvettRuhaAdatok->modosito = $UserId;
        $atvettRuhaAdatok->visszaVetelezesIdeje = Carbon::now();

        $ruha = Ruha::find($atvettRuhaAdatok->ruha_id);
        $ujKeszlet = $ruha->kiosztva - $atvettRuhaAdatok->darabszam;
        $ruha->kiosztva = $ujKeszlet;
        $ruha->modosito = (int)$user["id"];
        try 
        {
            $ruha->save();
        }
        catch(Exception $e)
        {
            return back()->withErrors('Hiba a készlet kivonás során!','failed');
        }

        if($atvettRuhaAdatok->save())
        {
            return back()->withErrors('A visszavételezés sikeresen megtörtént!','success');
        }
        else  return back()->withErrors('A visszavételezés sikertelen!','failed');

    }

    public function postAtadas(Request $request)
    {
        
        $loggeduser = auth()->user(); //atado
        $LoggedUserId = $loggeduser["id"]; 

        $UserID = $request->input('auid');
        $darabszam = $request->input('db');
        $ruhaID = $request->input('did'); //dressID
        $actTime = date('Y-m-d H:i:s');//Carbon::now();

        $ruha = Ruha::find($ruhaID);
        $kiosztva = (int)$ruha->kiosztva;
        $keszlet = (int)$ruha->keszlet;

        $ujKiosztottKeszlet = $kiosztva + $darabszam;
       
      try{
        if( (int)$ujKiosztottKeszlet <= $keszlet)
        {
            
            $ruha->kiosztva = $ujKiosztottKeszlet;
            
        }
        else throw new Exception();
      }
      catch(Exception $e)
      {
          return 0;
        //return 'Hiba a készletezés során. A készlet elfogyott!';
      }
      
      $ruhaKeszletMenteve = false;
      try{
        if($ruha->save())
        {
           
            $ruhaKeszletMenteve = true;
        }
    }
    catch(Exception $e)
    {
        return 1;
        //return back()->withErrors('Hiba a ruha készlet mentésekor!','failed');
    }


        $new = new RuhaAtadoAtvetel();
        $new->ruha_id = $ruhaID;
        $new->darabszam = $darabszam;
        $new->unisex_model = 0;
        $new->noi_model = 0;
        $new->atadasIdeje = $actTime;
        $new->felhasznalo_id = $UserID;
        $new->modosito = $LoggedUserId; //modosito/letrehozo
        $AtadoAtvetelMentve = false;

        try{
            if($new->save())
            {
                
                $AtadoAtvetelMentve = true;
            }
        }
        catch(Exception $e)
        {
            $error = new MyErrorLog();
            $error->controller = 'RuhaAtadoController';
            $error->methodname = 'postAtadas';
            $error->otherDescribe = 'Mentés hiba: 2';
            $error->exceptionMsg = $e;
            $error->save();
            return 2;
            //return back()->withErrors('Nem sikerült a darabszámok mentése!','failed');
        }

        if($AtadoAtvetelMentve &&  $ruhaKeszletMenteve)
        {
            $NewRecord = array();
             $dress["ruha_id"] = $ruhaID;
             $dress["ruha_atadoid"] = $new->id;
             $dress["ruha_neve"] = $ruha->ruhaNeve;
             $dress["atadasIdeje"] = $new->atadasIdeje;
             array_push($NewRecord,$dress);
            //return 3;
            return json_encode($NewRecord);
        }
        else 
        {
            return 4;
            //return back()->withErrors('Sikertelen átadás!','failed');
        }
    }


    public function dress_delete(Request $request)
    {
        $DressID = $request->input('id');

        $isDelete = 'nincs';

        $kiadottRuha = RuhaAtadoAtvetel::where('ruha_id',$DressID)->whereNull('visszaVetelezesIdeje')->first();
       
      
        $kiadva = true;
        try{
            if(isset($kiadottRuha))
            {
                 throw new Exception();
            }
            else 
            {
                $kiadva = false;
            }
        }
        catch(Exception $e)
        {
            $isDelete = 0;
            return $isDelete;
            //return back()->withErrors('A tételt nem lehet törölni, mert hiány van!','failed');
        }

        try {
            if(!$kiadva)
            {
                $ruha = Ruha::find($dressID)->delete();
                $atado = RuhaAtadoAtvetel::where('ruha_id',$DressID)->delete();
    
                if($ruha && $atado)
                {
                    $isDelete = 2;
                    return $isDelete;
                    //return back()->withErrors('A ruhát és kapcsolodó bejegyzései törlésre kerültek!','success');
                }
               
    
            }
        }
        catch(Exception $e) 
        {
            $isDelete = $e->message;
            return $isDelete;
            //return back()->withErrors('A ruhát és kapcsolodó bejegyzései törlése nem sikerült!','failed');
        }

        $isDelete = 1;
        return $isDelete;
    }


    /**
     * Ajandek
     */

     public function ajandek_index() 
     {
        $dress = Ajandekok::orderBy('created_at','desc')->paginate(15);



        return view('adminisztratorok/ruha_atado/ajandekok')->with('submenuitem',4)->with('dresses',$dress);
     }

     public function UjAjandek()
     {
        

        return view('adminisztratorok/ruha_atado/ajandekletrehozasa')->with('submenuitem',4);
     }

     public function AjandekLetrehozasa(Request $request)
     {
        $validate = $request->validate([
            "DressName" => 'required'
        ]);

        $user = auth()->user();
        $UserId = $user["id"];

        $uj =  new Ajandekok();
        $uj->ajandekNeve = $request->input('DressName');
        $uj->keszlet = $request->input('DressStock');
        $uj->kiosztva = $request->input('DressStockOut');
        $uj->letrehozo =  $UserId;
        $uj->modosito = 0;
        $uj->save();
       
        return redirect()->route('ajandek.info',['id' => $uj->id]);
     }

     public function AjandekInfo($id)
     {
        $dress = Ajandekok::where('id',$id)->first();
        //dd($dress);
        

       // dd($teruletJelentkezok[0]);

        $atadva = AjandekokAtadoAtvetel::select('felhasznalo_id')->where('ruha_id','=',$id)->whereNull('visszaVetelezesIdeje')->get();
        ///dd($atadva);
        return view('adminisztratorok/ruha_atado/ajandekmodositas')->with('dress',$dress)->with('submenuitem',0);
     }

     /***
      * Egy ajandek torlese
      */
     public function ajandek_delete(Request $request)
    {
        $DressID = $request->input('id');

        $isDelete = 'nincs';

        $kiadottRuha = AjandekokAtadoAtvetel::where('ruha_id',$DressID)->whereNull('visszaVetelezesIdeje')->first();
       
      
        $kiadva = true;
        try{
            if(isset($kiadottRuha))
            {
                 throw new Exception();
            }
            else 
            {
                $kiadva = false;
            }
        }
        catch(Exception $e)
        {
            $isDelete = 0;
            return $isDelete;
            //return back()->withErrors('A tételt nem lehet törölni, mert hiány van!','failed');
        }

        try {
            if(!$kiadva)
            {
                $ruha = Ajandekok::find($dressID)->delete();
                $atado = AjandekokAtadoAtvetel::where('ruha_id',$DressID)->delete();
    
                if($ruha && $atado)
                {
                    $isDelete = 2;
                    return $isDelete;
                    //return back()->withErrors('A ruhát és kapcsolodó bejegyzései törlésre kerültek!','success');
                }
               
    
            }
        }
        catch(Exception $e) 
        {
            $isDelete = $e->message;
            return $isDelete;
            //return back()->withErrors('A ruhát és kapcsolodó bejegyzései törlése nem sikerült!','failed');
        }

        $isDelete = 1;
        return $isDelete;
    }


     public function AjandekNevenekModositasa(Request $request)
     {
        $ujnev = $request->input('NewDressName');
        $ajiCode = (int)$request->input('dressCode');

        $ajandek = Ajandekok::find($ajiCode);
        $ajandek->ajandekNeve = $ujnev;

        $ajandek->save();

        return back();
     }

     public function AjandekKeszletModositasa(Request $request)
     {
        $ujertek = (int)$request->input('NewDressStock');
        $ajiCode = (int)$request->input('dressCode');

        $ajandek = Ajandekok::find($ajiCode);
        $ajandek->keszlet = $ujertek;

        $ajandek->save();

        return back();
     }

     public function AjandekKiosztModositasa(Request $request)
     {
        $ujertek = (int)$request->input('NewDressStockOut');
        $ajiCode = (int)$request->input('dressCode');

        $ajandek = Ajandekok::find($ajiCode);
        $ajandek->kiosztva = $ujertek;

        $ajandek->save();

        return back();
     }

     public function AjandekProfilNezo($UserId)
     {
        $user = User::find($UserId);
        $osszesRuha = Ajandekok::all();
        $ruhaLista = AjandekokAtadoAtvetel::where('felhasznalo_id',$UserId)->get();
       
        $jsonRuhaLista = array();
        try{
            if(count($ruhaLista) > 0)
            {
                foreach($ruhaLista as $ruha)
                {
                    if(!isset($ruha->visszaVetelezesIdeje) )
                    {
                     $item["ruhaid"] = $ruha->ruha_id;
                     array_push($jsonRuhaLista,$item);
                    }
                    
                }
            }
            else $ruhaLista = null;
        }
        catch(Exception $e)
        {
            $ruhaLista = null;
        }
        
       
        return view('adminisztratorok/ruha_atado/ajandekuserinfo')->with('user',$user)->with('ruhaLista',$ruhaLista)
        ->with('osszesRuha',$osszesRuha)->with('jsonRuhaLista',json_encode($jsonRuhaLista));
     }



     public function postAjandekAtadas(Request $request)
     {
         
         $loggeduser = auth()->user(); //atado
         $LoggedUserId = $loggeduser["id"]; 
 
         $UserID = $request->input('auid');
         $darabszam = $request->input('db');
         $ruhaID = $request->input('did'); //dressID
         $actTime = date('Y-m-d H:i:s');//Carbon::now();
 
         $ruha = Ajandekok::find($ruhaID);
         $kiosztva = (int)$ruha->kiosztva;
         $keszlet = (int)$ruha->keszlet;
 
         $ujKiosztottKeszlet = $kiosztva + $darabszam;
        
       try{
         if( (int)$ujKiosztottKeszlet <= $keszlet)
         {
             
             $ruha->kiosztva = $ujKiosztottKeszlet;
             
         }
         else throw new Exception();
       }
       catch(Exception $e)
       {
           return 0;
         //return 'Hiba a készletezés során. A készlet elfogyott!';
       }
       
       $ruhaKeszletMenteve = false;
       try{
         if($ruha->save())
         {
            
             $ruhaKeszletMenteve = true;
         }
     }
     catch(Exception $e)
     {
         return 1;
         //return back()->withErrors('Hiba a ruha készlet mentésekor!','failed');
     }
 
 
         $new = new AjandekokAtadoAtvetel();
         $new->ruha_id = $ruhaID;
         $new->darabszam = $darabszam;
         
         $new->atadasIdeje = $actTime;
         $new->felhasznalo_id = $UserID;
         $new->modosito = $LoggedUserId; //modosito/letrehozo
         $AtadoAtvetelMentve = false;
 
         try{
             if($new->save())
             {
                 
                 $AtadoAtvetelMentve = true;
             }
         }
         catch(Exception $e)
         {
             $error = new MyErrorLog();
             $error->controller = 'RuhaAtadoController';
             $error->methodname = 'postAjandekAtadas';
             $error->otherDescribe = 'Mentés hiba: 2';
             $error->exceptionMsg = $e;
             $error->save();
             return 2;
             //return back()->withErrors('Nem sikerült a darabszámok mentése!','failed');
         }
 
         if($AtadoAtvetelMentve &&  $ruhaKeszletMenteve)
         {
             $NewRecord = array();
              $dress["ruha_id"] = $ruhaID;
              $dress["ruha_atadoid"] = $new->id;
              $dress["ruha_neve"] = $ruha->ajandekNeve;
              $dress["atadasIdeje"] = $new->atadasIdeje;
              array_push($NewRecord,$dress);
             //return 3;
             return json_encode($NewRecord);
         }
         else 
         {
             return 4;
             //return back()->withErrors('Sikertelen átadás!','failed');
         }
     }


     /**
      * ajandekvisszavetelezes
      */
     public function ajandek_visszavetelezes(int $RuhaAtadoID)
     {
 
         /**nem számolja ruhát */
 
         $user = auth()->user();
         //dd($user->jogosultsag_data);
         $UserId = $user["id"];
 
         $atvettRuhaAdatok = AjandekokAtadoAtvetel::find($RuhaAtadoID);
         $atvettRuhaAdatok->modosito = $UserId;
         $atvettRuhaAdatok->visszaVetelezesIdeje = Carbon::now();
 
         $ruha = Ajandekok::find($atvettRuhaAdatok->ruha_id);
         $ujKeszlet = $ruha->kiosztva - $atvettRuhaAdatok->darabszam;
         $ruha->kiosztva = $ujKeszlet;
         $ruha->modosito = (int)$user["id"];
         try 
         {
             $ruha->save();
         }
         catch(Exception $e)
         {
             return back()->withErrors('Hiba a készlet kivonás során!','failed');
         }
 
         if($atvettRuhaAdatok->save())
         {
             return back()->withErrors('A visszavételezés sikeresen megtörtént!','success');
         }
         else  return back()->withErrors('A visszavételezés sikertelen!','failed');
 
     }


}
