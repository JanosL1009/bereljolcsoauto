<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Model\Felhasznalo;
use App\FelhasznaloInfo;
use App\Http\Controllers\PdfGenerateController;
use Auth;
use Illuminate\Support\Facades\DB;

class TanusitvanyController extends Controller
{
    //admin reszhez

    public function ProfileAdmin(Request $request,int $UserId)
    {
        $user = User::find($UserId);
        $igazolasIgenyID = FelhasznaloInfo::where('felhasznalo_id',$UserId)->first()->igazolasIgenyID??9;
        $igazolas = null;
        switch($igazolasIgenyID)
        {
            case 0:
                $igazolas = 'Nem';
                break;
            case 1:
                $igazolas = 'Igen, önkéntességről általában';
                break;
            case 2:
                    $igazolas = 'Igen, szakmai gyakorlathoz';
                    break;
            case 3:
                $igazolas = 'Igen, iskolai közösségi szolgálathoz (IKSZ)';
                break;
            case 4:
                $egyeb = FelhasznaloInfo::where('felhasznalo_id',$UserId)->first()->igazolasEgyeb??'';
                $igazolas = 'Egyéb: '.$egyeb;
                    break;
            default: 
            $igazolas = 'Nem.';
            break;

        }


        return view('adminisztratorok.tanusitvany.profil')->with('user',$user)
        ->with('igazolas',$igazolas);

    }


    public function igazolas_post_admin(Request $request)
    {
        $userid = (int)$request->input('userid')??null;
        $igazolasID = (int)$request->input('igazolas')??9;

        switch($igazolasID)
        {
            case 0:
                return back();
                break;
            case 1:
                return back();
                break;
            case 2:
                $pdfgeneralas = new PdfGenerateController();
                $res = $pdfgeneralas->getAltalnosOnkentesIgazolas($request, $userid);
                return $res;
                break;
            case 3:
                //dd('fut');
                $pdfgeneralas = new PdfGenerateController();
                $res = $pdfgeneralas->getIkszIgazolas($request, $userid);
                return $res;
                break;
            case 4:
                    return back();
                    break;
            default: 
                return back();
            break;

        }
    }




    //onkenetes resz
    public function ProfilOnkentes(Request $request,int $igazolasID)
    {
        $user = auth();
        $userid = Auth::id();
        

        switch($igazolasID)
        {
            case 0:
                return back();
                break;
            case 1:
                return back();
                break;
            case 2:
                $pdfgeneralas = new PdfGenerateController();
                $res = $pdfgeneralas->getAltalnosOnkentesIgazolas($request, $userid);
                return $res;
                break;
            case 3:
                //dd('fut');
                $pdfgeneralas = new PdfGenerateController();
                $res = $pdfgeneralas->getIkszIgazolas($request, $userid);
                return $res;
                break;
            case 4:
                    return back();
                    break;
            default: 
                return back();
            break;

        }

    }

    public function getsorozatba_iksz(Request $request)
    {

        $users = DB::table('kozepiskolasok')->join('felhasznalok','kozepiskolasok.id','=','felhasznalok.id')->
        where('felhasznalok.onkentesOrakSzama','>',0)->get('kozepiskolasok.id');

        foreach($users as $user)
        {
            $pdfgeneralas = new PdfGenerateController();
            $res = $pdfgeneralas->getAllIksz($request, $user->id);
        }

       
    }
}
