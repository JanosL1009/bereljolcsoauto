<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Gyik;
use App\Http\Models\AdminEsemenyekViewModel;
use Exception;

class GyikController extends Controller
{
    public function lista()
    {
        $user = auth()->user();
        $model = new AdminEsemenyekViewModel($user['id']);
        $model->profilpic = DB_OMR_Operations::GetProfilkep($user['id']);


        $gyikLista = Gyik::paginate(15);

        return view('adminisztratorok.gyik.lista')->with('gyikLista', $gyikLista)->with('model', $model);
    }

    public function letrehozas(){
        return view('adminisztratorok.gyik.letrehozas');
    }

    public function letrehozas_feldolgozo(Request $request)
    {
        $user = auth()->user();

        try{
            $gyik = new Gyik();
            $gyik->kerdes = $request->input('gyik_kerdes');
            $gyik->valasz = $request->input('gyik_valasz');
            $gyik->letrehozo =  $user['id'];
            $gyik->kulcsszavak = $request->input('gyik_kulcsszavak');
            $gyik->save();
        }
        catch(Exception $e)
        {
            return redirect(route('gyik.lista'))->withErrors("Hiba a létrehozás során.",'letrehozashiba');
        }
        return redirect(route('gyik.lista'))->withErrors("Az GYIK létrehozása sikerült!",'sikerletrehozas');
   
      }

    public function modositas(int $id)
    {
        $gyik = Gyik::find($id);

        return view('adminisztratorok.gyik.modositas')->with('gyik',$gyik);
    }

    public function frissites_feldolgozo(Request $request)
    {
        $user = auth()->user();

        try 
        {
            $gyik = Gyik::find($request->input("id"));
            $gyik->kerdes = $request->input('gyik_kerdes');
            $gyik->valasz = $request->input('gyik_valasz');
            $gyik->kulcsszavak = $request->input('gyik_kulcsszavak');
            $gyik->modosito =  $user['id'];
            $gyik->save();
        }
        catch(Exception $e)
        {
            return redirect(route('gyik.lista'))->withErrors("Hiba a módosítás során.",'modositasihiba');
        }
        return redirect(route('gyik.lista'))->withErrors("Sikeresen módosult a GYIK elem!",'sikermodositas');
    }


    public function torles(Request $request)
    {
        $_esid = $request->input('_esid');
        try {
            Gyik::find($_esid)->delete();
        }
        catch(Exception $e)
        {
            return 0;
        }

        return 1;
    }


    /** *****       *******         **********          *********           ********        *****       ***** */
                                        /********* ÖNKÉNTES OLDAL  ********** */
    /** *****       *******         **********          *********           ********        *****       ***** */

    public function index()
    {
        $gyikLista = null;
        try {
            $gyikLista = Gyik::paginate(25);
        }
        catch(Exception $e)
        {
            return redirect(route('gyik.onkentes.index'))->withErrors('Hiba a lekérdezés során vagy még nincs feltöltve GYIK.','lekerdezohiba');
        }

        return view('onkentes.gyik.index')->with('gyikLista',$gyikLista);
    }

    public function kereso_form(Request $request)
    {
       
        $request->validate([
            'gyik_kerdes' => 'string|required',
        ]);
        $kifejezes = $request->input('gyik_kerdes');
        $gyikLista = null;
        try {
            $gyikLista = Gyik::where('kerdes', 'like', '%'.$kifejezes.'%')->orWhere('kulcsszavak', 'like', '%'.$kifejezes.'%')->get()->paginate(25);
        }
        catch(Exception $e)
        {
            
            $gyikLista = Gyik::paginate(25);
            return redirect(route('gyik.onkentes.kereso'))->with('gyikLista',$gyikLista)->withErrors('Nincs találat.','lekerdezohiba');
       
        }

        return view('onkentes.gyik.kereso')->with('gyikLista',$gyikLista);
    }

}
