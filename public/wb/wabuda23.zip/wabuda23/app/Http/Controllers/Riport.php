<?php
namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Exception;
class Riport
{

    /**a passio2020 tablaban levo felhasznalo_id jó!
     * a felhasznalok id is jó
     *
    */

     /**
     * @return users Visszater egy user adataival a user táblából [asszoc. tömb]
     */
    public static function GetUser()
    {
        $Select = "SELECT * from users";
        $eredmeny = DB::select($Select);
        return $eredmeny;
    }


    public static function GetFelhasznalo($email)
    {
        $select = "SELECT * from felhasznalok where email =  '".$email."'";
        $eredmeny = collect(DB::select($select))->first();
       /* $data = null;
        foreach($eredmeny as $item)
        {
            $data["vezeteknev"] = $item->vezeteknev;
            $data["keresztnev"] = $item->keresztnev;
            $data["kozepsonev"] = $item->kozepsonev;
            $data["neme_id"] = $item->neme;
            $data["email"] = $item->email;
            $data["szulIdo"] = $item->szulIdo;
            $data["szulhely"] = $item->szulhely_ID;
            $data["orszag"] = $item->orszag_id;
           $data["telefonszam"] = $item->telefonszam;
           $data["kor"] = $item->kor;
        }
        unset($eredmeny);
         dd($eredmeny);*/
        return $eredmeny;
    }


    //3.
    public static function GetJelentkezesPassio($felhasznalo_id,$telefonszam)
    {
        $Select = "SELECT * from passio2020kerdoiv where  felhasznalo_id = ".$felhasznalo_id." AND telefonszam = '".$telefonszam."'";
        $eredmeny = collect(DB::select($Select))->first();

        return $eredmeny;
    }

    public static function GetFelhasznaloinfo($id)
    {
        $select = "select * from felhasznaloinfo where felhasznalo_id =  ".$id;
        $eredmeny = collect(DB::select($select))->first();
       /* $data = null;
        foreach($eredmeny as $item)
        {
            $data["felhasznalo_id"] = $id;
            $data["tevekenyseg_id"] = $item->tevekenyseg_id;
            $data["tevekenyseg"] = self::GetTevekenyseg($item->tevekenyseg_id);
            $data["polomeret"] = $item->polomeret;
            $data["fogyatekossag_id"] = $item->fogyatekossag;
            $data["fogyLeirasa"] = $item->fogyLeirasa;

            if($data["fogyatekossag_id"] == 0)
            {
                $data["fogyatekossag"] = "Nem";
            }
            else
            {
                $data["fogyatekossag"] = "Igen";
            }
        }
        unset($eredmeny);
*/
//dd($eredmeny);
        return $eredmeny;
    }

    public static function GetMagassag($telefonszam)
    {
        $passio = "SELECT * from passio2020kerdoiv where telefonszam = '".$telefonszam."' ";
        $eredmeny = collect(DB::select($passio))->first();
        return $eredmeny;
    }

    /**   seged fgvek */

    public static function GetTevekenyseg($tevekenysegID)
    {
        if($tevekenysegID != 0)
        {
            $select = "select * from tevekenyseg where id =  ".$tevekenysegID;
            $eredmeny = collect(DB::select($select))->first();

            return $eredmeny->tevekenyseg;
        }
        else return 0;
    }

    public static function GetEgyebSzervezet($felhasznaloid)
    {
        $egyeb = "SELECT * FROM egyeb_szervezet where felhasznalo_id = ".$felhasznaloid;
        $eredmeny = null;

        try{
            $eredmeny = collect(DB::select($egyeb))->first();
        }
        catch(Exception $exception)
        {
            unset($eredmeny);
            return "Nem";
        }

        if(isset($eredmeny->szervezet_neve))
        {
            return $eredmeny->szervezet_neve;
        }
        else{
            return "Nem";
        }
    }

    public static function GetCivilSzervezet($felhasznaloid)
    {
        $egyeb = "SELECT * FROM civil_szervezet where felhasznalo_id = ".$felhasznaloid;
        $eredmeny = null;

        try{
            $eredmeny = collect(DB::select($egyeb))->first();
        }
        catch(Exception $exception)
        {
            unset($eredmeny);
            return "Nem";
        }

        if(isset($eredmeny->szervezet_neve))
        {
            return $eredmeny->szervezet_neve;
        }
        else{
            return "Nem";
        }
    }


}
