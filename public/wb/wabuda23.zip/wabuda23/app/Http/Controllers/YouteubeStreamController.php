<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Models\YtViewModel;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\DB_OMR_Operations;
use App\YtpPlayed;
use App\Support\Collection;
use App\User;
use Exception;

class YouteubeStreamController extends Controller
{
    /**
     * Onkentes oldali
     */
    public function YoutubeStreamLive()
    {
        $user = auth()->user();
        $id = $user['id'];

        $model = new YtViewModel($id);
        $model->profilpic = DB_OMR_Operations::GetProfilkep($id);

        return view('onkentes.kozvetites.youtubekozvetites')->with('model',$model);

        //abort(404);
    }



    /**
     * Admin oldal
     */
    public function YtbAdminBoard(Request $request)
    {
        $user = auth()->user();
        $id = $user['id'];

        $model = new YtViewModel($id);
        $model->profilpic = DB_OMR_Operations::GetProfilkep($id);

        $ytpplayed = YtpPlayed::groupBy('felhasznalo_id')->get();
        $allviewer = count($ytpplayed);
        //dd( $ytpplayed);
        $ytpplayedList = array();
       // dd($ytpplayed[0]->felhasznalok_data);
       foreach( $ytpplayed as $user)
       {
            $stat =  $this->getUserStat($user->felhasznalo_id);
            array_push($ytpplayedList,$stat);
       }
    
        $userStatList = new Collection($ytpplayedList);
        
        return view('adminisztratorok.kozvetites.elostats')->with('model',$model)->with('ytpplayedstats',$userStatList->paginate(20))
        ->with('allviewer',$allviewer);
    }

    public function AdminSettings(Request $request)
    {
        return view('adminisztratorok.beallitasok.kozvetites');
    }


    public function getUserStat(int $UserID)
    {
        $ytp = YtpPlayed::where('felhasznalo_id',$UserID)->get();
        $result = [];
        foreach($ytp as $_user)
        {
            
            $user = User::find($_user->felhasznalo_id);
           
            $result['id'] = $user->id;
            
                $result['name'] = $user->name;
            
           
            $result['email'] = $user->email;
            $result['age'] = $user->felhasznalo_data->kor??0;
            if($user->felhasznalo_data->neme == 1)
            {
                $result['Neme'] = "Nő";
            }elseif($user->felhasznalo_data->neme == 0)
            {
                $result['Neme'] = "Férfi";
            }
            else 
            {
                $result['Neme'] = "Hiányos profil";
            }

            $result['click'] = $this->getUserStatClicked($user->id);
            $result['allplayedsec'] = $this->getAllMinutes($UserID);
            $result['allplayedmin'] =  $this->getMinutes($result['allplayedsec']);
            $result['startTime'] = $user->startTime;
        }
        return $result;
    }

    /**
     * Youtube Player play gomjat hanyszor nyomta meg.
     */
    protected function getUserStatClicked(int $UserID)
    {
        $ytp = YtpPlayed::where('felhasznalo_id',$UserID)->count();
        return $ytp;
    }


    protected function getMinutes(int $Minutes)
    {
        return gmdate("H:i:s",$Minutes);
    }

    protected function getAllMinutes(int $UserID)
    {
        $ytp = YtpPlayed::where('felhasznalo_id',$UserID)->sum("actplayTime");
        return $ytp;
    }



}
