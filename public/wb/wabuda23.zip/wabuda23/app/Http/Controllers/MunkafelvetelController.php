<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Munkafelvetel;
use App\Http\Models\Beosztas\OnkenteBeosztViewModel;
use App\Http\Models\Muszak\MuszakFelvetelIndexViewModel;
use App\FelhasznaloFeladat;
use Illuminate\Support\Carbon;
use App\Csoport;
use  App\Terulet;
use App\Esemeny;
use App\Http\Models\Muszak\MuszakFelvetel;
use App\Model\Felhasznalo;
use Exception;
use App\Model\BeosztasKezeloRepo;

class MunkafelvetelController extends Controller
{
    /**
     * Elokesziti a viewt az admin feluleten
     * @param int Terulet azonosito
     * @param int csoport azonosito
     * @return View adminisztratorok/munkafelvetel
     */
    public function AdminMunkafelvetel(Request $request,$teruletID,$csoportID,$valasztottNap = null)
    {
        $user = auth()->user();
        $model = new MuszakFelvetelIndexViewModel($user['id']);
        $model->profilpic = DB_OMR_Operations::GetProfilkep($user['id']);
        $model->teruletID = $teruletID;
        $model->csoportID = $csoportID;
        $model->esemenyID = Terulet::find($model->teruletID)->esemeny_id;
        /**
         * ha csoport id nem megfelelo, akkor hibat doba az oldal
         * mivel itt hivja meg elsokent a csoportot, nem kell kulon ellenorizni a csoport letezeset
         */
        try{
            $model->breadcrumblink = FrontEndMaker::getMunkafelvetelBreadCrumbLinks($model->csoportID);
        }
        catch(Exception $e) //ha kivetel keletkezik, akkor nem létezik a csoport, es 404es oldalra iranyitjuk a usert
        {
            abort(404);
        }

        /** Akik mar felvettek a munkat */
        $beosztottak = Munkafelvetel::where('csoport_id',$model->csoportID)->get('felhasznalo_id');

        // dd($beosztottak[0]->user_data->name);


        $muszakFelvetelKezelo =  new MuszakFelvetel($model->csoportID);
        //$muszakFelvetelKezelo->MuszakDatumokEllenorzese();
        $model->csoport =  $muszakFelvetelKezelo->getCsoportInformaciok();
        $muszakFelvetelKezelo->MuszakDatumokEllenorzese();
        $model->munkaNapokArray = $muszakFelvetelKezelo->getMuszakDatumok();


        /**A csoportba beosztottak, de meg nem vettek fel a munkat. */
        $nemBeosztottak = FelhasznaloFeladat::where('csoport_id',$model->csoportID)->get('felhasznalo_id');
       // dd($nemBeosztottak );
        //dd( $nemBeosztottak[0]->user_data->name,$nemBeosztottak[0]->felhasznalo_id,$nemBeosztottak[0]->munkafelvetel_data->csoport_id??0);
        if(isset($valasztottNap))
        {
            $model->MuszakID = $valasztottNap;
            $model->kivalasztottNap = $muszakFelvetelKezelo->getValasztottDatum($valasztottNap);
            $BeosztasKezeloRepo = new BeosztasKezeloRepo(null,$model->esemenyID,$model->teruletID,$model->csoportID);

            $model->csoportTagok = $BeosztasKezeloRepo->GetCsoportBeosztas();
            $model->muszakIgazoltak = null;
        }

        $csoportInfo = DB_OMR_Operations::CsoportLista($model->teruletID);

        return view('adminisztratorok/munkafelvetel')->with('model',$model)->
        with('nembeosztottak',$nemBeosztottak)->with('beosztottak', $beosztottak)->with('csoportInfo',$csoportInfo)
        ->with('muszak_datum_id',$valasztottNap )->with('actGroupID',$csoportID);

    }


    /**
     * Önkéntes oldalról, a vezetok ezen metodus segítsegevel tudjak igazolni a muszakot.
     * Lenyegeben megegyezik az admin oldalival.
     * @param int Terulet azonosito
     * @param int csoport azonosito
     * @return View onkentes/muszakigazolas
     */
    public function OnkentesVezetoiOldalMunkafelvetel(Request $request,int $teruletID,int $csoportID,int $valasztottNap = null)
    {
        $user = auth()->user();
        $model = new MuszakFelvetelIndexViewModel($user['id']);
        $model->profilpic = DB_OMR_Operations::GetProfilkep($user['id']);
        $model->teruletID = $teruletID;
        $model->csoportID = $csoportID;
        $model->esemenyID = Terulet::find($model->teruletID)->esemeny_id;
        /**
         * ha csoport id nem megfelelo, akkor hibat doba az oldal
         * mivel itt hivja meg elsokent a csoportot, nem kell kulon ellenorizni a csoport letezeset
         */
       // try{
       //     $model->breadcrumblink = FrontEndMaker::getMuszakigazolasOnekntesOldalrolBreadCrumbLinks($model->csoportID);
      //  }
       // catch(Exception $e) //ha kivetel keletkezik, akkor nem létezik a csoport, es 404es oldalra iranyitjuk a usert
        //{
       //     abort(404);
       // }

        /** Akik mar felvettek a munkat */
        $beosztottak = Munkafelvetel::where('csoport_id',$model->csoportID)->
        where('muszak_datum_id',$valasztottNap)->get('felhasznalo_id');

        $muszakFelvetelKezelo =  new MuszakFelvetel($model->csoportID);
        //$muszakFelvetelKezelo->MuszakDatumokEllenorzese();
        $model->csoport =  $muszakFelvetelKezelo->getCsoportInformaciok();
        $muszakFelvetelKezelo->MuszakDatumokEllenorzese();
        $model->munkaNapokArray = $muszakFelvetelKezelo->getMuszakDatumok();
        //dd($model->munkaNapokArray[0]->id);

       
        $nemBeosztottak = FelhasznaloFeladat::where('csoport_id',$model->csoportID)->get('felhasznalo_id');

        if(isset($valasztottNap))
        {
            $model->MuszakID = $valasztottNap;
            $model->kivalasztottNap = $muszakFelvetelKezelo->getValasztottDatum($valasztottNap);
            $BeosztasKezeloRepo = new BeosztasKezeloRepo(null,$model->esemenyID,$model->teruletID,$model->csoportID);

            $model->csoportTagok = $BeosztasKezeloRepo->GetCsoportBeosztas();

            $model->muszakIgazoltak = null;
        }
        else{
            try{
                $model->MuszakID = $model->munkaNapokArray[0]->id;
                $model->kivalasztottNap = $muszakFelvetelKezelo->getValasztottDatum($model->MuszakID);
                $BeosztasKezeloRepo = new BeosztasKezeloRepo(null,$model->esemenyID,$model->teruletID,$model->csoportID);

                $model->csoportTagok = $BeosztasKezeloRepo->GetCsoportBeosztas();
                $model->muszakIgazoltak = null;
            }
            catch(Exception $e)
            {
                $model->MuszakID = 0;
            }
           
            
        }
        $nemBeosztottak = $model->csoportTagok;
        return view('onkentes.muszakfelvetel.munkafelvetel')->with('model',$model)->
        with('nembeosztottak',$nemBeosztottak)->with('beosztottak', $beosztottak)->with('muszak_datum_id',$valasztottNap )->with('actGroupID',$csoportID);
    }

 /**AJAX POST method
  * Ez a metodus vegzi el az onnkentes orak beallitasat, valamint tarolja, hogy emberunk megjelent-e
  *a programon. A grafikus feluleten egy admin vagy egy megbizott vezeto tudja ezeket beallitani.
 * tablak: munkafelvetel, felhasznalok(onkentesOrakSzama) )
 */
    public function MunkafelvetelAdd(Request $request)
    {
        $csoportid = $request->input('csid');
        $UserId = $request->input('uid');
        $IgazoltOra = $request->input('wh');
        $muszakDatumID = $request->input('muszak');
        $igazolas = (int)$request->input('ig');

        if((int)$igazolas == 1)
        {
            $csoportIdValid = false; $userIdValid = false;
            if(is_int(intval($csoportid)))
            {
                $csoportIdValid = true;
    
            }
            if(is_int(intval($UserId)))
            {
                $userIdValid = true;
            }
    
            if($csoportIdValid && $userIdValid)
            {
                $csoport = Csoport::select(DB::raw('TIMEDIFF(befejezesIdeje,kezdesIdeje) as oraszam'),'kezdesDatuma','befejezesDatuma','terulet_id','kezdesIdeje','befejezesIdeje')->where('id','=',$csoportid)->first();
               // dd($csoport);
                $esemenyid = Terulet::where('id','=',$csoport->terulet_id)->first('esemeny_id')->esemeny_id;
                $acttime = Carbon::now();
                $actuser = auth()->user();
                $t = $csoport->kezdesDatuma.' '.$csoport->kezdesIdeje;
                $f = $csoport->befejezesDatuma.' '.$csoport->befejezesIdeje;
                $to = Carbon::parse($csoport->kezdesIdeje);
                $from = Carbon::parse($csoport->befejezesIdeje);
                $igazoltOra = $to->diffInHours($from);
                $munka = new Munkafelvetel;
                $munka->felhasznalo_id = $UserId;
                $munka->esemeny_id =  $esemenyid;
                $munka->terulet_id = $csoport->terulet_id;
                $munka->csoport_id = $csoportid;
                $munka->munkabaAllasIdeje = $acttime;  //az igazolas kelte lesz ...
                $munka->muszak_datum_id = $muszakDatumID;
                $split = explode(":",$csoport->oraszam); 
                //$igazoltOra =(int)$split[0];
                
                $munka->teljesitettOraszam = $igazoltOra;
                $munka->letrehozo = $actuser["id"];
    
                $munka->save();
    
                $split = explode(":",$csoport->oraszam); //$split[0]
                //$date = new Carbon($csoport->kezdesDatuma);
               
                    $felhasznalo = Felhasznalo::find($UserId);
                    $felhasznalo->onkentesOrakSzama = $felhasznalo->onkentesOrakSzama + $igazoltOra;
    
                    $felhasznalo->save();
                
    
                return 1;
            }
        }
        else 
        {
           
            $csoport = Csoport::select(DB::raw('TIMEDIFF(befejezesIdeje,kezdesIdeje) as oraszam'),'terulet_id')->where('id','=',$csoportid)->first();
            // dd($csoport);
             $esemenyid = Terulet::where('id','=',$csoport->terulet_id)->first('esemeny_id')->esemeny_id;
             $acttime = Carbon::now();
             $actuser = auth()->user();
             $munka = new Munkafelvetel;
             $munka->felhasznalo_id = $UserId;
             $munka->esemeny_id =  $esemenyid;
             $munka->terulet_id = $csoport->terulet_id;
             $munka->csoport_id = $csoportid;
             $munka->munkabaAllasIdeje = $acttime;  //az igazolas kelte lesz ...
             $munka->muszak_datum_id = $muszakDatumID;
             $split = explode(":",$csoport->oraszam); 
             $igazoltOra =(int)$split[0];
             
             $munka->teljesitettOraszam = 0;
             $munka->letrehozo = $actuser["id"];
 
             $munka->save();
 
            // $split = explode(":",$csoport->oraszam); //$split[0]
             //$date = new Carbon($csoport->kezdesDatuma);
            
               /*  $felhasznalo = Felhasznalo::find($UserId);
                 $felhasznalo->onkentesOrakSzama = $felhasznalo->onkentesOrakSzama + $igazoltOra;
 
                 $felhasznalo->save();*/
             
 
             return 1;
         
        
        }
       

    }

    /**AJAX POST method */
    public function MunkafelvetelRemove(Request $request)
    {
        $csoportid = $request->input('csid');
        $UserId = $request->input('uid');
        $MuszakID = $request->input('mid');
        $csoportIdValid = false; $userIdValid = false;
        if(is_int(intval($csoportid)))
        {
            $csoportIdValid = true;
        }
        if(is_int(intval($UserId)))
        {
            $userIdValid = true;
        }

        if($csoportIdValid && $userIdValid)
        {
            $munka = Munkafelvetel::where('felhasznalo_id','=',$UserId)->where('csoport_id','=',$csoportid)
            ->where('muszak_datum_id',$MuszakID)->first();
            $felhasznalo = Felhasznalo::find($munka->felhasznalo_id);
            $felhasznalo->onkentesOrakSzama = intval($felhasznalo->onkentesOrakSzama) - intval($munka->teljesitettOraszam);
            $felhasznalo->save();
            $munka->delete();
            return 1;
        }
        else return 0;
    }


}
