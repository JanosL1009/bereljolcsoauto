<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use App\Http\Controllers\DB_OMR_Operations;
use App\Http\Controllers\Riport; //DB queries
use Illuminate\Http\Request;

use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Facades\Excel;
use Maatwebsite\Excel\ExcelServiceProvider;
use Illuminate\Database\Eloquent\Collection;
use Maatwebsite\Excel\Writer;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\LaravelNovaExcel\Actions\DownloadExcel;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Events\BeforeExport;
use Maatwebsite\Excel\Events\AfterSheet;
use \Maatwebsite\Excel\Sheet;
use Illuminate\Support\Carbon;
use Illuminate\Support\Str;
use Mail;
use App\User;
use App\Http\Models\AdminRiportsViewModel;
use App\Http\Models\StatisticsModel;
use App\Akkreditacio;
use App\Http\Models\profilszerkesztesViewModel;
use DateTime;
use App\Http\Controllers\YouteubeStreamController;
use App\YtpPlayed;
use App\Support\Collection as Col;
use App\FelhasznaloFeladat;
use App\MyErrorLog;
use App\Esemeny;use App\Terulet;
/*
 * Az excel exporthoz szukseges objektum (Ha cellaegyesitest akarsz hasznalni, akkor implementalni kell a WithEvents interfacet...)
 */
class UserExport implements FromArray, WithHeadings
{
    protected $invoices;
    protected $sheet;

    /**
     *
     */
    protected $headingArray = array();

    public function __construct(array $invoices,array $myHeadings)
    {


        $this->invoices = $invoices;
        $this->headingArray = $myHeadings;
        //$sheet->mergeCells($range);
    }


/* Ha ellaegyestes kell akkor ig hasznald, nem tokeletes....
    public function registerEvents(): array
    {
        return [
            AfterSheet::class => function(AfterSheet $event) {
                // Merge Cells
                $event->sheet->getDelegate()->setMergeCells(['O1:R1']);
                // freeze the pane
               // $event->sheet->getDelegate()->freezePane('A4');
               /* / / Set the cell content centered
                $event->sheet->getDelegate()->getStyle('A1:A2')->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);
                / / Define the column width
                $widths = ['A' => 10, 'B' => 15, 'C' => 25,...];
                foreach ($widths as $k => $v) {
                    / / Set the column width
                    $event->sheet->getDelegate()->getColumnDimension($k)->setWidth($v);
                }
                / / Other style requirements (set border, background color, etc.) handle the macro given in the extension, you can also customize the macro to achieve, see the official website for details

            },
        ];
    }
*/

    public function array(): array
    {
        return $this->invoices;
    }

    public function actions(Request $request)
    {
        return [
            new DownloadExcel(),
        ];
    }

    public function headings(): array
    {
        return $this->headingArray;
    }

       /**
        * @param "Fejlec elemit egy tombben kapja meg"
        *  */
    public function SetHeadings($headingArray)
    {

    }

}


class RiportsController
{



     /*************************   EXPORT, RIPORT ************************************************************************************* */
    //HIBAS AZ ADATBAZIS KULCS KESZLET!!!! A LEKERDEZESEKET NEM LESZNEK JOK MERT EZ A RENDSZEREZES MIATT VAAAAN
    public function GetFullRiport()
    {
        $User = User::find(2353);
        //dd($User);
       // dd($User->felhasznaloinfo_data);
        

    } //getfullriport end

    /**
     * Megye is benne van
     */
        
    public $felhasznalok = array();

    public function GetFullRiportForCounty()
    {

        
        // $users = \App\User::limit(10)->get();
        $users = \App\User::all();
        //$users = Riport::GetUser();
        

    $felhasznalok = array();

    foreach($users as $user)
        {
            $felhasznalo = new ProfilSelectorForCounty(10);
            $felhasznalo->email = $user->email;
            $felhasznalo->password = $user->password;
            $felhasznalo->created_at = $user->created_at;
            $felhasznalo->updated_at = $user->updated_at;

            /** felhasznalok tabla */
            $FelhasznaloAdatok = Riport::GetFelhasznalo($user->email);


            if($FelhasznaloAdatok == null)
            {
                $felhasznalo->Vezeteknev = $user->name;
            }
            else
            {
                if(isset($FelhasznaloAdatok->id))
                {
                    $felhasznalo->felhasznalo_id =  $FelhasznaloAdatok->id;
                }


                if(isset($FelhasznaloAdatok->vezeteknev))
                {
                    $felhasznalo->Vezeteknev = $FelhasznaloAdatok->vezeteknev;

                }



                if(isset($FelhasznaloAdatok->kozepsonev))
                {
                    $felhasznalo->Kozepsonev = $FelhasznaloAdatok->kozepsonev;
                }

                if(isset($FelhasznaloAdatok->keresztnev))
                {
                    $felhasznalo->Keresztnev = $FelhasznaloAdatok->keresztnev;
                }

               if(isset($FelhasznaloAdatok->szulIdo))
               {
                    $felhasznalo->szulido = $FelhasznaloAdatok->szulIdo;
               }

               if(isset($FelhasznaloAdatok->orszag_id))
               {
                   // $felhasznalo->orszag_id = $FelhasznaloAdatok->orszag_id;
                    $felhasznalo->orszag = DB_OMR_Operations::GetOrszagNoCollect($FelhasznaloAdatok->orszag_id);

               }

               if(isset($FelhasznaloAdatok->szulhely))
               {
                    $felhasznalo->szulhely = $FelhasznaloAdatok->szulhely;
               }

               if(isset($FelhasznaloAdatok->lakcim))
               {
                    $felhasznalo->lakcim = $FelhasznaloAdatok->lakcim;
               }
               if(isset($FelhasznaloAdatok->Telefonszam))
               {
                    $felhasznalo->Telefonszam = $FelhasznaloAdatok->telefonszam;
               }

               if(isset($FelhasznaloAdatok->kor))
               {
                    $felhasznalo->EletKor = $FelhasznaloAdatok->kor;
               }

               $felhasznalo->Nem =  "";
                if(isset( $FelhasznaloAdatok->neme))
                {
                    $felhasznalo->Neme_id = $FelhasznaloAdatok->neme;
                    if($felhasznalo->Neme_id == 0)
                    {
                        $felhasznalo->Nem = "Férfi";
                    }
                    else
                    {
                        $felhasznalo->Nem = "Nő";
                    }
                }



                $felhasznalo->Telefonszam;
                if(isset($FelhasznaloAdatok->telefonszam))
                {
                     $felhasznalo->Telefonszam = $FelhasznaloAdatok->telefonszam;
                }

                if(isset($FelhasznaloAdatok->lakcim))
                {
                     $felhasznalo->lakcim = $FelhasznaloAdatok->lakcim;
                }


                unset($FelhasznaloAdatok);
            }



           // $FelhasznaloInfo = Riport::GetFelhasznaloinfo($felhasznalo->felhasznalo_id);
            if(isset($felhasznalo->felhasznalo_id))
            {
                $FelhasznaloInfo = Riport::GetFelhasznaloinfo($felhasznalo->felhasznalo_id);
            }

            if(isset($FelhasznaloInfo->tevekenyseg_id))
            {
                $felhasznalo->foteveknyseg_id = $FelhasznaloInfo->tevekenyseg_id;
                $felhasznalo->foteveknyseg = Riport::GetTevekenyseg($felhasznalo->foteveknyseg_id);
            }

            if(isset($FelhasznaloInfo->fogyatekossag))
            {
                $felhasznalo->fogyatekossag_id = $FelhasznaloInfo->fogyatekossag;
                if(  $felhasznalo->fogyatekossag_id == 0)
                {
                    $felhasznalo->fogyatekossag = "Nem";
                }
                else
                {
                    $felhasznalo->fogyatekossag = "Igen";
                    $felhasznalo->FogyLeirasa = $FelhasznaloInfo->fogyLeirasa;
                }

            }

            if(isset($FelhasznaloInfo->polomeret))
            {
                $felhasznalo->polomeret = $FelhasznaloInfo->polomeret;
            }

            $Passio = Riport::GetMagassag($felhasznalo->Telefonszam);

            if(isset($Passio->magassag))
            {
                $felhasznalo->magassag = $Passio->magassag." cm";
            }

            //Egyeb szervezet tablaba stimmel az id
            $egyeb = Riport::GetEgyebSzervezet($felhasznalo->felhasznalo_id);
            if($egyeb  != "Nem")
            {

                $felhasznalo->MasSzervezetNeve = $egyeb;
            }
            else{
                $felhasznalo->MasSzervezetNeve = "Nem";
            }

            $civil = Riport::GetCivilSzervezet($felhasznalo->felhasznalo_id);
            if($civil  != "Nem")
            {

                $felhasznalo->CivilSzervezetNeve = $civil;
            }
            else{
                $felhasznalo->CivilSzervezetNeve = "Nem";
            }

            $felhasznalo->countyID = DB_OMR_Operations::GetTartLakcim_MegyeIDForUser($felhasznalo->felhasznalo_id);
            if($felhasznalo->countyID > 0)
            {
                $felhasznalo->county = DB_OMR_Operations::GetSelectmegyek_id($felhasznalo->countyID);

            }

            /**  */


            array_push($felhasznalok,$felhasznalo);
        }


        $Array = array();
        //dd($felhasznalok );
      foreach ($felhasznalok as $line) {
       $megye = "";
        if(isset($line->county))
        {
            $ar = $line->county[0];
            $megye = $ar->megye_neve;
        }
        $t = array("Nev" => $line->GetTeljesNev(),"Neme" => $line->Nem, "Telefon" => $line->Telefonszam, "Email" => $line->email
        ,"szulido" => $line->szulido,"szulhely" => $line->szulhely,"eletkor" => $line->EletKor,
        "lakcim" => $line->lakcim,"Megye" =>  $megye,"foteveknyseg" => $line->foteveknyseg,
        "fogyatekossag" => $line->fogyatekossag, "FogyLeirasa" => $line->FogyLeirasa,"polomeret" => $line->polomeret,
        "szakallnovesztes" => $line->szakallnovesztes,"MasSzervezetNeve" => $line->MasSzervezetNeve,
        "CivilSzervezetNeve" => $line->CivilSzervezetNeve, "Magassag" => $line->magassag,"Register" => $line->created_at
        );
        array_push($Array,$t);

      }

      $Fajlneve = request()->fn."_export.xlsx";
      $hedingArray = [['Név','Neme','Telefon','Email','szulido','Szül. hely','Életkor',"Lakcím","Megye","Fotevekenyseg","fogyatekossag",
                    "FogyLeirasa","polomeret","szakallnovesztes","Más szervezet neve","Civil Szervezet neve","Magassag","Regisztráció ideje"
                       ]];
    

      Excel::store(new UserExport( $Array, $hedingArray ), $Fajlneve);

      \DB::table('created_riportok')->insert(["user_id" => \Auth::user()->id, "url" =>  $Fajlneve, "created_at" => date('Y-m-d H:i:s')]);
      $email = \Auth::user()->email;
/*
        if(( (env('FUTTATOKORNYEZET') == 'ELES') or (env('FUTTATOKORNYEZET') == 'TESZT' and (strpos($email, '@csbo.hu') !== false) ) ) ) {
                Mail::send("sikeres_riport",["email" => $email],
                    function($message) use ($email, $Fajlneve) {
                        $path = storage_path('app/'.$Fajlneve);
                        $message->to($email)
                                ->subject('Riport')
                                ->from(env('MAIL_FROM_NAME'));

                    }
                );
            } */

        return 1;


    }


    public function riportok(string $viewer){
        $user = auth()->user();
        $UserID = $user["id"];
        $model = new AdminRiportsViewModel($UserID);
        $model->profilpic = DB_OMR_Operations::GetProfilkep($user['id']);
        $model->setViewerURL($viewer);

       if($viewer == 'felhasznalok')
       {
            return view('adminisztratorok.riportok.felhasznalok')->with('model',$model);
       }



        return view('riportok')->with('model',$model);
    }

    public function felhasznaloiRiportok()
    {

    }

    public function getAllUsers() : int
    {
        return StatisticsModel::getAllUsers();
    }

    public function getDailyNewUsersCount(): int
    {
        return StatisticsModel::getDailyNewUsersCount();
    }

    public function getImportedValidUsersCount(): int
    {
        return StatisticsModel::getImportedValidUsersCount();
    }

    public function getImportedUpdatedUsersCount()
    {
        return StatisticsModel::getImportedUpdatedUsersCount();
    }

    public function getDailyLogins() : int
    {
        return StatisticsModel::getDailyLogins();
    }

    public function getAllVoluntary() : int 
    {
        return StatisticsModel::getAllVoluntary();
    } 

    public function getAllNewRegisteredUser() : int
    {
       
        return StatisticsModel::getAllNewRegisteredUser();
    }

    public function getExportAllNewRegisteredUser(Request $request)
    {
        $startDate = new DateTime('2021-04-20 00:00:00'); $endDate = Carbon::now();
        $Array = array();
        $users = StatisticsModel::getNewRegisters($startDate,$endDate );
        foreach($users as $user)
        {
           $t = array("ID" => $user->id,"Email" => $user->email, "Nev" => $user->name,"Regisztracio" => $user->created_at);
           array_push($Array,$t); 
        }

        $Fajlneve = "newregisteredusers_export.xlsx";
        $hedingArray = [['ID','Email','Név', 'Regisztráció ideje']];

        return Excel::download(new UserExport( $Array, $hedingArray ), $Fajlneve);

    }

    /**
     * Azonositot es emailt tartalmaz. Az Onkentesek es Adminok egyarant benne vannak.
     */
    public function downloadAllActiveUsers()
    {
        $users = DB::table('activeusers')->get();
        $Array = array();
        
        foreach($users as $user)
        {
            
           $t = array("ID" => $user->id,"Email" => $user->email );
           array_push($Array,$t); 
        }
  
        $Fajlneve = "activeusers_export.xlsx";
        $hedingArray = [['ID','Email']];
        //dd($Array);
        return Excel::download(new UserExport( $Array, $hedingArray ), $Fajlneve);
    }

    public function downloadSzemelyesAdatokNezet()
    {
        $users = DB::table('szemlyesadatoknezet')->get();
        $Array = array();
        
        foreach($users as $user)
        {
            
           $t = array("Név" => $user->name,"Email" => $user->email,"Telefonszam" => $user->telefonszam,
            "Nem" => $user->Neme, 
            "Kora" => $user->kor,
            "Anyja Neve" => $user->anyjaneve,
            "Szem. az.sz." => $user->szemigszam,
            "Állampolgárság" =>$user->allampolgarsag

        );
           array_push($Array,$t); 
        }
  
        $Fajlneve = "usersgeneraldatas_export.xlsx";
        $hedingArray = [['Név','Email','Telefonszám','Neme','Kor','Anyja neve','Szem.ig.azonositó','Állampolgárság']];
        //dd($Array);
        return Excel::download(new UserExport( $Array, $hedingArray ), $Fajlneve);
    }

    /**VIssza adja, hogy rendezvenyekkent mennyien jelentkeztek */
    public function riportRendezvenySzerint()
    {
        $esemenyek = Esemeny::where('id','!=',18)->where('id','!=',55)->get(); 
        
        $result = array();
        

        foreach($esemenyek as $esemeny)
        {
            $count = 0;
            $userscount = FelhasznaloFeladat::where('esemeny_id',$esemeny->id)->groupby('felhasznalo_id')->paginate();
            //dd($userscount->total());

            
            $subResult['esemenyNev'] = $esemeny->nev;
            $subResult['tervezettLetszam'] = $this->RendezvenyOsszTervezettLetszam($esemeny->id);
            $subResult['jeletkezokSzama'] = $userscount->total(); 
            array_push($result,$subResult);
        }

        $Array = array();
        
        foreach($result as $data)
        {
            
           $t = array("Rendezvény" => $data['esemenyNev'], "TervezettLetszam" => $data["tervezettLetszam"],
           "JeletkezőkSzáma" => $data['jeletkezokSzama']
        );
           array_push($Array,$t); 
        }

        $dt = Carbon::now(); $date = $dt->toDateString();
        
        $Fajlneve = "rendezvenyjelentkezokszama_".$date.".xlsx";
        $hedingArray = [['Rendezvény','Tervezett létszám','JeletkezőkSzáma']];
        //dd($Array);
        return Excel::download(new UserExport( $Array, $hedingArray ), $Fajlneve);

    }

    protected function RendezvenyOsszTervezettLetszam(int $EsemenyID)
    {
        $teruletek = Terulet::where('esemeny_id',$EsemenyID)->get();
        $sum = 0;
        foreach($teruletek as $terulet)
        {
            $sum = $sum + $terulet->tervezettLetszam;
        }
        unset($teruletek);

        return $sum;
    }

     /**VIssza adja, hogy rendezvenyekkent mennyien jelentkeztek */
     public function riportTeruletSzerint()
     {
         $teruletek = Terulet::all();
         $result = array();
         
 
         foreach($teruletek as $terulet)
         {
             $count = 0;
             $userscount = FelhasznaloFeladat::where('terulet_id',$terulet->id)->groupby('felhasznalo_id')->paginate();
             //dd($userscount->total());
             if(isset($terulet->Esemeny->nev))
             {
                 if($terulet->Esemeny->id != 18 && $terulet->Esemeny->id != 55)
                 {
                    $subResult['teruletid'] = $terulet->id??'';
                    $subResult['teruletNev'] = $terulet->nev??'';
                    $subResult['esemenyNev'] = $terulet->Esemeny->nev??'';
                    $subResult['tervezettLetszam'] = $terulet->tervezettLetszam;
                    $subResult['jeletkezokSzama'] = $userscount->total(); 
                    array_push($result,$subResult);
                 }
               
             }
            
             
         }
 
         $Array = array();
         
         foreach($result as $data)
         {
             
            $t = array(
                "TerületID"=> $data['teruletid'],
                "Terület" => $data['teruletNev'],
                "Rendezvény" => $data['esemenyNev'],
                "TervezettLétszám" => $data['tervezettLetszam'],
            "JeletkezőkSzáma" => $data['jeletkezokSzama']
         );
            array_push($Array,$t); 
         }
 
         $Fajlneve = "teruletjelentkezokszama_riport.xlsx";
         $hedingArray = [['TerületID','Terület','Rendezvény','TervezettLétszám','JeletkezőkSzáma']];
         //dd($Array);
         return Excel::download(new UserExport( $Array, $hedingArray ), $Fajlneve);
 
     }

     public function getTeruletBeosztottak(int $TeruletID)
     {
        $result = DB::table('terulet_beosztas')->join('users','terulet_beosztas.felhasznalo_id','=','users.id')->
        join('felhasznalok','felhasznalok.id','=','users.id')->where('terulet_beosztas.terulet_id',$TeruletID)->groupBy('terulet_beosztas.felhasznalo_id')->get([
            'users.id','users.name', 'users.email','felhasznalok.telefonszam as telefonszam'
        ]);


        $Array = array();
         
        foreach($result as $data)
        {
            
           $t = array(
               "ID"=> $data->id,
               "name" => $data->name,
               "email" => $data->email,
               "telefonszam" => $data->telefonszam
        );
           array_push($Array,$t); 
        }

        $Fajlneve = "teruletbeosztottak_riport.xlsx";
        $hedingArray = [['ID','Név','Email','Telefonszam']];
        //dd($Array);
        return Excel::download(new UserExport( $Array, $hedingArray ), $Fajlneve);
     }

     public function nemjelentkeztekrendezvenyre()
     {
         $result = DB::table('nem_jelentkeztek_rendezvenyre')->get();

         $Array = array();
         
         foreach($result as $user)
         {
             
            $t = array(
                "Név"=> $user->name,
                "Email" => $user->email,
                "Telefonszám" => $user->telefonszam
         );
            array_push($Array,$t); 
         }
 
         $Fajlneve = "nem_jelentkeztek_rendezvenyre_riport.xlsx";
         $hedingArray = [['Név','Email','Telefonszám']];
         //dd($Array);
         return Excel::download(new UserExport( $Array, $hedingArray ), $Fajlneve);

     }

     public function jelentkezettszallastigenylok()
     {
         $result = DB::table('szallastigenylok_aktivak')->where('TeruletJelentkezes','<>','Nem')->get();

         $Array = array();
         
         foreach($result as $user)
         {
             
            $t = array(
                'ID' => $user->id,
                "Név"=> $user->name,
                "Email" => $user->email,
                "Telefonszám" => $user->telefonszam,
                "Kor"=> $user->kor,
                "Neme"=> $user->Neme,
                "Telepules"=> $user->TelepulesID,
                "Megye"=> $user->megye_neve,
                "Szervezet neve"=> $user->szervezet_neve

         );
            array_push($Array,$t); 
         }
 
         $Fajlneve = "jelentkeztek_szallastkertek_riport.xlsx";
         $hedingArray = [['ID','Név','Email','Telefonszám','Kor','Neme','Telepules','Megye','Szervezet neve']];
         //dd($Array);
         return Excel::download(new UserExport( $Array, $hedingArray ), $Fajlneve);

     }

     public function nem_kitoltott_cserkesz_profilok()
     {
         $cserkeszek = DB::table('nem_kitoltott_profil_cserkeszek')->get();

         $Array = array();
         
         foreach($cserkeszek as $cserkesz)
         {
             
            $t = array(
                "ID" => $cserkesz->id,
                "Név"=> $cserkesz->name,
                "Email" => $cserkesz->email,
                "Telefonszám" => $cserkesz->telefonszam
         );
            array_push($Array,$t); 
         }
         $dt = Carbon::now(); $date = $dt->toDateString();
         $Fajlneve = "nem_kitoltott_profil_cserkeszek_".$dt.".xlsx";
         $hedingArray = [['ID','Név','Email','Telefonszám']];

         return Excel::download(new UserExport( $Array, $hedingArray ), $Fajlneve);
     }

     public function kitoltott_cserkesz_profilok()
     {
         $cserkeszek = DB::table('kitoltott_cserkesz_profilok')->get();

         $Array = array();
         
         foreach($cserkeszek as $cserkesz)
         {
             
            $t = array(
                "ID" => $cserkesz->id,
                "Név"=> $cserkesz->name,
                "Email" => $cserkesz->email,
                "Telefonszám" => $cserkesz->telefonszam
         );
            array_push($Array,$t); 
         }
         $dt = Carbon::now(); $date = $dt->toDateString();
         $Fajlneve = "kitoltott_profil_cserkeszek_".$dt.".xlsx";
         $hedingArray = [['ID','Név','Email','Telefonszám']];

         return Excel::download(new UserExport( $Array, $hedingArray ), $Fajlneve);
     }

     public function cserkesz_vagyok()
     {
         $cserkeszek = DB::table('cserkesz_vagyok')->get();

         $Array = array();
         
         foreach($cserkeszek as $cserkesz)
         {
             $importalt = "Nem";
             if($cserkesz->id > 6679 && $cserkesz->id < 6980)
             {
                $importalt = "Igen, cserkészek.";
             }
             if($cserkesz->id > 3029 && $cserkesz->id < 5018)
             {
                $importalt = "Igen, előregisztráció.";
             }
            $t = array(
                "ID" => $cserkesz->id,
                "Név"=> $cserkesz->name,
                "Importalt" => $importalt,
                "Email" => $cserkesz->email,
                "Telefonszám" => $cserkesz->telefonszam,
                "Szervezet" =>$cserkesz->szervezet_neve
         );
            array_push($Array,$t); 
         }
         $dt = Carbon::now(); $date = $dt->toDateString();
         $Fajlneve = "cserkesz_vagyok_".$dt.".xlsx";
         $hedingArray = [['ID','Név','Importalt','Email','Telefonszám','Szervezet']];

         return Excel::download(new UserExport( $Array, $hedingArray ), $Fajlneve);
     }

     /**
      * A jelentkező rendezvényeit adja vissza
      */
     public function jelentkezokEsemenykreBontva()
     {
        $egyediJelentkezok = DB::table('jelentkezok_egyedibontasban')->get();

        $Array = array();
        
        foreach($egyediJelentkezok as $user)
        {
           $jelentkezesek = DB::table('jelentkezokesemenyenkent')->where('id',$user->felhasznalo_id)->groupBy('nev')->get();
            $count = count($jelentkezesek);
            $excelRow = null;
            $esemenyek = null;
            $nev = null; $email = null; $kor = null;
           foreach($jelentkezesek as $jelentkezes)
           {
               $nev = $jelentkezes->name;
               $email = $jelentkezes->email;
               $kor = $jelentkezes->kor;
               if(isset($esemenyek ))
               {
                $esemenyek = $esemenyek.', '.$jelentkezes->nev;
               }
               else
               {
                $esemenyek = $jelentkezes->nev;
               }
                
           }
           

           $t = array(
               "ID" => $user->felhasznalo_id,
               "Név"=> $nev??'Törölt felhasználó',
               "Kor" =>$kor??'',
               "Email" => $email,
               "JelentkezesSzam" => $count,
               "Események" => $esemenyek 
        );


           array_push($Array,$t); 
        }
        $dt = Carbon::now(); $date = $dt->toDateString();
        $Fajlneve = "jelentkezok_rendezvenyei".$dt.".xlsx";
        $hedingArray = [['ID','Név','Kor','Email','Ennyi rendezvényre jelentkezett','Rendezvények']];

        return Excel::download(new UserExport( $Array, $hedingArray ), $Fajlneve);
     }

     public function TeruletiBeosztasokRiport()
     {
        $users = DB::table('teruleti_beosztasok')->get();

        $Array = array();
        
        foreach($users as $user)
        {
           
           $t = array(
               "ID" => $user->userid,
               "Név"=> $user->name,
               "Esemeny" => $user->esemenynev,
               "Terulet" => $user->teruletnev,
               "Email" => $user->email
              
        );
           array_push($Array,$t); 
        }
        $dt = Carbon::now(); $date = $dt->toDateString();
        $Fajlneve = "teruletbesosztasok_".$dt.".xlsx";
        $hedingArray = [['ID','Név','Esemeny','Terulet','Email']];

        return Excel::download(new UserExport( $Array, $hedingArray ), $Fajlneve);
     }

     public function TeruletiBeosztasokIgazolassalRiport()
     {
        $users = DB::table('teruleti_beosztasok')->get();

        $Array = array();
        
        foreach($users as $user)
        {
           
           $t = array(
               "ID" => $user->userid,
               "Név"=> $user->name,
               "Esemeny" => $user->esemenynev,
               "Terulet" => $user->teruletnev,
               "Email" => $user->email
              
        );
           array_push($Array,$t); 
        }
        $dt = Carbon::now(); $date = $dt->toDateString();
        $Fajlneve = "teruletbesosztasok_".$dt.".xlsx";
        $hedingArray = [['ID','Név','Esemeny','Terulet','Email']];

        return Excel::download(new UserExport( $Array, $hedingArray ), $Fajlneve);
     }

     public function BoesztottakUserenkentRiport()
     {
        $users = DB::table('beosztasok_userenkent')->join('felhasznalok','beosztasok_userenkent.id','=','felhasznalok.id')->
        get();

        $Array = array();
        
        foreach($users as $user)
        {
           
           $t = array(
               "ID" => $user->id,
               "Név"=> $user->name,
               "Esemeny" => $user->esemenyneve,
               "Terulet" => $user->teruletneve,
               "Kor" => $user->kor,
               'Neme' =>$user->neme,
               'OnkentesOrakSzama' => $user->onkentesOrakSzama
              
        );
           array_push($Array,$t); 
        }
        $dt = Carbon::now(); $date = $dt->toDateString();
        $Fajlneve = "teruletbeosztasok_uj_".$dt.".xlsx";
        $hedingArray = [['ID','Név','Esemeny','Terulet','Kor','Neme','OnkentesOrakSzama']];

        return Excel::download(new UserExport( $Array, $hedingArray ), $Fajlneve);
     }

     public function CsoportBeosztottakRiport()
     {
        $users = DB::table('csoportbeosztottak')->get();

        $Array = array();
        
        foreach($users as $user)
        {
           
           $t = array(
               "ID" => $user->id,
               "Név"=> $user->name,
               "Esemeny" => $user->esemenynev,
               "Terulet" => $user->teruletneve,
               "Csoport" => $user->nev,
               'Kor' => $user->kor,
               'Neme' => $user->neme,
               'OnkentesOrak' => $user->onkentesOrakSzama
              
        );
           array_push($Array,$t); 
        }
        $dt = Carbon::now(); $date = $dt->toDateString();
        $Fajlneve = "csoportbeosztottak_".$dt.".xlsx";
        $hedingArray = [['ID','Név','Esemeny','Terulet','Csoport','Kor','Neme','OnkentesOrak']];

        return Excel::download(new UserExport( $Array, $hedingArray ), $Fajlneve);
     }

     public function CsoportBeosztottakRiport1()
     {
        $users = DB::table('igazoltak_stathoz1')->leftJoin('beosztottak_felhasznaloinfo', 'igazoltak_stathoz1.id','=','beosztottak_felhasznaloinfo.id')->get();

        $Array = array();
        
        foreach($users as $user)
        {
           
            if($user->tevekenyseg_id == 1)
            {
                $fosuli = DB::table('fosuli')->where('felhasznalo_id', $user->id)->first();
            }

            if($user->tevekenyseg_id == 2)
            {
                $kozepiskola = DB::table('iskola')->where('felhasznalo_id', $user->id)->first();
            }

            if($user->tevekenyseg_id == 3)
            {
                $altalanosiskola = DB::table('iskola')->where('felhasznalo_id', $user->id)->first();
            }

            if($user->egyhazmegyeneve == 'Egyéb' || $user->egyhazmegyeneve == 'Határon túli egyházmegye')
            {
                $felegyeb = $user->masfelkezettagja;
            }

            $civilszervezet = DB::table('civil_szervezet')->where('felhasznalo_id', $user->id)->first()->szervezet_neve??'Nem';
           

           $t = array(
               "ID" => $user->id,
               "Név"=> $user->name,
               "Email" => $user->email,
               "Telefonszám" => $user->telefonszam,
               'Kor' => $user->kor,
               'Neme' => $user->neme,
               'OnkentesOrak' => $user->onkentesOrakSzama,
               'Tevekenyseg' => $user->tevekenyseg,
               'AltalanosIskola' =>  $altalanosiskola->intezmenyneve??'',
               'Kozepsuli' =>  $kozepiskola->intezmenyneve??'',
               'Fosuli' =>  $fosuli->intezmeny_neve??'',
                'Felekezet' => $user->felekezet??'',
                'Egyhazmegye' => $user->egyhazmegyeneve??'',
                'Egyebfelekezet' => $felegyeb??'',
                'IgazolasIgeny' => $user->igazolasIgeny??'Nincs kitöltve',
                'CivilSzervezet' => $civilszervezet
              
        );
        unset($felegyeb );unset($fosuli );unset($kozepiskola );unset($altalanosiskola );unset($civilszervezet );
           array_push($Array,$t); 
        }
        $dt = Carbon::now(); $date = $dt->toDateString();
        $Fajlneve = "csoportbeosztottak_stat21_".$dt.".xlsx";
        $hedingArray = [['ID','Név','Email','Telefonszám','Kor','Neme','OnkentesOrak',
            'Tevékenység',
            'Általános iskola',
            'Közép iskola',
            'Főiskola',
            'Felekezet', 'Egyházmegye' , 'Egyébfelekezet','Igazolás igény','Civil szervezet tagja'
        ]];

        return Excel::download(new UserExport( $Array, $hedingArray ), $Fajlneve);
     }

    



     public function AkkreditacioRiport()
     {
        $users = DB::table('akkred_osszevont')->where('status',1)->get();

        $Array = array();
        
        foreach($users as $user)
        {
           
           $t = array(
               "ID" => $user->ID,
               "Név"=> $user->nev.' '.$user->knev,
               "qr" => $user->qr,
               "qrlink" => $user->qrlink,
               "status" => $user->status,
               'atvette'=> $user->atvette,
               'card_number'=> $user->card_number,
               'photo'=> $user->photo,
              
        );
           array_push($Array,$t); 
        }
        $dt = Carbon::now(); $date = $dt->toDateString();
        $Fajlneve = "akkreditacio_".$dt.".xlsx";
        $hedingArray = [['ID','Név','QR','QRLink','Status','Atvette','Kártyaszám','Kép']];

        return Excel::download(new UserExport( $Array, $hedingArray ), $Fajlneve);
     }

     public function BeosztottakInfo()
     {
        $users = DB::table('beosztottak_felhasznaloinfo')->get();

        $Array = array();
        
        foreach($users as $user)
        {
           
           $t = array(
               "ID" => $user->id,
               "vezeteknev"=> $user->vezeteknev,
               "keresztnev" => $user->keresztnev,
               "kor" => $user->kor,
               "neme" => $user->neme,
               "onkentesOrakSzama" => $user->onkentesOrakSzama,
               "fogyatekossag" => $user->fogyatekossag,
               "polomeret" => $user->polomeret,
               "polotipus" => $user->polotipus,
               "szallastIgenyelt" => $user->szallastIgenyelt,
               "etkezesiigeny" => $user->etkezesiigeny,
               "igazolasIgeny" => $user->igazolasIgeny,
               "egyebIgazolasLeirasa" => $user->egyebIgazolasLeirasa
              
        );
           array_push($Array,$t); 
        }
        $dt = Carbon::now(); $date = $dt->toDateString();
        $Fajlneve = "beosztottak_info_".$dt.".xlsx";
        $hedingArray = [['ID','Vezetéknév','Keresztnév',
                            'Kor',
                            'Neme',
                            'onkentesOrakSzama',
                            'fogyatekossag',
                            'polomeret',
                            'polotipus',
                            'szallastIgenyelt',
                            'etkezesiigeny',
                            'igazolasIgeny',
                            'egyebIgazolasLeirasa'
                            ]
                        ];

        return Excel::download(new UserExport( $Array, $hedingArray ), $Fajlneve);
     }

     public function jelentkezok_nyelviszintjei()
     {
        $jelentkezesek = DB::table('jelentkezok_nyelviszintje')->get();
        $Array = array();
         
        foreach($jelentkezesek as $user)
        {
            $szint = null;
            if($user->nyelvszint_id == 1)
            {
                $szint = "Alapfokú";
            }
            if($user->nyelvszint_id == 2)
            {
                $szint = "Középfokú";
            }
            if($user->nyelvszint_id == 3)
            {
                $szint = "Felsőfokú";
            }
           $t = array(
               "ID" => $user->felhasznalo_id,
               "Név"=> $user->name,
               "Kor" => $user->kor,
               "Email" => $user->email,
               "Nyelv" =>$user->nyelv,
                "Szint" => $szint
                );
           array_push($Array,$t); 
        }

        $dt = Carbon::now(); $date = $dt->toDateString();
        $Fajlneve = "jelentkezok_nyelv".$dt.".xlsx";
        $hedingArray = [['ID','Név','Kor','Email','Nyelv',"Szint"]];

        return Excel::download(new UserExport( $Array, $hedingArray ), $Fajlneve);
     }

     public function jelentkezok_telszamok()
     {
        $jelentkezesek = DB::table('tel_round1_all_jelentkezo')->get();
        $Array = array();
         
        foreach($jelentkezesek as $user)
        {
            $telszam  = null;
          try{
              $telszam =  $this->telNumberFormatter_1((string)$user->formazott);
          }
          catch(Exception $e)
          {
                $log = new MyErrorLog();
                $log->controller = 'RiportsController';
                $log->methodname = 'jelentkezok_telszamok';
                $log->exceptionMsg = $e;
                $log->allAvilableData = $user;
                $log->save();
                $telszam ='000000';
          }

           $t = array(
              
               "Vezeteknev"=> $user->vezeteknev,
               "Keresztnev" => $user->kozepsonev,
               "Email" => $user->email,
               "Kor" =>$user->kor,
               "Telszam" =>$telszam
                );
           array_push($Array,$t); 
        }

        $dt = Carbon::now(); $date = $dt->toDateString();
        $Fajlneve = "jelentkezok_nyelv".$dt.".xlsx";
        $hedingArray = [['Vezetéknév','Keresztnév','Email','Kor',"Telefonszám"]];

        return Excel::download(new UserExport( $Array, $hedingArray ), $Fajlneve);
     }

     public function fogyatekossagletoltese()
     {
        $users = DB::table('fogyatekossag_riport')->get();
        $Array = array();
         
        foreach($users as $user)
        {
          
           $t = array(
              
               "Nev"=> $user->name,
               "Email" => $user->email,
               "Kor" =>$user->kor,
               "Telszam" => $this->telNumberFormatter_1($user->telefonszam),
               "FogyLeírása" =>$user->fogyLeirasa
                );
           array_push($Array,$t); 
        }

        $dt = Carbon::now(); $date = $dt->toDateString();
        $Fajlneve = "fogyatekossag_leirasa".$dt.".xlsx";
        $hedingArray = [['Név','Email','Kor',"Telefonszám","FogyLeírása"]];

        return Excel::download(new UserExport( $Array, $hedingArray ), $Fajlneve);
     }

    public function invalidPorfilePicturesUsers()
    {
        
    }

    public function downloadNotEdubaseAcc()
    {
        $users = DB::table('notedubaselogin')->get();
        $Array = array();
        
        foreach($users as $user)
        {
            
           $t = array("Email" => $user->email);
           array_push($Array,$t); 
        }
        
        $Fajlneve = "edubasenotaccount_export.xlsx";
        $hedingArray = [['Email']];
        //dd($Array);
        return Excel::download(new UserExport( $Array, $hedingArray ), $Fajlneve);
    }

    public function downloadEdubaseAcc()
    {
        $users = DB::table('edubaselogins')->get();
        $Array = array();
        
        foreach($users as $user)
        {
            
           $t = array("Email" => $user->email);
           array_push($Array,$t); 
        }
        
        $Fajlneve = "edubaseaccount_export.xlsx";
        $hedingArray = [['Email']];
        //dd($Array);
        return Excel::download(new UserExport( $Array, $hedingArray ), $Fajlneve);
    }


    public function downloadRendezvenyJelentkezokLetoltese(Request $request, int $EventID)
    {

        $users = DB::table('felhasznalo_feladat')->join('users','felhasznalo_feladat.felhasznalo_id','=','users.id')->
        join('felhasznalok','felhasznalo_feladat.felhasznalo_id','=','felhasznalok.id')->
        where('felhasznalo_feladat.esemeny_id','=',$EventID)->
        groupBy('felhasznalo_feladat.felhasznalo_id')
        ->get();
        $Array = array();
        
        foreach($users as $user)
        {
            
           $t = array("ID" => $user->id,"Nev" => $user->name, "Email" => $user->email,"Telefonszam" => $user->telefonszam,
           "Kor" => $user->kor);
           array_push($Array,$t); 
        }
        
        $Fajlneve = "rendezveny_egyedi_export.xlsx";
        $hedingArray = [['ID','Nev','Email','Telefonszam','Kor']];
        //dd($Array);
        return Excel::download(new UserExport( $Array, $hedingArray ), $Fajlneve);
    }

   
    public function downloadTeruletJelentkezokLetoltese(Request $request, int $AreaID)
    {

        $users = DB::table('felhasznalo_feladat')->join('users','felhasznalo_feladat.felhasznalo_id','=','users.id')->
        join('felhasznalok','felhasznalo_feladat.felhasznalo_id','=','felhasznalok.id')->
        where('felhasznalo_feladat.terulet_id','=',$AreaID)->
        groupBy('felhasznalo_feladat.felhasznalo_id')
        ->get();
        $Array = array();
        
        foreach($users as $user)
        {
            
           $t = array("ID" => $user->id,"Nev" => $user->name, "Email" => $user->email,"Telefonszam" => $user->telefonszam,
           "Kor" => $user->kor);
           array_push($Array,$t); 
        }
        
        $Fajlneve = "terulet_egyedi_export.xlsx";
        $hedingArray = [['ID','Nev','Email','Telefonszam','Kor']];
        //dd($Array);
        return Excel::download(new UserExport( $Array, $hedingArray ), $Fajlneve);
    }

    /***
     * *csoportbeosztottak
     */
    public function downloadCsoportJelentkezokLetoltese(Request $request, int $GroupID)
    {

        $users = DB::table('felhasznalo_feladat')->join('users','felhasznalo_feladat.felhasznalo_id','=','users.id')->
        join('felhasznalok','felhasznalo_feladat.felhasznalo_id','=','felhasznalok.id')->
        where('felhasznalo_feladat.csoport_id','=',$GroupID)->
        groupBy('felhasznalo_feladat.felhasznalo_id')
        ->get();
        $Array = array();
        
        foreach($users as $user)
        {
            
           $t = array("ID" => $user->id,"Nev" => $user->name, "Email" => $user->email,"Telefonszam" => $user->telefonszam,
           "Kor" => $user->kor);
           array_push($Array,$t); 
        }
        
        $Fajlneve = "csoprt_egyedi_export.xlsx";
        $hedingArray = [['ID','Nev','Email','Telefonszam','Kor']];
        //dd($Array);
        return Excel::download(new UserExport( $Array, $hedingArray ), $Fajlneve);
    }

    public function downloadTeruletBeosztottakLetoltese(Request $request, int $AreaID)
    {
        $users = DB::table('terulet_beosztas')->join('users','terulet_beosztas.felhasznalo_id','=','users.id')->
        join('felhasznalok','terulet_beosztas.felhasznalo_id','=','felhasznalok.id')->
        where('terulet_beosztas.terulet_id','=',$AreaID)->
        groupBy('terulet_beosztas.felhasznalo_id')
        ->get();
        $Array = array();
        
        foreach($users as $user)
        {
            
           $t = array("ID" => $user->id,"Nev" => $user->name, "Email" => $user->email,"Telefonszam" => $user->telefonszam,
           "Kor" => $user->kor);
           array_push($Array,$t); 
        }
        
        $Fajlneve = "terulet_beosztottak_export.xlsx";
        $hedingArray = [['ID','Nev','Email','Telefonszam','Kor']];
        //dd($Array);
        return Excel::download(new UserExport( $Array, $hedingArray ), $Fajlneve);
    }

    public function TeruletreNemBeosztottak()
    {
        $users = DB::table('nincsenek_beosztva_teruletre')->join('users','nincsenek_beosztva_teruletre.felhasznalo_id','=','users.id')->
        get();
        $Array = array();
        
        foreach($users as $user)
        {
            
           $t = array("ID" => $user->id,"Nev" => $user->name, "Email" => $user->email);
           array_push($Array,$t); 
        }
        
        $Fajlneve = "terulet_nem_beosztottak_export.xlsx";
        $hedingArray = [['ID','Nev','Email']];
        //dd($Array);
        return Excel::download(new UserExport( $Array, $hedingArray ), $Fajlneve);
    }

    public function downloadFormaRuhatAtvettek()
    {
        $users = DB::table('formaruhat_etvettek')->get();
        $Array = array();
        
        foreach($users as $user)
        {
           $t = array("ID" => $user->id ,"Név" => $user->name ,"Email" => $user->email);
           array_push($Array,$t); 
        }
        
        $Fajlneve = "formaruhatatvettek_export.xlsx";
        $hedingArray = [["ID","Név",'Email']];
        //dd($Array);
        return Excel::download(new UserExport( $Array, $hedingArray ), $Fajlneve);
    }

    public function downloadAjandekotAtvettek()
    {
        $users = DB::table('beosztottak_ajandakokatatvettek')->get();
        $Array = array();
        
        foreach($users as $user)
        {
           $t = array("ID" => $user->id ,
           "Név" => $user->vezeteknev.' '.$user->keresztnev,
           "Email" => $user->email,
           "onkentesOrakSzama" => $user->onkentesOrakSzama,
           'atadasIdeje' => $user->atadasIdeje,

        );
           array_push($Array,$t); 
        }
        
        $Fajlneve = "ajandekotatvettek_export.xlsx";
        $hedingArray = [["ID","Név",'Email','Önkéntes órák száma','átadás ideje']];
        //dd($Array);
        return Excel::download(new UserExport( $Array, $hedingArray ), $Fajlneve);
    }

    

    /**
     * SELECT count(felhasznalok.id) FROM `felhasznalok` inner join importhoz on felhasznalok.id = importhoz.felhasznalo_id where felhasznalok.updated_at > '2021-04-20 00:00:00'
     */

    public function download_riport(){

        return response()->download(storage_path( 'app/'.request()->fn) );
    }

    protected function ytpStatRiportDownload()
    {
        $ytp = new YouteubeStreamController();

        $ytpplayed = YtpPlayed::where('startTime','<','2021-05-29 17:15:00')->groupBy('felhasznalo_id')
        ->skip(600)->take(1000)->get();
        //$allviewer = count($ytpplayed);
        //dd( $ytpplayed);
        $ytpplayedList = array();
       // dd($ytpplayed[0]->felhasznalok_data);
       foreach( $ytpplayed as $user)
       {
            $stat =  $ytp->getUserStat($user->felhasznalo_id);
            array_push($ytpplayedList,$stat);
       }
    
        $userStatList = new Col($ytpplayedList);

       //dd($userStatList);

      return $userStatList;
    }

    public function downloadYtpStat()
    {
        $userStatList = $this->ytpStatRiportDownload();
        //dd($userStatList);
        $Array = array();
        $users =$userStatList;
        foreach($users as $user)
        {
            
           $t = array("ID" => $user['id'],"Email" => $user['email'], "Nev" => $user['name'],"Kor" => $user['age'],
                "Neme" => $user['Neme']
                
            );
           array_push($Array,$t); 
        }

        $Fajlneve = "livestats_export.xlsx";
        $hedingArray = [['ID','Email','Nev', 'Kor','Neme']];
        //dd($Array);
        return Excel::download(new UserExport( $Array, $hedingArray ), $Fajlneve);

    }

    public function akkreditaciosfajl()
    {
        $users = Akkreditacio::all();
        $Array = array();
       
        foreach($users as $user)
        {
            
           $t = array("Név" => $user->user_data->name,"Képnév" =>$user->picsslug
            );
           array_push($Array,$t); 
        }

        $Fajlneve = "livestats_export.xlsx";
        $hedingArray = [['Név','Képnév']];
        //dd($Array);
        return Excel::download(new UserExport( $Array, $hedingArray ), $Fajlneve);
    }

    public function iskolasokletoltese()
    {
        $users = DB::table('kozepiskolasok')->get();
        $Array = array();
       
        foreach($users as $user)
        {
            
           $t = array("Név" => $user->name,"Email" =>$user->email,'intezmenyneve' => $user->intezmenyneve,
            'evfolyam' => $user->evfolyam, 'regisztracioIdeje' => $user->regisztracioIdeje
            );
           array_push($Array,$t); 
        }

        $Fajlneve = "iskolasok_export.xlsx";
        $hedingArray = [['Név','Email','Intézmény neve','Évfolyam','Regisztráció ideje']];
        //dd($Array);
        return Excel::download(new UserExport( $Array, $hedingArray ), $Fajlneve);
    }

    public function testriport()
    {
       
    }

    public function igazolastkertek()
    {
        $users = DB::table('igazolaskert')->get();
        $Array = array();
       
        foreach($users as $user)
        {
            
            $neme = null;
            if($user->neme == 1)
            {
                $neme = 'Nő';
            } else $neme = 'Férfi';

            $igazolas = null;

           
            switch($user->igazolasIgenyID)
            {
                case 1: 
                    $igazolas = 'Igen, önkéntességről általában';
                    break; 
                case 2: 
                    $igazolas = 'Igen, szakmai gyakorlathoz';
                        
                    break; 
                       
                case 3: 
                    $igazolas = 'Igen, iskolai közösségi szolgálathoz (IKSZ)';
                    break; 

                case 4: 
                    $igazolas = $user->igazolasEgyeb;
                    break; 
                default: 
                    $igazolas = 'Nem';
                break;
            }

           $t = array('ID' => $user->id,"Név" => $user->name,"Email" =>$user->email,'Tel' => $user->telefonszam,
            'Neme' =>  $neme, 'Kor' => $user->kor, 'igazolas' => $igazolas
            );
           array_push($Array,$t); 
        }

        $Fajlneve = "igazolasok_export.xlsx";
        $hedingArray = [['ID','Név','Email','Telefonszam','Neme','Kor','Igazolás']];
        //dd($Array);
        return Excel::download(new UserExport( $Array, $hedingArray ), $Fajlneve);
    }

    public function teljesitettOnkentesOrak()
    {
        

        $users = DB::table('onkentesorakszama_view')->get();
        $Array = array();
       
        foreach($users as $user)
        {


           $t = array('ID' => $user->id,"Név" => $user->name,"Email" =>$user->email,'Tel' => $user->telefonszam,
            'Neme' =>  $user->neme, 'Kor' => $user->kor, 'oraszamok' => $user->onkentesOrakSzama
            );
           array_push($Array,$t); 
        }

        $Fajlneve = "onkentesorakszama_export.xlsx";
        $hedingArray = [['ID','Név','Email','Telefonszam','Neme','Kor','Önkéntes órák száma']];
        //dd($Array);
        return Excel::download(new UserExport( $Array, $hedingArray ), $Fajlneve);

    }

    public function aug20riport()
    {
        $usersIDArray = FelhasznaloFeladat::where('esemeny_id',55)->groupBy('felhasznalo_id')->get();
        
        $Array = array();
       
        foreach($usersIDArray as $user)
        {
            
           $t = array("ID" => $user->felhasznalo_id,
           "Nev" => $user->user_data->name??'Nincs név',
           "Email" => $user->user_data->email??'Nincs email', 
           "Telefonszam" => $user->felhasznalok_data->telefonszam??'Nincs teloszam',
           "SzulIdopontja" => $user->felhasznalok_data->szulIdo??'Nincs',
           "Szemigszam" =>  $user->szemelyesadatok_data->szemigszam??0
            );
           array_push($Array,$t); 
        }

        $Fajlneve = "laug20rendezveny_export.xlsx";
        $hedingArray = [['ID','Nev', 'Email','Telefonszám','Szuletesi datum','Szemigszam']];
        //dd($Array);
        return Excel::download(new UserExport( $Array, $hedingArray ), $Fajlneve);
    }

    public function ruha_keszlet()
     {
         $ruhak = DB::table('ruha')->get();

         $Array = array();
         
         foreach($ruhak as $ruha)
         {
            $maradek = (int)$ruha->keszlet - (int)$ruha->kiosztva;
            $t = array(
                "ID" => $ruha->id,
                "Név"=> $ruha->ruhaNeve,
                "Készlet" => $ruha->keszlet,
                "Kiosztva" => $ruha->kiosztva,
                "Maradék" => $maradek,
                
         );
            array_push($Array,$t); 
         }
         $dt = Carbon::now(); $date = $dt->toDateString();
         $Fajlneve = "ruha_keszlet_".$dt.".xlsx";
         $hedingArray = [['ID','Név','Készlet','Kiosztva','Maradék']];

         return Excel::download(new UserExport( $Array, $hedingArray ), $Fajlneve);
     }

     public function ajandek_keszlet()
     {
         $ajandekok = DB::table('ajandekok')->get();

         $Array = array();
         
         foreach($ajandekok as $ajandek)
         {
            $maradek = (int)$ajandek->keszlet - (int)$ajandek->kiosztva;
            $t = array(
                "ID" => $ajandek->id,
                "Név"=> $ajandek->ajandekNeve,
                "Készlet" => $ajandek->keszlet,
                "Kiosztva" => $ajandek->kiosztva,
                "Maradék" => $maradek,
                
         );
            array_push($Array,$t); 
         }
         $dt = Carbon::now(); $date = $dt->toDateString();
         $Fajlneve = "ajandek_keszlet_".$dt.".xlsx";
         $hedingArray = [['ID','Név','Készlet','Kiosztva','Maradék']];

         return Excel::download(new UserExport( $Array, $hedingArray ), $Fajlneve);
     }

    
    /**
     * 
     */
    protected function telNumberFormatter_1(string $phoneNumber)
    {
        

        $result = '';

        try 
        {
            if(isset($phoneNumber))
            {
                $length = strlen($phoneNumber);
                    
    
                       
                                /**
                             * 205981742 hasonlo telszamok ele beirja a 36-ot
                            */
                            if((int)$length == 9)
                            {
                                if( $phoneNumber[0] == 7 || $phoneNumber[0] == 3 || $phoneNumber[0] == 2 ||
                                $phoneNumber[0] == 5 && $phoneNumber[1] == 0 )
                                {
                                    $result = '36'.$phoneNumber;
                                    return $result;
                                }
                                
                            }
                        
                      
                            if((int)$length == 11)
                            {
                                if( ($phoneNumber[2] == 7 || $phoneNumber[2] == 3 || $phoneNumber[2] == 2 ||
                                $phoneNumber[2] == 5) && $phoneNumber[0] == 0 && $phoneNumber[1] == 6)
                                {
                                    $result = '36'.substr($phoneNumber,2);
                                    return $result;
                                }
                                
                            }
                
                            /* pl.: 6204445566 */
                if((int)$length == 10)
                {
                    $result = substr_replace($phoneNumber, "36", 0, 1);
                    return $result;
                }
            }
    
        }
        catch(Exception $e)
        {
            return $phoneNumber;
        }

       
        return $phoneNumber;

    }

}

class ProfilSelector extends profilszerkesztesViewModel
{
    public $felhasznalo_id;
    public $password;
    public $created_at;
    public $updated_at;
    public $lakcim;
    public $orszag_id ;
    public $orszag;

}

class ProfilSelectorForCounty extends ProfilSelector
{
    public $countyID;
    public $county;
}
