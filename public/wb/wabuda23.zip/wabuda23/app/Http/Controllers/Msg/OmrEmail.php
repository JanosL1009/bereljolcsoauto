<?php
namespace App\Http\Controllers\Msg;

use \Illuminate\Support\Facades\Mail;
use App\Esemeny;
use App\FelhasznaloFeladat;
use App\User;
use \Exception;
use Illuminate\Database\Eloquent\Model;

class OmrEmail
{
/* plain text
    Mail::raw($msg, function ($message) use ($email) {
        $message->from(env('MAIL_FROM_ADDRESS'), 'ÖMR');
        $message->sender(env('MAIL_FROM_ADDRESS'), 'ÖMR NEK');
        $message->to('lakatos.janos@csbo.hu', 'John Doe');
        $message->subject('Subject');

    });
*/
    /**
     * Rendszeruzenet
     *@param string Email address
     *@param string msg
     */
    public static function SendMailAnUser($email = null,$msg)
    {
            Mail::send([], [], function ($message) use ($msg,$email) {
                     $message->to($email)
                    ->subject('ÖMR Platform Üzenete érkezett')
                    ->from(env('MAIL_FROM_ADDRESS'),'ÖMR Platform')
                    ->setBody($msg, 'text/html');
            });


    }

   

    /**
     *
     */
    public static function GeneralMailSendWithBlade($blade,$toEmail,$subject)
    {
        Mail::send($blade, [], function ($message) use ($toEmail,$subject) {
            $message->to($toEmail)
           ->subject($subject, 'ÖMR Platform')
           ->from(env('MAIL_FROM_ADDRESS'),'ÖMR Platform');
        });
    }

    public static function SendMailPrograms($msg,Esemeny $program)
    {
        $FelhasznaloFeladat = FelhasznaloFeladat::select('felhasznalo_id')->where('esemeny_id','=',$program->id)->get()->toArray();

        $UsersObjects = null;
        $UsersObjects = self::getUsers($FelhasznaloFeladat);
        foreach($UsersObjects  as $ff)
        {
            $toEmail = $ff->email;
            Mail::send([], [], function ($message) use ($msg,$toEmail) {
                $message->to($toEmail)
               ->subject('Dokumentum hiánypótlásra felszólítás - ÖMR Platform')
               ->from(env('MAIL_FROM_ADDRESS'),'ÖMR Platform')
               ->setBody($msg, 'text/html');
            });

        }

    }

    /**
     * Rendszeruzenet
     *@param string Email address
     */
    public static function AlertUserDataChange($toEmail)
    {
        Mail::send('emails.msgblades.profildatachangewithuser', [], function ($message) use ($toEmail) {
            $message->to($toEmail)
           ->subject('Értesítés adatváltozásról - ÖMR Platform', 'ÖMR Platform')
           ->from(env('MAIL_FROM_ADDRESS'),'ÖMR Platform');
        });
    }

    /**
     * Rendszeruzenet
     *@param string Email address
     */
    public static function AlertUserDataChangeForAdmin($toEmail)
    {
        Mail::send('emails.msgblades.profiledaachangeforadmin', [], function ($message) use ($toEmail) {
            $message->to($toEmail)
           ->subject('Értesítés adatváltozásról - ÖMR Platform', 'ÖMR Platform')
           ->from(env('MAIL_FROM_ADDRESS'),'ÖMR Platform');
        });
    }

    /**
     * Rendszeruzenet
     * @param string Email address
     * @param Esemeny Program
     */
    public static function AlertSuccessProgramAppliedForUser($toEmail,Esemeny $program)
    {
        Mail::send('emails.msgblades.successprogramapplied', ['program' => $program,'esemenyNeve' => $program->nev ], function ($message) use ($toEmail) {
            $message->to($toEmail)
           ->subject('Sikeresen jelentkeztél rendezvényünkre - ÖMR Platform', 'ÖMR Platform')
           ->from(env('MAIL_FROM_ADDRESS'),'ÖMR Platform');
        });
    }

    /**
     * Rendszeruzenet
     * @param string Email address
     * @param Esemeny Program
     */
    public static function AlertDisclaimProgramAppliedForUser($toEmail,Esemeny $program)
    {
        Mail::send('emails.msgblades.disclaimprogramapplied', ['program' => $program,'esemenyNeve' => $program->nev ], function ($message) use ($toEmail) {
            $message->to($toEmail)
           ->subject('Terület lemondás történt - ÖMR Platform', 'ÖMR Platform')
           ->from(env('MAIL_FROM_ADDRESS'),'ÖMR Platform');
        });
    }

    /**
     * Rendszeruzenet
     * @param string Email address
     * @param Esemeny Program
     */
    public static function AlertDisclaimProgramAppliedForAdmin($toEmail,Esemeny $program,$teruletnev)
    {
        Mail::send('emails.msgblades.disclaimprogramappliedadmin', ['program' => $program,'esemenyNeve' => $program->nev,'teruletnev' => $teruletnev ], function ($message) use ($toEmail) {
            $message->to($toEmail)
           ->subject('Terület lemondás történt - ÖMR Platform', 'ÖMR Platform')
           ->from(env('MAIL_FROM_ADDRESS'),'ÖMR Platform');
        });
    }

    /**
     * Rendszeruzenet
     * @param string Email address
     * @param Esemeny Program
     */
    public static function AlertChangeAppliedAreaForUser($toEmail,Esemeny $program)
    {
        Mail::send('emails.msgblades.changedprogramapplied', ['program' => $program,'esemenyNeve' => $program->nev ], function ($message) use ($toEmail) {
            $message->to($toEmail)
           ->subject('Sikeresen módosítottad a terület jelentkezésed - ÖMR Platform', 'ÖMR Platform')
           ->from(env('MAIL_FROM_ADDRESS'),'ÖMR Platform');
        });
    }


    /**
     * Rendszeruzenet
     * @param string Email address
     * @param Esemeny Program
     */
    public static function AlertChangeAppliedAreaForAdmin($toEmail,Esemeny $program,string $Teruletnev)
    {
        Mail::send('emails.msgblades.changedprogramappliedadmin', ['program' => $program,'esemenyNeve' => $program->nev,'teruletnev' => $Teruletnev ], function ($message) use ($toEmail) {
            $message->to($toEmail)
           ->subject('Önkéntes által terület módosítás történt - ÖMR Platform', 'ÖMR Platform')
           ->from(env('MAIL_FROM_ADDRESS'),'ÖMR Platform');
        });
    }


    /**
     * Ertesitest kuldd ki a program, esemenyre jelentkezoknek
     * @param blade Egy blade, email template, amit a usereknek szeretnénk küldeni
     * @param Esemeny mely esemeny,program jelenkezoinek akarjuk kuldeni
     */
    public static function AccordingToThePrograms($blade,Esemeny $program)
    {
        $FelhasznaloFeladat = FelhasznaloFeladat::where('esemeny_id','=',$program->id)->get();

        foreach($FelhasznaloFeladat  as $ff)
        {
            $toEmail = $ff->user_data->email;
            Mail::send($blade, ['program' => $program,'esemenyNeve' => $program->nev ], function ($message) use ($toEmail) {
                $message->to($toEmail)
               ->subject('Dokumentum hiánypótlás - ÖMR Platform', 'ÖMR Platform')
               ->from(env('MAIL_FROM_ADDRESS'),'ÖMR Platform');
            });
        }

    }

    /**
     * Ertesitest kuldd ki a program, esemenyre vagy területre vagy csoportra jelentkezoknek.
     * @param blade Egy blade, email template, amit a usereknek szeretnénk küldeni
     * @param Esemeny mely esemeny,program jelenkezoinek akarjuk kuldeni
     * @param int Terulet azonosito
     * @param int Csoport azonosito
     */
    public static function AccordingToTheProgramsMore($blade,Esemeny $program,int $TeruletID=null, int $CsoportID=null)
    {
        $FelhasznaloFeladat = FelhasznaloFeladat::where('esemeny_id','=',$program->id)->get();

        foreach($FelhasznaloFeladat  as $ff)
        {
            $toEmail = $ff->user_data->email;
            Mail::send($blade, ['program' => $program,'esemenyNeve' => $program->nev ], function ($message) use ($toEmail) {
                $message->to($toEmail)
               ->subject('Dokumentum hiánypótlás - ÖMR Platform', 'ÖMR Platform')
               ->from(env('MAIL_FROM_ADDRESS'),'ÖMR Platform');
            });
        }

    }

    public static function NewPosyBoss(User $User,Model $Jelige)
    {
        $toEmail = $User->email;
        Mail::send('emails.msgblades.newPosyBoss', ['jelige' => $Jelige->jeligeNeve,'felhasznaloneve' => $User->name ], function ($message) use ($toEmail) {
            $message->to($toEmail)
           ->subject('Értesítés -Jelige csoport változásról - ÖMR Platform', 'ÖMR Platform')
           ->from(env('MAIL_FROM_ADDRESS'),'ÖMR Platform');
        });
    }

    /**
     * Altalanos rendszeruzenet kuldese
     * @param bool Ha TRUE, akkor az adminok is megkapják az uzenetet, kulonben csak az onkentesek
     * kapjak meg
     *
     */
    public static function FullSystemMessage(bool $Admins = false)
    {

    }

    private static function getUsers(Array $FelhasznaloID)
    {
            return User::select('email')->whereIn('id',$FelhasznaloID)->get();
    }

    /**
     * Tomeges mail kuldes a cronhoz. Adatbazisbol hiv.
     */
     public static function BulkMailsFromDB()
     {

     }

}
