<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\DB_OMR_Operations;
use App\Http\Models\AdminDocumentView;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Carbon;

class DokumentumController extends Controller
{

    public function getdocuments(Request $request,$field = null,$order = null)
    {
        $user = auth()->user();
        $model = new AdminDocumentView($user['id']);
        $model->profilpic = DB_OMR_Operations::GetProfilkep($user['id']);

        $model->documentsList = DB::table('alt_dokumentumok');

        if(isset($field) && isset($order) )
        {
            $fieldValid = false; $orderValid = false;

            /**elfogadhato parametrek, mezok */
            switch($field)
            {
                case 'docname':
                    $fieldValid = true;
                break;
                case 'uploaded':
                    $fieldValid = true;$field = "uploaded_at";
                break;
                case 'visibility':
                    $fieldValid = true;$field = "visibility_id";
                break;
                default:
                    $fieldValid = true;$field = "docname";
                break;
            }

            switch($order)
            {
                case 'asc':
                    $orderValid = true;
                break;
                case 'desc':
                    $orderValid = true;
                break;
                default:
                    $orderValid = true; $order = "desc";
                break;
            }
            if($fieldValid && $orderValid)
            {
                $model->documentsList = DB::table('alt_dokumentumok')->orderBy($field,$order);
            }

        }



        if(request()->searchName){
            $model->documentsList = $model->documentsList->where('docname', 'LIKE' , '%'.request()->searchName.'%');
        }

        if(request()->searchAdmin){
            $model->documentsList = $model->documentsList->where('visibility_id', 1);
        }

        $model->documentsList = $model->documentsList->paginate(15);

        return view('adminisztratorok/dokumentumtar')->with('model',$model);
    }


    public function UploadDocument(Request $request)
    {
        $user = auth()->user();
        $UserId = $user["id"];

        if ($request->isMethod('post'))
          {
            $validator = Validator::make($request->all(),
                [
                    'file' => 'required|max:10000',
                ] );
            if ($validator->fails())
                return back()->withErrors($validator->errors());
            $extension = $request->file('file')->getClientOriginalExtension();
            $dir = 'public/files/raw/';
            $filename = uniqid() . '_' . time() . '.' . $extension;
            $request->file('file')->move($dir, $filename);

            $mytime = Carbon::now();
            $date = $mytime->toDateTimeString();

            DB::table('alt_dokumentumok')->insert(['docname' => $request->input('dokumentumNeve'), 'visibility_id' => $request->input('doksimegjelenes'),'real_docname' => $filename, 'uploaded_at' => $date]);
                //dd( $request->file('file'));
            return redirect('admin/dokumentumtar');

            }
        else {
            return redirect('admin/dokumentumtar');
        }

    }

}
