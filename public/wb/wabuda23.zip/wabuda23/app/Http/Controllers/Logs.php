<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\DB_OMR_Operations;
use App\Http\Controllers\Msg\OmrEmail as MsgOmrEmail;
use App\LogUser;
use App\User;
use App\UserLogins;
class Logs
{

    /**
     * Last 10 operation
     */
    public static function getUsersTable(int $UserID)
    {
        $logs = LogUser::skip(0)->take(10)->orderBy('updated_at','DESC')->get();

        $result = array();

        for($i = 0; $i< count($logs);$i++)
        {
            $log = $logs[$i];
           
            $r['updated_at'] = $log->updated_at;
            if( ($i+1) < count($logs) )
            {
                $next = $logs[$i+1];
            }
           
            
            if($log->password == $next->password)
            {
                $r['pws_change'] = 0;
            }
            else 
            {
                $r['pws_change'] = 1;
            }

            if($log->name == $next->name)
            {
                $r['name_change'] = 0;
            }
            else 
            {
                $r['name_change'] = 1;
            }

            if($r['pws_change'] == 0 && $r['name_change'] == 0)
            {
                $r['other_change'] = 1;
            }
           
            array_push($result,$r);
        }
        
        return $result;
    }

    public static function getLogins(int $UserID)
    {
        return UserLogins::skip(0)->take(15)->where('felhasznalo_id',$UserID)->orderBy('loginDate','desc')->get();
    }

    
}