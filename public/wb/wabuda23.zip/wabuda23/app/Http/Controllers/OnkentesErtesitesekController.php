<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Ertesitesek;
use App\ErtesitesMegtekintese;
use App\ErtesitesProgram;
use App\ErtesitesUsers;
use App\Esemeny;
use App\Terulet;
use App\TeruletBeosztas;
use App\EsemenySzervezok;
use App\Http\Models\ErtesitesekKezelese;
use App\Support\Collection;
use App\FelhasznaloFeladat;
use App\Http\Models\Ertesites\OnkentesErtesitesViewModel;

use App\Model\BeosztasKezeloRepo;
use Exception;

class OnkentesErtesitesekController extends Controller
{

    protected $UserID = 0;
    protected $User = null;

    /**
     * Beallitja a $UserID:int valtozot
     */
    private function setUserID() : void
    {
        if($this->UserID == 0)
        {
            $this->User = auth()->user();
            $this->UserID = intval($this->User["id"]);
        }
    }

    public function index()
    {
        $this->setUserID();
        $ertesitesek = new ErtesitesekKezelese();
        $ertesitesekOsszes = $ertesitesek->getErtesitesekOnkentesnek($this->UserID);
        $ertesitekLista = [];
        foreach($ertesitesekOsszes as $ertesites)
        {
            array_push($ertesitekLista,$ertesites->ertesites);
        }

        $ertesitekLista = new Collection($ertesitekLista);
        $user = auth()->user();

        $model = new OnkentesErtesitesViewModel($this->UserID);
        $model->profilpic = DB_OMR_Operations::GetProfilkep($this->UserID);

        $vezeto = null;
        $jogszintjeim = [
            "koordinator" => false,
            "teruletvezeto" =>false,
            "csoportvezeto" => false
        ];
        $isEsemenyKoordinator = $model->isEsemenySzervezoJog();
        $isTeruletvezeto = $model->isTeruletvezetoJog();

        //Hianyzik a csoportvezeto
        if($isEsemenyKoordinator|| $isTeruletvezeto)
            {
                $vezeto = true;
                if($isEsemenyKoordinator)
                {
                    $jogszintjeim["koordinator"] = true;
                }

                if($isTeruletvezeto)
                {
                    $jogszintjeim["teruletvezeto"] = true;
                }
            }
        else
            $vezeto = false;
        //dd($model);

        return view('onkentes.ertesites.index',['ertesitesek' => $ertesitekLista->paginate(15)])->with('model',$model)
        ->with('isVezeto',$vezeto)->with('jogszintjeim',$jogszintjeim);
    }


    public function MegtekintveLink(Request $request,int $ErtesitesID)
    {
        $this->setUserID();
        $ertesitesek = new ErtesitesekKezelese();
        $ertesitesek->setMegtekintve($this->UserID,$ErtesitesID);
        $user = auth()->user();
       /* $model = new OnkentesErtesitesViewModel($this->UserID);
        $model->profilpic = DB_OMR_Operations::GetProfilkep($this->UserID);*/

        return redirect()->route('onkentes.ertesitesek');
    }

    /**
     * Friss ertesites kuldese egy adott usernak
     * POST metodushoz, anotiications.js fajlhoz!
     */
    public function getFrissErtesites()
    {
        $this->setUserID();
            //itt jartam a legfrisebb allapotot, nem megtekintett ertesitot kell lekerdezni es megjeleniteni

    }


    /**
     * Visszater a legfrissebb és nem elolvasott ertesitessel.
     * Method:POST
     * XHR
     *Route:/onkentes/ertesitesek/xhr/friss
     *@param int OnkentesID
     *@return JSON
     */
    public function XhrFrissErtesites(Request $request)
    {
        $ertesites = new ErtesitesekKezelese;
        return $ertesites->getLegfrissebb_NEM_OlvasottErtesites(); //json
    }

    /**
     * @since version 1.8.x
     */
    public function letrehozas(Request $request,$jogszint)
    {
        $this->setUserID();
        $model = new OnkentesErtesitesViewModel($this->UserID);
        $model->profilpic = DB_OMR_Operations::GetProfilkep($this->UserID);

        switch($jogszint)
        {
            case 'tvezeto':
                //$model->esemenyek = Esemeny::all();
                $teruletvezetoAzonositok = EsemenySzervezok::where('felhasznalo_id',$this->UserID)->where('szint_id',4)
                ->get();
                $model->esemenyek = Esemeny::whereIn('id',$teruletvezetoAzonositok->pluck(["Esemeny_id"])->toArray())->get();
                $model->teruletek = Terulet::whereIn('id',$teruletvezetoAzonositok->pluck(["terulet_id"])->toArray())->get(["id","nev","esemeny_id"]);
            break;
            case 'progkoord':
                $esemenyszervezoAzonositok = EsemenySzervezok::where('felhasznalo_id',$this->UserID)->where('szint_id',3)
                ->get(["Esemeny_id"])->toArray();
                $model->esemenyek = Esemeny::whereIn('id',$esemenyszervezoAzonositok)->get();
            break;
            case 'csopvezeto':

            break;
            default:
                abort(404);
            break;
        }


        //dd($model);
        return view('onkentes.ertesites.letrehozas')->with('model',$model)->with('jogszint',$jogszint);
    }


    /**
     * POST routehoz
     */
    public function ErtesitesLetrehozasa(Request $request)
    {
        $this->setUserID();
        $validatedData = $request->validate([
            'Teruletek' => 'required'
        ]);

        $ertesitesNeve =  $request->input('ertesitesNeve');
        $ertesitesTartalma = $request->input('ertesitesTartalma');
        $programID = $request->input('Programok');

        $ertesites = new Ertesitesek;
        $ertesites->nev = $ertesitesNeve;
        $ertesites->tartalom = $ertesitesTartalma;
        $ertesites->letrehozo = $this->UserID;
        $ertesites->modosito = 0;
        $ertesites->save();

        $ertesites_program = new ErtesitesProgram;


           
            $ertesites_program->allusers = 0;
            $ertesites_program->ertesites_id = $ertesites->id;
            $ertesites_program->letrehozo = $this->UserID;
            $ertesites_program->modosito = 0;

            $ertesites_program->esemeny_id = $programID;

            $teruletID = $request->input('Teruletek');
            if(isset($teruletID ))
            {
                $ertesites_program->terulet_id = $teruletID ;
            }

            $csoportID = $request->input('Csoportok');
            if(isset($csoportID ))
            {
                $ertesites_program->csoport_id = $csoportID ;
            }

            $ertesites_program->save();

            if(isset($csoportID) && $csoportID > 0)
            {
                $csoportBeosztottak = FelhasznaloFeladat::where('csoport_id',$csoportID)->get();
                foreach( $csoportBeosztottak as $user)
                {
                    $ertesitesUsers = new ErtesitesUsers;
                    $ertesitesUsers->felhasznalo_id = $user->felhasznalo_id;
                    $ertesitesUsers->ertesites_id = $ertesites->id;
                    $ertesitesUsers->megtekintve = 0;
                    $ertesitesUsers->megtekintes_ideje = null;
                    $ertesitesUsers->save();
                }
            }
            else //csak teruletbeosztottak
            {
                $beosztottak = TeruletBeosztas::where('terulet_id',$teruletID)->get();
                foreach( $beosztottak as $user)
                {
                    $ertesitesUsers = new ErtesitesUsers;
                    $ertesitesUsers->felhasznalo_id = $user->felhasznalo_id;
                    $ertesitesUsers->ertesites_id = $ertesites->id;
                    $ertesitesUsers->megtekintve = 0;
                    $ertesitesUsers->megtekintes_ideje = null;
                    $ertesitesUsers->save();
                }
            }

            //userek bepkaolasa a ertesites_users tablaba; csoport tagok
            /*
            if(isset($csoportID))
            {
                $beosztas = new BeosztasKezeloRepo(null,$programID,$teruletID,$csoportID);
                $usersID = $beosztas->GetCsoportBeosztas();
                foreach($usersID as $user)
                {
                    $ertesitesUsers = new ErtesitesUsers;
                    $ertesitesUsers->felhasznalo_id = $user->felhasznalo_id;
                    $ertesitesUsers->ertesites_id = $ertesites->id;
                    $ertesitesUsers->megtekintve = 0;
                    $ertesitesUsers->megtekintes_ideje = null;
                    $ertesitesUsers->save();
                }
                unset($beosztas);unset($usersID);
            }
            else
            {
                if(isset($teruletID))
                {
                    $beosztas = new BeosztasKezeloRepo(null,$programID,$teruletID,null);
                    $usersID = $beosztas->getTeruletreBeosztottakListajaID()->pluck('felhasznalo_id')->toArray();
                    dd($usersID);
                    //$vezetokID = $beosztas->getTeruletVezetokListaja()->pluck('id')->toArray();

                   // $usersID = array_merge($usersID,$vezetokID);
                    $e_id = $ertesites->id;

                    foreach($usersID as $user)
                    {
                        $ertesitesUsers = new ErtesitesUsers;
                        $ertesitesUsers->felhasznalo_id = $user;
                        $ertesitesUsers->ertesites_id = $e_id;
                        $ertesitesUsers->megtekintve = 0;
                        $ertesitesUsers->megtekintes_ideje = null;
                        $ertesitesUsers->save();
                    }
                    unset($beosztas);unset($usersID);
                }
                
            }

*/



        return redirect()->route("onkentes.ertesitesek");
    }

}
