<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Exception;
use App\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use App\FelhasznaloInfo;
use App\Model\Felhasznalo;
use App\Nyelvismeret;
use App\BeszeltNyelvek;
use App\SzemelyesAdatok;
use App\Importhoz;
use App\Egyhazmegyek;
use App\UserEgyhazmegye;
use App\OnkentesSzabadidopontok;

class MyImportController extends Controller
{
    public function getCSVContent()
    {
        
        $importer = new CsvImporter("C:/xampp/htdocs/devomr/public/omrimportra.csv",true,",");
       
        $beszelhetoNyelvek = BeszeltNyelvek::all();
        $result = $importer->get(2353);
        $index = 4866;
       // dd($result);
       /**
        * 0-451; OK
        * 451 - 831 OK
        * 831 - 1001 ok
        * 1001 - 1361 ok
        * 1361 - 1601 OK
        * 1601 - 1901 OK
        * 1901 - 2151 OK
        * 2151 - 2353
        */
        for($i = 2151;$i < 2353;$i++)
        {
           if($result[$i]['active'] == 1)
           {
            $pwd =  str_random(10);

          $user = new User();
            $user->id = $index;
            $user->name = utf8_encode($result[$i]['vezeteknev'])." ".utf8_encode($result[$i]['keresztnev']);
            $user->email = $result[$i]['emailcim'];
            $user->email_verified_at = '2021-04-12 11:11:11';
            $user->password =Hash::make($pwd);
            $user->blocked = 0;
            $user->modifier = 1;
            $user->save();

            $imp = new Importhoz();
            $imp->felhasznalo_id = $user->id;
            $imp->pwd = $pwd;
            $imp->save();

            $osz = new OnkentesSzabadidopontok();
            $osz->felhasznalo_id = $user->id;
            $osz->save();

            DB::table('jogosultsag')->insert(["felhasznalo_id" => $user->id, "felhasznaloszint_id" => 2]);
   
          // DB_OMR_Operations::InsertDatableEmail($user->id, $user->email);

           $telefonszam = null;

           try{
            $telefonszam = str_replace("+","00", $result[$i]['telefonszam']);
           }
           catch(Exception $e)
           {
               $telefonszam = '00000000';
           }
 

           $felhasznalo = new Felhasznalo();
           $felhasznalo->id = $user->id;

           $felhasznalo->vezeteknev = utf8_encode($result[$i]['vezeteknev']);
           $knev = explode(' ',utf8_encode($result[$i]['keresztnev']));
          
           if(isset($knev[1]))
           {
            $felhasznalo->keresztnev = $knev[1];
           }
           $felhasznalo->kozepsonev = $knev[0];
           $felhasznalo->telefonszam = $telefonszam;
           $felhasznalo->szulhely = "";
           $felhasznalo->profilkep = 'blank-profile-pic-omr.png';
           $felhasznalo->kor = 1;
            $felhasznalo->save();

           $f = new FelhasznaloInfo();
           $f->felhasznalo_id = $user->id;
           $f->save();
           unset($f);


           $aktNyelvId = 1;

           
           if($aktNyelvId < 6)
           {
                if(strlen($result[$i]['nyelv_angol']) > 2)
                {
                
                $nyelv  = "INSERT INTO `nyelvismeret` (`nyelv_id`, `felhasznalo_id`, `nyelv`, `nyelvszint_id`, `sorrend`) VALUES (NULL, ".$user->id.", 'angol', ".$this->nyelvszint(utf8_encode($result[$i]['nyelv_angol'])).", '".$aktNyelvId."');";
                try{
                    DB::insert($nyelv);
                }
                catch(Exception $e)
                {
                    dd($nyelv,
                    $this->nyelvszint(utf8_encode($result[$i]['nyelv_angol'])),
                    utf8_encode($result[$i]['nyelv_angol']),
                    $this->changechar(utf8_encode($result[$i]['nyelv_angol']))
                
                    );
                }
                DB::insert($nyelv);
                $aktNyelvId++;
                }
                if(strlen($result[$i]['nyelv_olasz']) > 2)
                {
                $nyelv  = "INSERT INTO `nyelvismeret` (`nyelv_id`, `felhasznalo_id`, `nyelv`, `nyelvszint_id`, `sorrend`) VALUES (NULL, ".$user->id.", 'olasz', ".$this->nyelvszint(utf8_encode($result[$i]['nyelv_olasz'])).", '".$aktNyelvId."');";
                DB::insert($nyelv);
                $aktNyelvId++;
                }
    
                if(strlen($result[$i]['nyelv_francia']) > 2)
                {
                $nyelv  = "INSERT INTO `nyelvismeret` (`nyelv_id`, `felhasznalo_id`, `nyelv`, `nyelvszint_id`, `sorrend`) VALUES (NULL, ".$user->id.", 'francia', ".$this->nyelvszint(utf8_encode($result[$i]['nyelv_francia'])).", '".$aktNyelvId."');";
                DB::insert($nyelv);
                $aktNyelvId++;
                }
    
    
    
                if(strlen($result[$i]['nyelv_spanyol']) > 2)
                {
                $nyelv  = "INSERT INTO `nyelvismeret` (`nyelv_id`, `felhasznalo_id`, `nyelv`, `nyelvszint_id`, `sorrend`) VALUES (NULL, ".$user->id.", 'spanyol', ".$this->nyelvszint(utf8_encode($result[$i]['nyelv_spanyol'])).", '".$aktNyelvId."');";
                DB::insert($nyelv);
                $aktNyelvId++;
                }
    
    
                if(strlen($result[$i]['nyelv_nemet']) > 2)
                {
                $nyelv  = "INSERT INTO `nyelvismeret` (`nyelv_id`, `felhasznalo_id`, `nyelv`, `nyelvszint_id`, `sorrend`) VALUES (NULL, ".$user->id.", 'német', ".$this->nyelvszint(utf8_encode($result[$i]['nyelv_nemet'])).", '".$aktNyelvId."');";
                DB::insert($nyelv);
                $aktNyelvId++;
                }
    
                if(strlen($result[$i]['nyelv_szlovak']) > 2)
                {
                $nyelv  = "INSERT INTO `nyelvismeret` (`nyelv_id`, `felhasznalo_id`, `nyelv`, `nyelvszint_id`, `sorrend`) VALUES (NULL, ".$user->id.", 'szlovák', ".$this->nyelvszint(utf8_encode($result[$i]['nyelv_szlovak'])).", '".$aktNyelvId."');";
                DB::insert($nyelv);
                $aktNyelvId++;
                }
    
                if(strlen($result[$i]['nyelv_roman']) > 2)
                {
                $nyelv  = "INSERT INTO `nyelvismeret` (`nyelv_id`, `felhasznalo_id`, `nyelv`, `nyelvszint_id`, `sorrend`) VALUES (NULL, ".$user->id.", 'román', ".$this->nyelvszint(utf8_encode($result[$i]['nyelv_roman'])).", '".$aktNyelvId."');";
                DB::insert($nyelv);
                $aktNyelvId++;
                }
    
                if(strlen($result[$i]['nyelv_ukran']) > 2)
                {
                $nyelv  = "INSERT INTO `nyelvismeret` (`nyelv_id`, `felhasznalo_id`, `nyelv`, `nyelvszint_id`, `sorrend`) VALUES (NULL, ".$user->id.", 'ukrán', ".$this->nyelvszint(utf8_encode($result[$i]['nyelv_ukran'])).", '".$aktNyelvId."');";
                DB::insert($nyelv);
                $aktNyelvId++;
                }
    
                if(strlen($result[$i]['nyelv_lengyel']) > 2)
                {
                $nyelv  = "INSERT INTO `nyelvismeret` (`nyelv_id`, `felhasznalo_id`, `nyelv`, `nyelvszint_id`, `sorrend`) VALUES (NULL, ".$user->id.", 'lengyel', ".$this->nyelvszint(utf8_encode($result[$i]['nyelv_lengyel'])).", '".$aktNyelvId."');";
                DB::insert($nyelv);
                $aktNyelvId++;
                }
    
                if(strlen($result[$i]['nyelv_horvat']) > 2)
                {
                $nyelv  = "INSERT INTO `nyelvismeret` (`nyelv_id`, `felhasznalo_id`, `nyelv`, `nyelvszint_id`, `sorrend`) VALUES (NULL, ".$user->id.", 'horvát', ".$this->nyelvszint(utf8_encode($result[$i]['nyelv_horvat'])).", '".$aktNyelvId."');";
                DB::insert($nyelv);
                $aktNyelvId++;
                }
    
                if(strlen($result[$i]['nyelv_szloven']) > 2)
                {
                $nyelv  = "INSERT INTO `nyelvismeret` (`nyelv_id`, `felhasznalo_id`, `nyelv`, `nyelvszint_id`, `sorrend`) VALUES (NULL, ".$user->id.", 'szlovén', ".$this->nyelvszint(utf8_encode($result[$i]['nyelv_szloven'])).", '".$aktNyelvId."');";
                DB::insert($nyelv);
                $aktNyelvId++;
                }
    
           }

           $insert = "INSERT INTO `allandolakcim` (`felhasznaloid`, `IranyitoSzam`, `Telepules`, `Orszag`, `Cim`, `megyeID`) VALUES ('".$user->id."', NULL, NULL, NULL, NULL, 0)";
            DB::insert($insert);

            $insert = "INSERT INTO `tartozkodasilakcim` (`felhasznaloid`, `IranyitoSzam`, `TelepulesID`, `OrszagID`, `Cim`, `megyeID`) VALUES ('".$user->id."', NULL, NULL, NULL, NULL, '0');";
            DB::insert($insert);

            $insert = "INSERT INTO `egyeb_szervezet` VALUES (NULL,NULL, ".$user->id.");";
            DB::insert($insert);

            $insert = "INSERT INTO `civil_szervezet` VALUES (NULL,NULL, ".$user->id.");";
            DB::insert($insert);

            /** iit jartam */
            $anyjaneve = null;
            if(isset($result[$i]['anyja_vezetekneve']) && isset($result[$i]['anyja_keresztneve']))
            {
                $anyjaneve = utf8_encode($result[$i]['anyja_vezetekneve'])." ".utf8_encode($result[$i]['anyja_keresztneve']);
            }

            $szemig = null;
            if(isset($result[$i]['szemelyi_azonosito_szam']))
            {
                $szemig = $result[$i]['szemelyi_azonosito_szam'];
            }

            $allampolgar = null;
            if(isset($result[$i]['magyar_allampolgar']))
            {
                $allampolgar = utf8_encode($result[$i]['magyar_allampolgar']);
            }

            try{
                    $szInsert = "INSERT INTO `szemelyesadatok` VALUES (NULL,".$user->id.",' ','".$anyjaneve."','".$szemig."','".$allampolgar."');";
                }
                catch(Exception $e)
                {
                    $szInsert = "INSERT INTO `szemelyesadatok` VALUES (NULL,".$user->id.",' ',NULL,NULL,NULL);";
                }
                finally{
                   DB::insert($szInsert);
                }


            $felekezet = null;

            if(isset($result[$i]['felekezet']))
            {
                $felekezet = utf8_encode($result[$i]['felekezet']);
            }
          
            
            if(isset($felekezet))
            {
                if($felekezet == "Római katolikus")
                {
                    $egyhazmegyeRomKat = null;
                    if(isset($result[$i]['egyhazmegye_romkat']))
                    {
                        
                        $egyhazmegyeRomKat = utf8_encode($result[$i]['egyhazmegye_romkat']);
                        
                        if($egyhazmegyeRomKat == "határon túli") //NÁLAM AZ EGYÉB !!!!!
                        {
                            $hataron_tul_nev = utf8_encode($result[$i]['hataron_tuli_rk_egyhazmegye'])." - Római katolikus";
                            $uj = new UserEgyhazmegye();
                            $uj->felhasznalo_id = $user->id;
                            $uj->egyhazmegye_id = 9;
                            $uj->egyebInputValue = $hataron_tul_nev;
                            $uj->modosito = 1;
                            $uj->save();
                        }
                        else {
                            $egyhazmegyeDB = Egyhazmegyek::where('felekezet','Római Katolikus Egyház')->get();
                            $uj = new UserEgyhazmegye();
                            try 
                            {
                                foreach($egyhazmegyeDB as $egyhaz)
                                {
                                    if($egyhaz->nev == $egyhazmegyeRomKat)
                                    {
                                       
                                        $uj->felhasznalo_id = $user->id;
                                        $uj->egyhazmegye_id = $egyhaz->id;
                                        $uj->modosito = 1;
                                        
                                    }
                                }
                            }
                            catch(Exception $e)
                            {
                                         $uj->felhasznalo_id = $user->id;
                                        $uj->modosito = 1;
                            }
                            finally{
                                $uj->save();
                            }
                           

                        }
                    }
                }
                if($felekezet == "Görögkatolikus")
                {
                    $egyhazmegyeDB = Egyhazmegyek::where('felekezet','Görög Katolikus Egyház')->get();
                    $uj = new UserEgyhazmegye();
                    try
                    {
                        $gorokatmegye = utf8_encode($result[$i]['egyhazmegye_gorkat']);
                        foreach($egyhazmegyeDB as $egyhaz)
                        {
                            if($egyhaz->nev == $gorokatmegye)
                            {
                               
                                $uj->felhasznalo_id = $user->id;
                                $uj->egyhazmegye_id = $egyhaz->id;
                                $uj->modosito = 1;
                            }
                        }
                    }
                    catch(Exception $e)
                    {
                                 $uj->felhasznalo_id = $user->id;
                                $uj->modosito = 1;
                    }
                    finally{
                        $uj->save();
                    }
                }
                if($felekezet == "egyéb")
                {
                    $egyebfel = utf8_encode($result[$i]['egyeb_fel_neve']);
                    $uj = new UserEgyhazmegye();
                    $uj->felhasznalo_id = $user->id;
                    $uj->egyhazmegye_id = 9;
                    $uj->egyebInputValue = $egyebfel;
                    $uj->modosito = 1;
                    $uj->save();
                }
                if($felekezet == "nem tartozom felekezethez")
                {
                   
                    $uj = new UserEgyhazmegye();
                    $uj->felhasznalo_id = $user->id;
                    $uj->egyhazmegye_id = 10;
                    $uj->nemTag = 1;
                    $uj->modosito = 1;
                    $uj->save();
                }
            }

            
         
            
            $egyhazmegyeGorKat = null;
            if(isset($result[$i]['egyhazmegye_gorkat']))
            {
                $egyhazmegyeGorKat = utf8_encode($result[$i]['egyhazmegye_gorkat']);
            }
          
           

            $index++;
           }
        }


           unset($beszelhetoNyelvek);
    }

    public function cserkeszImport()
    {
        $index = 6680;
        for($i = 1;$i < 300;$i++) //300
        {
            echo "(NULL, 'Cserkész vagyok', ".$index."),";
            $index = (int)$index + 1;
        }

        /*$importer = new CsvImporter("C:/xampp/htdocs/devomr/public/cserkesz_nek_regisztraltak.csv",true,",");
       
        
        $result = $importer->get(300);
       // dd( $result);
        $index = 6681;
        for($i = 1;$i < 300;$i++)
        {
            $pwd =  str_random(9);
            $namePieces = explode(" ", $result[$i]['nev']);
           $lastname = $namePieces[0];
           $firstname = $namePieces[1]??'';
           $email = $result[$i]['email'];
           $fullname = $lastname.' '.$firstname; 
            $telefonszam = $result[$i]['tel'];

           $secondname = null;
           if(isset($namePieces[2]))
           {
                if(isset($namePieces[3]))
                {
                    $secondname = $namePieces[2].' '.$namePieces[3];
                    $fullname = $fullname.' '.$secondname;
                }
                else{
                    $secondname = $namePieces[2];
                    $fullname = $fullname.' '.$secondname;
                }
           }

           $user = new User();
           $user->id = $index;
           $user->name = $fullname;
           $user->email = $email;
           $user->email_verified_at = '2021-06-25 12:55:11';
           $user->password =Hash::make($pwd);
           $user->blocked = 0;
           $user->modifier = 1;
           $user->save();

            $imp = new Importhoz();
            $imp->felhasznalo_id = $user->id;
            $imp->pwd = $pwd;
            $imp->save();

            $osz = new OnkentesSzabadidopontok();
            $osz->felhasznalo_id = $user->id;
            $osz->save();

            DB::table('jogosultsag')->insert(["felhasznalo_id" => $user->id, "felhasznaloszint_id" => 2]);

            $felhasznalo = new Felhasznalo();
            $felhasznalo->id = $user->id;
            $felhasznalo->email = $email;
            $felhasznalo->vezeteknev = $lastname;
           
           
            $felhasznalo->keresztnev = $secondname;
            
            $felhasznalo->kozepsonev =$firstname; 
            $felhasznalo->telefonszam = $telefonszam;
            $felhasznalo->szulhely = "";
            $felhasznalo->profilkep = 'blank-profile-pic-omr.png';
            $felhasznalo->kor = 1;
             $felhasznalo->save();
 
            $f = new FelhasznaloInfo();
            $f->felhasznalo_id = $user->id;
            $f->polomeret =  $result[$i]['polo'];
            $f->polotipus =  $result[$i]['ptipus'];
            $f->save();
            unset($f);

            $nyelv1  = "INSERT INTO `nyelvismeret` (`nyelv_id`, `felhasznalo_id`, `nyelv`, `nyelvszint_id`, `sorrend`) VALUES (NULL, ".$user->id.", NULL, NULL,1);";
            DB::insert($nyelv1);

            $nyelv2  = "INSERT INTO `nyelvismeret` (`nyelv_id`, `felhasznalo_id`, `nyelv`, `nyelvszint_id`, `sorrend`) VALUES (NULL, ".$user->id.", NULL, NULL,1);";
            DB::insert($nyelv2);

            $nyelv3  = "INSERT INTO `nyelvismeret` (`nyelv_id`, `felhasznalo_id`, `nyelv`, `nyelvszint_id`, `sorrend`) VALUES (NULL, ".$user->id.", NULL, NULL,1);";
            DB::insert($nyelv3);

            $nyelv4  = "INSERT INTO `nyelvismeret` (`nyelv_id`, `felhasznalo_id`, `nyelv`, `nyelvszint_id`, `sorrend`) VALUES (NULL, ".$user->id.", NULL, NULL,1);";
            DB::insert($nyelv4);

            $nyelv5  = "INSERT INTO `nyelvismeret` (`nyelv_id`, `felhasznalo_id`, `nyelv`, `nyelvszint_id`, `sorrend`) VALUES (NULL, ".$user->id.", NULL, NULL,1);";
            DB::insert($nyelv5);

            $insert = "INSERT INTO `allandolakcim` (`felhasznaloid`, `IranyitoSzam`, `Telepules`, `Orszag`, `Cim`, `megyeID`) VALUES ('".$user->id."', NULL, NULL, NULL, NULL, 0)";
            DB::insert($insert);

            $insert = "INSERT INTO `tartozkodasilakcim` (`felhasznaloid`, `IranyitoSzam`, `TelepulesID`, `OrszagID`, `Cim`, `megyeID`) VALUES ('".$user->id."', NULL, NULL, NULL, NULL, '0');";
            DB::insert($insert);

            $insert = "INSERT INTO `egyeb_szervezet` VALUES (NULL,'Cserkész vagyok', ".$user->id.");";
            DB::insert($insert);

            $insert = "INSERT INTO `civil_szervezet` VALUES (NULL,NULL, ".$user->id.");";
            DB::insert($insert);

            $szInsert = "INSERT INTO `szemelyesadatok` VALUES (NULL,".$user->id.",NULL,NULL,NULL,NULL,NULL,NULL);";
            DB::insert($szInsert);

            $uj = new UserEgyhazmegye();
            $uj->felhasznalo_id = $user->id;
            $uj->modosito = 1;
            $uj->save();
        
           $index = (int)$index + 1;
        }*/



    }

    private function nyelvszint($szint)
    {
        $s = null;
        $szint = $this->changechar($szint);
        
        if($szint == 'alap') {$s = 1;}
        if($szint == 'közép') {$s = 2;}
        if($szint == "felső") {$s = 3;}
        return $s;
    }

    private function changechar($txt){
        $mit  = array("õ" );
      $mire = array("ő");
        return(str_replace($mit,$mire,$txt)); 
    }


    public function Nylevszintteszt()
    {
        $importer = new CsvImporter("C:/xampp/htdocs/devomr/public/omrimportra.csv",true,",");
       
        $beszelhetoNyelvek = BeszeltNyelvek::all();
        $result = $importer->get(2248);

        return $this->nyelvszint(utf8_encode($result[14]['nyelv_angol']));

    }
}

class CsvImporter
{
    private $fp;
    private $parse_header;
    private $header;
    private $delimiter;
    private $length;
    //--------------------------------------------------------------------
    function __construct($file_name, $parse_header=false, $delimiter="\t", $length=8000)
    {
        $this->fp = fopen($file_name, "r");
        $this->parse_header = $parse_header;
        $this->delimiter = $delimiter;
        $this->length = $length;
      //  $this->lines = $lines;

        if ($this->parse_header)
        {
           $this->header = fgetcsv($this->fp, $this->length, $this->delimiter);
        }

    }
    //--------------------------------------------------------------------
    function __destruct()
    {
        if ($this->fp)
        {
            fclose($this->fp);
        }
    }
    //--------------------------------------------------------------------
    function get($max_lines=0)
    {
        //if $max_lines is set to 0, then get all the data

        $data = array();

        if ($max_lines > 0)
            $line_count = 0;
        else
            $line_count = -1; // so loop limit is ignored

        while ($line_count < $max_lines && ($row = fgetcsv($this->fp, $this->length, $this->delimiter)) !== FALSE)
        {
            if ($this->parse_header)
            {
                foreach ($this->header as $i => $heading_i)
                {
                    $row_new[$heading_i] = $row[$i];
                }
                $data[] = $row_new;
            }
            else
            {
                $data[] = $row;
            }

            if ($max_lines > 0)
                $line_count++;
        }
        return $data;
    }
    //--------------------------------------------------------------------

}
