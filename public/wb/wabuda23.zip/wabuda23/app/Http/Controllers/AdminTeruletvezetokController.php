<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\DB_OMR_Operations;
use App\Http\Models\Teruletvezetok\AdmintvezetokViewModel;
use App\Teruletvezetok;
use App\TeruletvezetoNote;
use \Exception;
use App\Support\Collection;
use App\Terulet;
use App\Esemeny;
use Illuminate\Support\Facades\DB;
use App\TeruletCsoportositas;
use App\TeruletCsoportositasAzonositok;
use App\TeruletVezetokTerulet;
use App\FelhasznaloFeladat;
use App\EsemenySzervezok;
use App\TeruletVezetokTerulet as AppTeruletVezetokTerulet;
use PhpParser\Node\Stmt\Catch_;
use Illuminate\Support\MessageBag;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Input;
use Symfony\Component\ErrorHandler\Error\FatalError;

class AdminTeruletvezetokController extends Controller
{
        public function Index(Request $request)
        {
            $user = auth()->user();
            $model = new AdmintvezetokViewModel($user['id']);
            $model->profilpic = DB_OMR_Operations::GetProfilkep($user['id']);
            $teruletvezetok = Teruletvezetok::paginate(15);

            $model->setTeruletVezetok($teruletvezetok);


            return view('adminisztratorok.teruletvezetok.index')->with('model',$model);
        }


        public function teruletvezeto_reszletes(Request $request,$TeruletVezetoID)
        {
            $user = auth()->user();
            $model = new AdmintvezetokViewModel($user['id']);
            $model->profilpic = DB_OMR_Operations::GetProfilkep($user['id']);

            $teruletvezeto = Teruletvezetok::where('id',$TeruletVezetoID)->first();

            $model->megjegyzes = TeruletvezetoNote::where('felhasznalo_id',$teruletvezeto->felhasznalo_id)->
            first()->megjegyzes??'';
            $teruletCsoportok = null;
            $csoportositas = TeruletCsoportositas::all();
            $startArray = '['; $endArray = ']';
            $teruletCsoportok.=$startArray;
            $numItems = count($csoportositas);
            $i = 0;
            foreach($csoportositas as $csoport)
            {
                //$teruletazonositok = $csoport->getTeruletAzonositok;
                //dd($csoport->getTeruletAzonositok->pluck(['terulet_id'])->toArray());
                //$teruletCsoportok .= $string;
                if(++$i === $numItems)
                {
                    $string = '{"csopID":'.$csoport->id.',"csoportNeve":"'. $csoport->csoportNev.'","teruletAzonositok":"'.implode(",",$csoport->getTeruletAzonositok->pluck(['terulet_id'])->toArray()).'"}';

                    $teruletCsoportok .= $string;
                }
                else
                {
                    $string = '{"csopID":'.$csoport->id.',"csoportNeve":"'. $csoport->csoportNev.'","teruletAzonositok":"'.implode(",",$csoport->getTeruletAzonositok->pluck(['terulet_id'])->toArray()).'"},';

                    $teruletCsoportok .= $string;
                }
            }
            $teruletCsoportok.=$endArray;
            /**
             * @var JSON A teruletek, aktiv programonkent!!!
             */
            $teruletek = DB::table('terulet')->join('esemeny', 'esemeny.id','=','terulet.esemeny_id')->select(['esemeny.nev as EsemenyNev','terulet.id','terulet.nev'])->get()->toJson();

            $selectedTeruletek = TeruletVezetokTerulet::where('teruletvezeto_id',$TeruletVezetoID)->select('terulet_id')->get()->toJSON();
            $selectdCsoportositottTeruletek =  TeruletVezetokTerulet::where('teruletvezeto_id',$TeruletVezetoID)->
            where('teruletcsoportositas_id','>',0)->groupby('teruletcsoportositas_id')
            ->select('teruletcsoportositas_id')->get()->toJSON();

            return view('adminisztratorok.teruletvezetok.teruletvezeto_reszletes',['teruletvezeto' => $teruletvezeto])->with('model',$model)
            ->with('teruletCsoportok',$teruletCsoportok)->with('teruletek',$teruletek)
            ->with('selectedTeruletek',$selectedTeruletek)
            ->with('selectdCsoportositottTeruletek',$selectdCsoportositottTeruletek);
        }


        public function MegjegyzesModositasa(Request $request)
        {
            $teruletVezetoID = $request->input("chiefID");
            $megjegyzes = $request->input("vezetoiMegjegyzes");
            $teruletvezeto = null;
            try{
                    $teruletVezetoID = intval($teruletVezetoID);
                    $teruletvezeto = Teruletvezetok::where('id',$teruletVezetoID)->first();
            }
            catch(Exception $e)
            {
                return "0";
            }

            $user = auth()->user();
            $vezeto = null;
            try{
                $vezeto = TeruletvezetoNote::where('teruletvezeto_id',$teruletVezetoID)->firstOrFail();
                $vezeto->felhasznalo_id = $teruletvezeto->felhasznalo_id;
                $vezeto->teruletvezeto_id = $teruletVezetoID;
            }
            catch(\Illuminate\Database\Eloquent\ModelNotFoundException $e)
            {
                $vezeto = new TeruletvezetoNote();
                $vezeto->felhasznalo_id = $teruletvezeto->felhasznalo_id;
                $vezeto->letrehozo = $user['id'];
                $vezeto->teruletvezeto_id = $teruletVezetoID;
            }
            finally{
                $vezeto->megjegyzes = $megjegyzes;
                $vezeto->modosito = $user['id'];
                $vezeto->save();
            }
            return back();
        }

        public function OraberModositasa(Request $request)
        {
            $teruletVezetoID = $request->input("chiefID");
            $huf = $request->input("huf");

            $user = auth()->user();
            $vezeto = Teruletvezetok::where('id',$teruletVezetoID)->first();
            $vezeto->oraber = $huf;
            $vezeto->modosito = $user['id'];
            $vezeto->save();

            if($vezeto)
            {
                return 1;
            }
            else return 0;


        }

        /**
         *
         */
        public function TeruletekCsoportositasa(Request $request)
        {
            $user = auth()->user();
            $model = new AdmintvezetokViewModel($user['id']);
            $model->profilpic = DB_OMR_Operations::GetProfilkep($user['id']);

            $teruletCsoportok = TeruletCsoportositas::paginate(20);

            return view('adminisztratorok.teruletvezetok.teruletek_csoportositasa')->with('model',$model)
            ->with('teruletCsoportok',$teruletCsoportok);
        }

        public function uj_terulet_csoportositas(Request $request)
        {
            $user = auth()->user();
            $model = new AdmintvezetokViewModel($user['id']);
            $model->profilpic = DB_OMR_Operations::GetProfilkep($user['id']);

            /**
             * @var Collection Az aktiv esemenyek teruleteit kerdezi le.
             *  */
            $teruletek = DB::table('terulet')->join('esemeny', 'esemeny.id','=','terulet.esemeny_id')->
            where('esemeny.statusz_id','=',2)->select(['esemeny.nev as EsemenyNev','terulet.id','terulet.nev'])->get()->toJson();
            //dd($teruletek);
            return view('adminisztratorok.teruletvezetok.uj_terulet_csoportositas',['teruletek' => $teruletek])->with('model',$model);
        }

        public function uj_terulet_csoportositas_feldolgozo(Request $request)
        {
            $user = auth()->user();
            $csoportNev = $request->input('csoportositasNeve');
            $multipleSelect = $request->input('optgroup');
            
           
            try{
                    $validator = Validator::make($request->all(),
                    ['csoportositasNeve' => 'required|unique:terulet_csoportositas,csoportNev',
                        'optgroup' => 'required',
                        'optgroup.*' => 'required',]
                );

                

            }
            catch(FatalError $e)
            {
                //dd($multipleSelect,$validator->fails(),$validator);
            } 

            if($validator->fails())
            {
                return redirect()->action('AdminTeruletvezetokController@uj_terulet_csoportositas')
                ->withErrors(['unsuccess', '1']);
            }
            
                $csoportositas = new TeruletCsoportositas();
                $csoportositas->csoportNev = $csoportNev;
                $csoportositas->letrehozo = $user['id'];
                $csoportositas->save();
    
                foreach($multipleSelect as $TeruletAzonosito)
                {
                    $id_csoportositas = new TeruletCsoportositasAzonositok();
                    $id_csoportositas->terulet_csoport_id = $csoportositas->id;
                    $id_csoportositas->terulet_id = $TeruletAzonosito;
                    $id_csoportositas->letrehozo = $user['id'];
                    $id_csoportositas->save();
                }
    
                return redirect()->action('AdminTeruletvezetokController@TeruletekCsoportositasa')
                ->withErrors(['success', '1']);
            
           
            
          

           // dd($request->all());
           /* $csoportositas = new TeruletCsoportositas();
            $csoportositas->csoportNev = $csoportNev;
            $csoportositas->letrehozo = $user['id'];
            $csoportositas->save();

            foreach($multipleSelect as $TeruletAzonosito)
            {
                $id_csoportositas = new TeruletCsoportositasAzonositok();
                $id_csoportositas->terulet_csoport_id = $csoportositas->id;
                $id_csoportositas->terulet_id = $TeruletAzonosito;
                $id_csoportositas->letrehozo = $user['id'];
                $id_csoportositas->save();
            }

            return redirect()->action('AdminTeruletvezetokController@TeruletekCsoportositasa')
            ->withErrors(['success', '1']);*/
        }


        public function Csoport_torles(Request $request)
        {
            $id = $request->input('tercsop');
            try{
                TeruletCsoportositas::find($id)->delete();
                $teruletAzonositok = TeruletCsoportositasAzonositok::where('terulet_csoport_id',$id)->get();
                TeruletCsoportositasAzonositok::where('terulet_csoport_id',$id)->delete();
                EsemenySzervezok::whereIn('terulet_id',$teruletAzonositok)->delete();
                unset($teruletAzonositok);
                TeruletVezetokTerulet::where('teruletcsoportositas_id',$id)->delete();

                return 1;
            }
            catch(Exception $e)
            {
                return $e;
            }
        }

        public function CsoportositasSzerkesztese(Request $request, int $id)
        {
            $user = auth()->user();
            $model = new AdmintvezetokViewModel($user['id']);
            $model->profilpic = DB_OMR_Operations::GetProfilkep($user['id']);

                $aktualiscsoport = TeruletCsoportositas::find($id);

                $valasztottTeruletAzonositok = TeruletCsoportositasAzonositok::where('terulet_csoport_id',$id)->get("terulet_id")->toArray();

            $teruletCsoportok = null;
            $csoportositas = TeruletCsoportositas::all();
            $startArray = '['; $endArray = ']';
            $teruletCsoportok.=$startArray;
            $numItems = count($csoportositas);
            $i = 0; $teruletek = null;
            foreach($csoportositas as $csoport)
            {
               if($csoport->id == $id)
               {
                if(++$i === $numItems)
                {
                    $string = '{"csopID":'.$csoport->id.',"csoportNeve":"'. $csoport->csoportNev.'","teruletAzonositok":"'.implode(",",$csoport->getTeruletAzonositok->pluck(['terulet_id'])->toArray()).'"}';

                    $teruletCsoportok .= $string;
                }
                else
                {
                    $string = '{"csopID":'.$csoport->id.',"csoportNeve":"'. $csoport->csoportNev.'","teruletAzonositok":"'.implode(",",$csoport->getTeruletAzonositok->pluck(['terulet_id'])->toArray()).'"}';
                    $teruletek = $csoport->getTeruletAzonositok->pluck(['terulet_id'])->toArray();
                    $teruletCsoportok .= $string;
                }
               }

            }
            $teruletCsoportok.=$endArray;
            $teruletek = DB::table('terulet')->join('esemeny', 'esemeny.id','=','terulet.esemeny_id')
            ->select(['esemeny.nev as EsemenyNev','terulet.id','terulet.nev'])->get()->toJson();

                return view('adminisztratorok.teruletvezetok.csoportositas_szerkesztes',['csoport' => $aktualiscsoport])
                ->with('model',$model)->with('teruletCsoportok',$teruletCsoportok)
                ->with('teruletek',$teruletek);
        }



        /**  *********************  *********************   ****************************************** */
         /**  *********************  XHR method's  ****************************************** */
        /*************************************************************************************************/

        public function change_simpleareas_multiselect(Request $request)
        {
            $user = auth()->user();

            $TeruletvetoID = $request->input('tvezetoid');
            $TeruletVezetokTabla = Teruletvezetok::find($TeruletvetoID);
            /**
             * @var Array[int]
             */
            $Teruletek = $request->input('teruletek');

            TeruletVezetokTerulet::where('felhasznalo_id',$TeruletVezetokTabla->felhasznalo_id)->delete();
            EsemenySzervezok::where('felhasznalo_id',$TeruletVezetokTabla->felhasznalo_id)->delete();

            foreach($Teruletek as $teruletID)
            {
                $TeruletVezetokTerulet = new TeruletVezetokTerulet();
                $TeruletVezetokTerulet->teruletvezeto_id =  $TeruletvetoID;
                $TeruletVezetokTerulet->felhasznalo_id =  $TeruletVezetokTabla->felhasznalo_id;
                $TeruletVezetokTerulet->teruletvezeto_id =  $TeruletvetoID;
                $TeruletVezetokTerulet->letrehozo = $user['id'];
                $TeruletVezetokTerulet->terulet_id = $teruletID;
                $TeruletVezetokTerulet->save();
                $Terulet = Terulet::find($teruletID);
                $EsemenySzervezok = new EsemenySzervezok();
                $EsemenySzervezok->felhasznalo_id = $TeruletVezetokTabla->felhasznalo_id;
                $EsemenySzervezok->Esemeny_id = $Terulet->esemeny_id;
                $EsemenySzervezok->szint_id = 4;
                $EsemenySzervezok->terulet_id = $teruletID;
                $EsemenySzervezok->csoport_id = null;
                $EsemenySzervezok->save();
            }



            return $Teruletek;
        }

        public function change_groupsareas_multiselect(Request $request)
        {
            $user = auth()->user();

            $TeruletvetoID = $request->input('tvezetoid');
            $TeruletVezetokTabla = Teruletvezetok::find($TeruletvetoID);
            /**
             * @var Array[int]
             */
            $TerulCsoportok = $request->input('csoportok');

            $TeruletCsoportositasok = TeruletCsoportositasAzonositok::whereIn('terulet_csoport_id',$TerulCsoportok)->get();
            $meglevoteruletek = TeruletVezetokTerulet::where('felhasznalo_id',$TeruletVezetokTabla->felhasznalo_id)->
            where('teruletcsoportositas_id','>',0)->get();

            $torlendoEsemenyekbol = $meglevoteruletek->pluck('terulet_id')->toArray();
            EsemenySzervezok::whereIn('terulet_id',$torlendoEsemenyekbol)->where('felhasznalo_id',$TeruletVezetokTabla->felhasznalo_id)->delete();
            if(count($torlendoEsemenyekbol) > 0)
            {
                $meglevoteruletek->delete();
            }

            unset($torlendoEsemenyekbol);
            foreach($TeruletCsoportositasok as $csoportok)
            {
                $TeruletVezetokTerulet = new TeruletVezetokTerulet();
                $TeruletVezetokTerulet->teruletvezeto_id =  $TeruletvetoID;
                $TeruletVezetokTerulet->felhasznalo_id =  $TeruletVezetokTabla->felhasznalo_id;
                $TeruletVezetokTerulet->teruletvezeto_id =  $TeruletvetoID;
                $TeruletVezetokTerulet->letrehozo = $user['id'];
                $TeruletVezetokTerulet->terulet_id = $csoportok->terulet_id;
                $TeruletVezetokTerulet->teruletcsoportositas_id = $csoportok->terulet_csoport_id;
                $TeruletVezetokTerulet->save();
                $Terulet = Terulet::find($csoportok->terulet_id);
                $EsemenySzervezok = new EsemenySzervezok();
                $EsemenySzervezok->felhasznalo_id = $TeruletVezetokTabla->felhasznalo_id;
                $EsemenySzervezok->Esemeny_id = $Terulet->esemeny_id;
                $EsemenySzervezok->szint_id = 4;
                $EsemenySzervezok->terulet_id = $csoportok->terulet_id;
                $EsemenySzervezok->csoport_id = null;
                $EsemenySzervezok->save();
            }

            return 1;
        }
}
