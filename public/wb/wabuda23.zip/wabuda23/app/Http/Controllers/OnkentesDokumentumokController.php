<?php

namespace App\Http\Controllers;

use App\Http\Models\UserDocuments;
use App\Http\Models\Documents;
use Illuminate\Foundation\Auth\User;
use Illuminate\Http\Request;
use App\Esemeny;
use App\Http\Controllers\Msg\OmrEmail;
use Exception;

class OnkentesDokumentumokController extends Controller
{

    public function __construct()
    {

    }


    public function index(Request $requeset,$field = null,$order = null)
    {
        $documents = null;
        if(isset($field) && isset($order) )
        {
            $fieldValid = false; $orderValid = false;

            /**elfogadhato parametrek, mezok */
            switch($field)
            {
                case 'docname':
                    $fieldValid = true;
                break;
                case 'uploaded':
                    $fieldValid = true;$field = "created_at";
                break;
                case 'name':
                    $fieldValid = true;$field = "name";
                break;
                default:
                    $fieldValid = true;$field = "docname";
                break;
            }

            switch($order)
            {
                case 'asc':
                    $orderValid = true;
                break;
                case 'desc':
                    $orderValid = true;
                break;
                default:
                    $orderValid = true; $order = "desc";
                break;
            }

            if($fieldValid && $orderValid)
            {
                $documents = UserDocuments::where('active', 1)->orderBy($field,$order);

                if(request()->searchName && !isset(request()->searchProgram)){
                     $documents = $documents->where('esemeny_id',request()->searchProgram)->
                     whereIn('felhasznalo_id',
                             \App\User::where('name', 'LIKE', '%'.request()->searchName.'%')
                             ->pluck('id')
                             ->toArray()
                     );
                }
                else{
                    $documents = $documents->where('esemeny_id',request()->searchProgram)->
                    whereIn('felhasznalo_id',
                    \App\User::where('name', 'LIKE', '%'.request()->searchName.'%')
                    ->pluck('id')
                    ->toArray()
                    );
                }

            }

        }
        else
        {
                $documents = UserDocuments::where('active', 1);

                if(request()->searchName){
                     $documents = $documents->
                     whereIn('felhasznalo_id',
                             \App\User::where('name', 'LIKE', '%'.request()->searchName.'%')
                             ->pluck('id')
                             ->toArray()
                     );
                }
                else
                {
                    $documents = $documents->
                     whereIn('felhasznalo_id',
                             \App\User::where('name', 'LIKE', '%'.request()->searchName.'%')
                             ->pluck('id')
                             ->toArray()
                     );
                }

        }

        $programs = Esemeny::orderBy('nev')->get();

        $documents = $documents->paginate(15);

        foreach($documents as $doc)
        {
            if($doc->esemeny_id == -1)
            {
                $doc->esemeny_id = "Általános";
            }
            else
            {
                try{
                    $doc->esemeny_id  = $programs->find($doc->esemeny_id)->nev;
                }
                catch(Exception $e)
                {
                    $doc->esemeny_id = "Törölt program";
                }

            }

        }
        return view('adminisztratorok/onkentes_dokumentumok', compact('documents'))->with('programs',$programs);

    }




    /**
     * Method: POST
     * Uzenetet kuld egy valasztott program usereinek
     */
    public function SendMessage(Request $request)
    {
        $programID = $request->input('warningProgram');
        $esemeny = Esemeny::find($programID);
        $msg = $request->input('MsgContent');

        OmrEmail::SendMailPrograms($msg,$esemeny);

        return back();
    }


    public function delete($id)
    {
        $document = UserDocuments::where('id', $id)->first();
        $document->active = 0;
        $document->save();

        return back();
    }
}
