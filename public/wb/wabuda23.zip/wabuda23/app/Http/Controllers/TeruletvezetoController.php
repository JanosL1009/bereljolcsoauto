<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Models\Teruletvezetok\TeruletvezetokViewModel;
use App\Http\Models\Teruletvezetok\MunkanaplomViewModel;
use App\Model\BeosztasKezeloRepo;
use App\Terulet;
use App\Teruletvezetok;
use App\TeruletCsoportositas;
use App\TeruletBeosztas;
use App\TeruletCsoportositasAzonositok;
use App\FelhasznaloFeladat;
use App\TeruletVezetokTerulet;

class TeruletvezetoController extends Controller
{
    public function Teruleteim()
    {
        $user = auth()->user();
        $UserId = $user["id"];
        $model = new TeruletvezetokViewModel($UserId);
        $model->profilpic = DB_OMR_Operations::GetProfilkep($UserId);

        $terulet_ID_Lista = TeruletVezetokTerulet::where('felhasznalo_id',$UserId)->get(['terulet_id']);
        $teruletListaTeljes = Terulet::whereIn('id',$terulet_ID_Lista->toArray())->paginate();
        //dd($teruletListaTeljes);
        return view('onkentes.teruletvezeto.teruleteim',['teruletListaTeljes' => $teruletListaTeljes])->with('model',$model);
    }


    public function Munkanaplom()
    {
        $user = auth()->user();
        $UserId = $user["id"];
        $model = new MunkanaplomViewModel($UserId);
        $model->profilpic = DB_OMR_Operations::GetProfilkep($UserId);




        return view('onkentes.teruletvezeto.munkanaplom')->with('model',$model);
    }


}
