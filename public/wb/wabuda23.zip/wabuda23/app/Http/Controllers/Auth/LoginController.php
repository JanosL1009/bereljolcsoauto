<?php

namespace App\Http\Controllers\Auth;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use App\Http\Controllers\DB_OMR_Operations;
use App\UserLogins;
use Illuminate\Support\Carbon;
use App\User;
use Illuminate\Support\Str;
class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = '/profil'; //onkentes
    protected $redirectToAdmin = '/admin/esemenyek'; //adminisztrator

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('login')->except('logout');


    }

     /**
     * Handle an authentication attempt.
     *
     * @param  \Illuminate\Http\Request $request
     *
     * @return Response
     */
    public function login(Request $request)
    {
        //$credentials = $request->only('email', 'password');

        $this->validateLogin($request);

        if (method_exists($this, 'hasTooManyLoginAttempts') &&
            $this->hasTooManyLoginAttempts($request)) {
            $this->fireLockoutEvent($request);

            return $this->sendLockoutResponse($request);
        }

        if (self::attemptLogin($request))
        {
            //Authentication passed...
            $user = auth()->user();
            $UserId = $user["id"];

            $permission = self::GetPermissionChecking($UserId);
            //return redirect()->intended($this->redirectTo);
            
            $_User = User::find($UserId);

            switch( $permission)
            {
                case 1:
                    $userlogin = new UserLogins;
                    $userlogin->felhasznalo_id = $UserId;
                    $userlogin->loginDate = Carbon::now();
                    $userlogin->save();
                    $_User->api_token = Str::random(80);
                    $_User->modifier = 1;
                    $_User->save();
                    return redirect($this->redirectToAdmin); //adminisztrator szint
                break;

                case 2: //onkentes
                    $userlogin = new UserLogins;
                    $userlogin->felhasznalo_id = $UserId;
                    $userlogin->loginDate = Carbon::now();
                    $userlogin->save();
                    $_User->api_token = Str::random(80);
                    $_User->modifier = 1;
                    $_User->save();
                    return redirect()->intended($this->redirectTo);
                break;
                case 4: //onkentes aki teruletvezetoi joggal bir...
                    $userlogin = new UserLogins;
                    $userlogin->felhasznalo_id = $UserId;
                    $userlogin->loginDate = Carbon::now();
                    $userlogin->save();
                    $_User->api_token = Str::random(80);
                    $_User->modifier = 1;
                    $_User->save();
                    return redirect()->intended($this->redirectTo);
                break;


                case 6: //felfüggesztett onkentes

                break;
            }


        }

        $this->incrementLoginAttempts($request);

        return $this->sendFailedLoginResponse($request);
    }

     /**
     * Attempt to log the user into the application.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return bool
     */
    protected function attemptLogin(Request $request)
    {
        return $this->guard()->attempt(
            $this->credentials($request), $request->filled('remember')
        );
    }

    /**
     * Jogosultsag ellenorzese
     * A fuggveny lekerei a paramaterben kapott id jogosultsagat
     *
     * @return bool TRUE: admin, FALSE: Onkentes
     */
    protected function GetPermissionChecking($UserId)
    {
        $Level = DB_OMR_Operations::Jogosultsag($UserId);

        return $Level->felhasznaloszint_id;


    }



}
