<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Msg\OmrEmail;
use App\Esemeny;
use App\User;
use Mail;
use App\Mail\Mailer;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\RuhaAtadoAtvetel;
use App\Hirlevel;
use App\HirlevelCsoportTarsitas;
use App\HirlevelUsers;

class EmailOmrController extends Controller
{

    public function SendMailSimple(Request $request)
    {
        $msg = $request->input('EmailMsgContent');
        $mail = $request->input('toMail');
        OmrEmail::SendMailAnUser($mail ,$msg);

        return back();
    }

    /**
     * POST
     */
    public function DocumentsGapsForUsers(Request $request)
    {
        $esemeny = Esemeny::find(17); //request() lesz
        OmrEmail::AccordingToThePrograms('emails.msgblades.DocumentsGapsForUsers',$esemeny);

    }

    /**
     * POST method! AJAX kereshez
     * Route::post('MailARuhaAtadasrol','EmailOmrController@RuhaAtadvaMail');
     */
    public function RuhaAtadvaMail(Request $request)
    {
        $id = $request->input('uid');
        $user = User::find($id);
        $atadoatvetel = RuhaAtadoAtvetel::where('felhasznalo_id',$id)->first();
        $atadoatvetel->mailKuldve = 1;
        $atadoatvetel->save();
        //OmrEmail::GeneralMailSendWithBlade('emails.msgblades.ruhatadvasikeresen',$user->email,'Sikeres ruha felvétel - ÖMR');


        return 1;
    }

    public function sendemail(Request $request)
    {
       // $user=User::whereIn('id',[1882,1885,1895])->get();
        /*
        Mail::queue('emails.msgblades.ruhatadvasikeresen', ['user' => $user],

            function($m) use ($user)
            {
                foreach ($user as $user)
                {
                $m->to($user->email)->subject('Teszt tömeges mail küldés');
                }
            });*/




    }

}

class MyMailer extends Mailable
{
    use Queueable, SerializesModels;
   // public $data;
    /**
    * Create a new message instance.
    *
    * @return void
    */
    public function __construct()
    {
      //  $this->data = $data;
    }

    /**
    * Build the message.
    *
    * @return $this
    */
    public function build()
    {
        return $this->subject('bulk amil')
        ->view('emails.msgblades.ruhatadvasikeresen');
    }
}
