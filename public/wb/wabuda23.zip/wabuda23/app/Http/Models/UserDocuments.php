<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;
use App\Http\Models\I_MagyarazoSzovegek;
use App\Http\Models\TraitMagyarazoSzoveg;

class UserDocuments extends Model
{
    use TraitMagyarazoSzoveg;

    protected $table = 'felhasznalo_dokumentumok';


	public function user()
    {
        return $this->belongsTo('App\User', 'felhasznalo_id');
    }

    public function esemeny()
    {
        return $this->belongsTo('App\Esemeny', 'esemeny_id');
    }

}
