<?php
namespace App\Http\Models\Teruletvezetok;

use \Exception;
use App\Http\Models\AbstractGeneralProfile;
use App\Teruletvezetok;

class MunkanaplomViewModel extends AbstractGeneralProfile
{

}
