<?php
namespace App\Http\Models;

class FelhasznaloHozzaadasaViewModel
{
    public  $jogszint;

    public $Vezeteknev;
    public $Kozepsonev;
    public $Keresztnev;
    public $Nem;
    public $Neme_id;
    public $Telefonszam;
    public $email;
    public $szulido;
    public $szulhely;
    public $EletKor;

    //lakcimeket lekerni
    public  $all_lakcim_orszag;
    public  $all_lakcim_telepules;
    public  $all_lakcim_irszam;
    public  $all_lakcim_utca;

    public  $tart_lakcim_orszag;
    public  $tart_lakcim_telepules;
    public  $tart_lakcim_irszam;
    public  $tart_lakcim_utca;

    public $foteveknyseg;
    public $foteveknyseg_id;

    public $fogyatekossag;
    public $fogyatekossag_id;
    public $FogyLeirasa;

    public $polomeret;
    public $polomeret_id;

    //nyelveket lekerni
    public $nyelv1;public $nyelv2;public $nyelv3;
    public $nyelv1szint;public $nyelv2szint;public $nyelv3szint;

    public function GetTeljesNev()
    {
        return $this->Vezeteknev." ".$this->Kozepsonev." ".$this->Keresztnev;
    }

    public $fotevekenysegHTML;

    public $profilpic;

    /**
     * @var HTML format
     */
    public $Megye_TartLakcim;

    /**
     * @var HTML format
     */
    public $Megye_AllLakcim;

    public $Orszag_TartLakcim;

    public $Orszag_AllandoLakcim;
    /**
     * @var bool
     */
    public $masSzervezetTagja;


    public $MasSzervezetNeve;

/**
     * @var bool
     */
    public $CivilSzervezetTagja;


    public $CivilSzervezetNeve;



}
