<?php
namespace App\Http\Models;

class BeallitasokViewModel extends AbstractGeneralProfile
{
    public $jogszint;
    public $nev;

    public $mode;



}
