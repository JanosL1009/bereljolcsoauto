<?php
namespace App\Http\Models;

use App\EsemenySzervezok;
use App\Http\Models\IGeneralProfile;
use Exception;
use App\Jogosultsag;
use App\EtkezesiIgenyek;
use App\FelhasznaloInfo;
use App\Teruletvezetok;
use App\Model\Felhasznalo;

abstract class AbstractGeneralProfile implements IGeneralProfile
{
    public $profilepic;
    public $profilpic;
    public $breadcrumb = null;
    protected $DressPermission = false;

    public $onkentesOrakSzama = 0;

    /**
     * Az aktualis felhasznalo id ja-> users->id
     * @var int
     */
    protected $id = null;

    /**
     * Altalanos jogszint
     * @var Integer
     */
    protected $jogszint = 0;

    /**
     * True erteket vesz fel, ha valamelyik teruletvezeto.
     * @var Boolean
     */
    protected $TeruletvezetoJog = false;

    /**
     * True erteket vesz fel, ha valamelyik programnál esemenyszervezo.
     * @var Boolean
     */
    protected $EsemenySzervezoJog = false;

    public $igazolasIgenyID = 0;
    public $igazolasIgenyLeiras = null;

    private $EtkezesiIgenyIDArray;

    public $EtkezesHTMLOutput = '';

    public $api_token = null;

    /**
     * Az etkezesi igenyeket kell tartalmaznia a DB-bol
     * Formatuma: 1,2,3
     * Ezt kell splittelni egy tombbe => EtkezesiIgenyIDArray
     * @var string
     */
    protected $EtkezesiIgenyek = null;

    /**
     * @param int Az aktualis felhasznali azonosito users->id
     */
    public function __construct(int $ActFelhasznaloId)
    {
        $this->id = $ActFelhasznaloId;
        $this->EtkezesiIgenyIDArray = array();
        $this->SettingDressPermission();
        $this->SetProgramkoodinatorJog();
        $this->SetTeruletvezetoJog();
        try{
            $this->onkentesOrakSzama = Felhasznalo::where('id',$this->id)->first()->onkentesOrakSzama;
        }
        catch(Exception $e)
        {
            $this->onkentesOrakSzama = 0;
        }
        
    }

    private function SettingDressPermission()
    {
        $value = Jogosultsag::where('felhasznalo_id',$this->id)->where('felhasznaloszint_id',7)->get()->toArray();
        if(count($value) == 1)
        {
            $this->DressPermission = true;
        }
        if(count($value) == 0 || !isset($value) || empty($value))
        {
            $this->DressPermission = false;
        }

    }

    public function SetProfilePicture($profilepic)
    {
        $this->profilepic = $profilepic;
    }


    public function GetProfilePic() {
        return $this->profilepic;
    }

    public function GetId()
    {
        return $this->id;
    }

    /**
     * Beallit egy jogosultsagot kezzel
     * @param int
     */
    public function SetJogosultsag($JogSzint)
    {

            if($JogSzint >= 1 && $JogSzint <= 5)
            {
                $this->jogszint = $JogSzint;
            }
            else {throw new Exception('Nem megfelelő jogosultsag!');}
    }

    public function SetTeruletvezetoJog()
    {
        if($this->TeruletvezetoJog == false)
        {
            $szint = Teruletvezetok::where('felhasznalo_id', $this->id)->first();
           // dd($this->id,$szint);
            if($szint !== null)
            {
                $this->TeruletvezetoJog = true;
            }
        }
    }

    public function isTeruletvezetoJog()
    {
        return  $this->TeruletvezetoJog;
    }

    public function SetProgramkoodinatorJog()
    {
        if($this->EsemenySzervezoJog == false)
        {
            $szint = EsemenySzervezok::where('felhasznalo_id', $this->id)->where('szint_id',3)->first();
           // dd($szint);
            if($szint !== null)
            {
                $this->EsemenySzervezoJog = true;
            }
        }
    }

    /**
     * @return Boolean
     */
    public function isEsemenySzervezoJog()
    {
        return  $this->EsemenySzervezoJog;
    }


    public function getJogSzint()
    {
        return $this->jogszint;
    }

   public function setDressPermission($isPermission){
       
        $this->DressPermission = $isPermission;
    }

    /**ruha atado jog */
    public function isDressPermission() : bool
    {
       
        return $this->DressPermission;
    }

    public function setEtkezesiIgenyekArray(string $EtkezesiIgenyek ) : void
    {
        $this->EtkezesiIgenyek = $EtkezesiIgenyek;
        $this->EtkezesiIgenyIDArray = explode(',' , $this->EtkezesiIgenyek);
    }

    /**
     * Visszater a feldarabolt stringel, mint egy tomb.
     * @return Array[int] Etkezesi igenyek, azonositok
     */
    public function getEtkezesiIgenyIDArray() : array
    {
        if(!isset($this->EtkezesiIgenyIDArray))
        {
            throw new Exception('Nem allitottad be a valtozot. Hivahato fgv.: setEtkezesiIgenyekArray() ');
        }
        else return $this->EtkezesiIgenyIDArray;
    }


    /**
     * @version 1.2.0
     * Változtak a lehetőségek... már csak két lehetőség van
     * 2021.03.09
     * @version 1.1.0
     * Ki véve az egyé
     * Ha vissza akarod állítani csak vedd ki a kommenteket és jó lesz!
     * @version 1.0.0.
     * @param bool
     * @return void Html kod output a viewra. Beallitja a valtozot.
     * @uses A controllerbe hivd meg a fgv-t es elo allitja a html kimenetet így bladbe/viewba
     * csak a EtkezesHTMLOutput peldany valtozot kell meghivni.
     */
    public function setEtkezesiIgenyekHTML(bool $zaroltProfilba = null) : void
    {
        $Igenyek = EtkezesiIgenyek::all();
       
        if(!isset($zaroltProfilba) || $zaroltProfilba == false)
        {
            foreach($Igenyek as $dbIgeny)
            {
                $attribute = null; //ezt is dinamikussa kell majd tenni ... DB-be be vinni plusz mezot attributeName nevvel
                switch($dbIgeny->id)
                {
                                case 1: $attribute = "normal"; break;
                                case 2: $attribute = "laktozz"; break;
                                case 3: $attribute = "gluten"; break;
                                case 4: $attribute = "vega"; break;

                 }
                 $checked = false;
                foreach($this->getEtkezesiIgenyIDArray() as $userIgeny)
                {
                    //checked
                    if($userIgeny == $dbIgeny->id)
                    {
                        /*if($dbIgeny->id == '6')
                        {
                            $egyebIgenyLeirasa = FelhasznaloInfo::where('felhasznalo_id',$this->GetId())->first()->etkezesIgenyEgyebLeiras;
                            $this->EtkezesHTMLOutput .= '<input type="checkbox" checked id="'.$attribute.'" name="'.$attribute.'" value="'.$dbIgeny->id.'"><label for="'.$dbIgeny->elnevezes.'">'.$dbIgeny->elnevezes.'</label><br>';

                            $this->EtkezesHTMLOutput .= '<input type="text" class="form-control" value="'.$egyebIgenyLeirasa.'" /><br>';
                        }
                        else*/
                        $this->EtkezesHTMLOutput .= '<input type="radio" checked id="'.$attribute.'" name="etkezes" value="'.$dbIgeny->id.'"> <label for="'.$dbIgeny->elnevezes.'" style="margin-left: 5px;"> '.$dbIgeny->elnevezes.'</label><br>';
                        $checked = true;
                        break;
                    }

                }
                if(!$checked)
                {
                    if($dbIgeny->id == 1)
                    {
                      $this->EtkezesHTMLOutput .= '<input type="radio" checked  id="'.$attribute.'" name="etkezes" value="'.$dbIgeny->id.'"> <label for="'.$dbIgeny->elnevezes.'"  style="margin-left: 5px;"> '.$dbIgeny->elnevezes.'</label><br>';
                  
                    }
                    else $this->EtkezesHTMLOutput .= '<input type="radio"  id="'.$attribute.'" name="etkezes" value="'.$dbIgeny->id.'"> <label for="'.$dbIgeny->elnevezes.'"  style="margin-left: 5px;"> '.$dbIgeny->elnevezes.'</label><br>';
                   /* if($dbIgeny->id == 6)
                    {
                        $this->EtkezesHTMLOutput .= '<input type="text" class="form-control" value="" /><br>';

                    }*/
                }
            }


        }
        else
        {
            foreach($this->getEtkezesiIgenyIDArray() as $userIgeny)
            {
                foreach($Igenyek as $dbIgeny)
                {
                    if($userIgeny == $dbIgeny->id)
                    {
                        /*if($dbIgeny->id == '6')
                        {
                            $egyebIgenyLeirasa = FelhasznaloInfo::where('felhasznalo_id',$this->GetId())->first()->etkezesIgenyEgyebLeiras;

                            $this->EtkezesHTMLOutput .= '<input type="text" class="form-control" readonly value="'.$egyebIgenyLeirasa.'">';
                        }
                        else*/
                        $this->EtkezesHTMLOutput .= '<input type="text" class="form-control" readonly value="'.$dbIgeny->elnevezes.'">';
                    }

                }
            }
        }
        unset($Igenyek);

    }

}
