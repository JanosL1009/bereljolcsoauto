<?php
namespace App\Http\Models;

use App\Http\Models\esemenyek_onkenteseknek_reszleteiViewModel;

class OnkentesJelentkezeseimViewModel extends esemenyek_onkenteseknek_reszleteiViewModel
{

    public $rendezvenySzervezo;
    public $teruletvezetok;
    public $csoportvezetok;

    public $teruletekJelentkezve;
}
