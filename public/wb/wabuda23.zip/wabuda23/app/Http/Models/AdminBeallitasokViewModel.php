<?php
namespace App\Http\Models;

class AdminBeallitasokViewModel extends AbstractGeneralProfile
{
    public $profilkepValtoztatasanaklehetosege;

    public function GetHTMLProfilkepValtoztatsaOutput()
    {
        $output = "";
        if($this->profilkepValtoztatasanaklehetosege == 0)
        {
            $output = '<option value="1">Engedélyezve</option>
            <option value="0" selected>Letiltva</option>';
        }
        else if($this->profilkepValtoztatasanaklehetosege == 1)
        {
            $output = '<option value="1" selected>Engedélyezve</option>
            <option value="0" >Letiltva</option>';
        }
        else{
            $output = '<option selected value>--Kérem válasszon --</option><option value="1" >Engedélyezve</option>
            <option value="0" >Letiltva</option>';
        }
        return $output;
    }
}
