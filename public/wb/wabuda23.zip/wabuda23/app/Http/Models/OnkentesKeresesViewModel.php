<?php
namespace App\Http\Models;

class OnkentesKeresesViewModel extends AbstractGeneralProfile
{
    /**
     * @return array
     */
    public $szemelyek;

    public $programok;

    public $SiteNavAndOp;
}
