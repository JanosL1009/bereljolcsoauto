<?php
namespace App\Http\Models;

interface I_Ertesitesek
{
    public function getMegtekintesekSzama();
    public function getMegtekintesekAranya(); //szazalekban kell visszternie
    public function getMegtekintettVezetoBeosztasuOnkentesek();
    public function getVezetokAkikNemTekintettekMegAzErtesitot();

    public function isRendszerSzintu():bool;

    /**Egy asszoc tombot kell megvalositania
     * ['rendszerszintu','program','terulet','csoport']
     */
    public function getEsemenyhezTartozas():array;
}
