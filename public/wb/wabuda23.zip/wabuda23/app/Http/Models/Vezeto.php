<?php
namespace App\Http\Models;

class Vezeto
{
    protected $felhasznalo_id;
    protected $felhasznaloSzintId;
    public $Nev;
    public $FelhasznaloSzint;
}

