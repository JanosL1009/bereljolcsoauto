<?php
namespace App\Http\Models;

/**
 * Implementáljuk es kidolgozzuk a logikat az interface-hez:I_MagyarazoSzovegek
 * Ezzel a trait-el biztosítjuk, hogy a kod egy helyen legyen valtoztathato de tobb osztalyba legyen hasznalhato
 *
*/
trait TraitMagyarazoSzoveg
{
    /**
     * Assoc tomb
     * @var Array
     */
    protected $MagyarazoSzovegekArray = null;

    /**
     * Key-value parok beallitasa
     * Egy assoc tombot fogunk generalni.
     * @param string  Key: a szoveg tartalma a DB-bol
     * @param string  Kulcs: a magyarzo szoveg rovid neve, amire hivatkozhatunk majd afrontenden
     */
    public function setMagyarazoSzovegek(string $key, string $describe)
    {
        /**
         * Ha nincs beallitva a tomb akkor array() declaraljuk
         */
        if(!isset($this->MagyarazoSzovegekArray))
        {
            $this->MagyarazoSzovegekArray = array();
        }
        $assocArray = array(
            $key => $describe
        );

        array_push($this->MagyarazoSzovegekArray,$assocArray);
    }

    /**
     * @param string A kulcs aminek az erteket ki vissza akarjuk kapni a frontendre
     * @return string Visszater az assoc tomb egy ertekevel (leiras) a kulcs alapjan
     */
    public function getMagyarazoSzoveg(string $mykey) : string
    {
        $notMatch = false;
        if($this->isMagyarazoSzovegekArray())
        {
           // dd($this->MagyarazoSzovegekArray[1]["semmi"]);
            foreach($this->MagyarazoSzovegekArray as $item)
            {

                foreach($item as $key => $value)
                {
                    if($key == $mykey)
                    {
                        unset($notMatch);
                       return $value;
                    }
                    else{
                        $notMatch = true;
                    }

                }


            }
        }
        else
        {
            return "Empty";
        }

        if(!$notMatch)
        {
            return "Nincs talalat";
        }
    }

    /**
     * Mezo ellenorzesehez letrehozva.
     * Ezzel a fgv-el lehet viszgalni, hogy a valtozo be van allitva.
     * @return bool
     */
    public function isMagyarazoSzovegekArray() : bool
    {
        if(isset($this->MagyarazoSzovegekArray))
            return true;
        else
            return false;
    }


}
