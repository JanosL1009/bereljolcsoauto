<?php
namespace App\Http\Models;

class AdminTeruletModel
{
    public $esemenyID;
    public $terulet_neve;
    public $terulet_leiras;

    public $kezdesIdopont;
    public $befejezesIdopont;

    public $tervezettLetszam;

    public $jelentkezokSzama = 0;

    public $teruletHelyszine;

    public $teruletAktiv;

}
