<?php
namespace App\Http\Models\Beosztas;
use \Exception;
use App\Http\Models\AbstractGeneralProfile;

class OnkenteBeosztViewModel extends AbstractGeneralProfile
{
    public $jogszint;
    public $nev;

    public $esemeny;
    public $terulet;
    public $csoport;

    public $esemenyHelyszinek;
    public $teruletHelyszinek;

    public $esemenyKoordinatorok;
    public $teruletVezetok;
    public $csoportVezetok;

    public $mode;
    public $state;

    public $profilpic;

    public $breadcrumb;

    public $UsersFreeTimes;

    protected $oraElszamolas = 0;

    /**
     * Setter fgv. Oraszamot csak annak allithatunk be aki mar archiv allpotban van. Az aktivnak nem lehet
     * mert meg fut a program/rendezveny ezaltal nem tudhatjuk, h megjelent-e
     * Beallitja a $oraElszamolas valotozot.
     * @param int OnkentesOraszam, amit a vezető igazolt
     */
    public function setOraElszamolas(int $OnkentesOraszam)
    {
        if($this->mode = "archiv" && ($this->state = "onkentes" || $this->state = "vezeto"))
        {
            $this->oraElszamolas = $OnkentesOraszam;
        }
        else
        {
            throw new Exception("Kizarolag archiv modban tudsz ora elszámolást csinálni, mert az aktív állapotban még nem jelent meg a rendezvényen!");
        }
    }

    /**
     * Visszater a szablyos ora elszamolassal
     * @return int Oraszam
     */
    public function getOraElszamolas()
    {
        return $this->oraElszamolas;
    }




}
