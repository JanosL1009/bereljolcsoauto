<?php
namespace App\Http\Models;
use App\Http\Models\AbstractGeneralProfile;

class AdminRiportsViewModel extends AbstractGeneralProfile
{

    protected $urlget = null;

    public function setViewerURL(string $param = null)
    {
        $this->urlget = $param;
    }

    public function getViewerURL()
    {
        if(isset($this->urlget))
        {
            return $this->urlget;
        }
        else 
        {
            return "felhasznalok";
        }
        
    }


}