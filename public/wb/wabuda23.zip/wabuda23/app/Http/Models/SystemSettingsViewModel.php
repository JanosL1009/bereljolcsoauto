<?php
namespace App\Http\Models;

class SystemSettingsViewModel  extends AbstractGeneralProfile
{


}
