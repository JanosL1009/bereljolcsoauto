<?php
namespace App\Http\Models;
use App\Http\Models\AbstractGeneralProfile;
use App\Http\Models\I_MagyarazoSzovegek;
use App\Http\Models\TraitMagyarazoSzoveg;
use App\Egyhazmegyek;
use App\UserEgyhazmegye;
use Exception;

class profilszerkesztesViewModel extends AbstractGeneralProfile implements I_MagyarazoSzovegek
{
    use TraitMagyarazoSzoveg;

    /**
     * Class constructor.
     */
    public function __construct(int $ActFelhasznaloId)
    {
        parent::__construct($ActFelhasznaloId);
        $this->EgyhazMegyeHTMLOutput = $this->GetEgyhazMegyeHTMLOutput($ActFelhasznaloId);
    }

    public $id;

    public  $jogszint;

    public $Vezeteknev;
    public $Kozepsonev;
    public $Keresztnev;
    public $Nem;
    public $Neme_id;
    public $Telefonszam;
    public $email;
    public $szulido;
    public $szulhely;
    public $EletKor;

    //lakcimeket lekerni
    public  $all_lakcim_orszag;
    public  $all_lakcim_telepules;
    public  $all_lakcim_irszam;
    public  $all_lakcim_utca;

    public  $tart_lakcim_orszag;
    public  $tart_lakcim_telepules;
    public  $tart_lakcim_irszam;
    public  $tart_lakcim_utca;

    public $foteveknyseg;
    public $foteveknyseg_id;

    public $munkakor;
    //at kerult  az AbstractGeneralProfile ba! 2021 02 18
    //public $onkentesOrakSzama = 0; 

    public $fogyatekossag;
    public $fogyatekossag_id;
    public $FogyLeirasa;

    public $polomeret;
    public $polomeret_id;

    public $nevelotag = null;

    //nyelveket lekerni
    public $nyelv1;public $nyelv2;public $nyelv3; public $nyelv4; public $nyelv5;
    public $nyelv1szint;public $nyelv2szint;public $nyelv3szint;public $nyelv4szint;
    public $nyelv5szint;

    public function GetTeljesNev()
    {
        if(isset($this->nevelotag))
        {
            return $this->nevelotag." ".$this->Vezeteknev." ".$this->Kozepsonev." ".$this->Keresztnev;
        }
        else{
            return $this->Vezeteknev." ".$this->Kozepsonev." ".$this->Keresztnev;
        }
        
    }

    public $fotevekenysegHTML;

    public $profilpic;

    /**
     * @var HTML format
     */
    public $Megye_TartLakcim;

    /**
     * @var HTML format
     */
    public $Megye_AllLakcim;

    public $Orszag_TartLakcim;

    public $Orszag_AllandoLakcim;
    /**
     * @var bool
     */
    public $masSzervezetTagja;


    public $MasSzervezetNeve;

/**
     * @var bool
     */
    public $CivilSzervezetTagja;


    public $CivilSzervezetNeve;

    public $magassag;
    public $fejkormeret;
    public $konfekciomeret;

    public $szakallnovesztes;


    /**
     * @var boolean
     */
    public $kepmodositas = true;

    public $anyjaneve = "", $szemigszam ="", $allampolgarsag = "";



    public $polotipusa;

    public function GetHTMLPolotipusa()
    {
        $output = null;
        if($this->polotipusa == 1 || $this->polotipusa == '1' )
        {
            $output = '<option value="0">Női</option><option value="1" selected>Férfi</option>';
        }else if($this->polotipusa == 0 || $this->polotipusa == '0')
        {
            $output = '<option value="0" selected>Női</option><option value="1" >Férfi</option>';
        }
        else
        {
            $output = '<option value="0">Női</option><option value="1">Férfi</option>';
        }
        return $output;
    }


   /* public function GetHTMLNadragtipusa()
    {
        $output = null;
        if($this->polotipusa == 1 || $this->polotipusa == '1' )
        {
            $output = '<option value="0">Női</option><option value="1" selected>Férfi</option>';
        }else if($this->polotipusa == 0 || $this->polotipusa == '0')
        {
            $output = '<option value="0" selected>Női</option><option value="1" >Férfi</option>';
        }
        else
        {
            $output = '<option value="0">Női</option><option value="1">Férfi</option>';
        }
        return $output;
    }*/

    public $BeszelhetoNyelvek;

    /**
     * A zarolt profilba visszater a egy html elemmel!
     * A valtozot a GetEgyhazMegyeHTMLOutput fgv allitja be!
     * Default: "" ures string
     * @var string HTML output
     */
    public $EgyhazMegyeHTMLOutput = "";

    /**
     * A zarolt profilba!
     * $EgyhazMegyeHTMLOutput valtozot allitja alaphelyezetbe.
     * Itt ajánlott meghívni: konstruktor
     * @return string
     */
    protected function GetEgyhazMegyeHTMLOutput(int $id) : string
    {
        $userEgyhaz = UserEgyhazmegye::where('felhasznalo_id',$id)->first();
        $egyhaz = null;
        $felekezet = 'null';
        try{
            $egyhaz = Egyhazmegyek::find($userEgyhaz->egyhazmegye_id);
            if(isset($egyhaz->felekezet))
            {
                $felekezet = $egyhaz->felekezet;
            }

        }
        catch(Exception $e)
        {
            $felekezet = 'default';
        }


        $htmlResult = "";
        if($felekezet == 'default')
        {
            $htmlResult = '<input type="text" class="form-control col-12 col-md-12" readonly disabled value="--- Nincs megadva ---">';

        }
        else
        {
            switch((string)$felekezet)
            {
                case 'Római Katolikus Egyház':
                    $Elem1 = '<input type="text" class="form-control col-12 col-md-12" readonly disabled value="'.str_replace('Egyház', '',$felekezet).'">';
                    $Elem2 = '<input type="text" class="form-control col-12 col-md-12" readonly disabled value="'.$egyhaz->nev.'" />';
                    $htmlResult = $Elem1.$Elem2;
                break;
                case 'Görög Katolikus Egyház':
                    $Elem1 = '<input type="text" class="form-control col-12 col-md-12" readonly disabled value="'.str_replace('Egyház', '',$felekezet).'">';
                    $Elem2 = '<input type="text" class="form-control col-12 col-md-12" readonly disabled value="'.$egyhaz->nev.'">';
                    $htmlResult = $Elem1.$Elem2;
                break;
                case 'Egyéb':
                    $htmlResult = '<input type="text" class="form-control col-12 col-md-12" readonly disabled value="'.$userEgyhaz->egyebInputValue.'">';
                break;
                case 'egyéb':
                    $htmlResult = '<input type="text" class="form-control col-12 col-md-12" readonly disabled value="'.$userEgyhaz->egyebInputValue.'">';
                break;
                case 'Nem tartozom felekezethez':
                    $htmlResult = '<input type="text" class="form-control col-12 col-md-12" readonly disabled value="'.$egyhaz->nev.'">';
                break;

                default:
                    $htmlResult = '<input type="text" class="form-control col-12 col-md-12" readonly disabled value="--- Nincs megadva ---">';
                break;
            }
        }


        return $htmlResult;
    }
}
