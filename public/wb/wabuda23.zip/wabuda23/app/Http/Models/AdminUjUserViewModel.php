<?php
namespace App\Http\Models;

class AdminUjUserViewModel
{

}
