<?php
namespace App\Http\Models\Muszak;

use \Exception;
use App\Http\Models\AbstractGeneralProfile;

class MuszakFelvetelIndexViewModel extends AbstractGeneralProfile
{

    public $csoport = null;
    public $esemenyID = 0;

    /**a  csoport napjait tartalmazza majd, asszoc tomb lesz */
    public $munkaNapokArray = null;

    public $kivalasztottNap = null;

    /**
     * @var int
     */
    public $MuszakID = null;

    public $muszakIgazoltak = null;

    /**
     * @var Collection
     */
    public $csoportTagok = null;

    public $breadcrumblink;

}
