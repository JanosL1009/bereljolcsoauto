<?php
namespace App\Http\Models;

class AdminHirlevelViewModel extends AbstractGeneralProfile
{






}
