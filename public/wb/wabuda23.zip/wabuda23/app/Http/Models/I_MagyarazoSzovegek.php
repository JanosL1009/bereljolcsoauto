<?php
namespace App\Http\Models;
/**
 * Az interface az onkentes oldali ViewModelelkre kell, hogy vonatkozzon!
 * A projekt es a rendszer megkoveteli az oldlankénti magyarazo szovegek elhelyezeset,
 * ezert meg kell kovetelnunk a ennek az interfacnek a kotelezo megvalositasat!
 */
interface I_MagyarazoSzovegek
{
    public function setMagyarazoSzovegek(string $key, string $describe);
    public function getMagyarazoSzoveg(string $key);
    public function isMagyarazoSzovegekArray();
}


