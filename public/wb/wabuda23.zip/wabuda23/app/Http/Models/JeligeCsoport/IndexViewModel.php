<?php
namespace App\Http\Models\JeligeCsoport;

use \Exception;
use App\Http\Models\AbstractGeneralProfile;


class IndexViewModel extends AbstractGeneralProfile
{
    /** @var AssocArray Syntax:  [ "id" => id(int), "jelige" => string, "letrehozo" =>string ]*/
    public $JeligeCsoportok  = array();

    public $mode = "";

    public function getMode() : string
    {
        return $this->mode;
    }

}
