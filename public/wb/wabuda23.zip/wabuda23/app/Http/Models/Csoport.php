<?php
namespace App\Http\Models;
use  App\Http\Models\AbstractGeneralProfile;

class Csoport extends AbstractGeneralProfile
{
    protected $CsoportID;

    /**
     * Class constructor.
     */
    public function __construct(int $UserID,int $CsoportID)
    {
        parent::__construct($UserID);
        $this->CsoportID = $CsoportID;
    }

    public $CsoportNeve;

    public $kezdesDatuma;
    public $kezdesIdeje;
    public $befejezesDatuma;
    public $befejezesIdeje;

    public $helyszin_id;
    public $helyszin;

    public $igenyeltOnkentesLetszam;
    public $JelentkezokSzama;

    public $BeosztottakSzama;

    public $CsoportVezetoVan = false;

    public function Ora($ido)
    {
        $ora = null;

        if(isset($ido))
        {
                $pieces = explode(":", $ido);
                $ora = $pieces[0];
        }

        return $ora;
    }

    public function Perc($ido)
    {
        $perc = null;

        if(isset($ido))
        {
                $pieces = explode(":", $ido);
                $perc = $pieces[1];
        }

        return $perc;
    }

    public $Leiras;
    public $terulet_id;
    public $teruletNeve;

    public function GetCsoportID()
    {
        return $this->CsoportID;
    }

    /**
     * Parameternek adjunk true-t ha az adott csoportnak mar van vezetoje
     * @param bool Default: false
     */
    public function setCsoportVezeto(bool $exist = false) : void
    {
        $this->CsoportVezetoVan = $exist;
        unset($exist);
    }

    /**
     * visszater egy boolean ertekkel, hogy van e vezetoje a csoportnak
     * Default: false
     * @return bool
     */
    public function isCsoportVezeto() : bool
    {
        if($this->CsoportVezetoVan)
            return true;
        else
        {
            return false;
        }
    }

    public $breadcrumblink = null;
}
