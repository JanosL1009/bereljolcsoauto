<?php

namespace App\Http\Models;

class AdminEsemenyTelepulesViewModel
{
    public $id;

    public $Telepulesnev;

    public $cim;
}
