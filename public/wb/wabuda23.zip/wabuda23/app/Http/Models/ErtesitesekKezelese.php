<?php
namespace App\Http\Models;

use App\Ertesitesek;
use App\ErtesitesMegtekintese;
use App\ErtesitesProgram;
use App\ErtesitesUsers;
use App\Http\Models\I_Ertesitesek;
use Carbon\Carbon;
use Exception;
use App\User;
use App\Esemeny;
use App\Terulet;
use App\Csoport;
use App\Model\BeosztasKezeloRepo;

/**
 * Az ertesiteseket kezeli. Elkesziti a statisztikákat, jelenteseket, a userekrol is es az onkenteseknek
 * is o kezeli a megtekinteseit/esemenyeit.
 */
class ErtesitesekKezelese implements I_Ertesitesek
{
    protected $ErtesitesID = 0;

    protected $ActUserID = 0;

    protected $ErtesitesNev = null;
    protected $Created_at = null;
    protected $LetrehozoID = 0;
    protected $LetrehozoNeve = null;

    private $Ertesites = null;
    private $ErtesitesProgram = null;

    private $ErtesitesreFeliratkozottakSzama = 0;
    private $megtekintesekSzama = 0;

    /**
     * @param int Az ertesites id-ja, aminek a statisztikait es jelenteseit leszeretnénk kérdezni
     */
    public function __construct(int $ertesitesID = null)
    {
        if(isset($ertesitesID))
        {
            $this->ErtesitesID = $ertesitesID;
            $this->Ertesites = Ertesitesek::find($ertesitesID);
            $this->ErtesitesProgram = ErtesitesProgram::where('ertesites_id',$this->Ertesites->id)->first();
            $this->MezoBeallito();
        }


    }

    private function MezoBeallito() : void
    {
        $this->ErtesitesNev = $this->Ertesites->nev;
        $this->Created_at = $this->Ertesites->Created_at;
        $this->LetrehozoID = $this->Ertesites->letrehozo;
        //dd($this->LetrehozoID);
        $user = User::find($this->LetrehozoID);
        $this->LetrehozoNeve = $user->name;
    }

    /**
     * Az ertesites neve
     * @return string Visszater az ertesites nevevvel
     */
    public function getErtesitesNeve() : string
    {
        return $this->ErtesitesNev;
    }

    public function getErtesitesTartalma():string
    {
        return $this->Ertesites->tartalom;
    }

    /**
     * Visszater egy model osszes adataval
     * @return Ertesitesek Visszater egy ertesites elquent modelel
     */
    public function getTeljesErtesites()
    {
        return $this->Ertesites;
    }

    /**
     * Egyben a letrehozas ideje is.
     * @return Timestamp
     */
    public function getErtesitesKikuldve()
    {
        return $this->Created_at;
    }

    /**
     * Egyben a kikuldo nevet is jelenti!
     *@return string Visszater a letrehozo/kuldo nevevel
     */
    public function getLetrehozoNeve() : string
    {
        return $this->LetrehozoNeve;
    }

    public function setActuallyUserID()
    {
        if($this->ActUserID == 0)
        {
            $user = auth()->user();
            $this->ActUserID = $user['id'];
        }

    }



    /**
     * a notification.js ben sezereplo ablakhoz tartozik, amikor ra kattintaz onkentes a gombra
     * @param int Ha a JS-be akaruk hasznali
     * @param int[] Az ertesitesek oldalon szereplo lista
     */
    public function setMegtekintve(int $OnkentesUserID = null,int $ertesitesID,array $ertesitesAzonositok = null)
    {
        if(!isset($this->ErtesitesProgram->id))
        {
            $this->ErtesitesID = $ertesitesID;
            $this->Ertesites = Ertesitesek::find($ertesitesID);
            $this->ErtesitesProgram = ErtesitesProgram::where('ertesites_id',$this->Ertesites->id)->first();
            $this->MezoBeallito();
        }
        $NotSetUser = false; $NotSetAzonositok = false;
        if(isset($OnkentesUserID))
        {
            $ertmegtekint = new ErtesitesMegtekintese;
            $ertmegtekint->felhasznalo_id = $OnkentesUserID;
            $ertmegtekint->ertestesek_id = $ertesitesID;
            $ertmegtekint->megtekintve = 1;
            $ertmegtekint->ert_program_id = $this->ErtesitesProgram->id;
            $ertmegtekint->save();

            $ertusers = ErtesitesUsers::where('felhasznalo_id',$OnkentesUserID)->where('ertesites_id',$ertesitesID)->
            where('megtekintve',0)->first();
            $ertusers->megtekintve = 1;
            $ertusers->megtekintes_ideje = Carbon::now();
            $ertusers->save();
        }
        else
            $NotSetUser = true;

        if($ertesitesAzonositok)
        {}
        else $NotSetAzonositok = true;

        if($NotSetUser == true && $NotSetAzonositok == true)
        {
            throw new Exception('Valamit kotelezoen kell hasznalni a parameterek kozul!!!');
        }
    }
    /**
     * Ekkor tudjuk, KONKRÉTAN, hogy mire kattintott, ezért egyertelmuen be lehet allitani a lathatosagot..
     */
    /*
        *Masodik parameter, amiokor kozvetlenul a menure, vagy apaginate->linksen keresztul erkezik, az adott oldalon szereplo
        *azonositok listaja szerint allitja be hogy megnezte oket.
     */




     /**
      * Egy ertesites megtekintesinek szamaval ter vissza
      * @return int Megtekintesek szama
      */
    public function getMegtekintesekSzama()
    {
        $this->megtekintesekSzama = ErtesitesMegtekintese::where('ertestesek_id',$this->ErtesitesID)->where('megtekintve',1)->count();
        return $this->megtekintesekSzama;
    }

    /**
     *
     * @return double
     */
    public function getMegtekintesekAranya() : float
    {
        $p1 =  ($this->ErtesitesreFeliratkozottakSzama/100);
        return ($this->megtekintesekSzama/$p1);
    }

    public function getMegtekintettVezetoBeosztasuOnkentesek()
    {
        $ertesitesusers = ErtesitesUsers::where('ertesites_id',$this->ErtesitesID)->where('megtekintve',1)
        ->get(['felhasznalo_id','updated_at']);
        $usersid = $ertesitesusers->pluck('felhasznalo_id')->toArray();
        $esemenyhezTartozas = $this->getEsemenyhezTartozas();
        $beosztaskezelo = new BeosztasKezeloRepo(null,intval($esemenyhezTartozas["ProgramID"]),intval($esemenyhezTartozas["TeruletID"]),null);

        $teruletvezetok = $beosztaskezelo->getTeruletVezetokListaja();
        $teruletvezetokID = $teruletvezetok->pluck('id')->toArray();
        $csoportvezetok = $beosztaskezelo->getCsoportVezetokListaja();
        $csoportvezetokID = $csoportvezetok->pluck('id')->toArray();

        $ertMegtekint = ErtesitesMegtekintese::whereIn('felhasznalo_id',$teruletvezetokID)->
        where('ertestesek_id',$this->ErtesitesID)->get();

        $res0 = array_intersect($usersid,$csoportvezetokID );
        $res1 = array_intersect($usersid,$teruletvezetokID );
        $result = array_merge($res0,$res1);

        $resultUsers = User::whereIn('id',$result)->get(['id','name']);

        return $resultUsers;


    }


    public function getVezetokAkikNemTekintettekMegAzErtesitot(){

        $ertesitesusers = ErtesitesUsers::where('ertesites_id',$this->ErtesitesID)->where('megtekintve',0)
        ->get(['felhasznalo_id','updated_at']);
        $usersid = $ertesitesusers->pluck('felhasznalo_id')->toArray();
        $esemenyhezTartozas = $this->getEsemenyhezTartozas();
        $beosztaskezelo = new BeosztasKezeloRepo(null,intval($esemenyhezTartozas["ProgramID"]),intval($esemenyhezTartozas["TeruletID"]),null);

        $teruletvezetok = $beosztaskezelo->getTeruletVezetokListaja();
        $teruletvezetokID = $teruletvezetok->pluck('id')->toArray();
        $csoportvezetok = $beosztaskezelo->getCsoportVezetokListaja();
        $csoportvezetokID = $csoportvezetok->pluck('id')->toArray();

        $ertMegtekint = ErtesitesMegtekintese::whereIn('felhasznalo_id',$teruletvezetokID)->
        where('ertestesek_id',$this->ErtesitesID)->get();

        $res0 = array_intersect($usersid,$csoportvezetokID );
        $res1 = array_intersect($usersid,$teruletvezetokID );
        $result = array_merge($res0,$res1);

        $resultUsers = User::whereIn('id',$result)->get(['id','name']);

        return $resultUsers;
    }

    public function isRendszerSzintu():bool
    {
        if($this->ErtesitesProgram->allusers == 1)
        {
            return true;
        }
        else return false;
    }

    /**Egy asszoc tombot kell megvalositania
     * ['rendszerszintu','program','terulet','csoport']
     */
    public function getEsemenyhezTartozas():array
    {
        $esemeny = Esemeny::find($this->ErtesitesProgram->esemeny_id);
        $terulet = null;
        if(isset($this->ErtesitesProgram->terulet_id))
        {
            $terulet = Terulet::find($this->ErtesitesProgram->terulet_id);
        }

        $csoport = Csoport::find($this->ErtesitesProgram->csoport_id);
        $retArr = [
            'RendszerSzintu' => $this->isRendszerSzintu(),
            'ProgramNeve' => $esemeny->nev??'',
            'ProgramID' => $esemeny->id??0,
            'TeruletNeve' => $terulet->nev??'',
            'TeruletID' => $terulet->id??0,
            'CsoportNeve' => $csoport->nev??'',
            'CsoportID' => $csoport->id??0,
        ];

        unset($esemeny); unset($terulet); unset($csoport);

        return $retArr;
    }

    /**
     * Visszater egy onkenteshez tartozo ertesitesek listajaval
     */
    public function getErtesitesekOnkentesnek(int $OnkentesID)
    {
        $ertesitesekListaja = ErtesitesUsers::where('felhasznalo_id',$OnkentesID)->orderby('created_at','desc')->get();
       return $ertesitesekListaja;
    }

    public function getLegfrissebb_NEM_OlvasottErtesites()
    {
        $this->setActuallyUserID();
        $uid = auth()->user();
       
        $userErtesitesei = ErtesitesUsers::where('felhasznalo_id',$uid["id"])
        ->where('megtekintve',0)->orderby('created_at')->first();

        
        $ertesites = null;
        try{
            $ertesites = Ertesitesek::find($userErtesitesei->ertesites_id)->toJson();
        }
        catch(Exception $e)
        {
            return  $ertesites;
            $ertesites = json_encode("empty",200);
        }
        finally{
            return $ertesites;
        }

        return $ertesites;
    }


    /**
     * Visszater egy szammal, ami a lfeiratkozok szamat jelenti. Az ertek automata beallitodik a notification letrehozasaokr!
     */
    public function getErtesitesreFeliratkozottakSzama() : int
    {
        $this->ErtesitesreFeliratkozottakSzama = ErtesitesUsers::where('ertesites_id',$this->ErtesitesID)->count();
        return $this->ErtesitesreFeliratkozottakSzama;
    }



}
