<?php

namespace App\Http\Models\Koordinatorok;
use App\Http\Models\AdminEsemenyViewModel;

class EsemenySzerkesztoViewModel extends AdminEsemenyViewModel
{

}
