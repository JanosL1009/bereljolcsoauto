<?php
namespace App\Http\Models\Koordinatorok;

use App\Http\Models\AbstractGeneralProfile;


class EsemenyKoordinatorokViewModel extends AbstractGeneralProfile
{

    /**
     * Tartalmazhatja a userhez kapcsolod esemenyeket, ahol o program koordinator.
     * @var Collection Esemenyek gyujtemenye
     */
    public $esemenyeim = null;

}
