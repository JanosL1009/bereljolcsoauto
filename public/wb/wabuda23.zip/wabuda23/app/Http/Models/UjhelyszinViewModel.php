<?php
namespace App\Http\Models;

use App\Http\Models\AbstractGeneralProfile;

class UjhelyszinViewModel extends AbstractGeneralProfile
{
    /**
     * @return array
     */
    public $helyszinek;


    /**
     * @return Array Assoc array SiteNavAndOperation::getPagesForSearches
     */
    public $SiteNavAndOp;
}
