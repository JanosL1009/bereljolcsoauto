<?php
namespace App\Http\Models\Hirek;

use App\Http\Models\AbstractGeneralProfile;
use App\Http\Models\Hirek;
use Exception;

class HirSzerkeszteseViewModel extends AbstractGeneralProfile
{
    use HirTrait;
    use HirSeoTrait;

    public $RelatedPrograms = [];


}
