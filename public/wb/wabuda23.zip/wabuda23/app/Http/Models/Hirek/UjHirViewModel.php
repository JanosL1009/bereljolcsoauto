<?php
namespace App\Http\Models\Hirek;

use App\Http\Models\AbstractGeneralProfile;

use Exception;

class UjHirViewModel extends AbstractGeneralProfile
{
    /**
     *
     */
    public $RelatedPrograms = array();

}
