<?php
namespace App\Http\Models\Hirek;

use App\Http\Models\AbstractGeneralProfile;
use App\Http\Models\Hirek\HirTrait;
use Exception;

class HirMegjeleneseOnkentes extends AbstractGeneralProfile
{

    use HirTrait;

    /**
     * HTML Content!!!
     */
    public $Leiras;

    public $seo_url;

    public $Description;
    public $keywords;
    public $title;
    public $og_desc;
    public $og_image;
    public $robot;

    /**
     * @var Array[Hir]
     * A legfrisebb hireket kell tartalmazni - last(5)
     */
    public $FrissHirek;

     /**
     * @var Array[Hir]
     * A kapcsolodó hirek. Mivel tobb is lehet az elso helyen kivalasztott
     *  programhoz tartozo legfrisebb hirek lesznek
     *
     */
    public $KapcsolodoHirek;



}

