<?php
namespace App\Http\Models\Hirek;
use Exception;

trait HirSeoTrait {
    public $hs_id;

    /**
     * Rövid max 240 karakteres leiras a description metahoz.
     * @var string
     */
    public $description;

    /**
     * SEO kulcsszavak a meta keywordshoz.
     * @var string
     */
    public $keywords;

    /**
     * Az oldal címe <title/> tagbe!
     * @var string
     */
    public $title;


    public $og_title;
    public $od_desc;

    /**
     *
     * @var Boolean
     *
     */
    protected $robots = false; //default

    protected $og_url;
    public $og_image;

    /**
     * SEO barat url NEM LEHET INT! NEM ID szerint dolgozunk!!!!!
     */
    public function setSeoUrl(string $slug)
    {
        if(gettype($slug) != 'string')
        {
            throw new Exception('String lehet a SLUG!');
        }
        else
        {
            $this->og_url = $slug;
        }

    }

/**
 * Visszater egy valid SLUG-al
 *
 * @return string SLUG
 */
    public function getOG_Url_Slug() : string
    {
        return $this->og_url;
    }


    public function setRobots($bit)
    {
        if(is_int((int)$bit))
        {
            $bit = (int)$bit;
            if($bit == 0 || $bit == 1)
            {
                switch($bit)
                {
                    case 0: $this->robots = false; break;
                    case 1: $this->robots = true; break;
                }
            }
            else
            {
                throw new Exception('0 vagy 1 erteket vehet fel (bit)');
            }
        }
        else
        {
            throw new Exception('Ineteger lehet a mezo erteke.');
        }

    }

    public function isRobots() : bool
    {
        return (bool)$this->robots;
    }

}
