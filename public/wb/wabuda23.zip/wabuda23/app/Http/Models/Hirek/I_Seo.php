<?php
namespace App\Http\Models\Hirek;

interface I_Seo
{
    public function getSlug();
    public function getKeywords();
    public function getDescription();
    public function getSiteTitle();
}
