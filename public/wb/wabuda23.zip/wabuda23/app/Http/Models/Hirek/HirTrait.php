<?php
namespace App\Http\Models\Hirek;

use Exception;

trait HirTrait {
    /**
     * A DB hir tablaban levo h_id erteke
     * @var int
     */
    public $HirID;

    /**
     * A hir cime, ami megjelenik a fron-enden
     * @var string
     */
    public $HirCime;

    /**
     * A hir tartalma
     * @var string
     *
     */
    public $Leiras;


    public $LetrehozasIdeje;
    public $Frissitve;

    /**
     * A megtekintesek szama
     * @var int
     */
    public $Megtekintve;

/**
 * A hir statusz: megjelenhet a nyilvanossag elott, vagy nem.
 * 0: A hir szerkesztes alatt van, csak admin oldalon lathato.
 * 1: A hir aktiv. Megjelenik az onnkentes oldalon, tehat publikalva van.
 * @var int
 */
    protected $Statusz;

    public function setStatusz($Statusz) : void
    {
        //$Statusz = (int)"1";

       
            if(is_int((int)$Statusz))
            {
                if((int)$Statusz == 0 || (int)$Statusz == 1)
                {
                    $this->Statusz = (int)$Statusz;
                }
                else
                {
                    throw new Exception('Az ertek 0 vagy 1 lehet!');
                }
               
            }
            else
            {
                 throw new Exception('Egesz (integer) tipus lehet a mezo erteke es 0 vagy 1 erteket veheti fel!');
                }

    }

    public function getStatusz() : int
    {
        return $this->Statusz;
    }

    /**
     * A hir megjeleniteset szabalyozza.
     * Lehetseges allapotok:
     * 0: Csak regisztralt tagok elott jelenik meg
     * 1: Publikus hir
     * 2:Mindekinek megjelenhet a hir
     * @var int
     */
    protected $HirMegjelenese;

    public function setHirMegjelenese($MegjelenesID) : void
    {
        if(is_int((int)$MegjelenesID))
            {
                if($MegjelenesID == 0 || $MegjelenesID == 1 || $MegjelenesID == 2)
                {
                    $this->HirMegjelenese = (int)$MegjelenesID;
                }
                else
                {
                    throw new Exception('Az ertek 0,1,2 lehet!');
                }
            }
            else
            {
           
             throw new Exception('Egesz (integer) tipus lehet a mezo erteke es 0,1,2 erteket veheti fel!');
            }

    }


    public function getMegjelenes() : int
    {
        return $this->HirMegjelenese;
    }


}
