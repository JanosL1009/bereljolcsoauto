<?php
namespace App\Http\Models;

use Exception;
use Illuminate\Support\Facades\Request;
use App\Model\Felhasznalo;
use Illuminate\Support\Carbon;

class CustomProfileValidator 
{
    public $IsFormValid = null;

    public $message;
    public $EmptyFieldsList = array();

    protected $isGeneral = true; protected $isAllando = true;
    protected $isTartLakcim = true;
    protected $isSzervezet = true;protected $isCivil = true;
    protected $isFogy = true; protected $isRuha = true; protected $isRuhaTipus = true;
    protected $isEgyhazKozosseg = true; protected $isAdatkezelesi = true;
    protected $isFotev = true;
    protected $isEgyebszervezet = true;
    protected $isCivilszervezet = true; protected $isProfilkep = true;
    protected $age = 0;

    public function __construct()
    {
        $this->IsFormValid = true; //a form nem valid
        $this->message = null;
    }


    public function setISFormValid()
    {
        if($this->isGeneral && $this->isAllando && $this->isTartLakcim && $this->isCivil && $this->isSzervezet && $this->isFogy && $this->isEgyebszervezet && $this->isCivilszervezet
        && $this->isRuha && $this->isRuhaTipus && $this->isEgyhazKozosseg && $this->isFotev && $this->isAdatkezelesi && $this->isProfilkep)
        {
            $this->IsFormValid = true;
        } else $this->IsFormValid = false;
    }

    public function is_FormValid()
    {
        
        return $this->IsFormValid;
    }

    /**
     * @return string
     */
    public function getMessage()
    {
        return $this->message;
    }

    public function ProfilPic($id){
        $kep = Felhasznalo::find($id);
        if($kep->profilkep == "blank-profile-pic-omr.png")
        {
            $this->isProfilkep = false;
            array_push($this->EmptyFieldsList,'blankprofile');
            $this->message = $this->message .'<li>A profilkép feltöltése kötelező!</li>';
        }
    }
    
    public function getEmptyFieldsList() : array
    {
        return $this->EmptyFieldsList;
    }

    public function setGenerals($vezeteknev,$keresztnev,$telefonszam,$szulEv,$szulHonap,$szulNap,$szulHely,$Neme,$AnyjaNeve,$allampolgarsag,$szemigszam)
    {
        $veznev_valid = false; 
        if(isset($vezeteknev))
        {
            $veznev_valid = true;
        }

        $kernev_valid = false; 
        if(isset($keresztnev))
        {
            $kernev_valid = true;
        }

        $telefonszam_valid = false; 
        if(isset($telefonszam))
        {
            $telefonszam_valid = true;
        }

        $szulEv_valid = false; 
        if(isset($szulEv))
        {
            if($szulEv == '--')
            {
                $szulEv_valid = false;
            } else  $szulEv_valid = true;
           // $szulEv_valid = true;
        }

        $szulHonap_valid = false; 
        if(isset($szulHonap))
        {
            $szulHonap_valid = true;
        }

        $szulNap_valid = false; 
        if(isset($szulNap))
        {
            $szulNap_valid = true;
        }

        $szulHely_valid = false; 
        if(isset($szulHely))
        {
            $szulHely_valid = true;
        }

        $Neme_valid = false; 
        if(isset($Neme))
        {
            $Neme_valid = true;
        }

        $AnyjaNeve_valid = false; 
        if(isset($AnyjaNeve))
        {
            $AnyjaNeve_valid = true;
        }

        $allampolgarsag_valid = false; 
        if(isset($allampolgarsag))
        {
            $allampolgarsag_valid = true;
        }

        $szemigszam_valid = false; 
        if(isset($szemigszam))
        {
            $szemigszam_valid = true;
        }

        if( $veznev_valid  && $kernev_valid && $telefonszam_valid && $szulEv_valid && $szulHonap_valid && $szulNap_valid && $szulHely_valid && $Neme_valid && $AnyjaNeve_valid && $allampolgarsag_valid && $szemigszam_valid )
        {
            $this->isGeneral = true; 
        }
        else{
            $this->isGeneral = false; 
            //$EmptyFieldsList
            //message string írása
            if(!$veznev_valid)
            {
                array_push($this->EmptyFieldsList,'vezeteknev');
                $this->message = '<li>A vezetéknév megadása kötelező!</li>';
            }

            if(!$kernev_valid)
            {
                array_push($this->EmptyFieldsList,'keresztnev');
                $this->message = $this->message .'<li>A keresztnév megadása kötelező!</li>';
            }

            if(!$telefonszam_valid)
            {
                array_push($this->EmptyFieldsList,'telefonszam');
                $this->message = $this->message .'<li>A telefonszám megadása kötelező!</li>';
            }

            if(!$szulEv_valid)
            {
                array_push($this->EmptyFieldsList,'szulev');
                $this->message = $this->message .'<li>A születési év megadása kötelező!</li>';
            }

            if(!$szulHonap_valid)
            {
                array_push($this->EmptyFieldsList,'szulhonap');
                $this->message = $this->message .'<li>A születési hónap megadása kötelező!</li>';
            }

            if(!$szulNap_valid)
            {
                array_push($this->EmptyFieldsList,'szulnap');
                $this->message = $this->message .'<li>A születési nap megadása kötelező!</li>';
            }

            //*********************************************** */
           
            if(!$szulHely_valid)
            {
                array_push($this->EmptyFieldsList,'szulhely');
                $this->message = $this->message .'<li>A születési hely megadása kötelező!</li>';
            }
           
            if(!$Neme_valid)
            {
                array_push($this->EmptyFieldsList,'neme');
                $this->message = $this->message .'<li>A <i>Nem</i> megadása kötelező! (Férfi/Nő)</li>';
            }

            /**************************************** */
            
            if(!$AnyjaNeve_valid)
            {
                array_push($this->EmptyFieldsList,'anyjaneve');
                $this->message = $this->message .'<li>Az <i>Anyja neve</i> mező megadása  kötelező!</li>';
            }
            
            if(!$allampolgarsag_valid)
            {
                array_push($this->EmptyFieldsList,'allampolgarsag');
                $this->message = $this->message .'<li>Az <i>Állampolgárság</i> mező megadása  kötelező!</li>';
            }
            if(!$szemigszam_valid)
            {
                array_push($this->EmptyFieldsList,'szemigszam');
                $this->message = $this->message .'<li>A <i>Személyi igazolvány száma</i> mező megadása  kötelező!</li>';
            }


        }
        //$szulEv,$szulHonap,$szulNap
        if($szulEv_valid)
        {
         /*  try 
           {
            $szulido = $szulEv."-".$szulHonap."-".$szulNap;// dd($szulido);
            $this->age = Carbon::parse($szulido)->age;
           }
           catch(Exception $e)
           {
            $this->age = 8;
           }*/
            $szulido = $szulEv."-".$szulHonap."-".$szulNap;// dd($szulido);
           $this->age = Carbon::parse($szulido)->age;
        }
       

    }

    public function setAllando($Orszag,$megye,$telepules,$irszam,$utca)
    {
        $orszag_valid = false; 
        if(isset($Orszag))
        {
            $orszag_valid = true;
        }

        $megye_valid = false; 
        if(isset($megye))
        {
            $megye_valid = true;
        }

        $telepules_valid = false; 
        if(isset($telepules))
        {
            $telepules_valid = true;
        }

        $irszam_valid = false; 
        if(isset($irszam))
        {
            $irszam_valid = true;
        }

        $utca_valid = false; 
        if(isset($utca))
        {
            $utca_valid = true;
        }

        if($orszag_valid && $megye_valid && $telepules_valid && $irszam_valid && $utca_valid)
        {
            $this->isAllando = true;
        }
        else {
             $this->isAllando = false;
                array_push($this->EmptyFieldsList,'allando_orszag');
                $this->message = $this->message .'<li>Az <i>Állandó lakcím</i> csillaggal(*) jelölt mező/mezői kitöltése kötelező!</li>';
            
        }
    }

    public function setTartozkodasi($Orszag,$megye,$telepules,$irszam,$utca)
    {
        $orszag_valid = false; 
        if(isset($Orszag))
        {
            $orszag_valid = true;
        }

        $megye_valid = false; 
        if(isset($megye))
        {
            $megye_valid = true;
        }

        $telepules_valid = false; 
        if(isset($telepules))
        {
            $telepules_valid = true;
        }

        $irszam_valid = false; 
        if(isset($irszam))
        {
            $irszam_valid = true;
        }

        $utca_valid = false; 
        if(isset($utca))
        {
            $utca_valid = true;
        }

        if($orszag_valid && $megye_valid && $telepules_valid && $irszam_valid && $utca_valid)
        {
            $this->isTartLakcim = true; 
        }
        else {
            $this->isTartLakcim = false; 
                array_push($this->EmptyFieldsList,'tartlakcim');
                $this->message = $this->message .'<li>Az <i>Tartózkodási helyem</i> csillaggal(*) jelölt mező/mezői kitöltése kötelező!</li>';
            
        }
    }


    public function setQuestions1($szervezet)
    {
        $szervezet_valid = false; 
        if(isset($szervezet))
        {
            $szervezet_valid = true;
        }

       

        if($szervezet_valid)
        {
            $this->isSzervezet = true;
        }
        else 
        {
            $this->isSzervezet = false; 
            if(!$szervezet_valid )
            {
                array_push($this->EmptyFieldsList,'szervezeterror');
                //dd($this->EmptyFieldsList);
                $this->message = $this->message .'<li>Az <i>Önkénteskedik-e Ön jelenleg más szervezet(ek)nél?</i> jelölt mező/mezői kitöltése kötelező!</li>';
            
            }
           
               
        }

    }

    public function setQuestions2($civil)
    {
       

        $civil_valid = false; 
        if(isset($civil))
        {
            $civil_valid = true;
        }

        if($civil_valid)
        {
            $this->isCivil = true;
        }
        else 
        {
            $this->isCivil = false; 
            if(!$civil_valid )
            {
                array_push($this->EmptyFieldsList,'civilerror');
                $this->message = $this->message .'<li>Az <i>Tagja-e Ön civil szervezetnek vagy valamilyen közösségnek?</i> mező/mezői kitöltése kötelező!</li>';
            
            }
               
        }

    }


    public function setFogy($fogy_valid)
    {
        
        if($fogy_valid)
        {
            $this->isFogy = true;
        }
        else 
        {
            $this->isFogy = false; 
           
                array_push($this->EmptyFieldsList,'fogyerror');
                $this->message = $this->message .'<li>Az <i>Ön fogyatékossággal élő személy?</i> mező/mezői kitöltése kötelező!</li>';
            
            
               
        }
    }

    
    public function setRuha($ruha)
    {
        $valid = false; 
        if(isset($ruha))
        {
            $valid = true;
        }

        if($valid)
        {
            $this->isRuha = true;
        }
        else 
        {
            $this->isRuha = false; 
            if(!$valid )
            {
                array_push($this->EmptyFieldsList,'poloerror');
                $this->message = $this->message .'<li>A <i>Pólómérete?</i> mező kitöltése kötelező!</li>';
            
            }
               
        }
    }

    public function setRuhaTipusa($tipusa)
    {
        if($tipusa)
        {
            $this->isRuhaTipus = true;
        }
        else 
        {
            $this->isRuhaTipus = false; 
            if(!$this->isRuhaTipus)
            {
                array_push($this->EmptyFieldsList,'polotipuserror');
                $this->message = $this->message .'<li>A <i>Póló típusa?</i> mező kitöltése kötelező!</li>';
            
            }
               
        }
    }

    public function setEgyhazKozosseg(bool $allapot)
    {
        $this->isEgyhazKozosseg = $allapot;
        if($this->isEgyhazKozosseg == false)
        {
            array_push($this->EmptyFieldsList,'egyhazmegyeerror');
            $this->message = $this->message .'<li>Nem választott egyházmegyét! Kérjük válasszon!</li>';
        }
    }

    public function setFelekezet($Felekezet)
    {
        

        
            if($Felekezet)
            {
                    $this->isEgyhazKozosseg = true;
               
            }
        else 
        {
            $this->isEgyhazKozosseg = false; 
           
                array_push($this->EmptyFieldsList,'kozossegerror');
                $this->message = $this->message .'<li>A <i>Tagja-e valamelyik egyházközösségnek?</i> mező/mezői kitöltése kötelező!</li>';
            
            
        }

        

    }

    public function setEgyhaz($Kozosseg)
    {
            if($Kozosseg)
            {
                    $this->isEgyhazKozosseg = true;
               
            }
        else 
        {
            $this->isEgyhazKozosseg = false; 
           
                array_push($this->EmptyFieldsList,'kozossegerror');
                $this->message = $this->message .'<li>A <i>Tagja-e valamelyik egyházközösségnek?</i> mező/mezői kitöltése kötelező!</li>';
            
            
        }

    }

    public function EgyhazEgyebInput($allapot)
    {
        if($allapot)
        {
                $this->isEgyhazKozosseg = true;
           
        }
    else 
    {
        $this->isEgyhazKozosseg = false; 
       
            array_push($this->EmptyFieldsList,'kozossegerror');
            $this->message = $this->message .'<li>A <i>Tagja-e valamelyik egyházközösségnek?</i> mező/mezői kitöltése kötelező!</li>';
        
        
    }

    }

    /**Alap adat bekersehez ahasznalni */
    public function setFoteveknyseg(bool $allapot, int $tevID)
    {
      

        if($this->age < 18)
        {
            //dd($this->age);
           if($tevID != 2 || $tevID != 3)
           {
            $this->isFotev = false;
            if(!$this->isFotev)
            {
                array_push($this->EmptyFieldsList,'tevekenysegerror');
                $this->message = $this->message .'<li>A tevékenység megadása kötelező! Kiskorúak kizárólag két főtevékenységet választhatnak: Általános iskolában tanulok, Középiskolában tanulok </li>';
            }
            
           }
        }
        else 
        {
            $this->isFotev = $allapot;
            if(!$this->isFotev)
            {
                array_push($this->EmptyFieldsList,'tevekenysegerror');
                $this->message = $this->message .'<li>A tevékenység megadása kötelező!</li>';
            }
        }
       
    }

    /**resz adat, ha meg van az alap adat */
    public function setFotevFelsoIskola(string $intnev,string $szakirany,int $evfolyam)
    {

        if(!empty($intnev) && !empty($szakirany) && $evfolyam > 0)
        {
            $this->isFotev = true;
            //dd("pedig ures: ".$szakirany);
        }
        else
        {
            $this->isFotev = false;
            array_push($this->EmptyFieldsList,'foteverror');
            $this->message = $this->message .'<li>A választott tevékenység összes mezőjének kitöltése kötelező!</li>';
        
        }
    }

    public function setFotevKozepIskola(string $intnev,int $evfolyam)
    {

        if(!empty($intnev) && $evfolyam > 0)
        {
            $this->isFotev = true;
            //dd("pedig ures: ".$szakirany);
        }
        else
        {
            $this->isFotev = false;
            array_push($this->EmptyFieldsList,'foteverror');
            $this->message = $this->message .'<li>A választott tevékenység összes mezőjének kitöltése kötelező!</li>';
        
        }
    }

    public function setFotevAltIskola(string $intnev,int $evfolyam)
    {

        if(!empty($intnev) && $evfolyam > 0)
        {
            $this->isFotev = true;
            //dd("pedig ures: ".$szakirany);
        }
        else
        {
            $this->isFotev = false;
            array_push($this->EmptyFieldsList,'foteverror');
            $this->message = $this->message .'<li>A választott tevékenység összes mezőjének kitöltése kötelező!</li>';
        
        }
    }

    public function setFotevMunka(string $munkakore)
    {

        if(!empty($munkakore))
        {
            $this->isFotev = true;
            //dd("pedig ures: ".$szakirany);
        }
        else
        {
            $this->isFotev = false;
            array_push($this->EmptyFieldsList,'foteverror');
            $this->message = $this->message .'<li>A választott tevékenység <i>munkaerő/beosztása</i> mezőjének kitöltése kötelező!</li>';
        
        }
    }

    public function setAdatkezelesi(bool $allapot)
    {
        if($allapot == false)
        {
            $this->isAdatkezelesi = false;
            array_push($this->EmptyFieldsList,'adatkezelesierror');
            $this->message = $this->message .'<li>Figyelem! Az Adatkezelési szabályzat elfogadása kötelező!</li>';
        
        }
    }

    public function setEgyebszervezet(bool $allapot)
    {
        if($allapot == false)
        {
            $this->isEgyebszervezet = false;
            array_push($this->EmptyFieldsList,'egyebszerverror');
            $this->message = $this->message .'<li>Az egyéb szervezet megadása kötelező!</li>';
        
        }
    }
    public function setCivilszervezet(bool $allapot)
    {
        if($allapot == false)
        {
            $this->isCivilszervezet = false;
            array_push($this->EmptyFieldsList,'civilszerverror');
            $this->message = $this->message .'<li>A civil szervezet megadása kötelező!</li>';
        
        }
    }


}