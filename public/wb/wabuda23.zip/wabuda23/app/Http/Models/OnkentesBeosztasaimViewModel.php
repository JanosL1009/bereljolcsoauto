<?php
namespace App\Http\Models;
use App\Http\Models\AbstractGeneralProfile;

class OnkentesBeosztasaimViewModel extends AbstractGeneralProfile
{
    public $jogszint;
    public $nev;

    public $esemenyek;

    public $mode;
    public $state;

    public $profilpic;

    public $AktivLink;
    public $ArchivLink;
    public $OnkentesLink;
    public $VezetoLink;

}
