<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HirStats extends Model
{
    protected $table = 'hir_stat';
}
