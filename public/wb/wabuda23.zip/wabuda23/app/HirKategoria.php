<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HirKategoria extends Model
{
    protected $table = 'hir_kategoria';

    /**
     * Visszater a Hir-el
     */
    public function Hir()
    {
        return $this->belongsTo('App\Hir','hir_id');
    }
}
