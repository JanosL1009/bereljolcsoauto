<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Akkreditacio extends Model
{
    protected $table = 'akkreditacio'; 

    public function  user_data()
    {
        return $this->hasOne('App\User', 'id', 'felhasznalo_id');
    }
}
