<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Hirlevel extends Model
{
    protected $table = "hirlevelek";


}
