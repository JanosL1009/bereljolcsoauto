<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Iskola extends Model
{
    protected $table = "iskola";

    protected $primaryKey = "i_id";

    protected $fillable = ["felhasznalo_id","intezmenyneve","evfolyam","modosito","created_at","updated_at","tevekenysegID"];

}
