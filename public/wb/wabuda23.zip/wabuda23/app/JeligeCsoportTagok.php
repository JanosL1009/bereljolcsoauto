<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Jeligek;

class JeligeCsoportTagok extends Model
{
    protected $table = "jelige_csoport_tagok";



    public function user()
    {
        return $this->belongsTo('App\User','felhasznalo_id');
    }

    public function jelige()
    {
        return $this->belongsTo('App\Jeligek','jelige_id');
    }


    /**
     * Akkor admin, ha a Jeligek tablaban o a letrehozo
     * $model->isAdmin()
     */
    public function isAdmin() : bool
    {
        $jelige = $this->jelige;

        if($jelige->letrehozo == $this->attributes['felhasznalo_id'])
            return true;
        else
        return false;
    }

}
