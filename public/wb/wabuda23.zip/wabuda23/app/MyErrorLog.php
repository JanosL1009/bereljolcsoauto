<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MyErrorLog extends Model
{
    protected $table = "myerrorlog";
}
