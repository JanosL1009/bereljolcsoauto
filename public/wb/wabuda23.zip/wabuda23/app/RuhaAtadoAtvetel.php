<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RuhaAtadoAtvetel extends Model
{
    protected $table = 'ruhaatado_atvetel';

    protected $fillable = ['felhasznalo_id','visszaVetelezesIdeje','modosito','ruha_id','updated_at','mailKuldve'];


    public function user()
    {
        return $this->hasOne('App\User','id', 'felhasznalo_id');
    }

    public function Ruha()
    {
        return $this->hasOne('App\Ruha','id', 'ruha_id');
    }
}
