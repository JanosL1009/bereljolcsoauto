<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HirKepek extends Model
{
    protected $table = 'hir_kepek';

    public $primaryKey = "idhir_kepek";

    public $fillable = ["hir_id","jumbotronImg", "thumbnailImg", "letrehozo", "modosito"];

    /**
     * Visszater a Hir-el
     */
    public function Hir()
    {
        return $this->belongsTo('App\Hir','hir_id');
    }

}
