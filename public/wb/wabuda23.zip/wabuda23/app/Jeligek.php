<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Jeligek extends Model
{
    protected $table = "jeligek";

    protected $fillable = ["felhasznalo_id","letrehozo"];

    public function csoportletrehozo()
    {
        return $this->belongsTo('App\User','letrehozo');
    }



}
