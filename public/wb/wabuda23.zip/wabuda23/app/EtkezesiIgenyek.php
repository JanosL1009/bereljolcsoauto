<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EtkezesiIgenyek extends Model
{
    protected $table = 'etkezesi_igenyek';
}
