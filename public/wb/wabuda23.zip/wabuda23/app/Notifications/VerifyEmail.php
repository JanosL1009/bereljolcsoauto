<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;

use Illuminate\Support\Facades\Lang;

use Illuminate\Auth\Notifications\VerifyEmail as VerifyEmailNotification;

class VerifyEmail extends VerifyEmailNotification
{

    public function toMail($notifiable)
    {
        $verificationUrl = $this->verificationUrl($notifiable);

        if (static::$toMailCallback) {
            return call_user_func(static::$toMailCallback, $notifiable, $verificationUrl);
        }

        return (new MailMessage)
            ->subject(Lang::getFromJson('Erősítse meg az e-mail címét'))
            ->line(Lang::getFromJson('Kérjük, kattintson az e-mail címe megerősítéséhez.'))
            ->action(Lang::getFromJson('Megerősítés'), $verificationUrl)
            ->line(Lang::getFromJson('Ha Ön nem regisztrálta az e-mail címét az Önkéntes Menedzsment Rendszerben, kérjük, hagyja figyelmen kívül ezt az üzenetet.'));
    }

}
