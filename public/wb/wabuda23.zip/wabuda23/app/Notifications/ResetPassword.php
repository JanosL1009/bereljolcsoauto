<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;

use Illuminate\Auth\Notifications\ResetPassword as ResetPasswordNotification;

use Illuminate\Support\Facades\Lang;

class ResetPassword extends ResetPasswordNotification
{

    public function toMail($notifiable)
    {
        if (static::$toMailCallback) {
            return call_user_func(static::$toMailCallback, $notifiable, $this->token);
        }

        return (new MailMessage)
            ->subject(Lang::getFromJson('Jelszó visszaállítása'))
            ->line(Lang::getFromJson('Jelszó visszaállítási kérelem érkezett hozzánk.'))
            ->action(Lang::getFromJson('Jelszó visszaállítása'), url(config('app.url').route('password.reset', ['token' => $this->token, 'email' => $notifiable->getEmailForPasswordReset()], false)))
            ->line(Lang::getFromJson('Ez a kód :count percig aktív.', ['count' => config('auth.passwords.'.config('auth.defaults.passwords').'.expire')]))
            ->line(Lang::getFromJson('Ha nem Ön kérvényezte a jelszó visszaállítását hagyja figyelmen kívül ezt az üzenetet.'));
    }

}
