<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Gyik extends Model
{
    protected  $table = 'gyik';
}
