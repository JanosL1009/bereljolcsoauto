<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RuhaEsemeny extends Model
{
    protected $table ="ruha_esemeny";

    public function programs()
    {
        return $this->belongsTo('App\Esemeny','esemeny_id');
    }

}
