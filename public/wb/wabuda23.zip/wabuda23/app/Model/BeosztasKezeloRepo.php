<?php

namespace App\Model;

/**
 * @version 1.1.1
 *
 *
 * @version 1.1.0.
 * A calendar json_foglalas adatai be kerulnek a ->ProfilAdatokBeosztashoz fuggvenybe
 */

use Illuminate\Support\Facades\DB;
use App\Http\Controllers\DB_OMR_Operations;
use Illuminate\Http\Request;
use  \App\Http\Models\CsoportokLekerdezese;
use App\User;
use \Illuminate\Support\Carbon;
use App\Esemeny;
use App\Terulet;
use App\Csoport;
use App\FelhasznaloFeladat;
use App\EsemenySzervezok;
use App\TeruletBeosztas;
use \Exception;
use App\Support\Collection;
use App\OnkentesSzabadidopontok;
use App\Nyelvismeret;

class BeosztasKezeloRepo
{
    protected $EsemenyID = null;
    protected $TeruletID = null;
    protected $CsoportID = null;

    protected $User = null;

    private $TeruletJelentkezok;
    private $jokerJelentkezok;

    protected $TeruletJelentkezokSzama = 0;
    protected $JokerJelentkezokSzama = 0;

    private $TeruletBeosztottakSzama = 0;
    private $CsoportBeosztottakSzama = 0;

     /**
     * Class constructor
     * @param User Actually User datatable model (needed is the log)
     * @param int Esemeny id, esemeny tabla
     * @param int Terulet id, terulet tabla
     */
    public function __construct(User $ActUser = null,int $EsemenyID,int $teruletID = null,int $CsoportID = null)
    {
        $this->User = $ActUser;
        $this->EsemenyID = $EsemenyID;
        $this->TeruletID = $teruletID;
        $this->CsoportID = $CsoportID;

        if(isset($teruletID))
        {
            $this->TeruletJelentkezok = $this->GetTeruletJelentkezokForID();
        }


        $this->jokerJelentkezok = $this->GetJokerJelentkezok();
       // dd($this->TeruletJelentkezok);
    }

    //ez nem biztos hogy jo
    public function getVezetokLista(int $FelhasznaloszintID)
    {
        switch($FelhasznaloszintID)
        {
            case  3: //esemenyszervezok
                return DB::table('users')->join('esemeny_szervezok','users.id','=','esemeny_szervezok.felhasznalo_id')->
                where('esemeny_szervezok.szint_id','=',3)->
                where('esemeny_szervezok.Esemeny_id',$this->EsemenyID)->get();

            break;
            case 4://teruletvezetok
                return  DB::table('users')->join('esemeny_szervezok','users.id','=','esemeny_szervezok.felhasznalo_id')->
                join('terulet','esemeny_szervezok.terulet_id','=','terulet.id')->
                join('jogosultsag','users.id','=','jogosultsag.felhasznalo_id')->
                where('esemeny_szervezok.szint_id','=',4)->
                where('esemeny_szervezok.terulet_id',$this->TeruletID)->
                where('jogosultsag.felhasznaloszint_id','=',4)->
                select('users.*','terulet.nev AS TeruletNeve')->get();

            break;
            case 5://csoportvezetok
                return DB::table('users')->join('esemeny_szervezok','users.id','=','esemeny_szervezok.felhasznalo_id')->
                join('terulet','esemeny_szervezok.terulet_id','=','terulet.id')->
                join('csoport','esemeny_szervezok.csoport_id','=','csoport.id')
                ->where('esemeny_szervezok.szint_id','=',5)->
                where('esemeny_szervezok.esemeny_id',$this->EsemenyID)->
                select('users.*','terulet.nev AS TeruletNeve','csoport.nev AS CsoportNeve')->get();
            break;
            default:
                 throw new Exception("Nem megengedett jogszint!");
            break;
        }
    }

    public function getIdTeruletJelentkezokListaja()
    {
       $jelentkezok = $this->TeruletJelentkezok;
        $j = 0;
       foreach($jelentkezok as $jelentkezo)
       {
            $beosztott = $this->getBeosztottTeruletDefault($jelentkezo->felhasznalo_id,$this->TeruletID);
            //dd($beosztott);
            if($beosztott)
            {
                //dd($jelentkezok[$j]);
                unset($jelentkezok[$j]);
            }
            $j++;
       }
       unset($j);
     //  dd( $jelentkezok);



       return $jelentkezok;

    }

    public function getJelelentkezokWithUserDatas()
    {
        $jelentkezok = $this->TeruletJelentkezok;
        $array = [];
        foreach($jelentkezok as $user)
        {
            array_push($array,$user->felhasznalo_id);
        }
        $users = DB::table('users')->whereIn('id',$array)->get();
        return $users;
    }

    /**
     * A joker jelentkezok mar szurve vannak. Ha valakit beosztottak egy teruletre, mashol mar nem jelenik meg
     * Priotitas szerint: ha mar valaki jelentkezett a területre, tehat be jelölte! akkor az sima jelentkező itt, függetlenül attól
     * , hogy 'minden' terület érdekli.
     */
    public function getJokerJelentkezoIDk()
    {
        $jokerOnkentesek = $this->jokerJelentkezok;
        $j = 0;
        foreach($jokerOnkentesek as $jelentkezo)
        {
             $beosztott = $this->getBeosztottTeruletDefault($jelentkezo->felhasznalo_id,$this->TeruletID);
             //dd($beosztott);
             if($beosztott)
             {
                 //dd($jelentkezok[$j]);
                 unset($jokerOnkentesek[$j]);
             }
             else{

                $jelentkezok[$j+1] = $jelentkezo->felhasznalo_id;
             }
             $jelentkezok = $this->TeruletJelentkezok;
             foreach($jelentkezok as $user)
             {
                if($user->felhasznalo_id == $jelentkezo->felhasznalo_id)
                {
                    unset($jokerOnkentesek[$j]);
                }
             }

             $j++;
        }
        unset($j);
       // dd($jokerOnkentesek);
        return $jokerOnkentesek;
    }

    /**
     * Visszater azok felhazsnalo idjaval akik mar be vannak osztva az adott teruletre
     */
    public function getTeruletreBeosztottakListajaID()
    {
         $beosztottak = TeruletBeosztas::where('terulet_id',$this->TeruletID)->get('felhasznalo_id');
         $this->TeruletBeosztottakSzama = count($beosztottak);
         return $beosztottak;
    }

    /**
     * Visszater azokkal az ID-kal akik be vannak osztva egy csoportba
     */
    public function GetCsoportBeosztas()
    {
        $beosztottak = FelhasznaloFeladat::where('csoport_id',$this->CsoportID)->get('felhasznalo_id');
        $this->CsoportBeosztottakSzama = count($beosztottak);
        return $beosztottak;
    }

    /**
     * Azoknak terulet jelentkezoknek az ID-javal ter vissza, akiket meg nem osztottak be,
     * az adott terulet egy csoportjaba sem
     *
     * @return array[int]
     */
    public function GetCsoportba_NEM_Beosztottak()
    {
        $newID = array();
        $TeruletCsoportjai = $this->getTeruletCsoportjai();
        $TeruletBeosztottak = $this->getTeruletreBeosztottakListajaID();
        //dd($TeruletBeosztottak);
        $terCsoportok = array();
        foreach($TeruletCsoportjai as $csoport)
        {
            array_push( $terCsoportok ,$csoport["id"]);
        } 
        


        foreach($TeruletBeosztottak as $beosztva)
        {
            $ffTabla  =  FelhasznaloFeladat::where('felhasznalo_id',$beosztva->felhasznalo_id)->
            whereIn('csoport_id',$TeruletCsoportjai )->exists();
            
/*
            if($beosztva->felhasznalo_id == 2358)
            {
                dd($ffTabla,$beosztva->felhasznalo_id);
            }*/

            if(isset($ffTabla))
            {
                if(!$ffTabla)
                {
                    array_push($newID,$beosztva->felhasznalo_id);
                }

                
            }
            
            
            /*$beoszt = null;
            if($this->isCsoportbaBeVanOsztva($beosztva->felhasznalo_id,$terCsoportok ))
            {
                array_push($newID,$beosztva->felhasznalo_id);
                //$beoszt = true;

            }
            else{
                array_push($newID,$beosztva->felhasznalo_id);
            }*/

        }
       //dd($newID);

       return $newID;

    }

    /**Terulet id szerint */
    public function getCsoportbaBeosztottakListaja()
    {
       return  FelhasznaloFeladat::where('felhasznalo_id',$this->User->id)->
        where('terulet_id',$this->TeruletID)->where('csoport_id','>',0)->get();
    }

    /**
     * Ellenoriz egy usert, hogy be van-e osztva csoportba
     */
    public function isCsoportbaBeVanOsztva(int $felhasznaloid,$teruletidArr = null) : bool
    {

            if(isset($teruletidArr))
            {
                $ff = FelhasznaloFeladat::where('felhasznalo_id',$felhasznaloid)->
                        whereIn('terulet_id',$teruletidArr)->where('csoport_id','>',0)->get();
            }
            else
            {
                $ff = FelhasznaloFeladat::where('felhasznalo_id',$felhasznaloid)->
                       where('terulet_id',$this->TeruletID)->where('csoport_id','>',0)->get();
            }

            if(isset($ff) && (count($ff) > 0))
            {
                   return false;

            }
            else
                return true;

    }




    /**
     * VIsszater egy terulet csoportjaival
     */
    protected function getTeruletCsoportjai()
    {
        return Csoport::where('terulet_id',$this->TeruletID)->get('id')->toArray();
    }

    /**
     * Visszater az esemeny osszes teruletevel!
     * @param bool Optional. Default:false, visszater a teljes mezokkel. True: csak az id-kal tervissza
     */
    protected function getEsemenyTeruletei(bool $is_id = false)
    {
        if($is_id)
            return Terulet::where('esemeny_id',$this->EsemenyID)->get(['id']);
        else
            return Terulet::where('esemeny_id',$this->EsemenyID)->get();
    }

    /**
     * Visszater az esemeny osszes csoportjaval!
     * @param bool Optional. Default:false, visszater a teljes mezokkel. True: csak az id-kal tervissza
     */
    protected function getEsemenyCsoportjai(bool $is_id = false)
    {
        $teruletIDList =  $this->getEsemenyTeruletei(true)->toArray(['id']);

        if($is_id)
          {
            return Csoport::whereIn('terulet_id',$teruletIDList)->get(['id']);
          }
        else
          {
            return Csoport::whereIn('terulet_id',$teruletIDList)->get();
          }

    }


    public function getTeruletJelentkezokSzama()
    {
        return count($this->TeruletJelentkezok);
    }

    public function getEsemenySzervezokListaja()
    {
        return $this->getVezetokLista(3);
    }

    public function getTeruletVezetokListaja()
    {
       return $this->getVezetokLista(4);

    }

    public function getCsoportVezetokListaja()
    {
       return $this->getVezetokLista(5);

    }



    /**
     * megvizsgalja, hogy az adott esemenyen belul, be van - mar osztva valamelyik teruletre
     * @return bool TRUE: beosztva, FALSE: nincs beosztva
     */
    private function getBeosztottTerulet($FelhasznaloID)
    {
        /**
         * @var Array:int egy esemeny teulet ID-jait tartalmazza
         */
        $TeruletLista = Terulet::where('esemeny_id',$this->EsemenyID)->select('id')->get()->toArray();
        //dd($TeruletLista);
        $UserTeruletBeosztasai = array();
        $OutBeosztva = false;
        foreach($TeruletLista as $terulet)
        {

           $beosztva = TeruletBeosztas::where('felhasznalo_id',$FelhasznaloID)->where('terulet_id',$terulet['id'])->exists();
            if($beosztva)
            {
                $OutBeosztva = true;;
                break;
            }
        }

        return $OutBeosztva;
    }

    /**
     * megvizsgalja, hogy az adott esemenyen belul, adott teruletere be van e osztva
     * @return bool TRUE: beosztva, FALSE: nincs beosztva
     */
    private function getBeosztottTeruletDefault($FelhasznaloID,$teruletID)
    {
        
        //dd($TeruletLista);
        
           $beosztva = TeruletBeosztas::where('felhasznalo_id',$FelhasznaloID)->where('terulet_id',$teruletID)->exists();
            if($beosztva)
            {
                return true;
            } else return false;
        
    }




    /**
     * Visszater egy collectionel, ami nem tartalmazza a jeletnkezeseket
     * @param Collection A modositando lekeres
     * @param Collection Ami alapjan torlunk az elso collection-bol
     *
     * @return Collection A szurt collection
     */
    private function JelentkezesSzuro($collection1, $collection2)
    {
                    $i = 0;
                    while($i < count($collection1))
                    {
                        $match = false; $id = 0;
                        foreach($collection2 as $jelentkezes)
                        {
                            if($collection1[$i]->id == $jelentkezes->id)
                            {
                                $match = true;
                                $id = $collection1[$i]->id;
                                break;
                            }
                        }
                        if($match)
                        {
                            $collection1 = $collection1->forget($i);
                        }

                        $i++;
                    }

                    return new Collection($collection1);
    }

    protected function GetTeruletJelentkezokForID()
    {
       // $jokers =DB::select('SELECT felhasznalo_feladat.felhasznalo_id FROM `felhasznalo_feladat` where `esemeny_id` = '.$this->EsemenyID.' AND other = 1 group by ("felhasznalo_id")');

        $jelentkezok = DB::select('SELECT felhasznalo_feladat.felhasznalo_id FROM `felhasznalo_feladat` left outer join esemeny_szervezok on felhasznalo_feladat.felhasznalo_id = esemeny_szervezok.felhasznalo_id where felhasznalo_feladat.terulet_id = '.$this->TeruletID.'    group by(felhasznalo_feladat.felhasznalo_id) order by felhasznalo_feladat.jelentkezesIdeje desc ');

       return $jelentkezok;
    }

    protected function GetTeruletJelentkezokFullyInfo()
    {
       // $jokers =DB::select('SELECT felhasznalo_feladat.felhasznalo_id FROM `felhasznalo_feladat` where `esemeny_id` = '.$this->EsemenyID.' AND other = 1 group by ("felhasznalo_id")');

        $jelentkezok = DB::select('SELECT felhasznalo_feladat.* FROM `felhasznalo_feladat` left outer join esemeny_szervezok on felhasznalo_feladat.felhasznalo_id = esemeny_szervezok.felhasznalo_id where felhasznalo_feladat.terulet_id = '.$this->TeruletID.'   group by(felhasznalo_feladat.felhasznalo_id) ');

       return $jelentkezok;
    }

    /**
     * Visszater azoknak az onkenteseknek az azonositojukkal akik bejeloltek, hogy minden
     * teruletre beoszthatoak
     *
     * @return Array[FelhasznaloFeladat[felhasznalo_id]] felhasznalo_feladat.felhasznalo_id
     */
    public function GetJokerJelentkezok()
    {
        $jokers = FelhasznaloFeladat::where('esemeny_id',$this->EsemenyID)->where('terulet_id','!=',$this->TeruletID)->where('other',1)->groupby("felhasznalo_id")->get("felhasznalo_id");

        $this->JokerJelentkezokSzama = count($jokers); //int

        return $jokers;
    }//tesztelve jo 07.23 11:36

    /**
     * Egy szemely jelentkezesrol eldonti, hogy joke-e
     * @param User Egy felhasznalo
     * @return bool Joker-e a szemelyunk az adott teruletre vagy nem
     */
    protected function isAJoker() : bool
    {
        $felhasznaloFeladat = FelhasznaloFeladat::where('felhasznalo_id',$this->User->id)->
        where('esemeny_id',$this->EsemenyID)->first();

        if(intval($felhasznaloFeladat->other) == 1)
            return true;
        else
            return false;
    }

    /**
     * @return int
     */
    public function getBeoszthatoOnkentesekSzama() : int
    {
        return  count($this->getIdTeruletJelentkezokListaja());
    }

    /**
     * Visszater a jelentkezezes nevevel a DB-bol.
     * @param int Prioritas, hogy hanyadik helyet akarjuk lekerdezni
     * @return string Visszater az elso helyen megjelolt teruletnevevel
     */
    protected function getJelentkezettTeruletNeve(int $priority) :string
    {
        $teruletNeve = "Nincs, törölve, lemondva";

        switch($priority)
        {
            case 1:
                try{
                    $felhasznaloFeladat = FelhasznaloFeladat::where('felhasznalo_id',$this->User->id)->
                    where('esemeny_id', $this->EsemenyID)->where('priority',1)->first();

                    $teruletNeve = Terulet::find($felhasznaloFeladat->terulet_id)->nev;
                }
                catch(Exception $e)
                {
                    $teruletNeve = "Lemondva, törölve";
                }

            break;
            case 2:
                try{
                    $felhasznaloFeladat = FelhasznaloFeladat::where('felhasznalo_id',$this->User->id)->
                    where('esemeny_id', $this->EsemenyID)->where('priority',2)->first();

                    $teruletNeve = Terulet::find($felhasznaloFeladat->terulet_id)->nev;
                }
                catch(Exception $e)
                {
                    $teruletNeve = "Lemondva, törölve";
                }
            break;
            case 3:
                try{
                    $felhasznaloFeladat = FelhasznaloFeladat::where('felhasznalo_id',$this->User->id)->
                    where('esemeny_id', $this->EsemenyID)->where('priority',3)->first();

                    $teruletNeve = Terulet::find($felhasznaloFeladat->terulet_id)->nev;
                }
                catch(Exception $e)
                {
                    $teruletNeve = "Lemondva, törölve";
                }
            break;
        }

        return $teruletNeve;

    }


    /**
     *  @version 1.1.0.
     * A calendar json_foglalas adatai be kerulnek
     */
    public function ProfilAdatokBeosztashoz()
    {


        $auser = User::find($this->User->id);
       

        $naptarbanJeloltIdopontjaim = null;
        //$idopontok = OnkentesSzabadidopontok::where('felhasznalo_id', $auser->id)->get();
        $naptarbanJeloltIdopontjaim = null;//json_encode($idopontok);
        try{
            $idopontok = OnkentesSzabadidopontok::where('felhasznalo_id', $auser->id)->get();
            $naptarbanJeloltIdopontjaim = json_encode($idopontok);
        }
        catch(Exception $e)
        {
            $naptarbanJeloltIdopontjaim = "hiba";
        }
        finally{
            unset($idopontok);
        }

        $OsszesJelentkezesemOtuput = array();
        $OsszesJelentkezesem = FelhasznaloFeladat::where('felhasznalo_id',$this->User->id)->get();
        $esemenyek = '';
        foreach($OsszesJelentkezesem as $jelentkezes)
        {
            $esemenynev = $jelentkezes->esemeny_data->nev??'Nem létező esemeny';
            $exist = false;

            if($OsszesJelentkezesemOtuput != null)
            {
                foreach($OsszesJelentkezesemOtuput as $output)
                {
                    if($output == $esemenynev)
                    {
                        $exist = true; break;
                    }
                    //$t = $OsszesJelentkezesemOtuput;

                    
                }
                if(!$exist)
                    {
                        array_push($OsszesJelentkezesemOtuput,$esemenynev);
                    }
            }
            else 
            {
                array_push($OsszesJelentkezesemOtuput,$jelentkezes->esemeny_data->nev);
            }

            

        }

        $beosztasok = $this->getBeosztasok($auser->id);

        $result = array(
            "id" => $auser->id,
            "name" => $auser->name,
            "email" => $auser->email,
            "picture" => DB_OMR_Operations::GetProfilkep($auser->id),
            "age" => $auser->felhasznalo_data->kor,
            'firstplace' => $this->getJelentkezettTeruletNeve(1),
            'secondplace' => $this->getJelentkezettTeruletNeve(2),
            'thirdplace' => $this->getJelentkezettTeruletNeve(3),
            "joker" => $this->isAJoker(),
            "beszeltnyelvek" => $this->getBeszelnyelvekLista($auser->id),
            'idopontok' =>$naptarbanJeloltIdopontjaim,
            'OsszesJelentkezes' => json_encode($OsszesJelentkezesemOtuput),
            'beosztas' =>json_encode($beosztasok)
        );

        return json_encode($result,200);
    }

    protected function getBeszelnyelvekLista(int $UserID)
    {
        $nyelvek = Nyelvismeret::where('felhasznalo_id',$UserID)->get();
        $eredmeny = [];

        foreach($nyelvek as $nyelv)
        {
            $ny['nyelv'] = $nyelv->nyelv;
            switch($nyelv->nyelvszint_id)
            {
                case 1:
                    $ny['szint'] = 'Alapfok';
                break;
                case 2:
                    $ny['szint'] = 'Középfok';
                break;
                case 3:
                    $ny['szint'] = 'Felsőfok';
                break;
            }
            array_push($eredmeny,$ny);
        }

        return $eredmeny;
    }


    protected function getTeruletNeve($TeruletID)
    {
        return Terulet::find($TeruletID)->nev??'Nem létező vagy megszűnt terület';
    }

    /**
     * @method visszater a user foglalasaval
     * @return string
     */
    public function Calendar(array $array)
    {
         /**
         * @since 1.1.0
         * @var mix calendar elemek, db-ből. OnkentesSzabadidopontok
         */
        $calendar = OnkentesSzabadidopontok::whereIn('felhasznalo_id',$array)->get(['felhasznalo_id','foglalas_json']);

        return $calendar;
    }

    /**
     * Innen kezdodnek a csoport es terulet letszamok lekerdezese
     */

     /**
      * Visszater az aktulasi terulet tervezett letszamalval
      * @return int
      */
     public function getTeruletMaxLetszama() : int
     {
         return intval(Terulet::find($this->TeruletID)->tervezettLetszam);
     }

     /**
      * Igenyelt onkentes letszam
      *@return int A szukseges letszam a csoport inditashoz
      */
     public function getCsoportLetszam() : int
     {
        return intval(Csoport::find($this->CsoportID)->igenyelt_onkentes_letszam);
     }



     /**
      * Visszater a joker jelenetkezok szamaval, de ebbol kivonja az aktualis teruletre jelentkezo jokereket
      * @return int
      */
     public function getTeruletJelentkezokJokerekSzama() : int
     {
        return $this->JokerJelentkezokSzama;
     }


     /**
      *Visszter az osszes jelentkezo letszamval. A normal terulet jelentkezokkel es a joker jelentkezok osszegevel
      *@return int
      */
     public function getTeruletJelentkezokSzamaOsszesWithJokers() : int
     {
         $jelentkezok = $this->getIdTeruletJelentkezokListaja();
         $jokers = $this->getJokerJelentkezoIDk();

            foreach($jokers as $user)
            {
            foreach($jelentkezok as $jelentkezo)
            {
                $i = 0;
                if($user->felhasznalo_id == $jelentkezo->felhasznalo_id)
                {
                    unset($jelentkezok[$i]);
                    // dd($user->felhasznalo_id,$jelentkezok,$jokers );
                }
                $i++;
            }
            }
        //$teruletjelentkezok = $this->getTeruletJelentkezokSzama();
        //$jokerek = $this->getTeruletJelentkezokJokerekSzama();
        return count($jelentkezok ); //legacy: $teruletjelentkezok + $jokerek
     }

     public function getTeruletAktualisBeosztottakSzama() : int
     {
        if($this->TeruletBeosztottakSzama == 0)
        {
            $beosztas = $this->getTeruletreBeosztottakListajaID();
            unset($beosztas);
        }
        return $this->TeruletBeosztottakSzama;
     }

     public function getCsoportAktualisBeosztottakSzama() : int
     {
        if($this->CsoportBeosztottakSzama == 0)
        {
            $beosztas = $this->GetCsoportBeosztas();
            unset($beosztas);
        }
        return $this->CsoportBeosztottakSzama;
     }


     /**
      *@version 1.1.0
      *Paraméterezve a fgv. vissza ter a vezetok szamaval is
      *
      * @version 1.0.0
      * Visszater a teljes programra beosztottak is-jaival! Tartalmazza koordinatorokat, vezetoket, csoportba beosztottakat
      *  @param bool Optional. Default:false, visszater a teljes mezokkel. True: csak az id-kal tervissza
      *@return Arry[int]
      */
     public function getProgramraBeosztottak(bool $is_id = false, bool $isTeruletVezetok = false) : array
     {
        $csoportok = $this->getEsemenyCsoportjai(true);
        $users = null;
        if($is_id)
        {
            if($isTeruletVezetok)
            {
                $teruletevezetok = $this->getTeruletVezetokListaja()->pluck('id')->toArray(['id']);
                return $teruletevezetok;
            }
            else
            {
                $felhasznalok = FelhasznaloFeladat::whereIn('csoport_id',$csoportok)->get()->pluck('felhasznalo_id')->toArray(['felhasznalo_id']);
                $csoportVezetok = $this->getCsoportVezetokListaja()->pluck('id')->toArray(['id']);
                $teruletevezetok = $this->getTeruletVezetokListaja()->pluck('id')->toArray(['id']);
                $esemenySzervezok = $this->getEsemenySzervezokListaja()->pluck('id')->toArray(['id']);

                $users = array_unique(array_merge($felhasznalok, $csoportVezetok,$teruletevezetok,$esemenySzervezok));

                return $users;
            }


        }
        else
        {
                ///a teljes user adatlapot ki kell dolgozni ....
        }

     }

     /**
      * @version 1.0.0
      *getProgramraBeosztottak fgv-t veszi alapul
      * @return int
      */
     public function GetBeosztottakSzama(bool $is_id = false, bool $isTeruletVezetok = false) : int
     {
         return count($this->getProgramraBeosztottak($is_id, $isTeruletVezetok ));
     }

      /**
      * @version 1.0.1
      * Visszater a nem beosztottak ID-javal, Program szintű!!!
      *Részben kidolgozott fuggveny! Idohiany miatt csak ID szerint megy param = true
      * @param bool ID szerinti viszaterest szeretnenk? JELENLEG csak az megy!
      * @return Array[int]
      */
     public function getNemBeosztottak(bool $is_id = false) : array
     {
        /**algortmus
         * 1. lekerdezni az összes területet egy programhoz -> idkat
         * 2. az id-k alapján a terület beosztottakat, pprogram szinten :array[]
         * 3. a terlüethez kapcsolodó csoport id-kat
         * 4. a csoportba beosztottak ID-ját
         *
         */
            $TeruletID_Array = $this->getEsemenyTeruletei(true); //1.
            $TeruletekreBeosztottak = TeruletBeosztas::whereIn('terulet_id',$TeruletID_Array)->get(); //2.

            $CsoportAzonositokTombje = [];

            foreach($TeruletID_Array as $terulet)
            {
                /** @var Array[int] */
                $csoportAzonositok = $this->getTeruletCsoportjai();
                foreach($csoportAzonositok as $csopID)
                {
                    array_push($CsoportAzonositokTombje,$csopID);
                }
            }

           // dd($csoportAzonositok );



        return $CsoportAzonositokTombje;
     }

      /**
      * @version 1.0.1
      * getProgramraBeosztottak fgv-t veszi alapul Program szintű!!!
      * @return int
      */
     public function get_NEM_BeosztottakSzama(bool $is_id = false) : int
     {
        return count($this->getNemBeosztottak($is_id));
     }

     /**
      * @var array Csoportok lista
      */
     protected $GroupsList = [];

     /**
      * Visszater egy json-el, ami tartalmazza a felhasznalo_id, csoport_id parosokat.
      *@return JSON
      */
     public function GetCsoportosJelentkezok()
     {

         $jelentkezokArr = $this->GetTeruletJelentkezokFullyInfo();
         $result = [];
         foreach($jelentkezokArr as $user)
         {
             if(isset($user->jeligeID))
             {
                $pairs['uid'] = $user->felhasznalo_id;
                $pairs['jeligeID'] = $user->jeligeID;
                array_push($result,$pairs);

                $jelige = \App\Jeligek::find($user->jeligeID);
                $ar['id'] = $user->jeligeID;
               /* try{}
                catch()
                {

                }*/
                /**itt kezelni kéne a törölt csoportokat... */
                $ar['jeligeNeve'] = $jelige->jeligeNeve??'Nincs';
                
                if(isset($this->GroupsList))
                {
                    $exist = false;
                    foreach($this->GroupsList as $listitem)
                    { 
                        if($listitem['id'] == $ar['id'])
                        {
                            $exist = true;
                        }
                       
                    }
                    if(!$exist)
                    {
                        array_push($this->GroupsList,$ar);
                    }
                   
                }
                else
                {
                    array_push($this->GroupsList,$ar);
                }
             }

         }
        unset( $jelentkezokArr);
        //dd(json_encode($result));
         return json_encode($result);
     }

     /**
      * Visszater a letezo csoportok adataival.
      * csoport_id, csoportnev
      */
     public function getExistGroups()
     {
        // dd(json_encode($this->GroupsList));
        return json_encode($this->GroupsList);
     }

     public function getBeosztasok(int $FelhasznaloID)
     {
         $teruletek = TeruletBeosztas::where('felhasznalo_id', $FelhasznaloID)->get();
         $arr = array();
         foreach($teruletek as $terulet)
         {
            $esemeny = Esemeny::find($terulet->Terulet->esemeny_id);
            $t = $esemeny->nev.'->'.$terulet->Terulet->nev;
            array_push($arr, $t);
         }

         return $arr;
     }

}
