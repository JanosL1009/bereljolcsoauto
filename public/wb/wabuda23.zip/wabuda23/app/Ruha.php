<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ruha extends Model
{
    protected $table = 'ruha';
}
