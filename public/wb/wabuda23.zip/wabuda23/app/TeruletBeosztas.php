<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TeruletBeosztas extends Model
{
     protected $table = 'terulet_beosztas';

     public function Terulet()
     {
        return $this->hasOne('App\Terulet','id','terulet_id');
     }

     public function user()
     {
          return $this->hasOne('App\User','id','felhasznalo_id');
     }
}
