<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TeruletvezetoNote extends Model
{
    protected $table = "teruletvezeto_note";
}
