<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FelhasznloSzintek extends Model
{
    protected $table = 'felhasznaloszintek';
}
