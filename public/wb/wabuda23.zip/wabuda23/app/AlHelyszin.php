<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AlHelyszin extends Model
{
    protected $table = 'alhelyszin';

    public function fohelyszin()
    {
        return $this->belongsTo('App\Helyszin','helyszinID');
    }


}
