<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LogFelhasznaloFeladat extends Model
{
    protected $table = "log_felhasznalo_feladat";

    
}
