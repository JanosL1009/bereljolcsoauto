<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Esemeny extends Model
{
    //
    protected $table = 'esemeny';

    public function Teruletek()
    {
        return $this->hasMany('App\Terulet','id','terulet_id');
    }
}
