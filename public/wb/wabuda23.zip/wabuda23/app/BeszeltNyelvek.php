<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * A DB táblát mezőkkel kell kiegszéíteni ha tobb nyelvűt akarunk csinálni belőle.
 * Pl.: alter table beszeeltnyelvek add angolNeve varchar(30) default null
 * A magyar nyelev kiegesszitese angolul is:
 * update from beszeltnyelvek set angolNeve = 'hungarian' where nyelvRovidJelzese = 'hu';
 * Így egy angol elott megtudod jeleniteni a sajat anyanyelven is az idegen nyelvet!
 */

/**
 * nek bd: beszeltnyelvek tabla
 * A beszelheto nyelvek listajat tartalmazza. Jelenleg magyarul csak.
 *
 */
class BeszeltNyelvek extends Model
{
    protected $table = 'beszeltnyelvek';

}
