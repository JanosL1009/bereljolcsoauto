<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class YtpPlayed extends Model
{
    protected $table = "ytpplayed";
    protected $fillable = ["felhasznalo_id","startTime","actplayTime","created_at","updated_at"];


    public function felhasznalok_data()
    {
        return $this->hasOne('App\User', 'id', 'felhasznalo_id');
    }

}
