<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Hir extends Model
{
    protected $table = 'hir';

    protected $primaryKey = 'h_id';

    /**
     *Visszater a seo  beallitasaival
     */
    public function SEO()
    {
        return $this->hasOne('App\HirSEO','hir_id');
    }

    public function Images()
    {
        return $this->hasOne('App\HirKepek','hir_id');
    }

}
