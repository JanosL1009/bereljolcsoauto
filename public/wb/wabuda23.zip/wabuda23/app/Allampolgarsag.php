<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Allampolgarsag extends Model
{
    protected $table = "allampolgarsagok";
}
