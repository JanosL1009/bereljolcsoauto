<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Terulet extends Model
{
    //
    protected $table = 'terulet';

    public function Esemeny()
    {
        return $this->hasOne('App\Esemeny','id','esemeny_id');
    }
}
