<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EsemenySzervezok extends Model
{
    protected $table = 'esemeny_szervezok';

    public function Esemeny()
    {
        return $this->hasOne('App\Esemeny','id','Esemeny_id');
    }

}
