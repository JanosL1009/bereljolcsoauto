<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ErtesitesMegtekintese extends Model
{
    protected $table = "ertesites_megtekintese";
}
