<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateFosuliTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('fosuli', function(Blueprint $table)
		{
			$table->integer('felhasznalo_id');
			$table->integer('egyetemID', true);
			$table->string('intezmeny_neve', 150);
			$table->string('szak', 150);
			$table->integer('evfolyam');
			$table->dateTime('modositas');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::dropIfExists('fosuli');
	}

}
