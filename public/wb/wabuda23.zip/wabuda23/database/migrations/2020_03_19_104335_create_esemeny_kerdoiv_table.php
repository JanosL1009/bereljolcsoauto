<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateEsemenyKerdoivTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('esemeny_kerdoiv', function(Blueprint $table)
		{
			$table->integer('id', true);
			$table->integer('esemeny_id')->nullable();
			$table->integer('kerdoiv_id')->nullable();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::dropIfExists('esemeny_kerdoiv');
	}

}
