<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddIndexes extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('allandolakcim', function (Blueprint $table) {
            $table->index(['megyeID']);
        });

        Schema::table('civil_szervezet', function (Blueprint $table) {
            $table->index(['felhasznalo_id']);
        });

        Schema::table('csoport', function (Blueprint $table) {
            $table->index(['helyszin_id']);
            $table->index(['terulet_id']);
        });

        Schema::table('egyeb_szervezet', function (Blueprint $table) {
            $table->index(['felhasznalo_id']);
        });

        Schema::table('esemeny', function (Blueprint $table) {
            $table->index(['telepules_id']);
        });



        Schema::table('esemeny_dokumentumok', function (Blueprint $table) {
            $table->index(['esemeny_id']);
            $table->index(['felhasznalo_id']);
        });

        Schema::table('esemeny_kerdoiv', function (Blueprint $table) {
            $table->index(['esemeny_id']);
            $table->index(['kerdoiv_id']);
        });

        Schema::table('esemeny_szervezok', function (Blueprint $table) {
            $table->index(['Esemeny_id']);
            $table->index(['SzervezoVezeto_id']);
            $table->index(['szint_id']);
        });

        Schema::table('esemeny_telepules', function (Blueprint $table) {
            $table->index(['esemeny_id']);
            $table->index(['telepules_id']);
        });

        Schema::table('felhasznaloinfo', function (Blueprint $table) {
            $table->index(['felhasznalo_id']);
            $table->index(['tevekenyseg_id']);
        });

        Schema::table('felhasznalok', function (Blueprint $table) {
            $table->index(['orszag_id']);
            $table->index(['email']);

        });

        Schema::table('felhasznalo_dokumentumok', function (Blueprint $table) {
            $table->index(['felhasznalo_id']);
        });




        Schema::table('felhasznalo_feladat', function (Blueprint $table) {
            $table->index(['felhasznalo_id']);
            $table->index(['feladat_id']);
            $table->index(['csoport_id']);
            $table->index(['terulet_id']);
            $table->index(['esemeny_id']);
        });

        Schema::table('felhasznalo_kepek', function (Blueprint $table) {
            $table->index(['felhasznalo_id']);
        });

        Schema::table('fosuli', function (Blueprint $table) {
            $table->index(['felhasznalo_id']);
        });

        Schema::table('iskola', function (Blueprint $table) {
            $table->index(['felhasznalo_id']);
            $table->index(['tevekenysegID']);
        });

        Schema::table('munkahely', function (Blueprint $table) {
            $table->index(['felhasznalo_id']);
        });



        Schema::table('nyelvismeret', function (Blueprint $table) {
            $table->index(['felhasznalo_id']);
            $table->index(['nyelvszint_id']);
        });

        Schema::table('passio2020kerdoiv', function (Blueprint $table) {
            $table->index(['felhasznalo_id']);
            $table->index(['telefonszam']);
        });

        Schema::table('tartozkodasilakcim', function (Blueprint $table) {
            $table->index(['OrszagID']);
            $table->index(['megyeID']);
        });

        Schema::table('telepules', function (Blueprint $table) {
            $table->index(['orszag_id']);
        });



    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {

 
        Schema::table('allandolakcim', function (Blueprint $table) {
            $table->dropIndex(['megyeID']);
        });

        Schema::table('civil_szervezet', function (Blueprint $table) {
            $table->dropIndex(['felhasznalo_id']);
        });

        Schema::table('csoport', function (Blueprint $table) {
            $table->dropIndex(['helyszin_id']);
            $table->dropIndex(['terulet_id']);
        });

        Schema::table('egyeb_szervezet', function (Blueprint $table) {
            $table->dropIndex(['felhasznalo_id']);
        });

        Schema::table('esemeny', function (Blueprint $table) {
            $table->dropIndex(['telepules_id']);
        });



        Schema::table('esemeny_dokumentumok', function (Blueprint $table) {
            $table->dropIndex(['esemeny_id']);
            $table->dropIndex(['felhasznalo_id']);
        });

        Schema::table('esemeny_kerdoiv', function (Blueprint $table) {
            $table->dropIndex(['esemeny_id']);
            $table->dropIndex(['kerdoiv_id']);
        });

        Schema::table('esemeny_szervezok', function (Blueprint $table) {
            $table->dropIndex(['Esemeny_id']);
            $table->dropIndex(['SzervezoVezeto_id']);
            $table->dropIndex(['szint_id']);
        });

        Schema::table('esemeny_telepules', function (Blueprint $table) {
            $table->dropIndex(['esemeny_id']);
            $table->dropIndex(['telepules_id']);
        });

        Schema::table('felhasznaloinfo', function (Blueprint $table) {
            $table->dropIndex(['felhasznalo_id']);
            $table->dropIndex(['tevekenyseg_id']);
        });

        Schema::table('felhasznalok', function (Blueprint $table) {
            $table->dropIndex(['orszag_id']);
            $table->dropIndex(['email']);
            
        });

        Schema::table('felhasznalo_dokumentumok', function (Blueprint $table) {
            $table->dropIndex(['felhasznalo_id']);
        });




        Schema::table('felhasznalo_feladat', function (Blueprint $table) {
            $table->dropIndex(['felhasznalo_id']);
            $table->dropIndex(['feladat_id']);
            $table->dropIndex(['csoport_id']);
            $table->dropIndex(['terulet_id']);
            $table->dropIndex(['esemeny_id']);
        });

        Schema::table('felhasznalo_kepek', function (Blueprint $table) {
            $table->dropIndex(['felhasznalo_id']);
        });

        Schema::table('fosuli', function (Blueprint $table) {
            $table->dropIndex(['felhasznalo_id']);
        });

        Schema::table('iskola', function (Blueprint $table) {
            $table->dropIndex(['felhasznalo_id']);
            $table->dropIndex(['tevekenysegID']);
        });

        Schema::table('munkahely', function (Blueprint $table) {
            $table->dropIndex(['felhasznalo_id']);
        });



        Schema::table('nyelvismeret', function (Blueprint $table) {
            $table->dropIndex(['felhasznalo_id']);
            $table->dropIndex(['nyelvszint_id']);
        });

        Schema::table('passio2020kerdoiv', function (Blueprint $table) {
            $table->dropIndex(['felhasznalo_id']);
            $table->dropIndex(['telefonszam']);
        });

        Schema::table('tartozkodasilakcim', function (Blueprint $table) {
            $table->dropIndex(['OrszagID']);
            $table->dropIndex(['megyeID']);
        });

        Schema::table('telepules', function (Blueprint $table) {
            $table->dropIndex(['orszag_id']);
        });

    }
}
