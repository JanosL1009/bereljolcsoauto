<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreatePassio2020kerdoivTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('passio2020kerdoiv', function(Blueprint $table)
		{
			$table->integer('id', true);
			$table->integer('felhasznalo_id')->nullable();
			$table->integer('magassag')->nullable();
			$table->string('konfekciomeret', 300)->nullable();
			$table->integer('cipo_meret')->nullable();
			$table->integer('fejkormeret')->nullable();
			$table->boolean('szakallnovesztes')->nullable()->default(0);
			$table->string('vallas', 200);
			$table->integer('neme');
			$table->string('telefonszam', 66);
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::dropIfExists('passio2020kerdoiv');
	}

}
