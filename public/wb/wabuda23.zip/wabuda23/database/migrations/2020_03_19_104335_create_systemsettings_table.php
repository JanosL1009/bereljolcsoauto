<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateSystemsettingsTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('systemsettings', function(Blueprint $table)
		{
			$table->integer('id', true);
			$table->string('settingkey', 75);
			$table->string('settingvalue', 45);
			$table->integer('modosito');
			$table->dateTime('modositasideje');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::dropIfExists('systemsettings');
	}

}
