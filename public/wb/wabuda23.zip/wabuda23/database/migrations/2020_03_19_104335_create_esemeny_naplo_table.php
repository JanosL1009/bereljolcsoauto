<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateEsemenyNaploTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('esemeny_naplo', function(Blueprint $table)
		{
			$table->integer('es_naplo_id', true);
			$table->integer('esemenyid');
			$table->text('old_nev', 65535)->nullable();
			$table->text('new_nev', 65535)->nullable();
			$table->date('old_bef_datuma')->nullable();
			$table->date('old_kezd_datuma')->nullable();
			$table->text('old_leiras', 65535)->nullable();
			$table->text('new_leiras', 65535)->nullable();
			$table->timestamp('ModTime')->default(DB::raw('CURRENT_TIMESTAMP'));
			$table->string('modosito_userid', 20);
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::dropIfExists('esemeny_naplo');
	}

}
