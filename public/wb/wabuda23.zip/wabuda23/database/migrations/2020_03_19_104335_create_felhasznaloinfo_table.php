<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateFelhasznaloinfoTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('felhasznaloinfo', function(Blueprint $table)
		{
			$table->integer('felhasznaloinfoid', true);
			$table->integer('felhasznalo_id')->nullable();
			$table->integer('tevekenyseg_id')->nullable();
			$table->string('polomeret', 200)->nullable();
			$table->boolean('fogyatekossag')->nullable()->comment('0:NEM, 1:IGEN');
			$table->string('fogyLeirasa', 300)->nullable();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::dropIfExists('felhasznaloinfo');
	}

}
