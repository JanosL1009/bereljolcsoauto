<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateFeladatTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('feladat', function(Blueprint $table)
		{
			$table->integer('id');
			$table->integer('csoport_id');
			$table->string('megnevezes', 250);
			$table->text('leiras', 65535);
			$table->integer('terites_osszege');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::dropIfExists('feladat');
	}

}
