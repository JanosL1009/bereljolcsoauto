<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateMunkahelyTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('munkahely', function(Blueprint $table)
		{
			$table->integer('m_id', true);
			$table->integer('felhasznalo_id');
			$table->string('intezmenyneve', 250);
			$table->string('beosztasa', 250);
			$table->dateTime('datetime');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::dropIfExists('munkahely');
	}

}
