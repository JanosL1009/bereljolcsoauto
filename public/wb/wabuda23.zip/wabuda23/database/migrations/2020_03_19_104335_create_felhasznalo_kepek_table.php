<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateFelhasznaloKepekTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('felhasznalo_kepek', function(Blueprint $table)
		{
			$table->integer('id', true);
			$table->integer('felhasznalo_id')->nullable();
			$table->string('picname', 250)->nullable();
			$table->date('hozzaadva')->nullable();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::dropIfExists('felhasznalo_kepek');
	}

}
