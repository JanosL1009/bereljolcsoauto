<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateAltDokumentumokTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('alt_dokumentumok', function(Blueprint $table)
		{
			$table->integer('doc_id', true);
			$table->string('docname', 200);
			$table->string('real_docname', 200);
			$table->boolean('visibility_id')->comment('A dokumentum lathatosaga: 0: mindenki, 1:adminok csak');
			$table->dateTime('uploaded_at');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::dropIfExists('alt_dokumentumok');
	}

}
