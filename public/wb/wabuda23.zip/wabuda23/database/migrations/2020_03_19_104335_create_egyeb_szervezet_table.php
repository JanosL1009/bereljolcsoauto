<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateEgyebSzervezetTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('egyeb_szervezet', function(Blueprint $table)
		{
			$table->integer('sz_id', true);
			$table->string('szervezet_neve', 250);
			$table->integer('felhasznalo_id');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::dropIfExists('egyeb_szervezet');
	}

}
