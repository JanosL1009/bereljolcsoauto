<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateFelhasznalokTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('felhasznalok', function(Blueprint $table)
		{
			$table->integer('id', true);
			$table->string('vezeteknev', 50)->nullable();
			$table->string('kozepsonev', 250)->nullable();
			$table->string('keresztnev', 100)->nullable();
			$table->boolean('neme')->nullable()->comment('0:ferfi; 1:no');
			$table->string('email', 200)->nullable();
			$table->date('szulIdo')->nullable();
			$table->string('szulhely_ID', 275)->nullable();
			$table->string('orszag_id', 60)->nullable();
			$table->string('lakcim', 150)->nullable();
			$table->string('telefonszam', 70);
			$table->string('szulhely', 100);
			$table->string('profilkep', 250);
			$table->integer('kor');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::dropIfExists('felhasznalok');
	}

}
