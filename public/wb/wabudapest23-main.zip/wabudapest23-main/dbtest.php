<?php
$mysqli = new mysqli("mysql2.rentit.hu","RentIT_nekonkentes","xohdu3-cospyx-vybJej","RentIT_nekonkentes");

// Check connection
if ($mysqli->connect_errno) {
  echo "Failed to connect to MySQL: " . $mysqli -> connect_error;
  exit();
}
else
{
    echo "OK";
}
?>