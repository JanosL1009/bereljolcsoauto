<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateIskolaTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('iskola', function(Blueprint $table)
		{
			$table->integer('i_id', true);
			$table->integer('felhasznalo_id');
			$table->string('intezmenyneve', 250);
			$table->integer('evfolyam');
			$table->integer('tevekenysegID');
			$table->dateTime('modositas');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::dropIfExists('iskola');
	}

}
