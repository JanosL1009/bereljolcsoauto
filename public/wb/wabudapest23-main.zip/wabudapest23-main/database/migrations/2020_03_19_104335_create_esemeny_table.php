<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateEsemenyTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('esemeny', function(Blueprint $table)
		{
			$table->integer('id', true);
			$table->string('nev', 300)->nullable();
			$table->date('kezdesDatum')->nullable();
			$table->time('kezdesIdeje')->nullable();
			$table->date('befejezesDatum')->nullable();
			$table->time('befejezesIdeje')->nullable();
			$table->integer('statusz_id')->nullable();
			$table->boolean('toborzas')->nullable()->comment('0:NEM; 1:IGEN');
			$table->text('Leiras', 65535)->nullable();
			$table->integer('telepules_id');
			$table->string('esemeny_profilkep', 150);
			$table->string('email', 150);
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::dropIfExists('esemeny');
	}

}
