<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateTeruletBeosztasTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('terulet_beosztas', function(Blueprint $table)
		{
			$table->integer('tid', true);
			$table->integer('felhasznalo_id');
			$table->integer('terulet_id');
			$table->dateTime('beosztasIdeje');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::dropIfExists('terulet_beosztas');
	}

}
