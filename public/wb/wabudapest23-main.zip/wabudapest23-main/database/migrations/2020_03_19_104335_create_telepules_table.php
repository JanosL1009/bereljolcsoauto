<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateTelepulesTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('telepules', function(Blueprint $table)
		{
			$table->integer('id', true);
			$table->string('nev', 100)->nullable();
			$table->integer('irszam');
			$table->integer('orszag_id');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::dropIfExists('telepules');
	}

}
