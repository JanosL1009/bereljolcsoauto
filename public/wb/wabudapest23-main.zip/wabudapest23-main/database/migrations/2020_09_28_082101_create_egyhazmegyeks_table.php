<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateEgyhazmegyeksTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('egyhazmegyek', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('felekezet');
            $table->string('nev');
            $table->integer('letrehozo');
            $table->integer('modosito')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('egyhazmegyek');
    }
}
