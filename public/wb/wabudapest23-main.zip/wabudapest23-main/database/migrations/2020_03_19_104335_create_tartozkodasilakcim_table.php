<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateTartozkodasilakcimTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('tartozkodasilakcim', function(Blueprint $table)
		{
			$table->integer('felhasznaloid')->primary();
			$table->string('IranyitoSzam', 11)->nullable();
			$table->string('TelepulesID', 60)->nullable();
			$table->string('OrszagID', 11)->nullable();
			$table->string('Cim', 100)->nullable();
			$table->integer('megyeID');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::dropIfExists('tartozkodasilakcim');
	}

}
