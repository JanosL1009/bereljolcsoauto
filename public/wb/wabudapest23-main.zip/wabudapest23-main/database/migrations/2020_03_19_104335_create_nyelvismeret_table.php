<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateNyelvismeretTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('nyelvismeret', function(Blueprint $table)
		{
			$table->integer('nyelv_id', true);
			$table->integer('felhasznalo_id')->nullable();
			$table->string('nyelv', 50)->nullable();
			$table->integer('nyelvszint_id')->nullable();
			$table->integer('sorrend');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::dropIfExists('nyelvismeret');
	}

}
