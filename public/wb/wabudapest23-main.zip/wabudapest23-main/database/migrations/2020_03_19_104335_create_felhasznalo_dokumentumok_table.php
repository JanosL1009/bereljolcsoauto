<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateFelhasznaloDokumentumokTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('felhasznalo_dokumentumok', function(Blueprint $table)
		{
			$table->integer('id', true);
			$table->integer('felhasznalo_id')->nullable();
			$table->string('docname', 300)->nullable();
			$table->date('hozzaadva')->nullable();
			$table->boolean('active')->nullable()->comment('0: nem aktiv, 1 :aktiv');
			$table->timestamps();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function dropIfExists()
	{
		Schema::drop('felhasznalo_dokumentumok');
	}

}
