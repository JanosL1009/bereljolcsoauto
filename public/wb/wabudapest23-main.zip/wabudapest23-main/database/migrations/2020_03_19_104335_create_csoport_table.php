<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateCsoportTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('csoport', function(Blueprint $table)
		{
			$table->integer('id', true);
			$table->string('nev', 80);
			$table->date('kezdesDatuma');
			$table->time('kezdesIdeje');
			$table->date('befejezesDatuma');
			$table->time('befejezesIdeje');
			$table->integer('helyszin_id');
			$table->integer('igenyelt_onkentes_letszam');
			$table->integer('jelentkezok_onkentes_letszam');
			$table->text('leiras', 65535);
			$table->integer('terulet_id');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::dropIfExists('csoport');
	}

}
