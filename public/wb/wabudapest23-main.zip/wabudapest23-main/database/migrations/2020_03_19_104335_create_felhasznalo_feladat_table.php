<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateFelhasznaloFeladatTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('felhasznalo_feladat', function(Blueprint $table)
		{
			$table->integer('jelentkezesID', true);
			$table->integer('felhasznalo_id');
			$table->integer('feladat_id');
			$table->integer('csoport_id');
			$table->integer('terulet_id');
			$table->integer('esemeny_id');
			$table->integer('priority');
			$table->boolean('other');
			$table->dateTime('jelentkezesIdeje')->nullable();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::dropIfExists('felhasznalo_feladat');
	}

}
