<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateSzemelyesadatokTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('szemelyesadatok', function(Blueprint $table)
		{
			$table->integer('id', true);
			$table->integer('felhasznalo_id');
			$table->string('email', 100);
			$table->string('szemigszam', 75);
			$table->string('anyjaneve', 100);
			$table->string('allampolgarsag', 75);
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::dropIfExists('szemelyesadatok');
	}

}
