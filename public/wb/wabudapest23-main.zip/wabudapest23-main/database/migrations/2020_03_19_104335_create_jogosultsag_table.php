<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateJogosultsagTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('jogosultsag', function(Blueprint $table)
		{
			$table->integer('id', true);
			$table->integer('felhasznalo_id')->nullable();
			$table->integer('felhasznaloszint_id')->nullable();
			$table->dateTime('utolsomodositas_ideje')->nullable();
			$table->integer('elozo_felh_szint')->nullable();
			$table->integer('modosito_felh_id')->nullable();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::dropIfExists('jogosultsag');
	}

}
