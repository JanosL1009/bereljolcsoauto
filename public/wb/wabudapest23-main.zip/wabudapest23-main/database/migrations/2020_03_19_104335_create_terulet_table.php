<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateTeruletTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('terulet', function(Blueprint $table)
		{
			$table->integer('id', true);
			$table->string('nev', 250)->nullable();
			$table->text('leiras', 65535);
			$table->integer('esemeny_id');
			$table->dateTime('kezdesIdopont')->nullable();
			$table->dateTime('befejezesIdopont')->nullable();
			$table->integer('tervezettLetszam')->nullable();
			$table->integer('jelentkezokSzama')->nullable();
			$table->integer('teruletHelyszineID')->nullable();
			$table->boolean('teruletAktiv')->nullable();
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::dropIfExists('terulet');
	}

}
