<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateAllandolakcimTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('allandolakcim', function(Blueprint $table)
		{
			$table->integer('felhasznaloid')->primary();
			$table->string('IranyitoSzam', 40)->nullable();
			$table->string('Telepules', 70)->nullable();
			$table->string('Orszag', 50)->nullable();
			$table->string('Cim', 100)->nullable();
			$table->integer('megyeID');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::dropIfExists('allandolakcim');
	}

}
