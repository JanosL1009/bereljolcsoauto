<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateEsemenySzervezokTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('esemeny_szervezok', function(Blueprint $table)
		{
			$table->integer('esz_id', true);
			$table->integer('felhasznalo_id');
			$table->integer('Esemeny_id')->nullable();
			$table->integer('terulet_id')->nullable();
			$table->integer('csoport_id')->nullable();
			$table->integer('szint_id')->comment('felhasznaloszint');
			$table->integer('modosito_id')->comment('felhasznalo_id');
			$table->timestamp('modositas_ideje')->default(DB::raw('CURRENT_TIMESTAMP'));
			$table->unique(['felhasznalo_id','Esemeny_id','szint_id'], 'felhasznalo_id');
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::dropIfExists('esemeny_szervezok');
	}

}
