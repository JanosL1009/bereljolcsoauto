<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Password Reset Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are the default lines which match reasons
    | that are given by the password broker for a password update attempt
    | has failed, such as for an invalid token or invalid new password.
    |
    */

    'password' => 'A jelszónak legalább 8 karakternek kell lenni és egyezniük kell!',
    'reset' => 'A jelszavad helyreállítva!',
    'sent' => 'E-mailben elküldtük a jelszó-visszaállítási linket!',
    'token' => 'Ez a jelszó-visszaállítási token érvénytelen.',
    'user' => "Nem találtunk felhasználót ezzel az email címmel!",

];
