@extends('layouts.admin')

@section('content')
<style>
    .beosztasEmpty{ color:red; } .beosztasNotEmpty{color: blue;}
</style>
<div class="row">
                <div class="col-12 col-md-12">
                    <a class="btn btn-primary" href="{{url()->to('/admin/esemeny_szerkesztes/'.$model->esemeny_id)}}">Vissza a rendezvény adatlapjára</a>
                    <a class="btn btn-primary float-right" href="{{url()->to('/admin/onkentesteruletbeosztasa/'.$model->teruletid)}}">Terület beosztása</a>
                    <a class="btn btn-primary float-right" href="{{route('riport.teruletJelentkezok',['AreaID' => $model->teruletid])}}">Jelentkezők letöltése</a>
                    <a class="btn btn-primary float-right" href="{{route('riport.terbeosztottak',['TeruletID' => $model->teruletid])}}">Beosztottak letöltése</a>
                </div>
                <div class="col-12 col-md-6">
                    <div class="card my-3">
                            <div class="card-body">
                                    <div class="row">
                                            <div class="col-12 d-flex justify-content-between">
                                            <h1>{{$model->rendezvenyNeve}} </h1>
                                            </div>
                                    </div>
                                    <div class="container">
                                            <div class="table-wrapper">

                                                <table class="table table-striped table-hover">

                                                        <tr>
                                                            <th>Terület neve</th>
                                                            <td>{{$model->teruletneve}} <a href="#editAreaNameModal"  data-toggle="modal"><i class="material-icons float-right edit"  style="cursor:default;" data-toggle="tooltip" title="Szerkesztés">&#xE254;</i></a></td>
                                                        </tr>

                                                        <tr>
                                                            <th>Helyszín</th>
                                                            <td>{{$model->helyszin}} <a href="#editLocaleModal"  data-toggle="modal"><i class="material-icons float-right edit"  style="cursor:default;" data-toggle="tooltip" title="Szerkesztés">&#xE254;</i></a></td>
                                                        </tr>

                                                        <tr>
                                                            <th>Cím</th>
                                                            <td>{{$model->cim}} </td>
                                                        </tr>

                                                        <tr>
                                                                <th>Jelentkezők száma</th>
                                                                <td>{{$model->jelentkezokSzama}}</td>
                                                        </tr>

                                                        <tr>
                                                            <th>Tervezett létszám</th>
                                                            <td>{{$model->tervezettLetszam}} <a href="#editAreaModal"  data-toggle="modal"><i class="material-icons float-right edit"  style="cursor:default;" data-toggle="tooltip" title="Szerkesztés">&#xE254;</i></a></td>
                                                        </tr>

                                                        <tr>
                                                            <th>Kezdés időpontja</th>
                                                            <td>{{$model->teruletKezdesIdopont}}<a href="#editStartDateModal"  data-toggle="modal"><i class="material-icons float-right edit"  style="cursor:default;" data-toggle="tooltip" title="Szerkesztés">&#xE254;</i></a></td>
                                                        </tr>

                                                        <tr>
                                                            <th>Befejezés időpontja</th>
                                                            <td>{{$model->teruletBefejezesIdopont}} <a href="#editEndDateModal"  data-toggle="modal"><i class="material-icons float-right edit"  style="cursor:default;" data-toggle="tooltip" title="Szerkesztés">&#xE254;</i></a></td>
                                                        </tr>


                                                        <tr>
                                                                <th>Terület aktív</th>
                                                                <td>
                                                                    <select id="teruletAktiv" class="form-control">
                                                                        @if($model->TeruletAktiv == 0)
                                                                            <option value="0" selected>Inaktív</option>
                                                                            <option value="1" >Aktív</option>
                                                                        @else
                                                                        <option value="0" >Inaktív</option>
                                                                        <option value="1" selected>Aktív</option>
                                                                        @endif
                                                                    </select>
                                                                </td>
                                                        </tr>


                                                </table>

                                            </div>
                                        </div>
                            </div>
                    </div>
                </div>

                <div class="col-12 col-md-6">
                        <div class="card my-3">
                                <div class="card-body">
                                        <div class="row">
                                                <div class="col-12 d-flex justify-content-between">
                                                        <h3>Terület leírása</h3>
                                                        <a href="#editAreaDescribeModal" data-toggle="modal"><i class="material-icons float-right edit" style="cursor:default;" data-toggle="tooltip" title="" data-original-title="Szerkesztés"></i></a>
                                                </div>
                                        </div>
                                        <div class="container">
                                                <div class="table-wrapper">

                                                    {!! $model->teruletLeiras !!}

                                                </div>
                                            </div>
                                </div>
                        </div>
                    </div>





          <div class="col-12 col-md-12">
            <div>
              <div>




                    <!-- Ter jel -->
                    <div id="editAreaModal" class="modal fade">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <form action="{{url('admin/csoportokterulet/letszamvalt')}}" method="POST" >
                                    <div class="modal-header">
                                        <h4 class="modal-title">Tervezett létszám módosítása</h4>
                                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                    </div>
                                    <div class="modal-body">
                                        <p>Biztosan módosítod a terület tervezett létszámát?</p>
                                        <p class="text-warning"><small>Ez a művelet nem visszavonható.</small></p>
                                        <p>
                                          <label>Kérjük add meg az új létszámot: </label>
                                          <input type="number" id="ujletszam" name="ujletszam" class="form-control">
                                        </p>
                                    </div>
                                    <div class="modal-footer">
                                    <input type="number" class="d-none" id="tid" name="tid" value="{{$model->teruletid}}">
                                    @csrf
                                        <input type="button" class="btn btn-default" data-dismiss="modal" value="Mégse">
                                        <input type="submit"  class="btn btn-danger" value="Változtatás">
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <div id="editAreaNameModal" class="modal fade">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <form action="{{url('admin/csoportokterulet/namemodify')}}" method="POST" >
                                    <div class="modal-header">
                                        <h4 class="modal-title">A terület nevének módosítás</h4>
                                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                    </div>
                                    <div class="modal-body">
                                        <p>Biztosan módosítod a terület nevét?</p>
                                        <p class="text-warning"><small>Ez a művelet nem visszavonható.</small></p>
                                        <p>
                                          <label>Kérjük add meg az új nevet: </label>
                                          <input type="text" id="newareaname" name="newareaname" class="form-control">
                                        </p>
                                    </div>
                                    <div class="modal-footer">
                                    <input type="number" class="d-none" id="tid" name="tid" value="{{$model->teruletid}}">
                                    @csrf
                                        <input type="button" class="btn btn-default" data-dismiss="modal" value="Mégse">
                                        <input type="submit" id="NewAreaNameSbmBtn" class="btn btn-danger" value="Változtatás">
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <div id="editLocaleModal" class="modal fade">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <form action="{{url('admin/csoportokterulet/localemodify')}}" method="POST" >
                                    <div class="modal-header">
                                        <h4 class="modal-title">A terület helyszínének módsítás</h4>
                                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                    </div>
                                    <div class="modal-body">
                                        <p>Biztosan módosítod a terület helyszínét?</p>
                                        <p class="text-warning"><small>Ez a művelet nem visszavonható.</small></p>
                                        <p><label>Kérjük add meg az új helyszínt: </label>
                                            <select class="form-control" id="hnev" name="hnev">
                                                <option value="0" disabled selected>--- Kérjük válassz ---</option>
                                            </select>
                                        </p>
                                    </div>
                                    <div class="modal-footer">
                                    <input type="number" class="d-none" id="tid" name="tid" value="{{$model->teruletid}}">
                                    @csrf
                                        <input type="button" class="btn btn-default" data-dismiss="modal" value="Mégse">
                                        <input type="submit" id="NewLocaleNameSbmBtn" class="btn btn-danger" value="Változtatás">
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                            <!-- Delete Modal HTML -->
                            <div id="deleteEmployeeModal" class="modal fade">
                                <div class="modal-dialog">
                                    <div class="modal-content">

                                            <div class="modal-header">
                                                <h4 class="modal-title">Csoport törlése</h4>
                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                            </div>
                                            <div class="modal-body">
                                                <p>Biztosan törölni szeretné?</p>
                                                <p class="text-warning"><small>Ez a művelet nem visszavonható.</small></p>
                                            </div>
                                            <div class="modal-footer">
                                                <input type="number" class="d-none" id="gid" name="gid" value="">
                                                <input type="button" class="btn btn-default" data-dismiss="modal" value="Mégse">
                                                <input type="submit" id="GroupDelSbm" class="btn btn-danger" value="Törlés">
                                            </div>

                                    </div>
                                </div>
                            </div>
                            <div id="editAreaDescribeModal" class="modal fade">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                    <form action="{{url('admin/csoportokterulet/areadescribemodify')}}" method="post" enctype="multipart/form-data">
                                            @csrf
                                            <div class="modal-header">
                                                <h4 class="modal-title">Terület leírás módosítása</h4>
                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="form-group">
                                                    <textarea class="form-control" id="areaNewDescribeTT" name="areaNewDescribeTT" class="newAreaDescribe" rows="10">
                                                      {!! $model->teruletLeiras !!}
                                                    </textarea>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <input type="number" class="d-none" id="areaid" name="areaid" value="{{$model->teruletid}}">
                                                <input type="button" class="btn btn-default" data-dismiss="modal" value="Mégse">
                                                <input type="submit" id="ModifyAreaDescribe" class="btn btn-danger" value="Módosítás">
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <!-- -->
                            <div id="editStartDateModal" class="modal fade">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                    <form action="{{url('admin/csoportokterulet/startdatemodify')}}" method="post" enctype="multipart/form-data">
                                            @csrf
                                            <div class="modal-header">
                                                <h4 class="modal-title">Terület kezdés időpontjának módosítása</h4>
                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="form-group">
                                                    <label>Kezdés dátuma</label>
                                                    <div class="input-group date form_date feherhatter" data-date="" data-date-format="yyyy MM dd" data-link-field="dtp_input2" data-link-format="yyyy-mm-dd">

                                                        <input type="text" class="form-control" id="datepicker" name="datepicker"  value="" >

                                                        <span class="input-group-addon"><span class="glyphicon glyphicon-remove"></span></span>
                                                              <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span>
                                                      </div>
<!--
                                                      <select id="kezdIdoEvT" name="kezdIdoEvT" class="form-control" style="width: 85px;"> 
                                                        <option value="2021">2021</option>
                                                    </select> 
                                                    <select id="kezdIdoHoT" name="kezdIdoHoT" class="form-control" style="width: 65px;">
                                                        <option value="13" default selected>---</option>
                                                        <option id="kezdHo-1" id="kezdHo-1" value="1" >1</option>
                                                        <option id="kezdHo-2" value="2">2</option>
                                                        <option id="kezdHo-3" value="3">3</option>
                                                        <option id="kezdHo-4" value="4">4</option>
                                                        <option id="kezdHo-5" value="5">5</option>
                                                        <option id="kezdHo-6" value="6">6</option>
                                                        <option id="kezdHo-7" value="7">7</option>
                                                        <option id="kezdHo-8" value="8">8</option>
                                                        <option id="kezdHo-9" value="9">9</option>
                                                        <option id="kezdHo-10" value="10">11</option>
                                                        <option id="kezdHo-11" value="12">12</option>
                                                        <option id="kezdHo-12" value="12">12</option>
                                                    </select> 
                                                    <select id="kezdIdoNapT" name="kezdIdoNapT" class="form-control" style="width: 65px;"> 
                                                        <option value="33">---</option>
                                                    </select> -->
                                                </div>
                                                <div class="form-group">
                                                    <label for="dtp_input3" class="control-label">Kezdés ideje</label>
                                                    <div class="input-group date form_time feherhatter" data-date="" data-date-format="hh:ii" data-link-field="dtp_input3" data-link-format="hh:ii">
                                                        <input type="number" value="" id="kezdIdejeOra" name="kezdIdejeOra" class="timeInput TimeHour valid" min="0" max="23" placeholder="23"> :
                                                        <input type="number" value="" id="kezdIdejePerc" name="kezdIdejePerc" class="timeInput TimeSec" min="0" value="0" max="59" placeholder="00" >
                                                    </div>

                                                  </div>
                                            </div>
                                            <div class="modal-footer">
                                                <input type="number" class="d-none" id="areaid" name="areaid" value="{{$model->teruletid}}">
                                                <input type="button" class="btn btn-default" data-dismiss="modal" value="Mégse">
                                                <input type="submit" id="ModifyAreaDescribe" class="btn btn-danger" value="Módosítás">
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <!-- -->
                            <div id="editEndDateModal" class="modal fade">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                    <form action="{{url('admin/csoportokterulet/enddatemodify')}}" method="post" enctype="multipart/form-data">
                                            @csrf
                                            <div class="modal-header">
                                                <h4 class="modal-title">Terület befejezés időpontjának módosítása</h4>
                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="form-group">
                                                    <label>Befejezés dátuma</label>
                                                    <div class="input-group date form_date " data-date="" data-date-format="yyyy MM dd" data-link-field="dtp_input2" data-link-format="yyyy-mm-dd">

                                                        <input type="text" class="form-control" id="datepicker2"  name="datepicker2" value="{{$model->GetBefejzesIdopont()}}" >

                                                        <span class="input-group-addon"><span class="glyphicon glyphicon-remove"></span></span>
                                                              <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span>
                                                      </div>
                                                </div>
                                                <div class="form-group">
                                                    <label>Befejezés ideje</label>
                                                    <div class="input-group date form_date " data-date="" data-date-format="yyyy MM dd" data-link-field="dtp_input2" data-link-format="yyyy-mm-dd">
                                                        <input type="number" value="{{$model->GetBefejezesIdeje('H')}}" id="befIdejeOra" name="befIdejeOra" class="timeInput TimeHour" min="0" max="23" placeholder="23" > :
                                                        <input type="number" value="{{$model->GetBefejezesIdeje('m')}}" id="befIdejePerc" name="befIdejePerc" class="timeInput TimeSec" min="0" max="59" placeholder="00" data-validation="required">
                                                     </div>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <input type="number" class="d-none" id="areaid" name="areaid" value="{{$model->teruletid}}">
                                                <input type="button" class="btn btn-default" data-dismiss="modal" value="Mégse">
                                                <input type="submit" id="ModifyAreaDescribe" class="btn btn-danger" value="Módosítás">
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                    <script type="text/javascript">
                        $(document).ready(function(){


                        });
                        /*teruletesek*/
                        function UserAreaCoordinatorAdd(itemid){
                            let _name =  $('tr#ter'+itemid+' td span.pointer').text();

                           $('tr#ter'+itemid).remove();
                           let newRow = '<tr id="'+itemid+'"><td> <span class="custom-checkbox"> <input type="checkbox" id="checkbox1" name="options[]" value="1"> <label for="checkbox1"></label> </span> </td><td><span class="pointer">'+_name+'</span></td><td> <i class="material-icons remove pointer"  data-toggle="tooltip"  title="Eltávolít" onclick="UserEventRemove('+itemid+')">close</i> </td>  </tr>';

                            $('table#teruletbeosztva tbody').append(newRow);
                            var tid = {{$model->teruletid}};
                            $.ajax({
                                type:'POST',
                                url:'{{url('TerVezBeosztas')}}',
                                data:{_token: '<?php echo csrf_token() ?>', tid:tid,uid:itemid},
                                success:function(data) {
                                    console.log(data);
                                }
                            });
                        }
                        $('#editLocaleModal').mousemove(function(){
                            $('#editLocaleModal').off( "mousemove" );
                            $.ajax({
                                    type:'POST',
                                    url:'{{url('GetHelyszinek')}}',
                                    data:{_token:'<?php echo csrf_token() ?>'},
                                    success:function(data) {
                                    var obj = data;
                                    let i = 0;
                                        for(i = 0; i < data.length;i++)
                                        {
                                            $("<option>").attr("value", data[i].id).text(data[i].Neve).appendTo("#hnev");
                                        }

                                    }
                                });
                        });



                    </script>


                    <div class="card my-3">
                            <div class="card-body">
                       @csrf


                                      <div class="row">
                                        <div class="col-12 d-flex justify-content-between">
                                          <h1>Csoportok</h1>
                                        </div>
                                      </div>
                                      <div class="container2">
                                              <div class="table-wrapper">

                                                  <table class="table table-striped table-hover">
                                                      <thead>
                                                          <tr>

                                                              <th>Csoport neve</th>
                                                              <th>Dátum</th>
                                                              <th></th>
                                                              <th>Igényelt létszám</th>
                                                              <th>Beosztva</th>
                                                              <th>Műveletek</th>
                                                          </tr>
                                                      </thead>
                                                      <tbody>
                                                          @php
                                                           $csoportok = $model->csoport;
                                                          @endphp
                                                              @foreach ($csoportok as $csoport)
                                                                  <tr -data-id="{{$csoport->GetCsoportID()}}">

                                                                      <td>{{$csoport->CsoportNeve}}</td>
                                                                      <td>{{$csoport->kezdesDatuma}}-{{$csoport->befejezesDatuma}}</td>
                                                                      <td>{{$csoport->helyszin}}</td>
                                                                      <td>{{$csoport->igenyeltOnkentesLetszam}}</td>
                                                                      <td>{{$csoport->BeosztottakSzama}} </td>

                                                                      <td>
                                                                          <a href="{{url('/admin/csoport_szerkesztes/'.$csoport->GetCsoportID())}}"  class="edit"><i class="material-icons" data-toggle="tooltip" title="Szerkesztés">&#xE254;</i></a>
                                                                          <a href="#deleteEmployeeModal" class="delete" data-toggle="modal"><i id="{{$csoport->GetCsoportID()}}" class="material-icons deltool" data-toggle="tooltip" title="Delete" data-valesid="{{$csoport->GetCsoportID()}}">&#xE872;</i></a>
                                                                          <a href="{{url('/admin/CsoportBeosztas/'.$model->teruletid.'/'.$csoport->GetCsoportID())}}"  class="subject" ><i class="material-icons @if($csoport->BeosztottakSzama == 0) {{ __("beosztasEmpty") }} @else {{ __("beosztasNotEmpty") }} @endif" data-toggle="tooltip" title="Csoportbeosztás">subject</i></a>
                                                                          <a href="{{url('/admin/CsoportVezetokBeosztasa/'.$model->teruletid.'/'.$csoport->GetCsoportID())}}" class="subject" ><i class="material-icons @if($csoport->isCsoportVezeto()) {{ __("beosztasNotEmpty") }} @else {{ __("beosztasEmpty") }} @endif" data-toggle="tooltip" title="Csoportvezető beosztása">supervisor_account</i></a>

                                                                          @if($csoport->isCsoportVezeto())
                                                                            <a href="{{url('/admin/muszakfelvetel/index/'.$model->teruletid.'/'.$csoport->GetCsoportID())}}" class="subject" ><i class="material-icons beosztasNotEmpty" data-toggle="tooltip" title="Műszakigazolás">fact_check</i></a>
                                                                          @else
                                                                          <a href="#" class="subject" ><i class="material-icons beosztasEmpty"  data-toggle="tooltip" title="Műszakigazolás">fact_check</i></a>
                                                                         @endif
                                                                        <a href="{{route('riport.csoportBeosztottak',['GroupID' => $csoport->GetCsoportID()])}}" class="subject" title="Beosztás letöltése"><i title="Beosztás letöltése" class="material-icons" data-toggle="tooltip">file_download</i> </a>

                                                                      </td>
                                                                  </tr>
                                                              @endforeach
                                                      </tbody>
                                                  </table>
                                                  <div class="clearfix float-left">

                                                  </div>
                                              </div>
                                          </div>


                                      </div>
                                  </div>



                            <script type="text/javascript">
                                $(document).ready(function(){
                                    // Activate tooltip
                                    $('[data-toggle="tooltip"]').tooltip();
                                    // Select/Deselect checkboxes
                                    var checkbox = $('table tbody input[type="checkbox"]');
                                    $("#selectAll").click(function(){
                                        if(this.checked){
                                            checkbox.each(function(){
                                                this.checked = true;
                                            });
                                        } else{
                                            checkbox.each(function(){
                                                this.checked = false;
                                            });
                                        }
                                    });
                                    checkbox.click(function(){
                                        if(!this.checked){
                                            $("#selectAll").prop("checked", false);
                                        }
                                    });
                                });
                                </script>





        <div id="ujCsoportLetrehozasa" class="modal fade">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form action="{{url('/admin/ujcsoport_hozzaadasa')}}" method="POST" enctype="multipart/form-data" id="UjCsoport" name="UjCsoport">
                        @csrf
                        <div class="modal-header">
                            <h4 class="modal-title">Új csoport létrehozása</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        </div>
                        <div class="modal-body">

                            <div class="card my-3">
                                <div class="card-body">
                                <h5 class="card-title"></h5>

                                    <div class="form-group">
                                        <label>Csoport neve</label>
                                        <input type="text" class="form-control" id="csoportNeve" name="csoportNeve" >
                                        <input type="text" class="d-none" id="esemeny" name="esemeny" value="2">
                                    </div>

                                    <div class="form-group"><label>Csoport leírása</label>
                                            <textarea class="form-control"  id="csoportLeiras" name="csoportLeiras" rows="10" ></textarea>
                                    </div>

                                    <div class="form-group"><label>Terület kiválasztása</label>
                                       <select class="form-control" id="csTerulet" name="csTerulet">
                                            <option value="-1" selected disabled>--- Terület választás ---</option>
                                       </select>
                                    </div>

                                    <div class="form-group"><label>Kezdés időpontja</label>

                                        <div class="input-group date form_time " data-date="" data-date-format="hh:ii" data-link-field="dtp_input3" data-link-format="hh:ii">
                                                <div class="myTime">
                                                        <input type="date" id="cskezdIdejeDatum" name="cskezdIdejeDatum">
                                                        <input type="number" id="cskezdIdejeOra" name="cskezdIdejeOra" class="timeInput TimeHour" min="0" max="23" placeholder="23" data-validation="required">:
                                                        <input type="number" id="cskezdIdejePerc"  name="cskezdIdejePerc"  class="timeInput TimeSec" min="0" max="59" placeholder="00" data-validation="required">
                                                </div>
                                            <span class="input-group-addon"><span class="glyphicon glyphicon-remove"></span></span>
                                                      <span class="input-group-addon"><span class="glyphicon glyphicon-time"></span></span>
                                        </div>
                                    </div>

                                    <div class="form-group"><label>Befejezés időpontja</label>
                                        <div class="input-group date form_time " data-date="" data-date-format="hh:ii" data-link-field="dtp_input3" data-link-format="hh:ii">
                                                <div class="myTime">
                                                        <input type="date" id="csbefIdejeDatum" name="csbefIdejeDatum">
                                                        <input type="number" id="csbefIdejeOra" name="csbefIdejeOra" class="timeInput TimeHour" min="0" max="23" placeholder="23" data-validation="required">:
                                                        <input type="number" id="csbefIdejePerc" name="csbefIdejePerc" class="timeInput TimeSec" min="0" max="59" placeholder="00" data-validation="required">
                                                </div>
                                            <span class="input-group-addon"><span class="glyphicon glyphicon-remove"></span></span>
                                                      <span class="input-group-addon"><span class="glyphicon glyphicon-time"></span></span>
                                        </div>
                                    </div>

                                    <div class="form-group"><label>Tervezett létszám</label>
                                            <input type="text" class="form-control" id="cstervLetszam" name="cstervLetszam">
                                    </div>

                                    <div class="form-group"><label>Helyszín</label>
                                        <div class="card-body">

                                                <div class="form-row rh" id="cshelyszin" data-lastid="1">
                                                  <div class="form-group col-md-6">
                                                    <label for="inputPassword4">A program helyszíne</label>
                                                    <input type="text" class="form-control" id="cshelyszin1" name="cshelyszin1" data-id="1">
                                                  </div>
                                                  <div class="form-group col-md-6">
                                                    <label for="inputEmail4">Cím</label>
                                                    <input type="text" class="form-control" id="cshelyszincim1" name="cshelyszincim1" data-id="1">
                                                  </div>
                                                </div>
                                                <div class="form-row">
                                                  <button class="btn btn-light" type="button" id="cstovabbitHelyszin" name="cstovabbitHelyszin">+ Helyszín hozzáadása</button>
                                                </div>
                                        </div>

                                    </div>
<!--
                                    <div class="form-group"><label>Állapot</label>
                                        input type checkbox ...
                                    </div>
                                -->


                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">

                            <input type="submit" id="AddNewGroupSbmBtn" class="btn btn-danger" value="Létrehozás">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


        <div class="col-12">
            <div class="card my-3">
                <div class="card-body">
                    <h4>Területi koordinátorok</h4>
                    <table id="teruletiKoordinatarokTablazat" class="table table-striped table-hover" id="esemenySzervezok">
                        <thead>
                            <tr>
                                <th>Név</th>
                                <th>Terület</th>
                            </tr>
                        </thead>
                        <tbody>
                            @if(count($model->TeruletVezetok) > 0)
                                @foreach($model->TeruletVezetok as $vezeto)
                                <tr>
                                    <td> {{$vezeto->name }}</td>
                                    <td> {{$vezeto->TeruletNeve}}</td>
                                </tr>
                                @endforeach
                            @endif
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="col-12">
            <div class="card my-3">
                <div class="card-body">
                    <h4>Csoportvezetők</h4>
                    <table id="csoportvezetokTablazat" class="table table-striped table-hover" id="esemenySzervezok">
                        <thead>
                            <tr>
                                <th>Név</th>
                                <th>Terület</th>
                                <th>Csoport</th>
                            </tr>
                        </thead>
                        <tbody>
                            @if(count($model->CsoportVezetok) > 0)
                                @foreach($model->CsoportVezetok as $vezeto)
                                    <tr>
                                        <td>{{$vezeto->name}}</td>
                                        <td>{{$vezeto->TeruletNeve}}</td>
                                        <td>{{$vezeto->CsoportNeve}}</td>
                                    </tr>
                                @endforeach
                            @endif


                        </tbody>
                    </table>
                </div>
            </div>
        </div>


        <script src="{{ asset('js/jquery.form-validator.min.js') }}"></script>
        <script>
            document.querySelector('input#kezdIdejeOra[type=number]').forEach(e => e.oninput = () => {
                    // Always 2 digits
                    if (e.value.length >= 2) e.value = e.value.slice(0, 2);
                    // 0 on the left (doesn't work on FF)
                    if (e.value.length === 1) e.value = '0' + e.value;
                    // Avoiding letters on FF
                    if (!e.value) e.value = '00';
                });
                document.querySelector('input#kezdIdejePerc[type=number]').forEach(e => e.oninput = () => {
                    if (e.value.length >= 2) e.value = e.value.slice(0, 2);
                    if (e.value.length === 1) e.value = '0' + e.value;
                    if (!e.value) e.value = '00';
                });
                document.querySelector('input#befIdejeOra[type=number]').forEach(e => e.oninput = () => {
                     if (e.value.length >= 2) e.value = e.value.slice(0, 2);
                    if (e.value.length === 1) e.value = '0' + e.value;
                    if (!e.value) e.value = '00';
                });
                document.querySelector('input#befIdejePerc[type=number]').forEach(e => e.oninput = () => {
                    // Always 2 digits
                    if (e.value.length >= 2) e.value = e.value.slice(0, 2);
                     if (e.value.length === 1) e.value = '0' + e.value;
                    if (!e.value) e.value = '00';
                });
        </script>
        <script>
           var myLanguage = {
                errorTitle: 'Az űrlap feldolgozása sikertelen.',
                requiredFields: 'You have not answered all required fields',
                badTime: 'You have not given a correct time',
                badEmail: 'You have not given a correct e-mail address',
                badTelephone: 'You have not given a correct phone number',
                badSecurityAnswer: 'You have not given a correct answer to the security question',
                badDate: 'You have not given a correct date',
                lengthBadStart: 'The input value must be between ',
                lengthBadEnd: ' karakter',
                lengthTooLongStart: 'The input value is longer than ',
                lengthTooShortStart: 'Az input érték nem lehet kevesebb, mint ',
                notConfirmed: 'Input values could not be confirmed',
                badDomain: 'Incorrect domain value',
                badUrl: 'The input value is not a correct URL',
                badCustomVal: 'The input value is incorrect',
                andSpaces: ' and spaces ',
                badInt: 'The input value was not a correct number',
                badSecurityNumber: 'Your social security number was incorrect',
                badUKVatAnswer: 'Incorrect UK VAT Number',
                badStrength: 'The password isn\'t strong enough',
                badNumberOfSelectedOptionsStart: 'You have to choose at least ',
                badNumberOfSelectedOptionsEnd: ' answers',
                badAlphaNumeric: 'The input value can only contain alphanumeric characters ',
                badAlphaNumericExtra: ' and ',
                wrongFileSize: 'The file you are trying to upload is too large (max %s)',
                wrongFileType: 'Only files of type %s is allowed',
                groupCheckedRangeStart: 'Please choose between ',
                groupCheckedTooFewStart: 'Please choose at least ',
                groupCheckedTooManyStart: 'Please choose a maximum of ',
                groupCheckedEnd: ' item(s)',
                badCreditCard: 'The credit card number is not correct',
                badCVV: 'The CVV number was not correct',
                wrongFileDim : 'Incorrect image dimensions,',
                imageTooTall : 'the image can not be taller than',
                imageTooWide : 'the image can not be wider than',
                imageTooSmall : 'the image was too small',
                min : 'min',
                max : 'max',
                imageRatioNotAccepted : 'Image ratio is not accepted'
            };
          $.validate({
            language : myLanguage
          });
        </script>
        <script type="text/javascript">
            $(document).ready(function(){
                // Activate tooltip
                $('[data-toggle="tooltip"]').tooltip();
            });
            </script>

        <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
        <!-- <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script> -->
        <script src="{{asset('js/jquery-ui-1.10.2.js')}}" ></script>
        <script>
           $(document).ready(function(){
               var availableTags = [];
               $( "#helyszin1" ).autocomplete({
                   source: availableTags
               });
               $.ajax({
                      type:'POST',
                      url:'{{url('gettelepuleslista')}}',
                      data:{_token:'<?php echo csrf_token() ?>' },
                      success:function(data) {
                      // var obj = JSON.parse(data);
                       let i = 0;
                           for(i = 0; i < data.length;i++)
                           {
                               availableTags.push(data[i].nev);
                           }
                      }
                   });
                   var tavailableTags = [];
               $( "#thelyszin1" ).autocomplete({
                   source: availableTags
               });
               $.ajax({
                      type:'POST',
                      url:'{{url('gettelepuleslista')}}',
                      data:{_token:'<?php echo csrf_token() ?>' },
                      success:function(data) {
                      // var obj = JSON.parse(data);
                       let i = 0;
                           for(i = 0; i < data.length;i++)
                           {
                               tavailableTags.push(data[i].nev);
                           }
                      }
                   });
               $('#tovabbiHelyszin').click(function(){
                   let lastid = $('.rh').last().data("lastid"); lastid++; let helyszin = 'helyszin'+lastid; let helyszincim = 'helyszincim'+lastid;
                   console.log(lastid);
                   var htmlout = '<div class="form-row rh" id="rhelyszin" data-lastid="'+lastid+'"> <div class="form-group col-md-6"><label for="inputPassword4">A program helyszíne</label> <input type="text" class="form-control" id="'+helyszin+'" name="'+helyszin+'" data-id="'+lastid+'"></div><div class="form-group col-md-6"> <label for="inputEmail4">Cím</label> <input type="text" class="form-control" id="'+helyszincim+'" name="'+helyszincim+'" data-id="'+lastid+'"> </div> </div>';
                   $('#rhelyszin').append(htmlout);
                   AutocompleteTerulet(helyszin);
               });
               $('#tovabbitHelyszin').click(function(){
                let lastid = $('.rh').last().data("lastid"); lastid++; let helyszin = 'thelyszin'+lastid; let helyszincim = 'thelyszincim'+lastid;
                console.log(lastid);
                var htmlout = '<div class="form-row rh" id="rhelyszin" data-lastid="'+lastid+'"> <div class="form-group col-md-6"><label for="inputPassword4">A program helyszíne</label> <input type="text" class="form-control" id="'+helyszin+'" name="'+helyszin+'" data-id="'+lastid+'"></div><div class="form-group col-md-6"> <label for="inputEmail4">Cím</label> <input type="text" class="form-control" id="'+helyszincim+'" name="'+helyszincim+'" data-id="'+lastid+'"> </div> </div>';
                $('#thelyszin').append(htmlout);
                AutocompleteTerulet(helyszin);
                });
                $('#csoportNeve').focus(function(){
                    let rend_id = $('#esemeny').val();
                    $.ajax({
                      type:'POST',
                      url:'{{url('GetTeruletek')}}',
                      data:{_token:'<?php echo csrf_token() ?>', es_id:rend_id },
                      success:function(data) {
                       var obj = data;
                       let i = 0;
                           for(i = 0; i < data.length;i++)
                           {
                            $("<option>").attr("value", data[i].id).text(data[i].nev).appendTo("#csTerulet");
                           }
                      }
                   });
                    /*teruletek betoltese*/
                });
           });
           function AutocompleteTerulet(hsz){
               var availableTags = [];
               $( "#"+hsz ).autocomplete({
                   source: availableTags
               });
               $.ajax({
                      type:'POST',
                      url:'{{url('gettelepuleslista')}}',
                      data:{_token:'<?php echo csrf_token() ?>' },
                      success:function(data) {
                      // var obj = JSON.parse(data);
                       let i = 0;
                           for(i = 0; i < data.length;i++)
                           {
                               availableTags.push(data[i].nev);
                           }
                      }
                   });
           }
        </script>
        <script type="text/javascript">
            $(document).ready(function(){
                // Activate tooltip
                $('[data-toggle="tooltip"]').tooltip();
                // Select/Deselect checkboxes
                var checkbox = $('table tbody input[type="checkbox"]');
                $("#selectAll").click(function(){
                    if(this.checked){
                        checkbox.each(function(){
                            this.checked = true;
                        });
                    } else{
                        checkbox.each(function(){
                            this.checked = false;
                        });
                    }
                });
                checkbox.click(function(){
                    if(!this.checked){
                        $("#selectAll").prop("checked", false);
                    }
                });

                $('#teruletAktiv').change(function(){
                    let val = $('#teruletAktiv').val(); var t = {{$model->teruletid}};
                    $.ajax({
                      type:'POST',
                      url:'{{url('SetTerAktiv')}}',
                      data:{_token:'<?php echo csrf_token() ?>',act:val,tid:t},
                      success:function(data) {
                         
                         $("#teruletAktiv").val(data);
                         if(data == 1)
                        {
                            alert('A terület aktív! Az Önkéntesek jelentkezhetnek erre a területre!');
                        }else {
                            alert('A terület inaktív! Az Önkéntesek NEM jelentkezhetnek erre a területre!');
                        }
                      }
                   });
                });

                $('.deltool').click(function(){
                        let v = $(this).data('valesid');console.log('Eleme ' +  v); $('#gid').val(v);
                });


                $('#GroupDelSbm').click(function(){
                    let omrr = $('#gid').val(); console.log(omrr);
                        $.ajax({
                                type:'POST',
                                url:'{{url('DelGroup')}}',
                                data:{_token:'<?php echo csrf_token() ?>', csid:omrr },
                                success:function(data) {
                                    if(data > 0) {location.reload();}
                                }
                            });
                    });



            });
            </script>

<script src="{{asset('js/datetimepicker-bs4.js')}}" type="text/javascript"></script>
<link href="https://unpkg.com/gijgo@1.9.13/css/gijgo.min.css" rel="stylesheet" type="text/css" />
@endsection

@section('scriptsection')
<script>
    $('#datepicker').datepicker({
      uiLibrary: 'bootstrap4',
      minDate: '{{date("Y-m-d")}}'
    });
    $('#datepicker2').datepicker({
    uiLibrary: 'bootstrap4'
  });
    </script>

    
 <script src="https://cdn.ckeditor.com/4.13.1/basic/ckeditor.js"></script>

 <script>
         CKEDITOR.replace( 'areaNewDescribeTT' );
 </script>

@endsection
