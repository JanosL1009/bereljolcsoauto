@extends('layouts.admin')


@section('content')
<style>
    .myLink{color: blue;} .error{ color: red;}
    /* .myButtonLink{background: #43baa9;border-radius: 3px;padding-top: 5px;} .myButtonLink icons-image {float: left;} */
</style>

<form class="form" id="onkentes_szeresztese_feldolgozo" name="onkentes_szerkesztese_feldolgozo" action="{{url('admin/onkentes_szerkesztese_feldolgozo/'.$id)}}" method="post" enctype="multipart/form-data">
<div class="row">
        @csrf

        <div class="col-12 d-flex justify-content-start">
          <h1>{{$model->GetTeljesNev()}} profilja</h1>
        </div>

        @if($errors->any())
        <div class="col-12 text-center">
          <h4  class="alert alert-danger" role="alert">{{$errors->first()}}</h4>
        </div>
        
      @endif
      @if($errors->telszam->first())
      <div class="col-12 text-center">
        <h4  class="alert alert-danger" role="alert">{{$errors->telszam->first()}}</h4>
      </div>
      
    @endif
  
    @if($errors->egyebures->first())
      <div class="col-12 text-center">
        <h4  class="alert alert-danger" role="alert">{{$errors->egyebures->first()}}</h4>
      </div>
      
    @endif
  
    @if($errors->lakcim_telepules->first())
      <div class="col-12 text-center">
        <h4  class="alert alert-danger" role="alert">{{$errors->lakcim_telepules->first()}}</h4>
      </div>
      
    @endif
  
  @if($errors->nyelv1->first())
      <div class="col-12 text-center">
        <h4  class="alert alert-danger" role="alert">{{$errors->nyelv1->first()}}</h4>
      </div>
      
    @endif
  
    @if($errors->nyelv2->first())
      <div class="col-12 text-center">
        <h4  class="alert alert-danger" role="alert">{{$errors->nyelv2->first()}}</h4>
      </div>
      
    @endif
  
    @if($errors->nyelv3->first())
    <div class="col-12 text-center">
      <h4  class="alert alert-danger" role="alert">{{$errors->nyelv3->first()}}</h4>
    </div>
    
  @endif
  
  @if($errors->nyelv4->first())
    <div class="col-12 text-center">
      <h4  class="alert alert-danger" role="alert">{{$errors->nyelv4->first()}}</h4>
    </div>
    
  @endif
  
  @if($errors->nyelv5->first())
    <div class="col-12 text-center">
      <h4  class="alert alert-danger" role="alert">{{$errors->nyelv5->first()}}</h4>
    </div>
    
  @endif


        <div class="col-12 d-flex justify-content-start mybuttons">
            <a href="#MailBox"  data-toggle="modal" class="btn-primary d-flex align-items-center p-2"><icons-image _ngcontent-wwl-c22="" _nghost-wwl-c19=""><span _ngcontent-wwl-c19="" class="material-icons icon-image-preview">email</span></icons-image>Levél küldés</a>

        </div>
       
            <div class="col-12 mt-3">
                <div class="card">
                    <div class="card-body">

                        <div id="accordion">
                            <div class="card">
                              <div class="card-header" id="headingOne">
                                <h5 class="mb-0">
                                  <a class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                    Bejelentkezések
                                  </a>
                                </h5>
                              </div>
                          
                              <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
                                <div class="card-body">
                                    <p>Utolsó 15 belépés: </p>
                                    <table class="table">
                                        <tbody>
                                         @isset($logins)
                                            @foreach($logins as $login)
                                            <tr>
                                            <td>
                                                {{$login->loginDate}}
                                            </td>
                                            
                                            
                                            </tr>
                                        @endforeach
                                         @endisset
                                        </tbody>
                                      </table>
                                </div>
                              </div>
                            </div> <!-- card end 1 -->
                            <div class="card">
                              <div class="card-header" id="headingTwo">
                                <h5 class="mb-0">
                                  <a class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                    Tevékenységnapló
                                  </a>
                                </h5>
                              </div>
                              <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
                                <div class="card-body">
                                    <table class="table">
                                        <thead>
                                          <tr>
                                            <th scope="col">Művelet(ek)</th>
                                            <th scope="col">Időpont</th>
                                            
                                          </tr>
                                        </thead>
                                        <tbody>
                                         @foreach($tevnaplo as $tev)
                                          <tr>
                                            <td>
                                                @if($tev['name_change'] == 1) [Név változtatás] @endif
                                                @if($tev['pws_change'] == 1) [Jelszó változtatás] @endif
                                                @isset($tev['other_change']) 
                                                    @if($tev['other_change'] == 1) [Egyéb változtatás] @endif
                                                @endisset
                                               
                                            </td>
                                            <td>{{$tev['updated_at']}}</td>
                                         
                                          </tr>
                                        @endforeach
                                        </tbody>
                                      </table>
                                </div>
                              </div>
                            </div><!-- card end 2 -->
                             <div class="card">
                              <div class="card-header" id="headingThree">
                                <h5 class="mb-0">
                                  <a class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                    Fiók és jelszó
                                  </a>
                                </h5>
                              </div>
                              <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
                                <div class="card-body">
                                  
                                  <table class="table">
                                    <thead>
                                      <tr>
                                        <th scope="col">Művelet(ek)</th>
                                        
                                        
                                      </tr>
                                    </thead>
                                    <tbody>
                                      <tr>
                                        <td>
                                         @if($accverified == true)
                                          <p>A profilt már megerősítették!</p>
                                         @else
                                          <a  href="#accountActivatedModal" class="btn btn-link" data-toggle="modal">Fiók aktiválása</a>
                                        @endif
                                         
                                           </td>
                                      </tr>
                                      <tr>
                                        <td>
                                          <a href="#PswdChangeBox" class="btn btn-link" data-toggle="modal"><i class="material-icons" data-toggle="tooltip" title="Jelszó változtatása" ></i>Jelszó változtatása</a>
  
                                        </td>
                                      </tr>
                                    </tbody>
                                  </table>
                                
                                </div>
                              </div>
                            </div>
                          </div>

                    </div>
                </div>
            </div>
      

        <div class="col-6">
          <div class="card my-3">
            <div class="card-body">
            <!--  <form> -->

              <div class="form-group">
                <label for="inputAddress">Név</label>
                <input type="text" class="form-control" id="userfullname" name="userfullname"  value="{{$model->GetTeljesNev()}}" readonly>
              </div>

              <div class="form-row">
                    <div class="form-group col-md-4">
                      <label for="vezeteknevLabel">Vezetéknév*</label>
                      <input type="hidden" id="felhasznaloid"  name="felhasznaloid" value="{{$id}}">
                    <input type="text" class="form-control" id="vezeteknev" name="vezeteknev" value="{{$model->Vezeteknev}}" data-validation="require" required>
                    </div>
                    <div class="form-group col-md-4">
                        <label for="vezeteknevLabel">Keresztnév*</label>
                      <input type="text" class="form-control" id="kozepsonev" name="kozepsonev" value="{{$model->Kozepsonev}}" data-validation="require">
                      </div>
                    <div class="form-group col-md-4">
                      <label for="keresztnevLabel" style="font-size:14px;">Második keresztnév</label>
                      <input type="text" class="form-control" id="keresztnev" name="keresztnev" value="{{$model->Keresztnev}}">
                    </div>
                  </div>



              <div class="form-row">
                <div class="form-group col-md-12">
                  <label for="inputPassword4">Telefonszám*</label>
                <input type="number" class="form-control" id="telszam" name="telszam" value="{{$model->Telefonszam}}" placeholder="{{$model->Telefonszam}}" data-validation="require" required>
                <sub>Formátum: 00 + országkód pl. 0036; 0049;</sub>
                </div>
              </div>

              <div class="form-group">
                <label for="inputAddress2">E-mail</label>
              <input type="text" class="form-control" id="sajatEmailCim" name="sajatEmailCim" placeholder="{{$model->email}}"  data-validation="email" value="{{$model->email}}" readonly>
              </div>
              <div class="form-row">
                <div class="form-group col-md-6">
                  <label for="szuletesiIdo">Születési idő*</label>
                  <div class="d-flex">
                                
                    <div class="col-4 ">
                      <select  id="szuletesiIdoEv" name="szuletesiIdoEv" class="form-control" style="width:85px;">
                          <option>Év</option>
                          
                      </select>
                    </div>
                    <div class=" col-4 ">
                      <select  id="szuletesiIdoHo" name="szuletesiIdoHo" class="form-control" style="width:65px;">
                          <option>Hó</option>
                      </select>
                    </div>
                    <div class="col-4 ">
                      <select  id="szuletesiIdoNap" name="szuletesiIdoNap" class="form-control" style="width:65px;">
                          <option>Nap</option>
                      </select>
                  </div>
                </div>
                </div>
                <div class="form-group col-md-6">
                  <label for="inputState">Születési hely*</label>
                <input type="text" class="form-control" id="szulhely" name="szulhely" value="{{$model->szulhely}}"  placeholder="{{$model->szulhely}}" data-validation="require" required>
                </div>
              </div>
              <div class="form-row">
                    <div class="form-group col-md-6">
                      <label for="inputEmail4">Életkor</label>
                        @if($model->EletKor == 1)
                            <input class="form-control" type="number" id="age" name="age" value="" readonly />
                        @else
                            <input class="form-control" type="number" id="age" name="age" value="{{ $model->EletKor }}" readonly />
                        @endif


                    </div>

                    <div class="form-group col-md-6">
                        <label for="inputEmail4">Neme*</label>
                        <select class="form-control" id="userneme" name="userneme" data-validation="require" required>
                              <option disabled selected value>--- --- ---</option>

                              @if($model->Neme_id == 1)
                                  <option value="0">Férfi</option>
                                  <option value="1" selected="selected">Nő</option>
                              @elseif($model->Neme_id == 0)
                              <option value="0" selected="selected">Férfi</option>
                              <option value="1" >Nő</option>
                              @else
                              <option value="0">Férfi</option>
                              <option value="1">Nő</option>
                              @endif


                        </select>
                      </div>

                      <div class="form-row">
                        <div class="form-group col-md-6">
                                <label for="inputEmail4">Anyja neve*</label>

                        <input class="form-control" type="text" id="mothername" name="mothername" value="{{$model->anyjaneve}}" data-validation="required" required>

                        </div>

                </div>
                 <div class="form-row">
                        <div class="form-group col-md-6">
                                <label for="inputEmail4">Állampolgárság*</label>

                                <input class="form-control" type="text" id="nationality" name="nationality" value="{{$model->allampolgarsag}}" data-validation="required" required>

                        </div>

                        <div class="form-group col-md-6">
                                <label for="inputEmail4">Személy igazolvány szám*</label>

                                <input class="form-control" type="text" id="szemigszam" name="szemigszam" value="{{ $model->szemigszam }}" data-validation="required" required>

                        </div>

                  </div>

                      <div class="form-group col-md-6">
                            <label for="inputEmail4">Jogosultsági szint:</label>
                            <select data-validation="required" class="form-control" id="jogstatusz" name="jogstatusz">
                                <option disabled selected value>--- --- ---</option>



                                    <option value="1"   @if($model->jogszint == 1)selected="selected"@endif>Adminisztrátor</option>
                                    <option value="2" @if($model->jogszint == 2)selected="selected"@endif>Önkéntes</option>
                                    <option value="4" @if($model->jogszint == 4)selected="selected"@endif>Területvezető</option>


                            </select>
                        </div>

                        <div class="form-group col-md-6">
                                <label for="inputEmail4">Státusz</label>
                                <select  class="form-control" id="accountstate" name="accountstate">
                                        <option value="0"   @if($model->blocked == 0)selected="selected"@endif>Aktív</option>
                                        <option value="1" @if($model->blocked == 1)selected="selected"@endif>Letiltva/bannolva</option>
                                </select>
                                @if($model->blocked == 1)
                                    <label class="error">
                                    A felhasználó tiltva lett: {{$model->blocked_at}} <br/>
                                    A tiltó személy: {{ $model->WhoBannedForName}}

                                    </label>
                                @endif
                        </div>

                  </div>


          <!--   </form>-->
          </div>
          </div>

          <div class="card my-3">
            <div class="card-body">
              <h5 class="card-title">Állandó lakcím</h5>
            <!-- <form> -->
                <div class="row">
                        <div class="form-group col-md-6">
                                <label for="inputEmail4">Ország*</label>

                              <select class="form-control"  id="al_lakcim_orszag" name="al_lakcim_orszag" required>
                                    <option disabled selected value>--- Ország választás ---</option>
                                    {!! $model->all_lakcim_orszag   !!}
                            </select>
                        </div>
                        <div class="form-group col-md-6">
                                <label for="inputPassword4">Megye*</label>

                              <select class="form-control"  id="al_lakcim_megye" name="al_lakcim_megye" required>
                                      <option disabled selected value>--- Megye választás ---</option>
                                    {!! $model->Megye_AllLakcim !!}
                              </select>
                              </div>
                </div>
              <div class="form-row">

                <div class="form-group col-md-6">
                  <label for="inputPassword4">Irányítószám*</label>
                  <input type="text" class="form-control" id="al_lakcim_irszam" name="al_lakcim_irszam" value="{{$model->all_lakcim_irszam}}" min="1000" max="9999" required>
                </div>
                <div class="form-group col-md-6">
                        <label for="inputEmail4">Település*</label>
                        <input type="text" class="form-control" id="al_lakcim_telepules" name="al_lakcim_telepules" value="{{$model->all_lakcim_telepules}}" required>
                </div>
              </div>
              <div class="form-row">
                <div class="form-group col-md-12">
                  <label for="inputPassword4">Utca, házszám*</label>
                  <input type="text" class="form-control" id="al_lakcim_utca" name="al_lakcim_utca" value="{{$model->all_lakcim_utca}}" required>
                </div>
              </div>

              <div class="form-row">
                <div class="form-group col-md-12">
                    <input type="checkbox" name="isTartLakcim" id="isTartLakcim"  value="TartAzonos" > A Tartozkodási helyem azonos, az Állandó lakcímemmel </div>
              </div>

           <!--  </form> -->
            </div>
          </div>

          <div class="card my-3" id="tartozkodasiBox" >
            <div class="card-body">
              <h5 class="card-title">Tartózkodási hely</h5>
            <form>


              <div class="form-row">
                    <div class="form-group col-md-6">
                      <label for="inputPassword4">Ország</label>

                    <select class="form-control"  id="tart_lakcim_orszag" name="tart_lakcim_orszag" >
                            <option disabled selected value>--- Ország választás ---</option>
                            {!! $model->tart_lakcim_orszag !!}
                    </select>
                    </div>

                    <div class="form-group col-md-6">
                            <label for="inputPassword4">Megye</label>

                          <select class="form-control"  id="tart_lakcim_megye" name="tart_lakcim_megye" >
                                  <option disabled selected value>--- Megye választás ---</option>
                              {!! $model->Megye_TartLakcim !!}
                          </select>
                          </div>
                </div>

                <div class="form-row">
                        <div class="form-group col-md-6">
                          <label for="inputPassword4">Irányítószám</label>
                        <input type="text" class="form-control" id="tart_lakcim_irszam" name="tart_lakcim_irszam" value="{{$model->tart_lakcim_irszam}}">
                        </div>
                        <div class="form-group col-md-6">
                                <label for="inputEmail4">Település</label>
                                <input type="text" class="form-control" id="tart_lakcim_telepules" name="tart_lakcim_telepules" value="{{$model->tart_lakcim_telepules}}">
                              </div>
                </div>

              <div class="form-row">

                <div class="form-group col-md-12">
                  <label for="inputPassword4">Utca, házszám</label>
                  <input type="text" class="form-control" id="tart_lakcim_utca" name="tart_lakcim_utca" value="{{$model->tart_lakcim_utca}}">
                </div>
              </div>


            </form>
            </div>
          </div>

          <div class="card my-3" id="AltKerdesekBox">
            <div class="card-body">
                <h5 class="card-title">Általános kérdések</h5>

                <div class="form-row">
                    <div class="form-group col-md-12">
                        <label>Önkénteskedik-e Ön jelenleg más szervezetnél? </label>
                        {!! $model->masSzervezetTagja !!}

                        <select class="form-control col-md-4" id="masSzervezetTagja" name="masSzervezetTagja">
                            <option disabled selected value>-- Kérem válasszon --</option>



                            @if (!isset($model->masSzervezetTagja ))
                                <option value="1" >Igen</option>
                                <option value="0">Nem</option>
                            @else
                                @if ($model->masSzervezetTagja)
                                <option value="1" selected>Igen</option>
                                <option value="0">Nem</option>
                                @endif
                                @if ($model->masSzervezetTagja == false)
                                    <option  value="1" >Igen</option>
                                    <option value="0" selected>Nem</option>
                                @endif
                            @endif



                        </select>

                        @if($model->masSzervezetTagja)
                            <div class="dinamikusSzervezetMegj">
                                <label>A szervezet neve</label>
                                <input type="text" class="form-control" id="egyebSzervezet" name="egyebSzervezet" value="{{$model->MasSzervezetNeve}}">
                            </div>

                        @else
                            <div class="dinamikusSzervezetMegj" style="display: none;">
                                <label>A szervezet neve</label>
                                <input type="text" class="form-control" id="egyebSzervezet" name="egyebSzervezet" value="{{$model->MasSzervezetNeve}}">
                            </div>
                        @endif


                    </div>



                </div>

                <div class="form-row">
                    <div class="form-group col-md-12">
                        <label>Tagja-e Ön civil szervezetnek valamilyen közösségnek? </label>


                        <select class="form-control col-md-4" id="masCivilSzervezetTagja" name="masCivilSzervezetTagja">
                            <option disabled selected value>-- Kérem válasszon --</option>
                            @if(!isset($model->CivilSzervezetTagja))
                            <option value="1">Igen</option>
                            <option value="0">Nem</option>
                            
                            @else
                              <option value="1" @if($model->CivilSzervezetTagja) selected @endif >Igen</option>
                             <option value="0" @if(!$model->CivilSzervezetTagja) selected @endif>Nem</option>
                        
                            @endif
                            
                        </select>

                        @if($model->CivilSzervezetTagja)
                        <div class="dinamikusSzervezetMegjCivil">
                            <label>A szervezet neve</label>
                            <input type="text" class="form-control" id="civilSzervezet" name="civilSzervezet" value="{{$model->CivilSzervezetNeve}}">

                        </div>

                        @else
                        <div class="dinamikusSzervezetMegjCivil" style="display: none;">
                            <label>A szervezet neve</label>
                            <input type="text" class="form-control" id="civilSzervezet" name="civilSzervezet" value="{{$model->CivilSzervezetNeve}}">

                        </div>
                        @endif

                    </div>
                </div>


                <div class="form-row">
                    <div class="form-group col-md-12">
                        <label>Tagja-e valamelyik egyházközösségnek?* </label>


                                <div class="dinamikusEgyhazMegj" id="Felekezet">
                                    <select class="form-control col-md-12" id="Felekezetek" name="Felekezetek" data-validation="required" onchange="select_egyhazkozosseg();">
                                        <option disabled  selected>Kérem válasszon</option>
                                        @foreach($felekezetek as $felekezet)
                                            <option value="{{$felekezet}}">{{$felekezet}}</option>
                                        @endforeach
                                    </select>
                                </div>

                                <div class="dinamikusEgyhazMegj d-none" id="EgyhazMegye">
                                    <select class="form-control col-md-12" id="egyhazmegyek" name="egyhazmegyek" >
                                        <option disabled  selected>Kérem válasszon</option>
                                    </select>
                                </div>

                                <div id="Egyebinput" class="d-none">
                                    <input type="text" id="egyhazinput" name="egyhazinput" class="form-control col-md-12">
                                </div>






                    </div>
                </div>


            </div>
        </div>

        </div>

        <div class="col-6">

                <div class="card my-3">
                        <div class="card-body">
                                <div class="form-group">
                                        <label for="profileKep">Profilkép feltöltés</label>
                                        <div style=" border: 1px solid whitesmoke ;text-align: center;position: relative" id="image">
                                                <img width="50%" height="50%" id="preview_image" src="{{ url('userpic/'.$model->OnkentesProfilPic) }}"/>
                                                <i id="loading" class="fa fa-spinner fa-spin fa-3x fa-fw" style="position: absolute;left: 40%;top: 40%;display: none"></i>
                                        </div>
                                            <p>


                                            </p>
                                            <input type="file" id="file" style="display: none"/>
                                            <input type="hidden" id="file_name"/>

                                </div>
                            <div class="form-group">
                              <label for="adminKepModeralas">Profilkép moderálása</label>
                              <a href="#" class="btn btn-primary" id="validprofilepic">Megfelelő profilkép</a>
                              <a  href="#" class="btn btn-danger" id="invalidprofilepic">Nem megfelelő</a>
                            </div>

                          <div class="form-group">
                              <label for="adminKepModeralas">Profilkép moderálásának állapota: 
                                 </label>
                              <table></table>
                            </div>
                          </div>
                </div>

                <div class="card my-3">
                    <div class="card-body">
                        <p>Önkéntes óráim száma: <input class="form-control" type="number" readonly value="{{$model->onkentesOrakSzama}}"></p>
                    </div>
                </div>

          <div class="card my-3">
            <div class="card-body">

                <div class="form-group">
                    <label for="inputAddress">Jelenleg főtevékenységként mivel foglalkozik?*</label>
                    <select data-validation="required" class="custom-select is-valid" id="tevekenyseg" name="tevekenyseg" data-validation="required" required>
                        <option disabled selected value>Kérem válasszon</option>

                        {!! $model->foteveknyseg !!}

                    </select>
                    <section id="fotevekenysegem">
                        {!! $model->fotevekenysegHTML !!}
                    </section>
                </div>
                <div class="form-group">
                    <label for="inputPassword4">Ön fogyatékossággal élő személy?*</label>
                    <select data-validation="required" class="custom-select col-12 col-md-6" id="fogyatekossag" name="fogyatekossag" required>
                        <option disabled selected value>Kérem válasszon</option>
                          @php if($model->fogyatekossag == 0) {$model->fogyatekossag = 'Nem';} else {$model->fogyatekossag = 'Igen';}  @endphp
                        @if($model->fogyatekossag == 'Nem')
                        <option value="1">igen</option>
                        <option value="0" selected="selected">nem</option>
                        @elseif($model->fogyatekossag == 'Igen')
                        <option value="1" selected="selected">igen</option>
                        <option value="0">nem</option>
                        @else
                        <option value="1">igen</option>
                        <option value="0">nem</option>
                        @endif

                    </select>

                    @if($model->fogyatekossag == 'Nem')

                    <div class="fogyMegj" style="display: none;">
                        <label style="font-size:12px;">Amennyiben igen, kérem, jelezze felénk fogyatékossága típusát és fokát; és önkéntes közreműködése során esetleges különleges igényeit!

                        </label>
                        <input type="text" class="form-control" id="fogyLeirasa" name="fogyLeirasa" value="{{$model->FogyLeirasa}}" />
                    </div>
                    @else
                    <div class="fogyMegj">

                        <input type="text" class="form-control" id="fogyLeirasa" name="fogyLeirasa" value="{{$model->FogyLeirasa}}" />
                    </div>
                    @endif

                </div>
                <div class="form-group py-2">
                    <label for="inputPassword5">Pólómérete?*</label>
                    <br>
                    <select data-validation="required" class="custom-select col-12 col-md-6" id="userpolomeret" name="userpolomeret" required>
                        <option disabled selected value>Kérem válasszon</option>
                        {{!! $model->polomeret !!}}
                    </select>
                </div>

                <div class="form-group py-2">
                    <label for="inputPassword5">Póló típusa?*</label>
                    <br>
                    <select class="custom-select col-12 col-md-6" id="userpolotipusa" name="userpolotipusa" data-validation="required" required>
                            <option disabled selected value>Kérem válasszon</option>
                            {!! $model->GetHTMLPolotipusa() !!}
                    </select>

                </div>

                <div class="form-group py-2 checkboxok">
                    <label for="basic-url">Kérlek, jelezd különleges étkezési igényed! </label><br>

                      {!! $model->EtkezesHTMLOutput !!}

                </div>

                <div class="form-group py-2 radioboxok">
                    <label for="basic-url">Önkéntes közreműködésedről kérsz-e igazolást? </label><br>
                    <input type="radio" id="nem" name="igazolas" @if($model->igazolasIgenyID == 0) {{ __('checked') }}  @endif value="0" onchange="SetIgazolas();">
                    <label for="male">Nem</label><br>
                    <input type="radio" id="igen-alt" name="igazolas" value="1" @if($model->igazolasIgenyID == 1) {{ __('checked') }}  @endif onchange="SetIgazolas();">
                    <label for="female">igen, önkéntességről általában</label><br>
                    <input type="radio" id="igen-szakmai" name="igazolas" value="2" @if($model->igazolasIgenyID == 2) {{ __('checked') }}  @endif onchange="SetIgazolas();">
                    <label for="other">igen, szakmai gyakorlathoz</label><br>
                    <input type="radio" id="iksz" name="igazolas" value="3" @if($model->igazolasIgenyID == 3) {{ __('checked') }}  @endif onchange="SetIgazolas();">
                    <label for="other">igen, iskolai közösségi szolgálathoz (IKSZ)</label><br>
                    <input type="radio" id="ig_egyeb" name="igazolas" value="4" @if($model->igazolasIgenyID == 4) {{ __('checked') }}  @endif onchange="SetIgazolas();">
                    <label for="other">egyéb</label><br>
                      @if($model->igazolasIgenyID == 4)
                      <div id="ifIgazolasOther" >
                          <label id="otherLabel1" for="other">Kérlek írd be egyéb igényed: </label><br>
                          <input type="text" id="egyedIgIgeny" name="egyedIgIgeny" class="form-control" aria-label="egyeb-igeny-igazolas" value="{{$model->igazolasIgenyLeiras}}">
                      </div>
                      @else
                      <div id="ifIgazolasOther" style="display: none;">
                          <label id="otherLabel1" for="other">Kérlek írd be egyéb igényed: </label><br>
                          <input type="text" id="egyedIgIgeny" name="egyedIgIgeny" class="form-control" aria-label="egyeb-igeny-igazolas" value="">
                      </div>
                      @endif

                    <br>
                  </div>
                  <hr>
                  <div class="form-group py-2 radioboxok">
                    <label for="basic-url">Szállást kér? </label><br>
                    <input type="radio" id="SzallasIgen" name="szallastIgenyel" value="1" @if($szallastIgenyel == 1) checked @endif>
                  <label for="igen">Igen</label><br>
                  <input type="radio" id="SzallasNem" name="szallastIgenyel" value="0" @if($szallastIgenyel == 0 || empty($szallastIgenyel)) checked @endif>
                  <label for="nem">Nem</label><br>
                </div>
            </div>
          </div>

          <div class="card my-3">
            <div class="card-body">
              <h5 class="card-title">Nyelvismeret</h5>

              <div class="form-row">
                  <div class="form-group col-md-6">
                      <label for="inputEmail4">Nyelv 1</label>
                      <select class="form-control"  id="nyelv1" name="nyelv1" >
                          <option disabled selected value>--- Kérjük válasszon ---</option>
                      </select>

                  </div>
                  <div class="form-group col-md-6">
                      <label for="inputEmail4">Nyelvtudás szintje</label>
                      <select class="custom-select" id="nyelv1szint" name="nyelv1szint" >
                          <option disabled selected value>Kérem válasszon</option>
                          {{!! $model->nyelv1szint !!}}
                      </select>
                  </div>
              </div>
              <div class="form-row">
                  <div class="form-group col-md-6">
                      <label for="inputEmail4">Nyelv 2</label>
                      <select class="form-control"  id="nyelv2" name="nyelv2" >
                          <option disabled selected>--- Kérjük válasszon ---</option>
                      </select>

                  </div>
                  <div class="form-group col-md-6">
                      <label for="inputEmail4">Nyelvtudás szintje</label>
                      <select class="custom-select" id="nyelv2szint" name="nyelv2szint" >
                          <option disabled selected value>Kérem válasszon</option>
                          {{!! $model->nyelv2szint !!}}
                      </select>
                  </div>
              </div>
              <div class="form-row">
                  <div class="form-group col-md-6">
                      <label for="inputEmail4">Nyelv 3</label>
                      <select class="form-control"  id="nyelv3" name="nyelv3" >
                          <option disabled selected >--- Kérjük válasszon ---</option>
                      </select>

                  </div>
                  <div class="form-group col-md-6">
                      <label for="inputEmail4">Nyelvtudás szintje</label>
                      <select class="custom-select" id="nyelv3szint" name="nyelv3szint" >
                          <option disabled selected value>Kérem válasszon</option>
                          {{!! $model->nyelv3szint !!}}
                      </select>
                  </div>
              </div>


              <div class="form-row">
                  <div class="form-group col-md-6">
                      <label for="inputEmail4">Nyelv 4</label>
                      <select class="form-control"  id="nyelv4" name="nyelv4">
                          <option disabled selected >--- Kérjük válasszon ---</option>
                      </select>

                  </div>
                  <div class="form-group col-md-6">
                      <label for="inputEmail4">Nyelvtudás szintje</label>
                      <select class="custom-select" id="nyelv4szint" name="nyelv4szint">
                          <option disabled selected value>Kérem válasszon</option>
                          {{!! $model->nyelv4szint !!}}
                      </select>
                  </div>
              </div>

              <div class="form-row">
                  <div class="form-group col-md-6">
                      <label for="inputEmail4">Nyelv 5</label>
                      <select class="form-control"  id="nyelv5" name="nyelv5">
                          <option disabled selected >--- Kérjük válasszon ---</option>
                      </select>

                  </div>
                  <div class="form-group col-md-6">
                      <label for="inputEmail5">Nyelvtudás szintje</label>
                      <select class="custom-select" id="nyelv5szint" name="nyelv5szint">
                          <option disabled selected value>Kérem válasszon</option>
                          {{!! $model->nyelv5szint !!}}
                      </select>
                  </div>
              </div>

          </div>
          </div>
        </div>


        <div class="col-12 d-flex justify-content-end">
                <button type="submit" class="btn btn-primary">Profil adatok mentése</button>

        </div>
      </div>


    </form>
        <form action="{{url('/admin/onkentes_torles/')}}" method="post" >
            @csrf
            <input type="hidden" name="email" value="{{$model->email}}" >
            <input type="submit" class="btn btn-danger" value="Törlés">
        </form>

        <div id="MailBox" class="modal fade">
            <div class="modal-dialog">
                <div class="modal-content">
                <form action="{{url('sendmailtouser')}}" method="POST" id="mailmsgform" name="mailmsgform">
                        <div class="modal-header">
                            <h4 class="modal-title">Email üzenet küldése</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        </div>
                        <div class="modal-body">
                            <textarea class="form-control" id="EmailMsgContent" name="EmailMsgContent"></textarea>
                        </div>
                        <div class="modal-footer">
                            @csrf
                             <input type="hidden" class="btn btn-default" id="uid" name="uid" value="{{$id}}">
                             <input type="hidden" class="btn btn-default" id="toMail" name="toMail" value="{{$model->email}}">
                            <input type="button" class="btn btn-default" data-dismiss="modal" value="Mégse">
                            <input type="submit" id="mailSendBtn" class="btn btn-danger" value="Küldés">
                        </div>
                    </form>
                </div>
            </div>
        </div>
<!-- MODAL'S -->
        <div id="accountActivatedModal" class="modal fade">
          <div class="modal-dialog">
              <div class="modal-content">

                      <div class="modal-header">
                          <h4 class="modal-title">Fiók aktiválása</h4>
                          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                      </div>
                      <div class="modal-body">
                          <p>Biztosan aktiválni szeretnéd a felhasználó helyett ezt a fiókot?</p>
                       </div>
                      <div class="modal-footer">
                          <input type="number" class="d-none" id="uid" name="uid" value="{{$id}}">
                          <input type="button" class="btn btn-default" data-dismiss="modal" value="Mégse">
                          <input type="button" id="esemenyTorlesBtn" class="btn btn-danger" value="Igen">
                      </div>

              </div>
          </div>
      </div>

      <div id="PswdChangeBox" class="modal fade">
        <div class="modal-dialog">
            <div class="modal-content">
               
                    <div class="modal-header">
                        <h4 class="modal-title">Jelszó változtatás</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    </div>
                    <div class="modal-body">
                        <p>Biztosan megváltoztatja a jelszavát?</p>
                        <div class="form-group">
                            <section id="messageSection">
                              <p id="alertmsg" class="alert alert-danger d-none">A jelszavak nem egyeznek!</p>
                            </section>
                        </div>
                        <div class="form-group">
                            <label>Új jelszó</label>
                            <input type="password" id="newPwd" class="form-control" name="newPwd">
                        </div>
                        <div class="form-group">
                            <label>Új jelszó ismét</label>
                            <input type="password" id="renewPwd" class="form-control" name="renewPwd">
                        </div>
                    </div>
                    <div class="modal-footer">
                      <input type="number" class="d-none" id="uid" name="uid" value="{{$id}}">
                        <input type="button" class="btn btn-default" data-dismiss="modal" value="Mégse">
                        <input type="submit" id="xhangePswd" class="btn btn-danger" value="Változtatás">
                    </div>
                
            </div>
        </div>
    </div>

<!-- MODAL'S END -->

<script>
  $(document).ready(function(){
    $('#accountActivatedModal').click(function(){
                        let uid = $('#uid').val();
                        $.ajax({
                                type:'POST',
                                url:'{{url('AccVerified')}}',
                                data:{_token:'<?php echo csrf_token() ?>', id:uid },
                                success:function(data) {
                                  
                                    if(data == 1) {
                                      alert("A fiók sikeresen megerősítve!");
                                    }
                                    $('#accountActivatedModal').modal('hide');
                                }
                            });
                    });
                    
                    
                    $('#xhangePswd').click(function(){
                        let uid = $('#uid').val();
                        let newpaswd = "";

                        let pwd =  $('#newPwd').val();
                        let repwd =  $('#renewPwd').val();
                      console.log(pwd);
                        if(pwd == repwd)
                        {
                          $.ajax({
                                type:'POST',
                                url:'{{url('PwdChangeForAdmin')}}',
                                data:{_token:'<?php echo csrf_token() ?>', id:uid, pwd:pwd },
                                success:function(data) {
                                  
                                    if(data == 1) {
                                      alert("A fiók sikeresen megerősítve!");
                                    }
                                    $('#PswdChangeBox').modal('hide');
                                }
                            });
                        }
                        else 
                        {
                          $('#alertmsg').removeClass('d-none');
                        }
                       
                    });

  });


</script>


    <script>

            $("input#isTartLakcim").change(function(){
                let isTart = $("input#isTartLakcim").is( ":checked" );
                if(isTart)
                {
                      $("#tartozkodasiBox").hide();
                     // console.log('true');
                }else
                {
                   // console.log('false');
                    $("#tartozkodasiBox").show();
                }
            });
            $("select#al_lakcim_orszag").change(function(){
            var selecValue = $("select#al_lakcim_orszag").val();
            if(selecValue != 109)
            {
                let i;
                for(i = 0; i < 21; i++)
                {
                    $("#al_lakcim_megye option[value='"+i+"']").hide();
                }
            }
            else{
                let i;
                for(i = 0; i < 21; i++)
                {
                    $("#al_lakcim_megye option[value='"+i+"']").show();
                }
            }
         });
         $('#fogyatekossag').change(function(){
            if($('#fogyatekossag').val() == 1)
            {
                $('.fogyMegj').show();
            }
         });
    </script>





<script src="{{asset('js/datetimepicker-bs4.js')}}" type="text/javascript"></script>
<link href="https://unpkg.com/gijgo@1.9.13/css/gijgo.min.css" rel="stylesheet" type="text/css" />


    <script>
        $('#datepicker').datepicker({
            uiLibrary: 'bootstrap4'
        });
    </script>

<script type="text/javascript">

    $(document).ready(function(){
      let szulDatum = '{{ $model->szulido }}';
        let szulDatumDarabok = szulDatum.split('-');
        let szulEv = szulDatumDarabok[0];let szulHo = szulDatumDarabok[1];let szulNap = szulDatumDarabok[2];
        console.log(szulEv);
        
        for(let i = 1930; i < 2006;i++)
        {
            if(szulEv == i)
            {//selected
                let x = document.getElementById("szuletesiIdoEv");
                let option = document.createElement("option");
                option.text =i; option.value = i; option.id = "ev-"+i;
                x.add(option);
                document.getElementById("ev-"+i).selected = true;
            }
            else //not selected 
            {
                let x = document.getElementById("szuletesiIdoEv");
                let option = document.createElement("option");
                option.text =i; option.value =i;option.id = "ev-"+i;
                x.add(option);
            }
        }

        for(let i = 1; i < 13;i++)
        {
            if(szulHo == i)
            {//selected
                let x = document.getElementById("szuletesiIdoHo");
                let option = document.createElement("option");
                option.text =i; option.value = i; option.id = "ho-"+i;
                x.add(option);
                document.getElementById("ho-"+i).selected = true;
            }
            else //not selected 
            {
                let x = document.getElementById("szuletesiIdoHo");
                let option = document.createElement("option");
                option.text =i; option.value =i;option.id = "ho-"+i;
                x.add(option);
            }
        }

        for(let i = 1; i < 32;i++)
        {
            if(szulNap == i)
            {//selected
                let x = document.getElementById("szuletesiIdoNap");
                let option = document.createElement("option");
                option.text =i; option.value = i; option.id = "nap-"+i;
                x.add(option);
                document.getElementById("nap-"+i).selected = true;
            }
            else //not selected 
            {
                let x = document.getElementById("szuletesiIdoNap");
                let option = document.createElement("option");
                option.text =i; option.value =i;option.id = "nap-"+i;
                x.add(option);
            }
        }


        $('#masSzervezetTagja').change(function(){
            let szervezet = $('#masSzervezetTagja').val();
            if(szervezet == 1)
            {
                $('div.dinamikusSzervezetMegj').show();;
            }
        });

        $('#masCivilSzervezetTagja').change(function(){
            let szervezet = $('#masCivilSzervezetTagja').val();
            if(szervezet == 1)
            {
                $('div.dinamikusSzervezetMegjCivil').show();;
            }
        });

        $('#tevekenyseg').change(function(){
            let tevekenyseg = $('#tevekenyseg').val();
            switch(tevekenyseg)
            {
                case "1":
                    $("#fotevekenysegem").empty();
                    var txt2 = $("<p></p>").text("Kérem, adja meg intézménye teljes nevét és címét! *");
                    var inputfield_iskneve = '<input class="form-control" type="text" id="foisk" name="foisk" />';
                    var txt3 =  $("<p></p>").text("Tanulmányi területének(szak) neve? *");
                    var inputfield_osztaly = '<input class="form-control" type="text" id="szakneve" name="szakneve" />';
                    var txt4 =  $("<p></p>").text("Hányadik évfolyamba jár? *");
                    var inputfield_osztaly2 = '<input class="form-control" type="number" id="evfolyam" name="evfolyam" />';
                     $("#fotevekenysegem").append( txt2, inputfield_iskneve,txt3, inputfield_osztaly,txt4,inputfield_osztaly2);
                break;
                case "2":
                    $("#fotevekenysegem").empty();
                    var txt2 = $("<p></p>").text("Kérem, adja meg intézménye teljes nevét és címét! *");
                    var inputfield_iskneve = '<input class="form-control" type="text" id="kozepisk" name="kozepisk" />';
                    var txt3 =  $("<p></p>").text("Hányadik osztályba jár? *");
                    var inputfield_osztaly = '<input class="form-control" type="number" id="kozepiskoszt" name="kozepiskoszt" />';
                     $("#fotevekenysegem").append( txt2, inputfield_iskneve,txt3, inputfield_osztaly);
                break;
                case "3":
                    $("#fotevekenysegem").empty();
                    var txt2 = $("<p></p>").text("Kérem, adja meg intézménye teljes nevét és címét! *");
                    var inputfield_iskneve = '<input class="form-control" type="text" id="altisk" name="altisk" />';
                    var txt3 =  $("<p></p>").text("Hányadik osztályba jár? *");
                    var inputfield_osztaly = '<input class="form-control" type="number" id="altiskoszt" name="altiskoszt" />';
                     $("#fotevekenysegem").append( txt2, inputfield_iskneve,txt3, inputfield_osztaly);
                break;
                case "4":
                    $("#fotevekenysegem").empty();
                    var txt2 = $("<p></p>").text("Kérem, adja meg intézménye teljes nevét és címét! *");
                    var inputfield_iskneve = '<input class="form-control" type="text" id="munkahely" name="munkahely" />';
                    var txt3 =  $("<p></p>").text("Kérem, írja be mi a munkája/beosztása *");
                    var inputfield_osztaly = '<input class="form-control" type="text" id="munkakor" name="munkakor" />';
                     $("#fotevekenysegem").append( txt2, inputfield_iskneve,txt3, inputfield_osztaly);
                break;
                default:
                $("#fotevekenysegem").empty();
                    break;
            }
        });


    });


</script>

@endsection

@section('scriptsection')

<script>
  var spokenLangs = {!!$model->BeszelhetoNyelvek!!};
  let nyelv1 = @if(strlen($model->nyelv1) > 3) '{{$model->nyelv1}}' @else 'undefined' @endif;
  let nyelv2 = @if(strlen($model->nyelv2) > 3) '{{$model->nyelv2}}' @else 'undefined' @endif;
  let nyelv3 = @if(strlen($model->nyelv3) > 3) '{{$model->nyelv3}}' @else 'undefined' @endif;
  let nyelv4 = @if(strlen($model->nyelv4) > 3) '{{$model->nyelv4}}' @else 'undefined' @endif;
  let nyelv5 = @if(strlen($model->nyelv5) > 3) '{{$model->nyelv5}}' @else 'undefined' @endif;

  $(document).ready(function(){
      for(let i = 0; i < spokenLangs.length;i++)
      {
          if(nyelv1 == spokenLangs[i]["nyelvNeve"])
          {
              $('#nyelv1').append(new Option(spokenLangs[i]["nyelvNeve"], spokenLangs[i]["nyelvNeve"],false,true));
          }
          else
          {
              $('#nyelv1').append(new Option(spokenLangs[i]["nyelvNeve"], spokenLangs[i]["nyelvNeve"]));
          }

          if(nyelv2 == spokenLangs[i]["nyelvNeve"])
          {
              $('#nyelv2').append(new Option(spokenLangs[i]["nyelvNeve"], spokenLangs[i]["nyelvNeve"],false,true));
               }
          else
          {
              $('#nyelv2').append(new Option(spokenLangs[i]["nyelvNeve"], spokenLangs[i]["nyelvNeve"]));
          }
          if(nyelv3 == spokenLangs[i]["nyelvNeve"])
          {
              $('#nyelv3').append(new Option(spokenLangs[i]["nyelvNeve"], spokenLangs[i]["nyelvNeve"],false,true));
               }
          else
          {
              $('#nyelv3').append(new Option(spokenLangs[i]["nyelvNeve"], spokenLangs[i]["nyelvNeve"]));
          }
          if(nyelv4 == spokenLangs[i]["nyelvNeve"])
          {
              $('#nyelv4').append(new Option(spokenLangs[i]["nyelvNeve"], spokenLangs[i]["nyelvNeve"],false,true));
               }
          else
          {
              $('#nyelv4').append(new Option(spokenLangs[i]["nyelvNeve"], spokenLangs[i]["nyelvNeve"]));
          }

          if(nyelv5 == spokenLangs[i]["nyelvNeve"])
          {
              $('#nyelv5').append(new Option(spokenLangs[i]["nyelvNeve"], spokenLangs[i]["nyelvNeve"],false,true));
           }
          else
          {
              $('#nyelv5').append(new Option(spokenLangs[i]["nyelvNeve"], spokenLangs[i]["nyelvNeve"]));
          }
          }

          let selectedLakcimOrsz = $("select#al_lakcim_orszag").val();
          if(selectedLakcimOrsz == 109)
          {
              $("#al_lakcim_megye option[value='" + 21 + "']").hide();
          }
          else
          {
              let i;
              for (i = 0; i < 21; i++) {
                  $("#al_lakcim_megye option[value='" + i + "']").hide();

              }
          }

          let selectedTartOrsz = $("select#tart_lakcim_orszag").val();
          if(selectedTartOrsz == 109)
          {
              $("#tart_lakcim_megye option[value='" + 21 + "']").hide();
          }
          else
          {
              let i;
              for (i = 0; i < 21; i++) {
                  $("#tart_lakcim_megye option[value='" + i + "']").hide();

              }
          }


          let selectedAllIrsz = $("#al_lakcim_irszam").val();let selectedTartIrsz = $("#tart_lakcim_irszam").val();
          let notNUll = false;

          if(parseInt(selectedAllIrsz) > 1009 && parseInt(selectedTartIrsz) > 1009)
          {notNUll = true;}
          else
          {
             // console.log("dsfs:" + selectedTartIrsz);
             // alert('Az irányítószám nem megfelelő! Kérjük ellenőrizze!');
          }
          console.log("notnull: " + notNUll);
         /*hide tart_lakcim_box*/
         if(notNUll)
         {

              let selectedAllMegye = $("select#al_lakcim_megye").val();
              let selectedAllTel = $("#al_lakcim_telepules").val();let selectedTartTel = $("#tart_lakcim_telepules").val();

              let selectedAllLakcim= $("#al_lakcim_utca").val();

              let selectedTartMegye = $("select#tart_lakcim_megye").val();

              let selectedTartLakcim= $("#tart_lakcim_utca").val();
              let Megye = false; let Irsz = false; let Lakcim = false; let Telepules = false;

              if(parseInt(selectedAllIrsz) == parseInt(selectedTartIrsz))
              {Irsz = true; }
              if(selectedAllTel == selectedTartTel)
              {Telepules = true;}
              if(selectedAllMegye == selectedTartMegye)
              {Megye = true;}
              if(selectedAllLakcim == selectedTartLakcim)
              {Lakcim = true;}

              if(Megye && Irsz && Lakcim && Telepules)
              {

                  $('#tartozkodasiBox').hide();
                  document.getElementById("isTartLakcim").checked = true;

              }
         }
         else {console.log("hiba");}
  });

  function SetIgazolas()
  {

      let igazolas_value = document.getElementById('ig_egyeb').checked;
      if(igazolas_value)
      {
           document.getElementById('ifIgazolasOther').style.display = 'block';
      }
      else
      {document.getElementById('ifIgazolasOther').style.display = 'none';}
  }

  var kozosseg = JSON.parse(@php echo json_encode($egyhazmegyek) @endphp);

  function select_egyhazkozosseg()
  {
      let felekezet = document.getElementById('Felekezetek').value;

      let romaikat = [];
      let gorogkat = [];
      for(let i = 0; i < Object.keys(kozosseg).length;i++)
      {
          if(kozosseg[i].felekezet == 'Görög Katolikus Egyház')
          {
              gorogkat.push(kozosseg[i].nev);
          }
          if(kozosseg[i].felekezet == 'Római Katolikus Egyház')
          {
              romaikat.push(kozosseg[i].nev);
          }
      }
      switch(felekezet)
      {
          case 'Római Katolikus Egyház':
              document.getElementById('Egyebinput').classList.add('d-none');
              $('#egyhazmegyek').empty().append(new Option("Kérem válasszon",''));
              for(let i = 0; i < romaikat.length;i++)
              {

                  $('#egyhazmegyek').append(new Option(romaikat[i], romaikat[i]));
              }
              $('#EgyhazMegye').removeClass('d-none');
              $('#egyhazmegyek').removeClass('d-none');
              document.getElementById('egyhazmegyek').dataset.validation = "required";
          break;
          case 'Görög Katolikus Egyház':
              $('#egyhazmegyek').empty().append(new Option("Kérem válasszon",''));
              document.getElementById('Egyebinput').classList.add('d-none');
              for(let i = 0; i < gorogkat.length;i++)
              {

                  $('#egyhazmegyek').append(new Option(gorogkat[i], gorogkat[i]));
              }
              $('#EgyhazMegye').removeClass('d-none');
              $('#egyhazmegyek').removeClass('d-none');
              document.getElementById('egyhazmegyek').dataset.validation = "required";
          break;

          case 'Egyéb':
          document.getElementById('egyhazmegyek').classList.add('d-none');
              $('#Egyebinput').removeClass('d-none');
              $("select#egyhazmegyek").removeData('validation');
          break;

          case 'egyéb':document.getElementById('egyhazmegyek').classList.add('d-none');
              $('#Egyebinput').removeClass('d-none'); $("select#egyhazmegyek").removeData('validation');
          break;
          default:
          document.getElementById('Egyebinput').classList.add('d-none');document.getElementById('egyhazmegyek').classList.add('d-none');
          $("select#egyhazmegyek").removeData('validation');
              $("#egyhazinput").removeData('validation');
          break;

      }
  }

  var valasztottEgyhaz = JSON.parse('{!! $valasztottEgyhazMegye !!}');
  var felekezet = null;

  $(document).ready(function(){
      let normal = true;
      if(valasztottEgyhaz.egyhazmegye_id == 10)
      {
        $("select#Felekezetek").val('Nem tartozom felekezethez');
        normal = false;
      }
      if(valasztottEgyhaz.egyhazmegye_id == 9)
      {
        $("select#Felekezetek").val('Egyéb');
        $("#Egyebinput").removeClass('d-none');
        $("#egyhazinput").val(valasztottEgyhaz.egyebInputValue);
        normal = false;
      }

      if(normal)
      {
        for(let i = 0; i < Object.keys(kozosseg).length;i++)
        {
            if(parseInt(kozosseg[i].id) == parseInt(valasztottEgyhaz.egyhazmegye_id))
            {
                felekezet = kozosseg[i];
                  
            }

        }
        switch(felekezet.felekezet)
        {
            case 'Római Katolikus Egyház':
                $("select#Felekezetek").val(felekezet.felekezet);
                select_egyhazkozosseg()
                $("select#egyhazmegyek").val(felekezet.nev);$("#EgyhazMegye").removeClass('d-none');
                //data-validation="required"
                $("select#egyhazmegyek").data('validation','required');
            break;
            case 'Görög Katolikus Egyház':
                $("select#Felekezetek").val(felekezet.felekezet);
                select_egyhazkozosseg();
                $("select#egyhazmegyek").val(felekezet.nev);$("#EgyhazMegye").removeClass('d-none');
                $("select#egyhazmegyek").data('validation','required');
            break;

            case 'Egyéb':
                $("#egyhazinput").val(felekezet.egyhazmegye_id);
                document.getElementById('Felekezetek').value = "9";
                $("select#egyhazmegyek").removeData('validation');
            break;

            case 'egyéb':document.getElementById('egyhazmegyek').classList.add('d-none');
                $("select#Felekezetek").val(felekezet.felekezet);
                $("select#egyhazmegyek").removeData('validation');
                document.getElementById('Egyebinput').classList.remove('d-none');
                document.getElementById('egyhazinput').value = valasztottEgyhaz.egyebInputValue;
            break;
            default:
                $("select#egyhazmegyek").val('Nem tartozom felekezethez');
                $("select#egyhazmegyek").removeData('validation');
                $("#egyhazinput").removeData('validation');
            break;

        }
      }
     
  });


</script>

<script src="https://cdn.ckeditor.com/4.13.1/basic/ckeditor.js"></script>

<script>
        CKEDITOR.replace( 'EmailMsgContent' );
</script>


<script src="{{ asset('js/jquery.form-validator.min.js') }}"></script>
<script>
    var myLanguage = {

        errorTitle: 'Az űrlap feldolgozása sikertelen.',
        requiredFields: 'Az összes kötelező mezőt ki kell tölteni!',
        badTime: 'Rossz idő formátum',
        badEmail: 'Nem megfelelő e-mail cím formátum',
        badTelephone: 'Nem megfelelő telefonszám formátum',
        badDate: 'You have not given a correct date',
        lengthBadStart: 'The input value must be between ',
        lengthBadEnd: ' karakter',
        lengthTooLongStart: 'The input value is longer than ',
        lengthTooShortStart: 'Az input érték nem lehet kevesebb, mint ',
        notConfirmed: 'Input values could not be confirmed',
        badDomain: 'Incorrect domain value',
        badUrl: 'The input value is not a correct URL',
        badCustomVal: 'The input value is incorrect',
        andSpaces: ' and spaces ',
        badInt: 'The input value was not a correct number',
        badSecurityNumber: 'Your social security number was incorrect',
        badUKVatAnswer: 'Incorrect UK VAT Number',
        badStrength: 'The password isn\'t strong enough',
        badNumberOfSelectedOptionsStart: 'You have to choose at least ',
        badNumberOfSelectedOptionsEnd: ' answers',
        badAlphaNumeric: 'The input value can only contain alphanumeric characters ',
        badAlphaNumericExtra: ' and ',
        wrongFileSize: 'The file you are trying to upload is too large (max %s)',
        wrongFileType: 'Only files of type %s is allowed',
        groupCheckedRangeStart: 'Please choose between ',
        groupCheckedTooFewStart: 'Please choose at least ',
        groupCheckedTooManyStart: 'Please choose a maximum of ',
        groupCheckedEnd: ' item(s)',
        badCreditCard: 'The credit card number is not correct',
        badCVV: 'The CVV number was not correct',
        wrongFileDim: 'Incorrect image dimensions,',
        imageTooTall: 'the image can not be taller than',
        imageTooWide: 'the image can not be wider than',
        imageTooSmall: 'the image was too small',
        min: 'min',
        max: 'max',
        imageRatioNotAccepted: 'Image ratio is not accepted'
    };

    $.validate({
        language: myLanguage,
        rules: {
            required: true,
            telszam: {minlength: 7}
        }
    });

    $('#validprofilepic').click(function(){
                         let uid = $('#uid').val();
                        $.ajax({
                                type:'POST',
                                url:'#',
                                data:{_token:'<?php echo csrf_token() ?>', id:uid,vstatus: 1 },
                                success:function(data) {
                                  $("#picmodstatusLbl").text('Moderálva - Elfogadva').css('color','green');
                                }
                            });
    });

    
     $('#invalidprofilepic').click(function(){
                         let uid = $('#uid').val();
                        $.ajax({
                                type:'POST',
                                url:'#',
                                data:{_token:'<?php echo csrf_token() ?>', id:uid,vstatus: 2 },
                                success:function(data) {
                                  $("#picmodstatusLbl").text('Moderálva - Elutasítva - Email értesítés').css('color','red');
                                }
                            });
    });
</script>
@endsection
