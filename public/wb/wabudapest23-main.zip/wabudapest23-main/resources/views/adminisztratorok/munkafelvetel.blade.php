@extends('layouts.admin')

@section('content')

<div class="row">
    <div class="col-12 d-flex justify-content-between">
            <h1>Műszakigazolás</h1>
    </div>
    <div class="col-12 d-flex ">
            <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                      {!! $model->breadcrumblink !!}
                    </ol>
             </nav>

    </div>

    <div class="col-12 col-md-12 col-sm-12">
        <div class="card my-3">
            <div class="card-body">
                <p><span style="font-size: bold;">INFORMÁCIÓ:</span>a csoport időpontok kizárólag akkor jelennek meg, ha csoportnak van már vezetője!</p>
            </div>
        </div>
    </div>

    <div class="col-4 col-md-4 col-sm-12">
        <div class="card my-3">
            <div class="card-body">
                <table  class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>Csoport időpontok</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($model->munkaNapokArray as $datum)
                            <tr>
                                <td>{{$datum->csoport_date}}</td>
                                <td><a href="{{url('admin/muszakfelvetel/index/'.$model->teruletID.'/'.$model->csoportID.'/'.$datum->id)}}" class="btn btn-primary"> Kiválaszt </a></td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="col-6 col-md-6 col-sm-12">
        <div class="card my-3">
            <div class="card-body">
                <h3>Csoport információ</h3>
                <table  class="table table-striped table-hover">
                    <tbody>
                        <tr>
                            <th>Csoport neve:</th>
                            <td>{{$model->csoport->nev}}</td>
                        </tr>
                        <tr>
                            <th>Kezdés:</th>
                            <td>{{$model->csoport->kezdesDatuma}} {{$model->csoport->kezdesIdeje}}</td>
                        </tr>
                        <tr>
                            <th>Befejezés:</th>
                            <td>{{$model->csoport->befejezesDatuma}} {{$model->csoport->befejezesIdeje}}</td>
                        </tr>

                        @if(isset($model->kivalasztottNap))
                            <tr>
                                <th>Kiválasztott nap:</th>
                                <td style="color:Red;">
                                 @isset($muszak_datum_id) 
                                    {{$model->kivalasztottNap}}
                                @else 
                                    Válassz egy napot!
                                @endisset
                                </td>
                            </tr>
                        @endif


                    </tbody>
                </table>
            </div>
        </div>
    </div>


</div>

<div class="row">

    <div class="col-12 col-md-12">
<div class="card my-3">
<div class="card-body">



    <div class="row">
        <div class="col-12 d-flex justify-content-between">
            <h1>Műszakfelvétele, igazolása</h1>
        </div>
    </div>
    <div class="container2">

        <section>
            <p>
FIGYELEM! A '<b>H</b>' jelzés jelentése: Hiányzás. Akkor válassza a <b>'H'</b>-t, ha az Önkéntes nem jelent meg, tehát nem vette fel a műszakot!
            </p>
            <p>
 A '<b>M</b>' jelzés jelentése: Megjelent. 
            </p>
            <p>Az óraszámot, a rendszer automatikusan igazolja!</p>
        </section>
        <div class="row">

            <div class="col-12 col-md-12">

                <div class="card my-3">

                    <div class="card-body" style="height:600px;overflow-y:scroll;">

                        <div class="form-group">
                            <h5>
                                A csoportba beosztottak
                            </h5>
 @isset($muszak_datum_id)
                               <table class="table table-striped table-hover" id="teruletVezetok">
                                <thead>
                                    <tr>
                                        <th>Név</th>
                                        <th>Igazolás/Teljesített órák</th>
                                        <th>Művelet</th>
                                    </tr>
                                </thead>
                                <tbody class="addAbleMore"></tbody>
                                <tbody style="border-top: 3px solid #333" class="addAble">
                                    @foreach($nembeosztottak as $user)
                                    @php 
                                        $isMuszak = null;
                                        if($user->MuszakIgazolas($user->user_data->id,$actGroupID,$muszak_datum_id) > 0)
                                        {
                                                $isMuszak = true;
                                        }
                                        $teljesitettOraszam = $user->TeljesitettOraszam($user->user_data->id,$actGroupID,$muszak_datum_id);
                                    @endphp
                                        <tr id="usrow-{{$user->user_data->id}}" data-muig="{{$user->MuszakIgazolas($user->user_data->id,$actGroupID,$muszak_datum_id) }}" data-muszakid="{{$muszak_datum_id}}"  @isset($isMuszak) @if($user->MuszakIgazolas($user->user_data->id,$actGroupID,$muszak_datum_id) == $muszak_datum_id)  style="background-color: #708090;" @endif @endisset>
                                            <td>
                                                <span title="`+elem.birth+` - `+elem.address+`" class="pointer">{{$user->user_data->name}} </span></td>
                                        
                                            <td>
                                                <select class="form-control" style="width: 75px;" id="wh-{{$user->user_data->id}}" data-whid = "{{$user->user_data->id}}"  @isset($isMuszak) @if($user->MuszakIgazolas($user->user_data->id,$actGroupID,$muszak_datum_id) == $muszak_datum_id) disabled @endif @endisset>
                                                    
                                                    @isset($isMuszak) disabled 
                                                            
                                                        @if($user->MuszakIgazolas($user->user_data->id,$actGroupID,$muszak_datum_id) == $muszak_datum_id) 
                                                            <option value="" selected disabled>{{ $teljesitettOraszam}}</option>
                                                        @else 
                                                        <option value="" selected >--</option>
                                                        @endif
                                                    @else
                                                                <option value="" selected >--</option>
                                                    @endisset
                                                    
                                                    
                                                    <option value="0">H</option>
                                                    <option value="1">M</option>
                                                
                                                </select>
                                            </td>
                                            <td>
                                            
                                                <button id="igbtn-{{$user->user_data->id}}" class="btn btn-info" @isset($isMuszak) data-uid="{{$user->user_data->id}}"   @endisset
                                                 
                                                 
                                                 
                                                 @isset($isMuszak)
                                                    @if($user->MuszakIgazolas($user->user_data->id,$actGroupID,$muszak_datum_id) == $muszak_datum_id)
                                                     onclick="UserEventRemove({{$user->user_data->id}})" 
                                                    @else 
                                                     onclick="UserEventAdd({{$user->user_data->id}})"  
                                                    @endif
                                                  @else 
                                                      onclick="UserEventAdd({{$user->user_data->id}})"  

                                                  @endisset

                                                 >@isset($isMuszak)
                                                    @if($user->MuszakIgazolas($user->user_data->id,$actGroupID,$muszak_datum_id) == $muszak_datum_id)
                                                     Visszavonás 
                                                    @else 
                                                     Igazolás
                                                    @endif

                                                  @else 
                                                     Igazolás

                                                  @endisset</button>
                                                
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>                 
    
  @endisset
                            
                        </div>
                    </div>
                </div>
            </div>

        </div>



    </div>
</div>
</div>
</div>


<script>
$(document).on('keyup', '#searchOthers', function(){
var searchString = $(this).val();
if(searchString.length > 2){

    $('.addAbleMore').html(users.map(function(elem) {
        if(
            (elem.name.toLowerCase().includes(searchString.toLowerCase()) || elem.email.toLowerCase().includes(searchString.toLowerCase()))
            && !muszakIgazoltak.includes(elem.id)
            )
        return `

        <tr id="`+elem.id+`">
            <td>
                <span class="custom-checkbox">
                    <input type="checkbox" id="checkbox1" name="options[]" value="`+elem.id+`">
                    <label for="checkbox1"></label>
                </span>

            </td>
            <td><span title="`+elem.birth+` - `+elem.address+`" class="pointer">`+elem.name+`</span></td>

            <td>
                <i class="material-icons add_box pointer"  data-toggle="tooltip"  data-uid="`+elem.id+`" onclick="UserEventAdd(`+elem.id+`)">add_box</i>
            </td>
        </tr>

        `;
    }));

} else{
    $('.addAbleMore').html('');
}

})

function UserEventAdd(itemid){
    let csoport_id = {{$model->csoportID}};
    let selectid = 'wh-'+itemid;
  
    let muszakID = {{$model->MuszakID??0}};
    let sel = document.getElementById(selectid).value;
    $.ajax({
        type:'POST',
        url:'{{url('MunkafelvetelAdd')}}',
        data:{_token: '<?php echo csrf_token() ?>', csid:csoport_id,uid:itemid,muszak:muszakID,ig:sel},
        success:function(data) {
            if (data ==1 ) {
                           let trID = 'usrow-'+itemid; let whID = 'wh-'+itemid; let btnID = 'igbtn-'+itemid;
                            document.getElementById(trID).style.backgroundColor = '#708090';
                             document.getElementById(whID).disabled = true;
                             document.getElementById(btnID).innerText = 'Visszavonás';
                             document.getElementById(btnID).onclick = function() { UserEventRemove(itemid); }
                        }

        }
    });

}

function UserEventRemove(itemid)
{
   let csoport_id = {{$model->csoportID}};
    let selectid = 'wh-'+itemid;
  
    let muszakID = {{$model->MuszakID??0}};

    $.ajax({
            type:'POST',
            url:'{{url('MunkafelvetelRemove')}}',
            data:{_token: '<?php echo csrf_token() ?>', csid: csoport_id ,uid:itemid, mid:muszakID},
            success:function(data) {
                location.reload();

            }
        });

}

@if(isset($model->MuszakID))

function OraszamCheck(id,oraszam)
{
    let rmwh = 'rmwh-'+id;
    let item = document.getElementById(rmwh);
    item.innerText = oraszam;
}

function teljesitettOraszamBeirasa()
{

}

@endif



</script>


</div>





@endsection
