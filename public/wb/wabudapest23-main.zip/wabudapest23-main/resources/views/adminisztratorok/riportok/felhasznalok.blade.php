@extends('layouts.admin')
@section('content')
    <div class="row">
        <div class="col-12 d-flex justify-content-between">
            <h1>Letölthető riportok felhasználókról</h1>
        </div>
    </div>

    <div class="row">
        <div class="col-12 d-flex justify-content-between">
            <div class="card">
                <div class="card-body">
                    <div id="accordion">
                        <div class="card">
                            <div class="card-header" id="headingOne">
                                <h5 class="mb-0">
                                <button class="btn btn-link" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                   Regisztrált Önkéntesek adatainak exportálása
                                </button>
                                </h5>
                            </div>
                        
                            <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
                                <div class="card-body">
                                    <table class="table">
                                        <thead>
                                          <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Lekérdezés elnevezése</th>
                                            <th scope="col">Leírás</th>
                                            <th scope="col">Művelet</th>
                                          </tr>
                                        </thead>
                                        <tbody>
                                          <tr>
                                            <th scope="row">1</th>
                                            <td>Összes regisztrált felhasználó exportálása</td>
                                            <td>2020.04.20 után regisztrált felhasználók exportálása excelben.<i>Megjelenített mezők:Sorszám,email,név,regisztráció ideje.</i></td>
                                            <td><form action="{{route('Riports.Export.AllRegisteredUser')}}" method="post"> @csrf <button type="submit" class="btn btn-success">Exportálás</button></form></td>
                                          </tr>
                                          <tr>
                                            <th scope="row">2</th>
                                            <td>Összes felhasználó személyes adatainak exportálása</td>
                                            <td>Akinél az életkor 1 az nem erősítette meg a profilját.<i>Megjelenített mezők:Név, Email, Telefonszám, Neme, Kora, Anyja neve, Szem. ig. azonosító, Állampolgárság</i></td>
                                            <td><form action="{{route('Riports.Export.User.Personals')}}" method="post"> @csrf <button type="submit" class="btn btn-success">Exportálás</button></form></td>
                                          </tr>
                                          <tr>
                                            <th scope="row">3</th>
                                            <td>Az Önkéntesek iskolai adatainak exportálása</td>
                                            <td><i>Megjelenített mezők:Név, Email,Intézmény neve, Évfolyam, Regisztráció ideje</i></td>
                                             <td><a href="{{route('riport.osszes.iskolasok')}}" class="btn btn-success">Lekérdezés</a></td>
                                         
                                          </tr>

                                          <tr>
                                            <th scope="row">3</th>
                                            <td>Fogyatékosság leírása</td>
                                            <td><i>Megjelenített mezők:Név, Email,Telefonszám, Kor,Fogyatékosság leírása</i></td>
                                             <td><a href="{{route('riport.fogyletoltese')}}" class="btn btn-success">Lekérdezés</a></td>
                                         
                                          </tr>

                                        </tbody>
                                      </table>
                               
                                </div>
                            </div>
                            </div>





                            <div class="card">
                            <div class="card-header" id="headingTwo">
                                <h5 class="mb-0">
                                <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                    Aktív felhasználók 
                                </button>
                                </h5>
                            </div>
                            <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
                                <div class="card-body">
                                    <table class="table">
                                        <thead>
                                          <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Lekérdezés elnevezése</th>
                                            <th scope="col">Leírás</th>
                                            <th scope="col">Művelet</th>
                                          </tr>
                                        </thead>
                                        <tbody>
                                          <tr>
                                            <th scope="row">1</th>
                                            <td>Összes aktív felhasználó exportálása</td>
                                            <td><i>Megjelenített mezők:Sorszám,email.</i></td>
                                            <td><form action="{{route('Riports.Export.AllActiveUser')}}" method="post"> @csrf <button type="submit" class="btn btn-success">Exportálás</button></form></td>
                                            </tr>

                                            <tr>
                                            <th scope="row">2</th>
                                            <td>Szállást igénylő, jelentkezett Önkéntesek</td>
                                            <td>Azokat az Önkénteseket tartalmazza, akik jelentkeztek területre!<i>Megjelenített mezők:Sorszám,név,email,telefonszám,kor, neme, település, megye</i></td>
                                             <td><a href="{{route('riport.szallas.jelentkezettigenylok')}}" class="btn btn-success">Lekérdezés</a></td>
                                            </tr>

                                            <tr>
                                            <th scope="row">3</th>
                                            <td>Igazolás export</td>
                                            <td>Exportálja az Igazolás igénykeket!<i>Megjelenített mezők:Sorszám,név,email,telefonszám,kor, neme, igazolás</i></td>
                                             <td><a href="{{route('riport.igazolasexport')}}" class="btn btn-success">Lekérdezés</a></td>
                                            </tr>

                                            <tr>
                                            <th scope="row">4</th>
                                            <td>Önkéntes órák export</td>
                                            <td>Az Önkéntesek igazolt óraszámait exportálja.<i>Megjelenített mezők:Sorszám,név,email,telefonszám,kor, neme, teljesített önkéntes órák száma</i></td>
                                             <td><a href="{{route('riport.onkentesorak')}}" class="btn btn-success">Lekérdezés</a></td>
                                            </tr>

                                        
                                        </tbody>
                                      </table>
                                </div>
                            </div>
                            </div>


                            <div class="card">
                            <div class="card-header" id="headingThree">
                                <h5 class="mb-0">
                                <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                    Tananyagok / Edubase integráció
                                </button>
                                </h5>
                            </div>
                            <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
                                <div class="card-body">
                                   <table class="table">
                                        <thead>
                                          <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Lekérdezés elnevezése</th>
                                            <th scope="col">Leírás</th>
                                            <th scope="col">Művelet</th>
                                          </tr>
                                        </thead>
                                        <tbody>
                                          <tr>
                                            <th scope="row">1</th>
                                            <td>Edubase profillal NEM rendelkezők</td>
                                            <td><i>Megjelenített mezők: email.</i></td>
                                            <td><form action="{{route('riport.letoltes.notedubaseacc')}}" method="post"> @csrf <button type="submit" class="btn btn-success">Exportálás</button></form></td>
                                          </tr>
                                         <tr>
                                            <th scope="row">2</th>
                                            <td>Edubase profillal rendelkezők</td>
                                            <td><i>Megjelenített mezők: email.</i></td>
                                            <td><form action="{{route('riport.letoltes.edubaseacc')}}" method="post"> @csrf <button type="submit" class="btn btn-success">Exportálás</button></form></td>
                                          </tr>
                                        </tbody>
                                      </table>
                                 </div>
                            </div>
                            </div>


                            <div class="card">
                            <div class="card-header" id="headingTwo">
                                <h5 class="mb-0">
                                <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                    Formaruha és akkreditáció
                                </button>
                                </h5>
                            </div>
                            <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
                                <div class="card-body">
                                    <table class="table">
                                        <thead>
                                          <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Lekérdezés elnevezése</th>
                                            <th scope="col">Leírás</th>
                                            <th scope="col">Művelet</th>
                                          </tr>
                                        </thead>
                                        <tbody>
                                          <tr>
                                            <th scope="row">1</th>
                                            <td>Formaruhát átvették</td>
                                            <td><i>Megjelenített mezők:Sorszám,név,email.</i></td>
                                             <td><a href="{{route('riport.formaruhatatvettek')}}" class="btn btn-success">Lekérdezés</a></td>
                                          </tr>

                                          <tr>
                                            <th scope="row">2</th>
                                            <td>Formaruha készlet</td>
                                            <td><i>Megjelenített mezők:Sorszám,név,készlet szám, kiosztva, maradék.</i></td>
                                             <td><a href="{{route('riport.keszlet.ruha')}}" class="btn btn-success">Lekérdezés</a></td>
                                          </tr>

                                          <tr>
                                            <th scope="row">3</th>
                                            <td>Ajándék készlet</td>
                                            <td><i>Megjelenített mezők:Sorszám,név,készlet szám, kiosztva, maradék.</i></td>
                                             <td><a href="{{route('riport.keszlet.ajandek')}}" class="btn btn-success">Lekérdezés</a></td>
                                          </tr>

                                           <tr>
                                            <th scope="row">4</th>
                                            <td>Ajándékot átvették</td>
                                            <td>Ha az email hiányzik, és az önkéntes óra szám nem 0, akkor nem megerősített profilnak lett igazolva. (Irodai angyalok rendezvény)
                                            <i>Megjelenített mezők:Sorszám,név,email,önkéntes órákl száma, átadás ideje(ha NULL szerepel, akkor nem vették át)</i></td>
                                             <td><a href="{{route('riport.ajandekotatvettek')}}" class="btn btn-success">Lekérdezés</a></td>
                                          </tr>
                                          <tr>
                                            <th scope="row">4</th>
                                            <td>Akkreditáció</td>
                                            <td><i>Megjelenített mezők:ID, Név, qr, qrlink,status(a kártya elkészült:1),átvette(1; 0: nem vette át), kártyaszám,kép</i></td>
                                             <td><a href="{{route('riport.akkredriport')}}" class="btn btn-success">Lekérdezés</a></td>
                                          </tr>
                                        </tbody>
                                      </table>
                                </div>
                            </div>
                            </div>


                      <div class="card">
                            <div class="card-header" id="headingFour">
                                <h5 class="mb-0">
                                <button class="btn btn-link" data-toggle="collapse" data-target="#collapseFour" aria-expanded="true" aria-controls="collapseFour">
                                   Rendevény és terület alapú riportok
                                </button>
                                </h5>
                            </div>
                        
                            <div id="collapseFour" class="collapse show" aria-labelledby="headingFour" data-parent="#accordion">
                                <div class="card-body">
                                    <table class="table">
                                        <thead>
                                          <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Lekérdezés elnevezése</th>
                                            <th scope="col">Leírás</th>
                                            <th scope="col">Művelet</th>
                                          </tr>
                                        </thead>
                                        <tbody>
                                          <tr>
                                            <th scope="row">1</th>
                                            <td>Rendezvény létszámok</td>
                                            <td>A rendezvényekre jelentkezok számát tölti le. <i>Megjelenített mezők: Rendezvény neve,Tervezett létszámok, Jelentkezők száma</i></td>
                                            <td><a href="{{route('riport.letoltes.rendezveny.count')}}" class="btn btn-success">Lekérdezés</a></td>
                                          </tr>
                                          <tr>
                                            <th scope="row">2</th>
                                            <td>Rendezvényekre jelentkezők</td>
                                            <td>A rendezvényekre jelentkezoket tölti le. Emberenként megmutatja, hogy hány darab rendezvényre és név szerint melyikre jelentkezett. <i>Megjelenített mezők:ID,Név,Kor,Email,Ennyi rendezvényre jelentkezett,Rendezvények</i></td>
                                            <td><a href="{{route('riport.jelentkezokEsemenykreBontva')}}" class="btn btn-success">Lekérdezés</a></td>
                                          </tr>
                                          <tr>
                                            <th scope="row">3</th>
                                            <td>Terület létszámok</td>
                                            <td>A területekről nyúj információt.<i>Megjelenített mezők:Terület azonosító, Terület neve,Rendezvény neve,Tervezett lészám, Jelentkezők száma </i></td>
                                            <td><a href="{{route('riport.letoltes.terulet.count')}}" class="btn btn-success">Lekérdezés</a></td>
                                          </tr>
                                          <tr>
                                            <th scope="row">4</th>
                                            <td>Nem jelentkeztek területre</td>
                                            <td>Nem jelentkeztek területre<i>Megjelenített mezők:Név, Telefonszám,Email </i></td>
                                            <td><a href="{{route('riport.nemjelentkeztekrendezvenyre')}}" class="btn btn-success">Lekérdezés</a></td>
                                          </tr>
                                          <tr>
                                            <th scope="row">5</th>
                                            <td>Jelentkezok nyelvi szintjei</td>
                                            <td>Nem jelentkeztek területre<i>Megjelenített mezők:Név,Kor, Telefonszám,Email </i></td>
                                            <td><a href="{{route('riport.jelentkezok.nyelviszintek')}}" class="btn btn-success">Lekérdezés</a></td>
                                          </tr>
                                          <tr>
                                            <th scope="row">6</th>
                                            <td>Jelentkezok telefonszamok</td>
                                            <td>Jelentkezok telefonszamok<i>Megjelenített mezők: </i></td>
                                            <td><a href="{{route('riport.jelentkezok.telszamok')}}" class="btn btn-success">Lekérdezés</a></td>
                                          </tr>
                                          <tr>
                                            <th scope="row">7</th>
                                            <td>Augusztus 20 rendezvény</td>
                                            <td>Jelentkezok letöltése<i>Megjelenített mezők:név, email, tel szám, születési időpontja, helye, szem.ig. szám </i></td>
                                            <td><a href="{{route('riport.jelentkezok.aug20')}}" class="btn btn-success">Lekérdezés</a></td>
                                          </tr>
                                          <tr>
                                            <th scope="row">8</th>
                                            <td>Terulet beosztások</td>
                                            <td>A területre beosztott Önkénteseket exportálja.<i>Megjelenített mezők:név, rendezvény neve, terulet neve </i></td>
                                            <td><a href="{{route('riport.TeruletBeosztasok')}}" class="btn btn-success">Lekérdezés</a></td>
                                          </tr>

                                           <tr>
                                            <th scope="row">9</th>
                                            <td>Területre NEM beosztott Önkéntesek</td>
                                            <td>A területre nem beosztott Önkénteseket exportálja.<i>Megjelenített mezők:id, név, email </i></td>
                                            <td><a href="{{route('riport.nemterbeosztottak')}}" class="btn btn-success">Lekérdezés</a></td>
                                          </tr>
                                          <tr>
                                            <th scope="row">10</th>
                                            <td>Beosztottak info</td>
                                            <td>Azokat  tartalmazza, akik be lettek osztva csoportba. Akinél az Önkéntes óraszám 0, vagy nincs még leigazolva, vagy nem jelent meg de be volt osztva!<i>Megjelenített mezők:id, név, kor,nem,önkéntes órák száma,fogyatékosság,pólóméret,pólótípus,szállás igénylés,igazolás igénylés, egyéb igazolás igény </i></td>
                                            <td><a href="{{route('riport.beosztottakinfo')}}" class="btn btn-success">Lekérdezés</a></td>
                                          </tr>

                                          <tr>
                                            <th scope="row">11</th>
                                            <td>Beosztottak info - terület besoztások</td>
                                            <td>Terüéeti beosztások kiegészített lekérdezés.<i>Megjelenített mezők:id, név,esemenynév,terület neve kor,nem,önkéntes órák száma </i></td>
                                            <td><a href="{{route('riport.BoesztottakUserenkentRiport')}}" class="btn btn-success">Lekérdezés</a></td>
                                          </tr>

                                          <tr>
                                            <th scope="row">12</th>
                                            <td>Csoport beosztások</td>
                                            <td>Területi beosztások kiegészített lekérdezés.<i>Megjelenített mezők:id, név,esemenynév,terület neve, csoport neve kor,nem,önkéntes órák száma </i></td>
                                            <td><a href="{{route('riport.CsoportBeosztottakRiport')}}" class="btn btn-success">Lekérdezés</a></td>
                                          </tr>

                                          <tr>
                                            <th scope="row">13</th>
                                            <td>Csoport beosztások 2 </td>
                                            <td>Területi beosztások kiegészített lekérdezés.<i>Megjelenített mezők:id, név, email, telefonszám, kor,nem,önkéntes órák száma, tevékenység, iskolák, felekezet, egyházmegye,igazolás igény, civil szervezet tagja </i></td>
                                            <td><a href="{{route('riport.CsoportBeosztottakRiport1')}}" class="btn btn-success">Lekérdezés</a></td>
                                          </tr>
                                        </tbody>
                                      </table>
                               
                                </div>
                            </div>
                            </div>

                             <div class="card">
                            <div class="card-header" id="headingFifth">
                                <h5 class="mb-0">
                                <button class="btn btn-link" data-toggle="collapse" data-target="#collapseFifth" aria-expanded="false" aria-controls="collapseFifth">
                                   Cserkészek
                                </button>
                                </h5>
                            </div>
                        
                            <div id="collapseFifth" class="collapse " aria-labelledby="headingFifth" data-parent="#accordion">
                                <div class="card-body">
                                    <table class="table">
                                        <thead>
                                          <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Lekérdezés elnevezése</th>
                                            <th scope="col">Leírás</th>
                                            <th scope="col">Művelet</th>
                                          </tr>
                                        </thead>
                                        <tbody>
                                          <tr>
                                            <th scope="row">1</th>
                                            <td>Nem kitöltött importált cserkészek</td>
                                            <td>Nem kitöltött importált cserkészek. <i>Megjelenített mezők: Azonosító, Név, Email, Telefonszám</i></td>
                                            <td><a href="{{route('riport.nem_kitoltott_cserkesz_profilok')}}" class="btn btn-success">Lekérdezés</a></td>
                                          </tr>
                                          <tr>
                                            <th scope="row">2</th>
                                            <td>Kitöltött importált cserkészek</td>
                                            <td>kitöltött importált cserkészek.<i>Megjelenített mezők:Azonosító, Név, Email, Telefonszám </i></td>
                                            <td><a href="{{route('riport.kitoltott_cserkesz_profilok')}}" class="btn btn-success">Lekérdezés</a></td>
                                          </tr>
                                          <tr>
                                            <th scope="row">3</th>
                                            <td>Cserkész vagyok</td>
                                            <td>Az egyéb  szervezeti leírásban a "cserkész" szó szerepel.<i>Megjelenített mezők:Azonosító, Név, Email, Telefonszám </i></td>
                                            <td><a href="{{route('riport.cserkesz_vagyok')}}" class="btn btn-success">Lekérdezés</a></td>
                                          </tr>
                                         
                                        </tbody>
                                      </table>
                               
                                </div>
                            </div>
                            </div>


                            


                        </div>

                </div>
              </div>
        </div>
    </div>
@endsection