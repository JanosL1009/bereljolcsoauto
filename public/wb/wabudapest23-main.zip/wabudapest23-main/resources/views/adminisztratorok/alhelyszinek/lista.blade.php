@extends('layouts.admin')

@section('content')

@if($errors->sikerletrehozas->first())
<div class="col-12 col-md-12 text-center">
  <h4  class="alert alert-success" role="alert">{{$errors->sikerletrehozas->first()}}</h4>
</div>
@endif

@if($errors->sikermodositas->first())
<div class="col-12 col-md-12 text-center">
  <h4  class="alert alert-success" role="alert">{{$errors->sikermodositas->first()}}</h4>
</div>
@endif


@if($errors->letrehozoashiba->first())
<div class="col-12 col-md-12 text-center">
  <h4  class="alert alert-danger" role="alert">{{$errors->letrehozoashiba->first()}}</h4>
</div>
@endif

<div class="col-12 col-md-12">
    <div class="card my-3">
      <div class="card-body">
        <div class="row">
            <div class="col-12 d-flex justify-content-between">
              <h1>Csoport helyszínek</h1>
            </div>

            <div class="col-12 col-md-12">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item active" aria-current="page">Csoport helyszínek kezelése:</li>
                      <li class="breadcrumb-item"><a href="{{route('alhelyszin.letrehozas')}}">Létrehozás</a></li>
                     </ol>
                  </nav>
        </div>

          </div>
          <div class="table-wrapper">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                       
                        <th>Csoport helyszín neve</th>
                        <th>Helyszín neve</th>
                        <th>Módosítás</th>
                    </tr>
                </thead>
                <tbody>

                    @if(isset($helyszinek))
                        @foreach($helyszinek as $helyszin)
                        <tr>
                            <td>{{$helyszin->nev}}</td>
                            <td>{{$helyszin->fohelyszin->Neve}}</td>
                            
                            <td><a href="{{route('alhelyszin.modositas',['id' => $helyszin->id])}}">Módosítás</a></td>
                        </tr>
                        @endforeach
                    @endif
                    
                       
                            
                      

                </tbody>
            </table>
            <div class="clearfix float-left">
                <ul class="pagination">
                    {{$helyszinek->links()}}
                </ul>
            </div>
          </div>


      </div>
    </div>
</div>
@endsection