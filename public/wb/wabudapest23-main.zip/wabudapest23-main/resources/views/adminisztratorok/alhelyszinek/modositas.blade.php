@extends('layouts.admin')

@section('content')
<style>

    .hint-text {
        float: left;
        margin-top: 10px;
        font-size: 13px;
    }
</style>
        <div class="row">
            <div class="col-12 d-flex justify-content-between">
                <h1>Csoport helyszín módosítása</h1>
              </div>
              <div class="col-12 col-md-12">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item active" aria-current="page">Csoport helyszínek kezelése:</li>
                      <li class="breadcrumb-item"><a href="{{route('alhelyszin.lista')}}">Lista</a></li>
                      <li class="breadcrumb-item"><a href="{{route('alhelyszin.letrehozas')}}">Új csoport helyszín létrehozása</a></li>
                     
                    </ol>
                  </nav>
        </div>
          <div class="col-12 col-md-12">
            <div class="card my-3">
              <div class="card-body">
                
              <form action="{{route('alhelyszin.frissites_form',['id' => $alhelyszin->id])}}" method="POST" enctype="multipart/form-data" id="helyszin_hozzaadas_form" name = "helyszin_hozzaadas_form">
                @csrf
                <div class="form-row">
                    <div class="form-group col-md-4">
                        <label for="inputEmail4">Helyszín választás</label>
                        <input type="text" class="form-control" id="helyszin_neve" name="helyszin_neve" data-validation="required" value="{{$alhelyszin->fohelyszin->Neve}}">
                        <span>Kezdje el gépelni egy helyszín nevét, majd válasszon a lehetőségek közül egyet!</span>
                    </div>
                </div>
                <hr>
                <div class="form-row">
                  <div class="form-group col-md-4">
                    <label for="inputEmail4">Csoport helyszín neve</label>
                    <input type="text" class="form-control" id="csophelyszin_neve" name="csophelyszin_neve" data-validation="required" value="{{$alhelyszin->nev}}">
                  </div>
                </div>

                <hr>

                <div class="form-row">
                    <div class="form-group col-md-4">
                        <button  type="submit" class="btn btn-primary">Mentés</button>
                      </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-12">
                       <b>Megjegyzés:</b> <br>
                       Egy alhelyszínt tudsz létrehozni a csoportokhoz. <br>
                       Például: 
                       A Puskás Arénához szektorokat beléptetéshez.
                       <ol>
                           <li>Helyszínválasztásnál kiválsztani a Puskás Arénát</li>
                           <li>Csoport helyszín nevénél megadni a kívánt nevet.: Például: C1</li>

                       </ol>
                       <p>A C1 , a C szektor 1. kapujának a rövidítése a Puskásban.</p>
                      </div>
                </div>
              </form>
            </div>
            </div>
          </div>

          

        </div>
        <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
        <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

        <script>
              var availableTags = [];
        $( "#helyszin_neve" ).autocomplete({
            source: availableTags
        });
        $.ajax({
               type:'POST',
               url:'{{url('GetHelyszinek')}}',
               data:{_token:'<?php echo csrf_token() ?>' },
               success:function(data) {
               // var obj = JSON.parse(data);
                let i = 0;
                    for(i = 0; i < data.length;i++)
                    {
                        availableTags.push(data[i].Neve);
                    }

               }
            });

        </script>
        <script src="{{ asset('js/jquery.form-validator.min.js') }}"></script>
        <script>
           var myLanguage = {

                errorTitle: 'Az űrlap feldolgozása sikertelen.',
                requiredFields: 'You have not answered all required fields',
                badTime: 'You have not given a correct time',
                badEmail: 'You have not given a correct e-mail address',
                badTelephone: 'You have not given a correct phone number',
                badSecurityAnswer: 'You have not given a correct answer to the security question',
                badDate: 'You have not given a correct date',
                lengthBadStart: 'The input value must be between ',
                lengthBadEnd: ' karakter',
                lengthTooLongStart: 'The input value is longer than ',
                lengthTooShortStart: 'Az input érték nem lehet kevesebb, mint ',
                notConfirmed: 'Input values could not be confirmed',
                badDomain: 'Incorrect domain value',
                badUrl: 'The input value is not a correct URL',
                badCustomVal: 'The input value is incorrect',
                andSpaces: ' and spaces ',
                badInt: 'The input value was not a correct number',
                badSecurityNumber: 'Your social security number was incorrect',
                badUKVatAnswer: 'Incorrect UK VAT Number',
                badStrength: 'The password isn\'t strong enough',
                badNumberOfSelectedOptionsStart: 'You have to choose at least ',
                badNumberOfSelectedOptionsEnd: ' answers',
                badAlphaNumeric: 'The input value can only contain alphanumeric characters ',
                badAlphaNumericExtra: ' and ',
                wrongFileSize: 'The file you are trying to upload is too large (max %s)',
                wrongFileType: 'Only files of type %s is allowed',
                groupCheckedRangeStart: 'Please choose between ',
                groupCheckedTooFewStart: 'Please choose at least ',
                groupCheckedTooManyStart: 'Please choose a maximum of ',
                groupCheckedEnd: ' item(s)',
                badCreditCard: 'The credit card number is not correct',
                badCVV: 'The CVV number was not correct',
                wrongFileDim : 'Incorrect image dimensions,',
                imageTooTall : 'the image can not be taller than',
                imageTooWide : 'the image can not be wider than',
                imageTooSmall : 'the image was too small',
                min : 'min',
                max : 'max',
                imageRatioNotAccepted : 'Image ratio is not accepted'
            };

          $.validate({
            language : myLanguage
          });
        </script>
        
@endsection
