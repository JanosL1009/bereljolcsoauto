@extends('layouts.admin')
@section('content')
<style>

        .hint-text {
            float: left;
            margin-top: 10px;
            font-size: 13px;
        }
    </style>
<style>
#ui-id-1,#ui-id-2, #ui-id-3,#ui-id-12,#ui-id-13,#ui-id-14, .myCompleteUI{
    z-index: 10000;
}
</style>
    @php
        $Esemeny = $model;
    @endphp
    <form action="{{url ('/admin/esemeny_szerkesztese_feldolgozo/'.$Esemeny->esemenyID)}}" method="POST" enctype="multipart/form-data" id="esemeny_szerkesztese_feldolgozo" name = "esemeny_szerkesztese_feldolgozo">
    @csrf
        <div class="row">
          <div class="col-12 d-flex justify-content-start">
            <h1>{{$Esemeny->esemenyNeve}}-szerkesztése</h1>
          </div>
          <div class="col-12 d-flex justify-content-end">
            <a href="#ujTeruletLetrehozasa" class="btn btn-primary" data-toggle="modal">Új terület létrehozása</a>
            <a href="#ujCsoportLetrehozasa" class="btn btn-primary" data-toggle="modal">Új csoport létrehozása</a>
            <a href="{{route('riport.rendezvenyJelentkezok',['EventID' => $Esemeny->esemenyID])}}" class="btn btn-primary" >Jelentkezők letöltése</a>
          </div>

          @if($errors->any() == 1)
            <div class="col-12">
                <div class="alert alert-success" role="alert">
                    A terület sikeresen létrehozva! 
                 </div>
            </div>
          @endif
        @if($errors->nemletezoelhelyszin->first())
          <div class="col-12">
              <div class="alert alert-danger" role="alert">
                <h4  class="alert alert-danger" role="alert">{{$errors->nemletezoelhelyszin->first()}}</h4>
               </div>
          </div>
        @endif

        @if($errors->nemletezohelyszin->first())
        <div class="col-12">
            <div class="alert alert-danger" role="alert">
              <h4  class="alert alert-danger" role="alert">{{$errors->nemletezohelyszin->first()}}</h4>
             </div>
        </div>
      @endif

           @if ($errors->any())
           <div class="col-12 col-lg-12 d-flex @if($errors->any() == 1) d-none @endif ">
            <div class="alert alert-danger @if($errors->any() == 1) d-none @endif " role="alert">
                @error('cskezdIdejeDatum')
                    <p>Hiba a csoport létrehozásánál: nem adtad meg a kezdés dátumát!</p>
                @enderror
                @error('cskezdIdejeDatum')
                    <p>Hiba a csoport létrehozásánál: nem adtad meg a befejezés dátumát!</p>
                @enderror
                
            </div>
           
         </div>
                
            @endif

          <div class="col-12 col-lg-6">
            <div class="card my-3">
              <div class="card-body">

                <div class="form-group">
                </div>
                <div class="form-group">
                  <label for="inputAddress">Rendezvény neve</label>
                  <input type="text" class="form-control" name="Esemenynev" id="inputAddress" placeholder="Aktív önkéntes" value="{{$Esemeny->esemenyNeve}}">
                </div>


              <div class="row">
                <div class="form-group col-12 col-md-6 dataszabalyzo datumkiemeles">
                  <label for="dtp_input2" class="control-label">Kezdés dátuma</label>
                  <div class="input-group date form_date " data-date="" data-date-format="yyyy MM dd" data-link-field="dtp_input2" data-link-format="yyyy-mm-dd">

                    <input type="text" class="form-control" id="datepicker" <?php /* id="esemenykezdesDatum" */?> name="esemenykezdesDatum" value="{{$Esemeny->kezdesDatuma}}" >

                    <span class="input-group-addon"><span class="glyphicon glyphicon-remove"></span></span>
          			    <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span>
                  </div>

                </div>
                <div class="form-group col-12 col-md-6">
                  <label for="dtp_input3" class="control-label">Kezdés ideje</label>
                  <div class="input-group date form_time " data-date="" data-date-format="hh:ii" data-link-field="dtp_input3" data-link-format="hh:ii">
                    <input class="form-control" type="text" id="esemenyKezdesIdeje" name="esemenyKezdesIdeje" value="{{$Esemeny->kezdesIdeje}}">
                    <span class="input-group-addon"><span class="glyphicon glyphicon-remove"></span></span>
                    <span class="input-group-addon"><span class="glyphicon glyphicon-time"></span></span>
                    </div>

                    </div>
              </div>

              <div class="row">
                <div class="form-group col-12 col-md-6 dataszabalyzo datumkiemeles">
                  <label for="dtp_input2" class="control-label">Befejezés dátuma</label>
                  <div class="input-group date form_date " data-date="" data-date-format="yyyy MM dd" data-link-field="dtp_input4" data-link-format="yyyy-mm-dd">
                    <input class="form-control" type="text"  id="datepicker2" name="befejezesDatuma" value="{{$Esemeny->befejezesDatuma}}">
                    <span class="input-group-addon"><span class="glyphicon glyphicon-remove"></span></span>
                    <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span>
                    </div>

                    </div>

                <div class="form-group col-12 col-md-6">
                  <label for="dtp_input3" class="control-label">Befejezés ideje</label>
                  <div class="input-group date form_time " data-date="" data-date-format="hh:ii" data-link-field="dtp_input5" data-link-format="hh:ii">
                    <input class="form-control" type="text" value="{{$Esemeny->befejezesIdeje}}" id="befejezesIdeje" name="befejezesIdeje">
                    <span class="input-group-addon"><span class="glyphicon glyphicon-remove"></span></span>
                    <span class="input-group-addon"><span class="glyphicon glyphicon-time"></span></span>
                    </div>

                    </div>
              </div>

                <div class="form-row">
                  <div class="form-group col-md-6">
                    <label for="inputEmail4">Státusz</label>
                    {!!$Esemeny->Statusz!!}
                  </div>

                </div>

                <div class="form-group">
                    <label>Leírás</label>
                    <textarea class="form-control" name="rendezvenyLeiras" style="visibility: hidden; display: none;">{!!$Esemeny->Leiras!!}</textarea>
                </div>

                <div class="form-group">
                  <button type="button" class="btn btn-danger">Rendezvény törlése</button>
                  <input type="submit" class="btn btn-primary" value="Mentés">
                </div>


            </div>
            </div>
          </div>

          <div class="col-12 col-lg-6">
            <div class="card my-3">
              <div class="card-body">



                  <div class="form-row">
                        <div class="card-body" >

                            <table id="rhelyszin" class="table table-striped table-hover">
                              <thead>
                                  <tr>
                                      <th>
                                        A rendezvény helyszíne
                                      </th>
                                      <th>Műveletek</th>
                                  </tr>
                              </thead>
                                @if(isset($Esemeny->helyszin))
                            @foreach ($Esemeny->helyszin as $helyszin)
                                <tr class="rhp" id="rhelyszin{{$helyszin->id}}" data-lastid="{{$helyszin->id}}">
                                    <td class="form-group col">
                                        <!-- <label for="inputEvent4">A Program helyszíne</label> -->
                                        <input type="text" class="form-control" value="{{$helyszin->Telepulesnev}}" id="helyszin{{$helyszin->id}}" name="helyszin{{$helyszin->id}}" data-id="{{$helyszin->id}}">
                                    </td>
                                    <td>
                                        <a href="#DeletePlace" class="float-right delete" data-toggle="modal"><i class="material-icons deltool" data-toggle="tooltip" title="" data-placeid="{{$helyszin->id}}"  data-esid="{{$Esemeny->esemenyID}}" data-original-title="Törlés"></i></a>
                                    </td>


                                </tr>
                            @endforeach
                            @endif
                          </table>
                                <div class="form-row">
                                  <button class="btn btn-light" type="button" id="tovabbiHelyszin" name="tovabbiHelyszin">+ Helyszín hozzáadása</button>
                                </div>
                                @if(isset($Esemeny->helyszin[0]))
                                  <td>
                                    <input type="hidden" value="{{$Esemeny->helyszin[0]->id}}" name="elsohelyszin" id="elsohelyszin">
                                  </td>
                                @else
                                  <td>
                                    <input type="hidden" value="" name="elsohelyszin" id="elsohelyszin">
                                  </td>
                                @endif
                        </div>
                  </div>


              </div>
            </div>

            <div class="card my-3">
              <div class="card-body">
                <h5 class="card-title">Területek</h5>
                <form>
                  <div class="form-group">
                        <table id="AreEnum" class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>
                                            <span class="custom-checkbox">
                                                <input type="checkbox" id="selectAll">
                                                <label for="selectAll"></label>
                                            </span>
                                        </th>
                                        <th></th>
                                    <!--    <th>Helyszín</th>
                                        <th>Kezdés időpont</th>-->

                                        <th>Műveletek</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @php
                                        $teruletek = $model->teruletek;
                                    @endphp
                                    @foreach($teruletek as $terulet)

                                    <tr data-tid={{$terulet->id}}>
                                        <td>
                                            <span class="custom-checkbox">
                                                <input type="checkbox" id="teruletcheckbox-{{$terulet->id}}" name="options[]" value="{{$terulet->id}}">
                                                <label for="teruletcheckbox-{{$terulet->id}}"></label>
                                            </span>
                                        </td>
                                        <td data-label="Név">{{$terulet->nev}}</td>


                                        <td data-label="Műveletek">
                                            @if($terulet->teruletAktiv == 1)
                                              <span class="material-icons" style="color:green;" title="Aktív terület">
check_circle
</span>
 @else
                                              

<span class="material-icons" style="color:red;" title="Inaktív terület">
highlight_off
</span>
                                            @endif
                                            
                                            <a href="{{url('/admin/csoportokterulet/'.$terulet->id)}}" class="edit" ><i class="material-icons" data-toggle="tooltip" title="Szerkesztés">&#xE254;</i></a><!-- ezt paraméteresíteni! -->
                                            <a href="#TeruletTorlese" class="delete areadelete" data-toggle="modal" data-areaname="{{$terulet->nev}}" data-tid="{{$terulet->id}}"><i class="material-icons" data-toggle="tooltip" title="Törlés">&#xE872;</i></a>
                                        </td>
                                    </tr>


                                    @endforeach
                                </tbody>
                            </table>
                  </div>
                </form>
              </div>
            </div>


          </div>

        </div>
    </form>

        <div id="ujTeruletLetrehozasa" class="modal fade">
            <div class="modal-dialog modal-xl">
                <div class="modal-content">
                    <form action="{{url('/admin/ujterulet_hozzaadasa')}}" method="POST" enctype="multipart/form-data" id="UjTerulet" name="UjTerulet">
                        @csrf
                        <div class="modal-header">
                            <h4 class="modal-title">Új terület létrehozása</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        </div>
                        <div class="modal-body">

                            <div class="card my-3">
                                <div class="card-body">
                                <h5 class="card-title"></h5>

                                    <div class="form-group">
                                        <label>Terület neve</label>
                                        <input type="text" class="form-control" id="teruletNeve" name="teruletNeve" >
                                        <input type="text" class="d-none" id="teruletesemenyi" name="teruletesemenyi" value="{{$Esemeny->esemenyID}}" data-validation="required">
                                    </div>

                                    <div class="form-group"><label>Terület leírása</label>
                                            <textarea class="form-control"  id="teruletLeiras" name="teruletLeiras" rows="10" data-validation="required"></textarea>
                                    </div>
                                    @php 
                                        
                                    @endphp
                                    <div class="form-group dataszabalyzo datumkiemeles">
                                      <label for="dtp_input2" class="control-label">Kezdés időpontja</label>
                                      <div class="input-group date form_date " data-date="" data-date-format="hh:ii" data-link-field="dtp_input3" data-link-format="hh:ii">
                                        <div class="myTime">
                                        <!--  <input class="form-control" type="text"  id="kezdIdejeDatum" name="kezdIdejeDatum" value="">
                                        --> 
                                           <select id="kezdIdoEvT" name="kezdIdoEvT" class="form-control" style="width: 85px;"> 
                                                <option value="2021">2021</option>
                                            </select> 
                                            <select id="kezdIdoHoT" name="kezdIdoHoT" class="form-control">
                                                <option value="13" default selected>---</option>
                                                <option id="kezdHo-1" id="kezdHo-1" value="1" >1</option>
                                                <option id="kezdHo-2" value="2">2</option>
                                                <option id="kezdHo-3" value="3">3</option>
                                                <option id="kezdHo-4" value="4">4</option>
                                                <option id="kezdHo-5" value="5">5</option>
                                                <option id="kezdHo-6" value="6">6</option>
                                                <option id="kezdHo-7" value="7">7</option>
                                                <option id="kezdHo-8" value="8">8</option>
                                                <option id="kezdHo-9" value="9">9</option>
                                                <option id="kezdHo-10" value="10">11</option>
                                                <option id="kezdHo-11" value="12">12</option>
                                                <option id="kezdHo-12" value="12">12</option>
                                            </select> 
                                            <select id="kezdIdoNapT" name="kezdIdoNapT" class="form-control"> 
                                                <option value="33">---</option>
                                            </select> 
                                          <input type="number" id="kezdIdejeOra" name="kezdIdejeOra" class="timeInput TimeHour" placeholder="23" data-validation="required">:
                                          <input type="number" id="kezdIdejePerc"  name="kezdIdejePerc"  class="timeInput TimeSec" placeholder="00" data-validation="required">
                                          <span class="input-group-addon"><span class="glyphicon glyphicon-remove"></span></span>
                                          <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span>
                                        </div>
                                      </div>
                                    </div>


                                    <div class="form-group dataszabalyzo datumkiemeles">
                                      <label for="dtp_input2" class="control-label">Befejezés időpontja</label>
                                      <div class="input-group date form_date " data-date="" data-date-format="hh:ii" data-link-field="dtp_input3" data-link-format="hh:ii">
                                        <div class="myTime"><!--
                                          <input class="form-control" type="text"  id="befIdejeDatum" name="befIdejeDatum" value="{{$model->befejezesDatuma}}"> -->
                                          
                                          <select id="befIdoEvT" name="befIdoEvT" class="form-control" style="width: 85px;"> 
                                            <option value="2021">2021</option>
                                        </select> 
                                        <select id="befIdoHoT" name="befIdoHoT" class="form-control">
                                            <option value="13" default selected>---</option>
                                            <option id="befHo-1" id="kezdHo-1" value="1" >1</option>
                                            <option id="befHo-2" value="2">2</option>
                                            <option id="befHo-3" value="3">3</option>
                                            <option id="befHo-4" value="4">4</option>
                                            <option id="befHo-5" value="5">5</option>
                                            <option id="befHo-6" value="6">6</option>
                                            <option id="befHo-7" value="7">7</option>
                                            <option id="befHo-8" value="8">8</option>
                                            <option id="befHo-9" value="9">9</option>
                                            <option id="befHo-10" value="10">11</option>
                                            <option id="befHo-11" value="12">12</option>
                                            <option id="befHo-12" value="12">12</option>
                                        </select> 
                                        <select id="befIdoNapT" name="befIdoNapT" class="form-control"> 
                                            <option value="33">---</option>
                                        </select> 
                                          
                                          <input type="number"  id="befIdejeOra" name="befIdejeOra" class="timeInput TimeHour"  placeholder="23" data-validation="required">:
                                          <input type="number"  id="befIdejePerc" name="befIdejePerc" class="timeInput TimeSec" placeholder="00" data-validation="required">
                                          <span class="input-group-addon"><span class="glyphicon glyphicon-remove"></span></span>
                                          <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span>
                                        </div>
                                      </div>
                                    </div>


                                    <div class="form-group"><label>Tervezett létszám</label>
                                            <input type="text" class="form-control" id="tervLetszam" name="tervLetszam" data-validation="required">
                                    </div>

                                    <div class="form-group">

                                                <div class="form-row rh" id="thelyszin" data-lastid="1">
                                                  <div class="form-group col-md-6">
                                                    <label for="inputPassword4">A terület helyszíne</label>
                                                    <input type="text" class="form-control" id="thelyszin1" name="thelyszin1" data-id="1" placeholder="Autocomplete mező" data-validation="required">
                                                  </div>
                                                  <div class="form-group col-md-6">
                                                    <label for="InfoMeassageHead">Információ</label><br/>
                                                    <label for="InfoMeassage" style="font-size:10px;">Ha nem találja a listában a megfelelő helyszínt, akkor a Helyszínek menüpont alatt vegye fel!</label>
                                                   </div>
                                                </div>


                                    </div>



                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">

                            <input type="submit" class="btn btn-danger" value="Létrehozás">
                        </div>
                    </form>
                </div>
            </div>
        </div>


        <!-- uj csoport-->
<div id="ujCsoportLetrehozasa" class="modal fade">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form action="{{url('/admin/ujcsoport_hozzaadasa')}}" method="POST" enctype="multipart/form-data" id="UjCsoport" name="UjCsoport">
                        @csrf
                        <div class="modal-header">
                            <h4 class="modal-title">Új csoport létrehozása</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        </div>
                        <div class="modal-body">

                            <div class="card my-3">
                                <div class="card-body">
                                <h5 class="card-title"></h5>

                                    <div class="form-group">
                                        <label>Csoport neve</label>
                                        <input type="text" class="form-control" id="csoportNeve" name="csoportNeve" >
                                        <input type="text" class="d-none" id="esemenyi" name="esemenyi" value="{{$Esemeny->esemenyID}}" data-validation="required">
                                    </div>

                                    <div class="form-group"><label>Csoport leírása</label>
                                            <textarea class="form-control"  id="csoportLeiras" name="csoportLeiras" rows="10" data-validation="required"></textarea>
                                    </div>

                                    <div class="form-group"><label>Terület kiválasztása</label>
                                       <select class="form-control" id="csTerulet" name="csTerulet" data-validation="required">
                                            <option value="-1" selected disabled>--- Terület választás ---</option>
                                       </select>
                                    </div>

                                    <div class="form-group"><label>Kezdés időpontja</label>

                                        <div class="input-group date form_time " data-date-format="hh:ii" data-link-field="dtp_input3" data-link-format="hh:ii" data-date-viewmode="month">
                                                <div class="myTime">
                                                    <select id="kezdIdoEvCs" name="kezdIdoEvCs" class="form-control" style="width: 85px;"> 
                                                        <option value="2021">2021</option>
                                                    </select> 
                                                    <select id="kezdIdoHoCs" name="kezdIdoHoCs" class="form-control">
                                                        <option value="13" default selected>---</option>
                                                        <option id="kezdHoCs-1" value="1" >1</option>
                                                        <option id="kezdHoCs-2" value="2">2</option>
                                                        <option id="kezdHoCs-3" value="3">3</option>
                                                        <option id="kezdHoCs-4" value="4">4</option>
                                                        <option id="kezdHoCs-5" value="5">5</option>
                                                        <option id="kezdHoCs-6" value="6">6</option>
                                                        <option id="kezdHoCs-7" value="7">7</option>
                                                        <option id="kezdHoCs-8" value="8">8</option>
                                                        <option id="kezdHoCs-9" value="9">9</option>
                                                        <option id="kezdHoCs-10" value="10">11</option>
                                                        <option id="kezdHoCs-11" value="12">12</option>
                                                        <option id="kezdHoCs-12" value="12">12</option>
                                                    </select>
                                                    <select id="kezdIdoNapCs" name="kezdIdoNapCs" class="form-control"> 
                                                        <option value="33">---</option>
                                                    </select>    
                                                    
                                                    <input type="number" id="cskezdIdejeOra" name="cskezdIdejeOra" class="timeInput TimeHour" min="0" max="23" placeholder="23" data-validation="required">:
                                                    <input type="number" id="cskezdIdejePerc"  name="cskezdIdejePerc"  class="timeInput TimeSec" min="0" max="59" placeholder="00" data-validation="required">
                                                </div>
                                            <span class="input-group-addon"><span class="glyphicon glyphicon-remove"></span></span>
                                                      <span class="input-group-addon"><span class="glyphicon glyphicon-time"></span></span>
                                        </div>
                                    </div>

                                    <div class="form-group"><label>Befejezés időpontja</label>
                                        <div class="input-group date form_time " data-date="" data-date-format="hh:ii" data-link-field="dtp_input3" data-link-format="hh:ii">
                                                <div class="myTime">
                                                    
                                                    <select id="befIdoEvCs" name="befIdoEvCs" class="form-control" style="width: 85px;"> 
                                                        <option value="2021">2021</option>
                                                    </select> 
                                                    <select id="befIdoHoCs" name="befIdoHoCs" class="form-control">
                                                        <option value="13" default selected>---</option>
                                                        <option id="befHoCs-1"  value="1" >1</option>
                                                        <option id="befHoCs-2" value="2">2</option>
                                                        <option id="befHoCs-3" value="3">3</option>
                                                        <option id="befHoCs-4" value="4">4</option>
                                                        <option id="befHoCs-5" value="5">5</option>
                                                        <option id="befHoCs-6" value="6">6</option>
                                                        <option id="befHoCs-7" value="7">7</option>
                                                        <option id="befHoCs-8" value="8">8</option>
                                                        <option id="befHoCs-9" value="9">9</option>
                                                        <option id="befHoCs-10" value="10">11</option>
                                                        <option id="befHoCs-11" value="12">12</option>
                                                        <option id="befHoCs-12" value="12">12</option>
                                                    </select> 
                                                    <select id="befIdoNapCs" name="befIdoNapCs" class="form-control"> 
                                                        <option value="33">---</option>
                                                    </select> 
                                                    
                                                    <input type="number"  id="csbefIdejeOra" name="csbefIdejeOra" class="timeInput TimeHour" min="0" max="23" placeholder="23" data-validation="required">:
                                                    <input type="number"  id="csbefIdejePerc" name="csbefIdejePerc" class="timeInput TimeSec" min="0" max="59" placeholder="00" data-validation="required">
                                                </div>
                                            <span class="input-group-addon"><span class="glyphicon glyphicon-remove"></span></span>
                                                      <span class="input-group-addon"><span class="glyphicon glyphicon-time"></span></span>
                                        </div>
                                    </div>

                                    <div class="form-group"><label>Tervezett létszám</label>
                                            <input type="text" class="form-control" id="cstervLetszam" name="cstervLetszam" data-validation="required">
                                    </div>

                                    <div class="form-group">

                                        <div class="form-row rh" id="cshelyszin" data-lastid="1">
                                          <div class="form-group col-md-6">
                                            <label for="inputPassword4">A csoport helyszíne</label>
                                            <input type="text" class="form-control" id="cshelyszin1" name="cshelyszin1" data-id="1" placeholder="Autocomplete mező" data-validation="required">
                                          </div>
                                          <div class="form-group col-md-6">
                                            <label for="InfoMeassageHead">Információ</label><br/>
                                            <label for="InfoMeassage" style="font-size:10px;">Ha nem találja a listában a megfelelő helyszínt, akkor a Helyszínek menüpont alatt vegye fel! <span id="noGroupLocation"></span></label>
                                            
                                        </div>
                                        </div>


                            </div>


                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">

                            <input type="submit" class="btn btn-danger" value="Létrehozás">
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- uj csoport vege, scriptek kezdete -->
        <div id="TeruletTorlese" class="modal fade">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <form action="{{url('admin/csoportokterulet/areadelete')}}" method="POST" enctype="multipart/form-data" id="TerDelete" name="TerDelete">
                            @csrf
                            <div class="modal-header">
                                <h4 class="modal-title">Terület törlése</h4>
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                            </div>
                            <div class="modal-body">

                                <div class="card my-3">
                                    <div class="card-body">
                                    <h5 class="card-title"></h5>

                                        <div class="form-group">
                                            <label>Terület neve: <span id="areanamespan"></span></label>
                                            <input type="number" class="d-none" id="teruletDelid" name="teruletDelid" value="">
                                            <input type="text" class="d-none" id="teruletesemenyi" name="teruletesemenyi" value="{{$Esemeny->esemenyID}}">
                                        </div>


                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <input type="button" class="btn btn-default" data-dismiss="modal" value="Mégse">
                                <input type="submit" class="btn btn-danger" value="Törlés">
                            </div>
                        </form>
                    </div>
                </div>
            </div>


            <div id="DeletePlace" class="modal fade">
                <div class="modal-dialog">
                    <div class="modal-content">

                            <div class="modal-header">
                                <h4 class="modal-title">Helyszín eltávolítás</h4>
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                            </div>
                            <div class="modal-body">
                                <p>Biztosan törlöd ezt a helyszínt a rendezvénytől?</p>
                               </div>
                            <div class="modal-footer">
                                <input type="number" class="d-none" id="hid" name="hid" value="-1">
                                <input type="button" class="btn btn-default" data-dismiss="modal" value="Mégse">
                                <input type="button" id="helyszinTorlesBtn" class="btn btn-danger" value="Törlés">
                            </div>

                    </div>
                </div>
            </div>

        @include('adminisztratorok.rendezvenyszervezok_kezelo')

        <div class="row">
            <div class="col-12">
                <div class="card my-3">
                    <div class="card-body">
                        <h4>Területi önkéntes koordinátorok</h4>
                        <table id="teruletiKoordinatarokTablazat" class="table table-striped table-hover" id="esemenySzervezok">
                            <thead>
                                <tr>
                                    <th>Név</th>
                                    <th>Terület</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($teruletvezetok as $vezeto)
                                <tr>
                                    <td>{{ $vezeto->name }}</td>
                                    <td>{{ $vezeto->nev }}</td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-12">
                <div class="card my-3">
                    <div class="card-body">
                        <h4>Csoportvezetők</h4>
                        <table id="csoportvezetokTablazat" class="table table-striped table-hover" id="esemenySzervezok">
                            <thead>
                                <tr>
                                    <th>Név</th>
                                    <th>Csoport</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($csoportvezetok as $vezeto)
                                    <tr>
                                        <td>{{ $vezeto->name }}</td>
                                        <td>{{ $vezeto->nev }}</td>
                                    </tr>
                                @endforeach

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>


        <script>/*
                document.querySelector('input#kezdIdejeOra[type=number]').forEach(e => e.oninput = () => {
                        // Always 2 digits
                        if (e.value.length >= 2) e.value = e.value.slice(0, 2);
                        // 0 on the left (doesn't work on FF)
                        if (e.value.length === 1) e.value = '0' + e.value;
                        // Avoiding letters on FF
                        if (!e.value) e.value = '00';
                    });
                    document.querySelector('input#kezdIdejePerc[type=number]').forEach(e => e.oninput = () => {
                        if (e.value.length >= 2) e.value = e.value.slice(0, 2);
                        if (e.value.length === 1) e.value = '0' + e.value;
                        if (!e.value) e.value = '00';
                    });
                    document.querySelector('input#befIdejeOra[type=number]').forEach(e => e.oninput = () => {
                         if (e.value.length >= 2) e.value = e.value.slice(0, 2);
                        if (e.value.length === 1) e.value = '0' + e.value;
                        if (!e.value) e.value = '00';
                    });
                    document.querySelector('input#befIdejePerc[type=number]').forEach(e => e.oninput = () => {
                        // Always 2 digits
                        if (e.value.length >= 2) e.value = e.value.slice(0, 2);
                         if (e.value.length === 1) e.value = '0' + e.value;
                        if (!e.value) e.value = '00';
                    });*/
            </script>


<script src="{{ asset('js/jquery.form-validator.min.js') }}"></script>
<script>
    var honapNapjai = '{"1":"31","2":"28","3":"31","4":"30","5":"31","6":"30","7":"31","8":"31","9":"30","10":"31","11":"30","12":"31"}';
    var NapokJsonObject = JSON.parse( honapNapjai);
   
    var myLanguage = {
        errorTitle: 'Az űrlap feldolgozása sikertelen.',
        requiredFields: 'You have not answered all required fields',
        badTime: 'You have not given a correct time',
        badEmail: 'You have not given a correct e-mail address',
        badTelephone: 'You have not given a correct phone number',
        badSecurityAnswer: 'You have not given a correct answer to the security question',
        badDate: 'You have not given a correct date',
        lengthBadStart: 'The input value must be between ',
        lengthBadEnd: ' karakter',
        lengthTooLongStart: 'The input value is longer than ',
        lengthTooShortStart: 'Az input érték nem lehet kevesebb, mint ',
        notConfirmed: 'Input values could not be confirmed',
        badDomain: 'Incorrect domain value',
        badUrl: 'The input value is not a correct URL',
        badCustomVal: 'The input value is incorrect',
        andSpaces: ' and spaces ',
        badInt: 'The input value was not a correct number',
        badSecurityNumber: 'Your social security number was incorrect',
        badUKVatAnswer: 'Incorrect UK VAT Number',
        badStrength: 'The password isn\'t strong enough',
        badNumberOfSelectedOptionsStart: 'You have to choose at least ',
        badNumberOfSelectedOptionsEnd: ' answers',
        badAlphaNumeric: 'The input value can only contain alphanumeric characters ',
        badAlphaNumericExtra: ' and ',
        wrongFileSize: 'The file you are trying to upload is too large (max %s)',
        wrongFileType: 'Only files of type %s is allowed',
        groupCheckedRangeStart: 'Please choose between ',
        groupCheckedTooFewStart: 'Please choose at least ',
        groupCheckedTooManyStart: 'Please choose a maximum of ',
        groupCheckedEnd: ' item(s)',
        badCreditCard: 'The credit card number is not correct',
        badCVV: 'The CVV number was not correct',
        wrongFileDim : 'Incorrect image dimensions,',
        imageTooTall : 'the image can not be taller than',
        imageTooWide : 'the image can not be wider than',
        imageTooSmall : 'the image was too small',
        min : 'min',
        max : 'max',
        imageRatioNotAccepted : 'Image ratio is not accepted'
    };
  $.validate({
    language : myLanguage
  });
</script>

<script type="text/javascript">
    $(document).ready(function(){
        // Activate tooltip
        $('[data-toggle="tooltip"]').tooltip();
    });
    </script>

<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<!-- <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script> -->
<script src="{{asset('js/jquery-ui-1.10.2.js')}}" ></script>

<script>
   $(document).ready(function(){

        $('#teruletNeve').focus(function(){

            let kezdesDatum = '{{$model->kezdesDatuma}}';
            let befejezesDatum = '{{$model->befejezesDatuma}}';

            let kezdes = kezdesDatum.split('-');
            document.getElementById('kezdHo-'+parseInt(kezdes[1])).selected = true;
            let max = NapokJsonObject[parseInt(kezdes[1])];
            for(let i = 0; i < max;i++)
            {
                let nap = i + 1;
                 $("<option>").attr("value", nap).attr("id", "kezdOptIdNap-"+nap).text(nap).appendTo("#kezdIdoNapT");
                  
                    
            }
            document.getElementById('kezdOptIdNap-'+parseInt(kezdes[2])).selected = true;

            let befejezes  = befejezesDatum.split('-');

            document.getElementById('befHo-'+parseInt(befejezes[1])).selected = true;
            max = NapokJsonObject[parseInt(befejezes[1])];
            for(let i = 0; i < max;i++)
            {
                let nap = i + 1;
                $("<option>").attr("value", nap).attr("id", "befOptIdNap-"+nap).text(nap).appendTo("#befIdoNapT");
                  
                     
            }
            document.getElementById('befOptIdNap-'+parseInt(befejezes[2])).selected = true;

            let tavailableTags = [];
            $.ajax({
                    type:'POST',
                    url:'{{url('GetHelyszin/'.$Esemeny->esemenyID)}}',
                    data:{_token:'<?php echo csrf_token() ?>' },
                    success:function(data) {
                    // var obj = JSON.parse(data);
                    console.log(data);
                    let i = 0;
                        for(i = 0; i < data.length;i++)
                        {
                            tavailableTags.push(data[i].Neve);
                        }
                    }
                });
                $( "#thelyszin1" ).autocomplete({
                        source: tavailableTags
                    });
        });


       $('#tovabbiHelyszin').click(function(){
           let lastid = $('.rhp').last().data("lastid");  lastid++; let helyszin = 'helyszin'+lastid; let helyszincim = 'helyszincim'+lastid;
          
           var htmlout = '<tr class="" id="rhelyszin'+lastid+'" data-lastid="'+lastid+'"> <td class="form-group col"> <input type="text" class="form-control" id="'+helyszin+'" name="'+helyszin+'" data-id="'+lastid+'"></td><td><a href="#DeletePlace" class="float-right delete" data-toggle="modal"><i class="material-icons deltool" data-toggle="tooltip" title=""  data-original-title="Törlés"></i></a></td></tr>';
           $('#rhelyszin').append(htmlout);
           AutocompleteTerulet(helyszin);
       });
       $('#tovabbitHelyszin').click(function(){
            let lastid = $('.rh').last().data("lastid"); lastid++; let helyszin = 'thelyszin'+lastid; let helyszincim = 'thelyszincim'+lastid;

            var htmlout = '<div class="form-row rh" id="rhelyszin" data-lastid="'+lastid+'"> <div class="form-group col-md-6"><label for="inputPassword4">A rendezvény helyszíne</label> <input type="text" class="form-control" id="'+helyszin+'" name="'+helyszin+'" data-id="'+lastid+'"></div> </div>';
            $('#thelyszin').append(htmlout);
            AutocompleteHelyszinek(helyszin);
        });

        $('#csoportNeve').focus(function(){
            let rend_id = $('#esemenyi').val();
            let selectCounter = document.getElementById("csTerulet").length;
            if(selectCounter <= 1)
            {
                $.ajax({
                    type:'POST',
                    url:'{{url('GetTeruletek')}}',
                    data:{_token:'<?php echo csrf_token() ?>', es_id:rend_id },
                    success:function(data) {
                    var obj = data;
                    let i = 0;
                        for(i = 0; i < data.length;i++)
                        {
                            $("<option>").attr("value", data[i].id).text(data[i].nev).appendTo("#csTerulet");
                        }
                    }
                });
            } /*teruletek betoltese*/
            

        });

        $('#csTerulet').change(function(){
            /* csoport helyszinek */
            let tavailableTags = [];
            let titem = document.getElementById("csTerulet").value;
            $.ajax({
                    type:'POST',
                    url:'{{url('GetAlHelyszinek')}}',
                    data:{_token:'<?php echo csrf_token() ?>',TeruletID:titem },
                    success:function(data) {
                    if(data.length == 0)
                    {
                        $('#cshelyszin1').prop( "disabled", true );
                        $('#noGroupLocation').text('Nincs elérhető választható helyszín!').css('color','red');
                        alert('Ennek a helyszínnek nincs választható alhelyszíne!');
                        $('#csoportLeiras').focus();
                        $('.close').click();
                    }
                    else 
                    {
                        let i = 0;
                        for(i = 0; i < data.length;i++)
                        {
                            tavailableTags.push(data[i].nev);
                        }
                    }
                    }
                   
                });
                $( "#cshelyszin1" ).autocomplete({
                        source: tavailableTags
                });
        });
        




   });
   function AutocompleteTerulet(hsz){
     var availableTags = [];
      $( "#"+hsz ).autocomplete({
          source: availableTags
      });
      $.ajax({
             type:'POST',
             url:'{{url('GetHelyszinek')}}',
             data:{_token:'<?php echo csrf_token() ?>' },
             success:function(data) {
             // var obj = JSON.parse(data);
              let i = 0;
                  for(i = 0; i < data.length;i++)
                  {
                      availableTags.push(data[i].Neve);
                  }

             }
          });
   }
   function AutocompleteHelyszinek(hsz)
   {
    var availableTags = [];
       $( "#"+hsz ).autocomplete({
           source: availableTags
       });
       $.ajax({
              type:'POST',
              url:'{{url('GetHelyszinek')}}',
              data:{_token:'<?php echo csrf_token() ?>' },
              success:function(data) {
              // var obj = JSON.parse(data);
               let i = 0;
                   for(i = 0; i < data.length;i++)
                   {
                       availableTags.push(data[i].Neve);
                   }
              }
           });
   }
</script>
<script type="text/javascript">
    $(document).ready(function(){
        // Activate tooltip
        $('[data-toggle="tooltip"]').tooltip();
        // Select/Deselect checkboxes
        var checkbox = $('table#AreEnum tbody input[type="checkbox"]');
        $("#selectAll").click(function(){
            if(this.checked){
                checkbox.each(function(){
                    this.checked = true;
                });
            } else{
                checkbox.each(function(){
                    this.checked = false;
                });
            }
        });
        checkbox.click(function(){
            if(!this.checked){
                $("#selectAll").prop("checked", false);
            }
        });

        $('.areadelete').click(function(){
            let arename = $(this).data('areaname'); let tid = $(this).data('tid');
            $('#areanamespan').html(arename); $('#teruletDelid').val(tid);

        });

        $('.deltool').click(function(){
                        let v = $(this).data('placeid'); $('#hid').val(v);

                    });

                    $('#helyszinTorlesBtn').click(function(){
                       let place = $('#hid').val();

                        $.ajax({
                                type:'POST',
                                url:'{{url('ProgramLocationDel')}}',
                                data:{_token:'<?php echo csrf_token() ?>',hid:place },
                                success:function(data) {
                                    if(data == 1) {location.reload();}
                                }
                            });
                    });




    });
    </script>


<script src="{{asset('js/datetimepicker-bs4.js')}}" type="text/javascript"></script>
<link href="https://unpkg.com/gijgo@1.9.13/css/gijgo.min.css" rel="stylesheet" type="text/css" />

<script>
  $('#datepicker').datepicker({
    uiLibrary: 'bootstrap4',
    minDate: '{{date("Y-m-d")}}'
  });
  $('#datepicker2').datepicker({
    uiLibrary: 'bootstrap4',
    minDate: '{{$Esemeny->kezdesDatuma}}'
  });
  
  $('#befIdejeDatum').datepicker({
    uiLibrary: 'bootstrap4',
    minDate: '{{$model->kezdesDatuma}}',
    maxDate: '{{$model->befejezesDatuma}}'
  });

  $(document).ready(function(){
      let TeruletKezdIdeje = {{$model->kezdesDatuma}};
  });

  $('select#csTerulet').change(function(){
                let tid = $('select#csTerulet').val();
                let ff = {{$model->kezdesDatuma}}; 
                $.ajax({
                type:'POST',
                url:'{{url('GetTeruletIdok')}}',
                data:{_token:'<?php echo csrf_token() ?>', tid:tid },
                success:function(data) {
                    let startDateSplit = data[0].kezdesIdopont.split(' ');
                    let endDateSplit = data[0].befejezesIdopont.split(' ');
                   
                    let kezdesDatum = startDateSplit[0];
                    let befejezesDatum = endDateSplit[0];

                    let kezdes = kezdesDatum.split('-');
                    document.getElementById('kezdHoCs-'+parseInt(kezdes[1])).selected = true;
                    let max = NapokJsonObject[parseInt(kezdes[1])];
                    for(let i = 0; i < max;i++)
                    {
                        let nap = i + 1;
                        $("<option>").attr("value", nap).attr("id", "kezdOptIdNapCs-"+nap).text(nap).appendTo("#kezdIdoNapCs");
                        
                            
                    }
                    document.getElementById('kezdOptIdNapCs-'+parseInt(kezdes[2])).selected = true;

                    let befejezes  = befejezesDatum.split('-');
                    console.log("befejezes");
                    console.log(befejezes);
                    document.getElementById('befHoCs-'+parseInt(befejezes[1])).selected = true;
                    max = NapokJsonObject[parseInt(befejezes[1])];
                    for(let i = 0; i < max;i++)
                    {
                        let nap = i + 1;
                        $("<option>").attr("value", nap).attr("id", "befOptIdNapCs-"+nap).text(nap).appendTo("#befIdoNapCs");
                        
                            
                    }
                    document.getElementById('befOptIdNapCs-'+parseInt(befejezes[2])).selected = true;

                }
            });
        });
      
</script>

 <script src="https://cdn.ckeditor.com/4.13.1/basic/ckeditor.js"></script>

 <script>
         CKEDITOR.replace( 'rendezvenyLeiras' );
          CKEDITOR.replace( 'teruletLeiras' );
 </script>
<script> var token = '<?php echo csrf_token() ?>';</script>


@endsection
