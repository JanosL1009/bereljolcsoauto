<!-- esemeny -->
<div class="row">
<div class="col-12">
	<div class="card my-3">
		<div class="card-body">
			<div class="row">
				<div class="col-12 d-flex justify-content-between">
					<h1>Rendezvény (program) koordinátor beosztása</h1>
                </div>
                <div class="col-12 col-md-6">
                        <p>Jelmagyarázat:</p>
                        <ul>
                            <li><strong>A</strong>: adminisztrátor jogosultsági szintű</li>
                        <!--<li><strong>Ö V</strong>: Önkéntes,valamelyik programnál szerepelt már vezető beosztásban</li>
                        -->
                        </ul>
                </div>
			</div>
			<div class="container2">
				<div class="row">

					<div class="col-12 col-lg-6">
						<div class="card my-3">
							<div class="card-body" style="height:600px;overflow-y:scroll;">

								<div class="form-group">
									<h5>
										Felhasználók
										<input id="searchOthers" style="padding: 3px 10px;" type="text" placeholder="Továbbiak keresése.." />
									</h5>
									<!-- modal link -->
									<button type="button" id="loaderanimataion" class="btn btn-link d-none" data-toggle="modal" data-target="#exampleModal">
									linkbe elhelyezhető
									</button>
									<table id="jelentkezok" class="table table-striped table-hover" id="esemenySzervezok">
										<thead>
											<tr>
												<th>
													<span class="custom-checkbox">
														<input type="checkbox" id="selectAllApplicants">
														<label for="selectAll"></label>
													</span>
												</th>
												<th>Név</th>
												<th>Műveletek</th>
											</tr>
										</thead>
										<tbody id="addAbleMore" class="addAbleMore"></tbody>
										<tbody style="border-top: 3px solid #333" class="addAble"></tbody>
									</table>
								</div>
							</div>
						</div>
					</div>


					<div class="col-12 col-lg-6">
						<div class="card my-3">
							<div class="card-body" style="height:600px;overflow-y:scroll;">

								<div class="form-group">
									<h5 >Beosztva</h5>
									<table id="beosztva" class="table table-striped table-hover">
										<thead>
											<tr>
												<th>
													<span class="custom-checkbox">
														<input type="checkbox" id="selectAllAssigned">
														<label for="selectAllAssigned"></label>
													</span>
												</th>
												<th>Név</th>
												<th>Műveletek</th>
											</tr>
										</thead>
										<tbody class="added"></tbody>
									</table>
								</div>
							</div>
						</div>
					</div>

				</div>

                  <div id="layer"></div>
                  <div id="ProgressBarDiv" class="progress-bar progress-bar-striped progress-bar-animated d-none" style="width:45%;height:15px;margin:0 auto;"></div>

                </div>
            </div>
		</div>
	</div>
</div>
<!-- Modal -->
<div class="modal fade" id="loaderModal" tabindex="-1" role="dialog" aria-labelledby="loaderModalLabel" aria-hidden="true">
<div class="modal-dialog modal-dialog-centered d-flex justify-content-center">
<div class="loader"></div>

</div>
</div>
	<!-- esemeny vege -->
	<script>
        $(function () {
        $('[data-toggle="tooltip"]').tooltip()
        });

	var felhasznalok = [@foreach($model->adminLista as $user){'id': '{{$user->id}}','name': '{{$user->name}}','email': '{{$user->email}}',},	@endforeach
    @foreach($bovitettLista as $user){'id': '{{$user->id}}','name': '{{$user->name}}','email': '{{$user->email}}',},	@endforeach
    ];

	var users = [@foreach($model->adminLista as $user){'id': '{{$user->id}}','name': '{{$user->name}}','email': '{{$user->email}}'},@endforeach
    @foreach($bovitettLista as $user){'id': '{{$user->id}}','name': '{{$user->name}}','email': '{{$user->email}}',},	@endforeach
    ].map(function(elem) {

		var birthText = 'Nincs megadva';
		var addressText = 'Nincs megadva';


		var birth = felhasznalok.find(element => element.email == elem.email);

		if(birth){
			birthText = birth.birth;
			addressText = birth.address;
		}

		return {
			'id': parseInt(elem.id),
			'name': elem.name,
			'email': elem.email,
			'birth': birthText,
			'address': addressText
		};
	});

	var adminArray = [@foreach(\DB::table('jogosultsag')->where('felhasznaloszint_id', 1)->get() as $jog){{$jog->felhasznalo_id}},@endforeach];

	var szervezokArray = [@foreach(\DB::table('esemeny_szervezok')->where('szint_id', 3)->get() as $sz){{$sz->felhasznalo_id}},@endforeach];

	var selectedSzervezokArray = [@foreach(\DB::table('esemeny_szervezok')->where('szint_id', 3)->where('Esemeny_id', $Esemeny->esemenyID)->get() as $sz){{$sz->felhasznalo_id}},	@endforeach];

	var renderElements = function(){

		$('.addAble').html(users.map(function(elem) {
			if(adminArray.includes( parseInt(elem.id) ) && !selectedSzervezokArray.includes(elem.id)){
			return `

			<tr id="`+elem.id+`" >
				<td>
					<span class="custom-checkbox">
						<input type="checkbox" id="checkbox`+elem.id+`" name="options[]" value="`+elem.id+`">
						<label for="checkbox`+elem.id+`"></label>
					</span>

				</td>
				<td>
					<span title="`+elem.birth+` - `+elem.address+`" class="pointer" data-toggle="tooltip">`+elem.name+`</span></td>
				<td>
					<i class="material-icons add_box pointer kez"  data-toggle="tooltip"  data-uid="`+elem.id+`" onclick="UserEventAdd(`+elem.id+`)"  data-toggle="modal" data-target="#exampleModal">add_box</i>
                    <i class="material-icons add_box pointer "  data-toggle="tooltip"  >A</i>
                </td>
			</tr>

			`;}

             if(szervezokArray.includes( parseInt(elem.id)) && !selectedSzervezokArray.includes(elem.id))
            {
                return `

                <tr id="`+elem.id+`" >
                    <td>
                        <span class="custom-checkbox">
                            <input type="checkbox" id="checkbox`+elem.id+`" name="options[]" value="`+elem.id+`">
                            <label for="checkbox`+elem.id+`"></label>
                        </span>

                    </td>
                    <td>
                        <span title="`+elem.birth+` - `+elem.address+`" class="pointer" data-toggle="tooltip">`+elem.name+`</span></td>
                    <td>
                        <i class="material-icons add_box pointer kez"  data-toggle="tooltip"  data-uid="`+elem.id+`" onclick="UserEventAdd(`+elem.id+`)"  data-toggle="modal" data-target="#exampleModal">add_box</i>
                        <i class="material-icons add_box pointer "  data-toggle="tooltip"  >Ö V</i>
                    </td>
                </tr>

                `;
            }

		}));

		$('.added').html(users.map(function(elem) {
			if(selectedSzervezokArray.includes( parseInt(elem.id) ))
			return `

			<tr id="group`+elem.id+`">
				<td>
					<span class="custom-checkbox">
						<input type="checkbox" id="checkbox1" name="options[]" value="`+elem.id+`">
						<label for="checkbox1"></label>
					</span>
				</td>
				<td><span title="`+elem.birth+` - `+elem.address+`" class="pointer" data-toggle="tooltip">`+elem.name+`</span></td>

				<td>
					<i class="material-icons remove pointer kez"  data-toggle="tooltip"  data-uid="`+elem.id+`" onclick="UserEventRemove(`+elem.id+`)" title="Eltávolít" >close</i>

				</td>
			</tr>

			`;
		}));

		
	}

	renderElements();


	$(document).on('keyup', '#searchOthers', function(){
		let searchString = $(this).val();
		if(searchString.length > 4){

            $.ajax({
				type:'POST',
				url:'{{url('getusersfiltered')}}',
				data:{_token: '<?php echo csrf_token() ?>', jszint:2, item:searchString},
				success:function(data) {
                    var d = JSON.parse(data);
                    let resultString = '';
                    for(let i = 0; i < d.length;i++)
                    {

                        let res = `
                                    <tr id="group`+d[i].id+`">
                                        <td>
                                            <span class="custom-checkbox">
                                                <input type="checkbox" id="" name="options[]" value="`+d[i].id+`">
                                                <label for="checkbox1"></label>
                                            </span>
                                        </td>
                                        <td><span title="" class="pointer" data-toggle="tooltip">`+d[i].name+`</span></td>

                                        <td>
                                            <i class="material-icons add_box pointer kez"  data-toggle="tooltip"  data-uid="`+d[i].id+`" onclick="UserEventAddForSearch(`+d[i].id+`,'`+d[i].name+`')" data-username="`+d[i].name+`" data-toggle="modal" data-target="#exampleModal">add_box</i>
                                            <i class="material-icons add_box pointer "  data-toggle="tooltip"  ></i>

                                        </td>
                                    </tr>

                                    `;
                                    resultString = resultString + res;
                    }
                    if(resultString != 'undefined')
                    {
                        document.getElementById('addAbleMore').innerHTML = resultString;
                    }

				}
			});




		} else{
			$('.addAbleMore').html('');
		}

	});



		function UserEventAdd(itemid){
           
		 
			var  rend_id = $('#esemeny').val();
		
			$.ajax({
				type:'POST',
				url:'{{url('EsSzervBeosztas')}}',
				data:{_token: '<?php echo csrf_token() ?>', eid: {{$Esemeny->esemenyID}}, tid: rend_id, uid: itemid},
				success:function(data) {
					if (data ==1 ) {
						$('#loaderModalClose').click();
						//document.getElementById('exampleModal').click();
						success = true;
						selectedSzervezokArray.push(itemid);
						renderElements();
						
					}

				}
			});
			
		}

		function UserEventAddForSearch(itemid,username){

            var  rend_id = $('#esemeny').val();

            $.ajax({
                type:'POST',
                url:'{{url('EsSzervBeosztas')}}',
                data:{_token: '<?php echo csrf_token() ?>', eid: {{$Esemeny->esemenyID}}, tid: rend_id, uid: itemid},
                success:function(data) {
                    if (data ==1 ) {
                        selectedSzervezokArray.push(itemid);

                        let item = {'id':itemid, 'name': username};
                        users.push(item);
                        renderElements();
                        document.getElementById('group'+itemid).style.display = 'None';
                    }

                }
            });
        }

		function UserEventRemove(itemid)
		{
		
			var  rend_id = $('#esemeny').val();

			$.ajax({
				type:'POST',
				url:'{{url('EsSzervBeosztasTorles')}}',
				data:{_token: '<?php echo csrf_token() ?>', eid: {{$Esemeny->esemenyID}} ,uid:itemid},
				success:function(data) {
					if (data == 1) {
						selectedSzervezokArray = selectedSzervezokArray.filter(id => id !== itemid);
						renderElements();
					}

				}
			});



		}
    </script>
    <script>
      var checkbox2 = $('table#jelentkezok tbody input[type="checkbox"]');
        $("#selectAllApplicants").click(function(){
            if(this.checked){
                checkbox2.each(function(){
                    this.checked = true;
                });
            } else{
                checkbox2.each(function(){
                    this.checked = false;
                });
            }
        });
        checkbox2.click(function(){
            if(!this.checked){
                $("#selectAllApplicants").prop("checked", false);
            }
        });

        var checkbox3 = $('table#beosztva tbody input[type="checkbox"]');
        $("#selectAllAssigned").click(function(){
            if(this.checked){
                checkbox3.each(function(){
                    this.checked = true;
                });
            } else{
                checkbox3.each(function(){
                    this.checked = false;
                });
            }
        });
        checkbox3.click(function(){
            if(!this.checked){
                $("#selectAllAssigned").prop("checked", false);
            }
        });

</script>
