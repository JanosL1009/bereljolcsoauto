@extends('layouts.admin')

@section('content')

    <div class="row">
            <div class="col-12 d-flex justify-content-between">
                    <h1>Csoportbeosztás  </h1>
            </div>
            <div class="col-12 d-flex ">
                    <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                              {!! $model->breadcrumblink !!}
                            </ol>
                     </nav>

            </div>
     </div>

    <div class="row">

            <div class="col-12 col-md-12">
	<div class="card my-3">
		<div class="card-body">



			<div class="row">
				<div class="col-12 d-flex justify-content-between">
                    <h1>Csoport beosztása</h1>
				</div>
            </div>

			<div class="container2">


				<div class="row">

					<div class="col-12 col-md-6">
						<div class="card my-3">
							<div class="card-body" style="height:600px;overflow-y:scroll;">

								<div class="form-group">
									<h5>
										Jelentkezők
									</h5>
									<div class="myBox">
										<input id="searchOthers" style="padding: 3px 10px;" type="text" placeholder="Továbbiak keresése.." />
									
									</div>
									<div class="myBox">

                                        <select id="searchGroups" style="padding: 3px 10px;" >
                                            <option >--- Elérhető jelige csoportok ---</option>
                                        </select>
                                    </div>
									<table class="table table-striped table-hover" id="teruletVezetok">
										<thead>
											<tr>
												<th>
													<span class="custom-checkbox">
														<input type="checkbox" id="selectAll">
														<label for="selectAll"></label>
													</span>
												</th>

												<th>Név</th>
												<th>Műveletek</th>

											</tr>
										</thead>
										<tbody class="addAbleMore"></tbody>
										<tbody style="border-top: 3px solid #333" class="addAble"></tbody>
									</table>
								</div>
							</div>
						</div>
					</div>


					<div class="col-12 col-md-6">
						<div class="card my-3">
							<div class="card-body" style="height:600px;overflow-y:scroll;">

								<div class="form-group">
                                    <h5 >Beosztva</h5>
                                    <p id="GroupCounter" style="text-align: center;"> <span id="actCount">{{$model->BeosztottakSzama}}</span>  / {{$model->TervezettCsoportLetszam}} </p>
									<table id="teruletbeosztva" class="table table-striped table-hover">
										<thead>
											<tr>
												<th>
													<span class="custom-checkbox">
														<input type="checkbox" id="selectAll">
														<label for="selectAll"></label>
													</span>
												</th>

												<th>Név</th>
												<th>Műveletek</th>

											</tr>
										</thead>
										<tbody class="added"></tbody>
									</table>
								</div>
							</div>
						</div>
					</div>

				</div>



			</div>
		</div>
	</div>
</div>



<script>
	var users = [
		@foreach($users as $user){'id': '{{$user->id}}','name': '{{$user->name}}'},@endforeach
];


    {{-- terulet jelentkezok --}}
	var szervezokArray = [@foreach($model->jelentkezokLista as $sz){{$sz}}, @endforeach];

    {{-- csoport beosztottak --}}
    var selectedSzervezokArray = [@foreach($csoportBeosztottakID as $sz){{$sz->felhasznalo_id}},	@endforeach];

	var renderElements = function(){

		$('.addAble').html(users.map(function(elem) {
			if(
				(szervezokArray.includes( parseInt(elem.id) ))
				&& !selectedSzervezokArray.includes(parseInt(elem.id))
				)
			return `

			<tr id="`+elem.id+`">
				<td>
					<span class="custom-checkbox">
						<input type="checkbox" id="checkbox1" name="options[]" value="`+elem.id+`">
						<label for="checkbox1"></label>
					</span>

				</td>
				<td class="username" >
					<span class="pointer" title="`+elem.birth+` - `+elem.address+`"  onclick="ShowProfile(`+elem.id+`)" style="cursor:pointer;">`+elem.name+`</span></td>
				<td>
					<i class="material-icons add_box pointer"  data-toggle="tooltip"  data-uid="`+elem.id+`" onclick="UserEventAdd(`+elem.id+`)">add_box</i>
				</td>
			</tr>

			`;
		}));

		$('.added').html(users.map(function(elem) {
			if(selectedSzervezokArray.includes( parseInt(elem.id) ))
			return `

			<tr id="group`+elem.id+`">
				<td>
					<span class="custom-checkbox">
						<input type="checkbox" id="checkbox1" name="options[]" value="`+elem.id+`">
						<label for="checkbox1"></label>
					</span>
				</td>
				<td class="username" >
					<span class="pointer" title="`+elem.birth+` - `+elem.address+`"  onclick="ShowProfile(`+elem.id+`)" style="cursor:pointer;">`+elem.name+`</span></td>
				<td>

				<td>
					<i class="material-icons remove pointer"  data-toggle="tooltip"  data-uid="`+elem.id+`" onclick="UserEventRemove(`+elem.id+`)" title="Eltávolít" >close</i>

				</td>
			</tr>

			`;
		}));


	}

	renderElements();

	$(document).on('keyup', '#searchOthers', function(){
		var searchString = $(this).val();
		if(searchString.length > 2){

			$('.addAbleMore').html(users.map(function(elem) {
				if(
					(elem.name.toLowerCase().includes(searchString.toLowerCase()))
					&& !selectedSzervezokArray.includes(elem.id)
					)
				return `

				<tr id="`+elem.id+`">
					<td>
						<span class="custom-checkbox">
							<input type="checkbox" id="checkbox1" name="options[]" value="`+elem.id+`">
							<label for="checkbox1"></label>
						</span>

					</td>
					<td class="username" >
						<span class="pointer" title="`+elem.birth+` - `+elem.address+`"  onclick="ShowProfile(`+elem.id+`)" style="cursor:pointer;">`+elem.name+`</span></td>
					

					<td>
						<i class="material-icons add_box pointer"  data-toggle="tooltip"  data-uid="`+elem.id+`" onclick="UserEventAdd(`+elem.id+`)">add_box</i>
					</td>
				</tr>

				`;
			}));

		} else{
			$('.addAbleMore').html('');
		}

	})

    function UserEventAdd(itemid){
    	let csoport_id = {{$model->csoportID}};

        $.ajax({
            type:'POST',
            url:'{{url('CsopBeosztas')}}',
            data:{_token: '<?php echo csrf_token() ?>', csid:csoport_id,uid:itemid},
            success:function(data) {
                if (data == 1 ) {
                                selectedSzervezokArray.push(itemid);
                                renderElements();

                                CounterGrowth();
                            }
                console.log(data);
            }
        });

    }

    function UserEventRemove(itemid)
    {

        // Ha kell:
    	var csoport_id = {{$model->csoportID}};
        $.ajax({
				type:'POST',
				url:'{{url('CsopBeosztUserRemove')}}',
				data:{_token: '<?php echo csrf_token() ?>', csid: csoport_id ,uid:itemid},
				success:function(data) {
					if (data == 1) {
                        selectedSzervezokArray = selectedSzervezokArray.filter(id => id !== itemid);
                        szervezokArray.push(itemid);
                        renderElements();CounterDeacrease();
                        renderGroupsColor();

					}
					console.log(data);
				}
			});

    }

    function CounterDeacrease()
    {
        let val = document.getElementById('actCount').innerText;
        document.getElementById('actCount').textContent= parseInt(val) - 1;

    }

    function CounterGrowth()
    {
        let val = document.getElementById('actCount').innerText;
        document.getElementById('actCount').textContent= parseInt(val) + 1;
    }

</script>


        </div>















            <script type="text/javascript">
                $(document).ready(function(){
                    // Activate tooltip
                    $('[data-toggle="tooltip"]').tooltip();

                    // Select/Deselect checkboxes
                    var checkbox = $('table tbody input[type="checkbox"]');
                    $("#selectAll").click(function(){
                        if(this.checked){
                            checkbox.each(function(){
                                this.checked = true;
                            });
                        } else{
                            checkbox.each(function(){
                                this.checked = false;
                            });
                        }
                    });
                    checkbox.click(function(){
                        if(!this.checked){
                            $("#selectAll").prop("checked", false);
                        }
                    });
                });
                </script>

				
<script>
    var CsoportosJelentkezok = {!! $CsoportosJelentkezok !!};
    var Jeligek = {!! $JeligeLista !!};
    var searchGroupsSelect = document.getElementById('searchGroups');
    for(let i = 0;i < Jeligek.length;i++)
    {
        let opt = document.createElement('option');
        opt.value = Jeligek[i].id;
        opt.innerHTML = Jeligek[i].jeligeNeve;
        searchGroupsSelect.appendChild(opt);
    }

    document.getElementById("searchGroups").onchange = function() {
        //alert('A kereső fejlesztés alatt!');
        let id = document.getElementById("searchGroups").value;
           
            if(id > 0){
				
				let output = '';
				for(let i =0;i < CsoportosJelentkezok.length ;i++)
				{
					if(CsoportosJelentkezok[i].jeligeID == id )
					{
						let csoportNeve = getJeligeNeve(id);
						for(let j = 0; j < users.length;j++)
						{
							if(CsoportosJelentkezok[i].uid == users[j].id)
							{
								output = output + `<tr id="`+users[j].id+`">
									<td>
										<span class="custom-checkbox">
											<input type="checkbox" id="checkbox1" name="options[]" value="`+users[j].id+`">
											<label for="checkbox1"></label>
										</span>

									</td>
									<td><span class="pointer" data-toggle="tooltip">`+users[j].name+` (`+csoportNeve+`)</span></td>

									<td>
										<i class="material-icons add_box pointer"  data-toggle="tooltip"  data-uid="`+users[j].id+`" onclick="UserEventAdd(`+users[j].id+`)">add_box</i>
									</td>
								</tr>`;
								
							}
							
						}
						
					} 
				}
				$('.addAbleMore').html(output);

				} else{
				$('.addAbleMore').html('');
				} //ifend

        };

		function getJeligeNeve(id){
			let nev = 0;
				for(let i = 0; i < Jeligek.length; i++ )
				{
					if(Jeligek[i].id == id)
					{
						nev = Jeligek[i].jeligeNeve;
					} 
				}

				return nev;
			}

</script>


@include('assets.beosztasRovidProfile')

@endsection

