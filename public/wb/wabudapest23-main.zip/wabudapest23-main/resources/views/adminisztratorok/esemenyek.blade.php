@extends('layouts.admin')

@section('content')
<style>

    .hint-text {
        float: left;
        margin-top: 10px;
        font-size: 13px;
    }
</style>
@php
$subTitle = null; 

       $mode = $model->getMode();
        switch($mode)
        {
            case 'all': $subTitle = 'Összes'; break;
            case 'active': $subTitle = 'Aktív'; break;
            case 'notcomplete': $subTitle = 'Szerkesztés alatt'; break;
            case 'noteligible': $subTitle = 'Nem lehet rá jelentkezni'; break;
            case 'archive': $subTitle = 'Archív'; break;
        }
   

@endphp

        <div class="row">
                <div class="col-12 d-flex justify-content-between">
                        <h1>Rendezvények @if(isset($subTitle))- {{$subTitle}} @endif</h1>
                </div>
        </div>


        <div class="card my-3">
                <div class="card-body">
                <div class="table-wrapper">

                        @php
                             $rendezvenyek = $model->rendezveny;
                             //dd($rendezvenyek);
                        @endphp

                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>
                                    <span class="custom-checkbox">
                                        <input type="checkbox" id="selectAll">
                                        <label for="selectAll"></label>
                                    </span>
                                </th>
                                <th>Rendezvény neve
                                  <a href="{{url('admin/esemenyek/'.$model->getMode().'/nev/asc')}}" class="szuro">
                                    <span class="material-icons">expand_less</span>
                                  </a>
                                  <a href="{{url('admin/esemenyek/'.$model->getMode().'/nev/desc')}}" class="szuro">
                                    <span class="material-icons">expand_more</span>
                                  </a>
                                </th>
                            <!--    <th>Helyszín</th> -->
                                <th>Kezdés időpont
                                  <a href="{{url('admin/esemenyek/'.$model->getMode().'/kezdesDatum/asc')}}" class="szuro">
                                    <span class="material-icons">expand_less</span>
                                  </a>
                                  <a href="{{url('admin/esemenyek/'.$model->getMode().'/kezdesDatum/desc')}}" class="szuro">
                                    <span class="material-icons">expand_more</span>
                                  </a>
                                </th>
                                <th>Státusz </th>
                                <th>Műveletek</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($rendezvenyek as $rendezveny)

                            <tr data-eid={{$rendezveny->id}}>
                                <td>
                                    <span class="custom-checkbox">
                                        <input type="checkbox" id="checkbox1" name="options[]" value="1">
                                        <label for="checkbox1"></label>
                                    </span>
                                </td>
                                <td data-label="Rendezveny neve">{{$rendezveny->nev}}</td>
                              <!--  <td>{{$rendezveny->telepules_id}}</td> -->
                                <td data-label="Kezdés időpont">{{$rendezveny->kezdesDatum}}</td>
                                <td  data-label="Státusz">{{$rendezveny->statusz_id}}</td>
                                <td data-label="Műveletek">
                                    <a href="{{url('admin/esemeny_szerkesztes/'.$rendezveny->id)}}" class="edit" ><i class="material-icons" data-toggle="tooltip" title="Módosítás">&#xE254;</i></a><!-- ezt paraméteresíteni! -->
                                    <a href="#deleteEmployeeModal" class="delete" data-toggle="modal"><i class="material-icons deltool" data-toggle="tooltip" title="Törlés" data-valesid="{{$rendezveny->id}}">&#xE872;</i></a>

                                </td>
                            </tr>


                            @endforeach
                        </tbody>
                    </table>





                    <div class="clearfix float-left">
                            {{ $model->rendezveny->links() }}
                    </div>
                </div>
            </div>
        </div>


            <!-- Delete Modal HTML -->
            <div id="deleteEmployeeModal" class="modal fade">
                <div class="modal-dialog">
                    <div class="modal-content">

                            <div class="modal-header">
                                <h4 class="modal-title">Rendezvény törlése</h4>
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                            </div>
                            <div class="modal-body">
                                <p>Biztosan törölni szeretné, ezt a rendezvényt?</p>
                                <p style="color: #ff0000;" >Ha törli a rendezvényt, később az adatokat nem tudjuk visszaállítani!</p>
                            </div>
                            <div class="modal-footer">
                                <input type="number" class="d-none" id="esid" name="esid" value="-1">
                                <input type="button" class="btn btn-default" data-dismiss="modal" value="Mégse">
                                <input type="button" id="esemenyTorlesBtn" class="btn btn-danger" value="Törlés">
                            </div>

                    </div>
                </div>
            </div>
            <script type="text/javascript">
                $(document).ready(function(){

                    $('.deltool').click(function(){
                        let v = $(this).data('valesid'); $('#esid').val(v);
                    });

                    $('#esemenyTorlesBtn').click(function(){
                        let omrr = $('#esid').val();
                        $.ajax({
                                type:'POST',
                                url:'{{url('EsemenyDelete')}}',
                                data:{_token:'<?php echo csrf_token() ?>', _esid:omrr },
                                success:function(data) {
                                    if(data == 1) {location.reload();}
                                }
                            });
                    });


                    // Activate tooltip
                    $('[data-toggle="tooltip"]').tooltip();

                    // Select/Deselect checkboxes
                    var checkbox = $('table tbody input[type="checkbox"]');
                    $("#selectAll").click(function(){
                        if(this.checked){
                            checkbox.each(function(){
                                this.checked = true;
                            });
                        } else{
                            checkbox.each(function(){
                                this.checked = false;
                            });
                        }
                    });
                    checkbox.click(function(){
                        if(!this.checked){
                            $("#selectAll").prop("checked", false);
                        }
                    });
                });


                </script>

@endsection
