@extends('layouts.admin')


@section('htmlhead')


<style>

div.myTime {
    background-color: white;
    display: inline-flex;
    border: 1px solid #ccc;
    color: #555;
  }

  input.timeInput {
    border: none;
    color: #555;
    text-align: center;
    width: 60px;
  }

  .form-error{
    color: #ff0000;
  }
  .bootstrap-select:not([class*="col-"]):not([class*="form-control"]):not(.input-group-btn) {
    width: 100%!important;
  }
</style>

<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/css/bootstrap-select.css" />


@endsection

@section('content')

       <!-- <div class="row"> -->
       <form id="UjHirLetrehozasa" class="row" action="{{ url('/admin/hir/ujhir_letrehozo') }}" method="post" enctype="multipart/form-data" width="100%">
        @csrf
          <div class="col-12 d-flex justify-content-start">
            <h1>Új hír létrehozása</h1>
          </div>

          <div class="col-12">
            <div class="card my-3">
              <div class="card-body">

                <div class="form-group">
                  <label for="HirCime" id="HirCime">Hír címe</label>
                  <input type="text" class="form-control" id="hirCime" name="hirCime" placeholder="Hír címe" data-validation-length="min4" data-validation="required">
                </div>

                <!-- <div class="form-row"> -->
                    <div class="form-group">
                      <label for="dtp_input2" class="control-label">Kapcsolódó rendezvény</label>
                          <select class="selectpicker" multiple  data-live-search="true" id="kapcsolodoProgram" name="kapcsolodoProgram" data-validation="required">
                              <!-- <option  disabled value selected>--- Kérem válasszon ---</option> -->
                              <option  value="-1" >Az összes rendezvény</option>
                              @foreach($model->RelatedPrograms as $program)
                                  <option value="{{$program['id']}}">{{$program['cim']}}</option>
                              @endforeach
                          </select>
                          <input type="hidden" id="relatedprograms" name="relatedprograms" value="">
                    </div>
                <!-- </div> -->


                <!-- <div class="form-row"> -->
                  <div class="form-group col-md-6 p-0">
                    <label for="inputEmail4">Státusz</label>
                    <select class="custom-select" id="HirStatusza" name="HirStatusza" data-validation="required">
                      <option value="0" selected disabled>Válassz ...</option>
                      <option value="1">Szerkesztés alatt</option>
                      <option value="2">Publikált</option>

                    </select>
                  </div>

                <!-- </div> -->

                <div class="form-group" >
                  <label for="hirLeirasaTextArea">Hír leírása</label>


                  <textarea class="form-control" name="hirLeiras" data-validation="required"></textarea>

                </div>


            </div>
            </div>
          </div>

          <div class="col-12">
            <div class="card my-3">
                <div class="card-body">
                    <h5>SEO - Keresőoptimalizálás</h5>

                    <div class="form-row">
                      <div class="form-group col-12">
                        <label for="">Leírás</label>
                        <textarea type="text" id="seoDescription" name="seoDescription" class="form-control" maxlength="240" data-validation="required"></textarea>
                      </div>
                    </div>

                    <div class="form-row">
                      <div class="form-group col-12">
                          <label for="">Kulcsszavak</label>
                            <input type="text" id="seoKeywords" name="seoKeywords" class="form-control" maxlength="160" data-validation="required">
                      </div>
                    </div>

                    <div class="form-row">
                      <div class="form-group col-12">
                        <label for="">Oldal cím / title</label>
                        <input type="text" id="seoTitle" name="seoTitle" class="form-control" maxlength="120" data-validation="required">
                      </div>
                    </div>

                    <div class="form-row">
                      <div class="form-group col-12">
                        <label for="">Közösségi cím / og_title</label>
                        <input type="text" id="ogTitle" name="ogTitle" class="form-control" maxlength="120" data-validation="required">
                      </div>
                    </div>

                    <div class="form-row">
                      <div class="form-group col-12">
                        <label for="">Közösségi leírás / og_description</label>
                        <textarea type="text" id="ogDescription" name="ogDescription" class="form-control" maxlength="240" data-validation="required"></textarea>
                      </div>
                    </div>

                    <div class="form-row">
                      <div class="form-group col-12">
                        <label for="">A kereső robotok (pl.: Googlebot) indexelhetik ezt az oldalt?</label>
                        <input type="checkbox" name="botindex" id="botindex">
                        <label for="botindex"> Igen (Ha nem szeretnéd, hogy ennek az oldalnak a tartalmát indexelje a bot, akkor ne pipáld be ezt a boxot!)</label><br>
                      </div>
                    </div>

              </div>
          </div>
        </div>

       

                <div class="col-12 d-flex ">
                        <input type="file" class="d-none" id="thumbnailNewsImg" name="thumbnailNewsImg" >
                        <input type="text" id="wysiwyg" name="wysiwyg" class="d-none" >
                        <button type="submit" id="SaveNews" class="btn btn-primary ">Mentés</button>
                </div>

            </form>

            
        


<script src="{{ asset('js/jquery.form-validator.min.js') }}"></script>
<script>
   var myLanguage = {

        errorTitle: 'Az űrlap feldolgozása sikertelen.',
        requiredFields: 'You have not answered all required fields',
        badTime: 'You have not given a correct time',
        badEmail: 'You have not given a correct e-mail address',
        badTelephone: 'You have not given a correct phone number',
        badSecurityAnswer: 'You have not given a correct answer to the security question',
        badDate: 'You have not given a correct date',
        lengthBadStart: 'The input value must be between ',
        lengthBadEnd: ' karakter',
        lengthTooLongStart: 'The input value is longer than ',
        lengthTooShortStart: 'Az input érték nem lehet kevesebb, mint ',
        notConfirmed: 'Input values could not be confirmed',
        badDomain: 'Incorrect domain value',
        badUrl: 'The input value is not a correct URL',
        badCustomVal: 'The input value is incorrect',
        andSpaces: ' and spaces ',
        badInt: 'The input value was not a correct number',
        badSecurityNumber: 'Your social security number was incorrect',
        badUKVatAnswer: 'Incorrect UK VAT Number',
        badStrength: 'The password isn\'t strong enough',
        badNumberOfSelectedOptionsStart: 'You have to choose at least ',
        badNumberOfSelectedOptionsEnd: ' answers',
        badAlphaNumeric: 'The input value can only contain alphanumeric characters ',
        badAlphaNumericExtra: ' and ',
        wrongFileSize: 'The file you are trying to upload is too large (max %s)',
        wrongFileType: 'Only files of type %s is allowed',
        groupCheckedRangeStart: 'Please choose between ',
        groupCheckedTooFewStart: 'Please choose at least ',
        groupCheckedTooManyStart: 'Please choose a maximum of ',
        groupCheckedEnd: ' item(s)',
        badCreditCard: 'The credit card number is not correct',
        badCVV: 'The CVV number was not correct',
        wrongFileDim : 'Incorrect image dimensions,',
        imageTooTall : 'the image can not be taller than',
        imageTooWide : 'the image can not be wider than',
        imageTooSmall : 'the image was too small',
        min : 'min',
        max : 'max',
        imageRatioNotAccepted : 'Image ratio is not accepted'
    };

  $.validate({
    language : myLanguage
  });
</script>
 <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
 <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>


 <script src="//cdn.ckeditor.com/4.14.0/standard/ckeditor.js" rel="dns-prefetch"></script>
<!--<script src="{{asset('js/ckeditor/filebrowser/plugin.js')}}"></script>
 ckfinder kell -->
<script>

        CKEDITOR.replace( 'hirLeiras',{
            filebrowserBrowseUrl: 'https://onkentes.iec2020.hu/public/ckfinder/ckfinder.html',
	        filebrowserUploadUrl: '/omr_nek/public/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files'
        });

        CKEDITOR.hirLeiras = function( config ) {
            config.uiColor = '#AADC6E';


        };

        function readURL(input) {
  if (input.files && input.files[0]) {
    var reader = new FileReader();

    reader.onload = function(e) {
      $('#jumbotronImg').attr('src', e.target.result);
    }

    reader.readAsDataURL(input.files[0]); // convert to base64 string
  }
}

$("#imgInp").change(function() {

  readURL(this);
});

</script>


@endsection

@section('scriptsection')

<script src="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.9/dist/js/bootstrap-select.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.9/js/i18n/defaults-hu_HU.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/js/all.min.js"></script>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css">
<script type="text/javascript">
    var relatedprograms = [];
    $('.selectpicker').change(function(){
        $('#relatedprograms').val($('#kapcsolodoProgram').val());
    });
 </script>

<div id="uploadimageModal" class="modal modal-lg mycenter" role="dialog">
	
           
  <div class="modal-header">
     
      <h4 class="modal-title">Profilkép szerkesztés</h4> <button type="button" class="close mymodaldes" data-dismiss="modal">&times;</button>
  </div>
  <div class="modal-body">
      <div id="image_demo" ></div>
      <button class="btn btn-success crop_image">Kivágás</button>
  </div>
  <div class="modal-footer">
      <button type="button" class="btn btn-default" data-dismiss="modal">Bezárás</button>
  </div>
  

</div>


 
<link href="https://cdnjs.cloudflare.com/ajax/libs/croppie/2.6.5/croppie.css" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/croppie/2.6.5/croppie.js" ></script>
    <script>
/* js beallito fajl*/
  $image_crop = $('#image_demo').croppie({
enableExif: false,
viewport: {
  width:310,
  height:390,
  type:'square' //circle
},
boundary:{
  width:500,
  height:410
},
customClass: 'crop-area',
showZoomer: true,
enableResize: false,
enableOrientation: false,
mouseWheelZoom: 'ctrl'

});

$('#upload_image').on('change', function(){
var reader = new FileReader();
reader.onload = function (event) {
  $image_crop.croppie('bind', {
    url: event.target.result
  }).then(function(){
    console.log('jQuery bind complete');
  });
}
reader.readAsDataURL(this.files[0]);
$('#uploadimageModal').modal('show');
});

$('.crop_image').on('click', function (event) {
    $image_crop.croppie('result', {
      //type: 'blob',
      //format: 'jpeg',
      type: 'canvas',
      //size: 'viewport'
      size: {width:310, height: 390}
      }).then(function (response) {
      
       
      $('#preview_image').attr('src',response);

    

      $('#uploadimageModal').modal('hide');

    });

    $image_crop.croppie('result', {
      type: 'blob',
      format: 'jpeg',
      
      size: {width:310, height: 390}
      }).then(function (response) {
       
        const formData = new FormData();
	    formData.append('file', response,'file.jpg');

        $('#file_name').prop("files",response);

    });

    return false;
});

function changeProfile() {
        $('#upload_image').click();
    }

</script>

@endsection
