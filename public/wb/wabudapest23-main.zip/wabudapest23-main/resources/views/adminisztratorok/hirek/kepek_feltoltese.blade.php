@extends('layouts.admin')

@section('content')

<div class="row">
    <div class="col-12">
        <h2>Képek szerkesztése/feltöltése : {{$HirCime??"Nem létező hír"}}</h2>
    </div>
</div>

<div class="row">
    <div class="col-12">
        
       <div class="card">
            <div class="card-body">
                <h3>Kép a fő megjelenéshez és OpenGraphoz</h3>
                <div class="mt-5">
                    <input type='file' id="imgInp" name="imgInp" value="@if(isset($hirKepek->jumbotronImg)) {{asset('hir/'.$hirKepek->jumbontronImg)}} @else {{asset('image/default-image-800x600.jpg')}} @endif"/>
                    <hr>
                    <img id="jumbotronImg" src="@if(isset($hirKepek->jumbotronImg)) {{asset('hir/'.$hirKepek->jumbotronImg)}} @else {{asset('image/default-image-800x600.jpg')}} @endif" width="800" height="600" />
                </div>
            </div>
        </div>
    </div>
</div>


<div class="row mt-5" >
    <div class="col-12">
        
       <div class="card">
            <div class="card-body">
                <h3>Thumbnail(kisméretű borítókép) kép</h3>
                <div class="mt-5">
                    <input type='file' id="imgThumb" name="imgThumb" value="@if(isset($hirKepek->thumbnailImg)) {{asset('hir/'.$hirKepek->thumbnailImg)}} @else {{asset('image/default-image-800x600.jpg')}} @endif"/>
                    <hr>
                    <img id="thumbnailImg" src="@if(isset($hirKepek->thumbnailImg)) {{asset('hir/'.$hirKepek->thumbnailImg)}} @else {{asset('image/default-image-800x600.jpg')}} @endif " width="310" height="390" />
                </div>
            </div>
        </div>
    </div>
</div>


<div id="uploadMainImgModal" class="col-12 modal" role="dialog">
	
           
    <div class="modal-header">
       
        <h4 class="modal-title">Főkép szerkesztés</h4> <button type="button" class="close mymodaldes" data-dismiss="modal">&times;</button>
    </div>
    <div class="modal-body">
        <div id="image_demo" ></div>
        <button class="btn btn-success crop_image">Kivágás</button>
    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Bezárás</button>
    </div>
    
  
  </div>


  <div id="uploadThumbnailModal" class="col-12 modal" role="dialog">
	
           
    <div class="modal-header">
       
        <h4 class="modal-title">Thumbnail szerkesztés</h4> <button type="button" class="close mymodaldes" data-dismiss="modal">&times;</button>
    </div>
    <div class="modal-body">
        <div id="image_demo2" ></div>
        <button class="btn btn-success crop_image2">Kivágás</button>
    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Bezárás</button>
    </div>
    
  
  </div>

@endsection


@section('scriptsection')
<link href="https://cdnjs.cloudflare.com/ajax/libs/croppie/2.6.5/croppie.css" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/croppie/2.6.5/croppie.js" ></script>

<script>
    /* js beallito fajl*/
      $image_crop = $('#image_demo').croppie({
    enableExif: false,
    viewport: {
      width:800,
      height:600,
      type:'square' //circle
    },
    boundary:{
      width:'90%',
      height:600
    },
    customClass: 'crop-area',
    showZoomer: true,
    enableResize: false,
    enableOrientation: false,
    mouseWheelZoom: 'ctrl'
    
    });
    
    $('#imgInp').on('change', function(){
    var reader = new FileReader();
    reader.onload = function (event) {
      $image_crop.croppie('bind', {
        url: event.target.result
      }).then(function(){
        console.log('jQuery bind complete');
      });
    }
    reader.readAsDataURL(this.files[0]);
    $('#uploadMainImgModal').modal('show');
    });
    
    $('.crop_image').on('click', function (event) {
        $image_crop.croppie('result', {
          type: 'blob',
          format: 'jpeg',
          //type: 'canvas',
          //size: 'viewport'
          size: {width:800, height: 600}
          }).then(function (response) {
          
            const formData = new FormData();
	        formData.append('file', response,'file.jpg');
            formData.append('hirID', {{$hiID}});
            formData.append('_token', '{{csrf_token()}}');

            $.ajax({
            url: "{{route('Hirek.Feltoltes.Jumbotron')}}",
            data: formData,
            type: 'POST',
            contentType: false,
            processData: false,
            success: function(data) {
                let urlResult =" {{asset('hir/')}}"; urlResult = urlResult + "/" + data;
                $('#jumbotronImg').attr('src',urlResult);
                if (data.fail) {
                   
                    alert(data.errors['file']);
                } 
                
            },
            error: function(xhr, status, error) {
                alert(xhr.responseText);
            }
        });

           
         
    
        
    
          $('#uploadMainImgModal').modal('hide');
    
        });
    
        
    
        return false;
    });
    </script>

<script>
  
  
  $('#imgThumb').on('change', function(){

    $image_crop = $('#image_demo2').croppie({
  enableExif: false,
  viewport: {
    width:310,
    height:390,
    type:'square' //circle
  },
  boundary:{
    width:400,
    height:600
  },
  customClass: 'crop-area',
  showZoomer: true,
  enableResize: false,
  enableOrientation: false,
  mouseWheelZoom: 'ctrl'
  
  });

  var reader = new FileReader();
  reader.onload = function (event) {
    $image_crop.croppie('bind', {
      url: event.target.result
    }).then(function(){
      console.log('jQuery bind complete');
    });
  }
  reader.readAsDataURL(this.files[0]);
  $('#uploadThumbnailModal').modal('show');
  });
  
  $('.crop_image2').on('click', function (event) {
      $image_crop.croppie('result', {
        type: 'blob',
        format: 'jpeg',
        //type: 'canvas',
        //size: 'viewport'
        size: {width:310, height: 390}
        }).then(function (response) {

            const formDataThumb = new FormData();
	        formDataThumb.append('file', response,'file.jpg');
            formDataThumb.append('hirID', {{$hiID}});
            formDataThumb.append('_token', '{{csrf_token()}}');

            $.ajax({
            url: "{{route('Hirek.Feltoltes.Thumbnail')}}",
            data: formDataThumb,
            type: 'POST',
            contentType: false,
            processData: false,
            success: function(data) {
                let urlResult =" {{asset('hir/')}}"; urlResult = urlResult + "/" + data;
                
                $('#thumbnailImg').attr('src',urlResult);
                if (data.fail) {
                   
                    alert(data.errors['file']);
                } 
                
            },
            error: function(xhr, status, error) {
                alert(xhr.responseText);
            }
        });
         
       
  
      
  
        $('#uploadThumbnailModal').modal('hide');
  
      });
  
      
  
      return false;
  });

  </script>
@endsection