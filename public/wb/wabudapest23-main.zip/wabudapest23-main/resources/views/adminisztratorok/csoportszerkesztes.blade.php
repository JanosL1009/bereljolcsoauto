@extends('layouts.admin')

@section('content')
<h1 class="card-title">Csoport szerkesztése</h1>
<div class="row">
    <div class="col-12 d-flex ">
      <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
          {!! $model->breadcrumblink !!}
        </ol>
     </nav>
    </div>

    @if($errors->sikeresmentes->first())
    <div class="col-12 col-md-12 text-center">
    <h4  class="alert alert-success" role="alert">{{$errors->sikeresmentes->first()}}</h4>
    </div>
    @endif

    @if($errors->hibamentes->first())
    <div class="col-12 col-md-12 text-center">
    <h4  class="alert alert-success" role="alert">{{$errors->hibamentes->first()}}</h4>
    </div>
    @endif

    <div class="col-12">
    <form action="{{url('/admin/csoport_szerkesztes_feldolgozo/'.$model->GetCsoportID())}}" method="POST" enctype="multipart/form-data" id="csoport_szerekesztes_feldolgozo" name="csoport_szerekesztes_feldolgozo" class="csoportszerkesztes">
    @csrf
        <div class="card my-3">
            <div class="card-body">
                <div class="form-group">
                    <label>Csoport neve</label>
                    <input type="text" class="form-control" id="csoportNeve" name="csoportNeve" value="{{$model->CsoportNeve}}">
                </div>
                <div class="form-group"><label>Csoport leírása</label>
                    <textarea class="form-control"  id="csoportLeiras" name="csoportLeiras" rows="10" >{{$model->Leiras}}</textarea>
                </div>
                <div class="form-group"><label>Kezdés időpontja</label>
                    <div class="input-group date form_time " data-date="" data-date-format="hh:ii" data-link-field="dtp_input3" data-link-format="hh:ii">
                        <div class="myTime">
                            <input type="text" id="cskezdIdejeDatum" name="cskezdIdejeDatum" value="{{$model->kezdesDatuma}}">
                          <div class="oraperc">
                            <input type="number" id="cskezdIdejeOra" name="cskezdIdejeOra" value="{{$model->Ora($model->kezdesIdeje)}}" class="timeInput TimeHour" min="0" max="23" placeholder="23" data-validation="required">:
                            <input type="number" id="cskezdIdejePerc"  name="cskezdIdejePerc" value="{{$model->Perc($model->kezdesIdeje)}}"  class="timeInput TimeSec" min="0" max="59" placeholder="00" data-validation="required">
                          </div>
                        </div>
                            <span class="input-group-addon"><span class="glyphicon glyphicon-remove"></span></span>
                            <span class="input-group-addon"><span class="glyphicon glyphicon-time"></span></span>
                        </div>
                    </div>
                    <div class="form-group"><label>Befejezés időpontja</label>
                        <div class="input-group date form_time " data-date="" data-date-format="hh:ii" data-link-field="dtp_input3" data-link-format="hh:ii">
                            <div class="myTime">
                                <input type="text" id="csbefIdejeDatum" name="csbefIdejeDatum" value="{{$model->befejezesDatuma}}">
                              <div class="oraperc">
                                <input type="number" id="csbefIdejeOra" name="csbefIdejeOra" value="{{$model->Ora($model->befejezesIdeje)}}" class="timeInput TimeHour" min="0" max="23" placeholder="23" data-validation="required">:
                                <input type="number" id="csbefIdejePerc" name="csbefIdejePerc" value="{{$model->Perc($model->befejezesIdeje)}}" class="timeInput TimeSec" min="0" max="59" placeholder="00" data-validation="required">
                              </div>
                            </div>
                            <div>
                                <span class="input-group-addon"><span class="glyphicon glyphicon-remove"></span></span>
                                <span class="input-group-addon"><span class="glyphicon glyphicon-time"></span></span>
                            </div>
                        </div>
                        <div class="form-group"><label>Tervezett létszám</label>
                            <input type="text" class="form-control" id="cstervLetszam" name="cstervLetszam" value="{{$model->igenyeltOnkentesLetszam}}">
                        </div>
                       
                      </div>

                      <div class="form-group">
                            <div class="form-row rh" id="cshelyszin" data-lastid="1">
                            <div class="form-group col-md-6">
                                <label for="inputPassword4">A csoport helyszíne</label>
                                <input type="text" class="form-control" id="cshelyszin1" name="cshelyszin1" data-id="1" placeholder="Autocomplete mező" data-validation="required" value="{{ $model->helyszin}}">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="InfoMeassageHead">Információ</label><br>
                                <label for="InfoMeassage" style="font-size:10px;">Ha nem találja a listában a megfelelő helyszínt, akkor a Helyszínek menüpont alatt vegye fel!</label>
                            </div>
                            </div>
                        </div>

            </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12 d-flex justify-content-end">
            <input type="submit" class="btn btn-primary" value="Mentés">
        </div>
    </form>


</div>
        <script src="{{ asset('js/jquery.form-validator.min.js') }}"></script>

        <script>
           var myLanguage = {
                errorTitle: 'Az űrlap feldolgozása sikertelen.',
                requiredFields: 'You have not answered all required fields',
                badTime: 'You have not given a correct time',
                badEmail: 'You have not given a correct e-mail address',
                badTelephone: 'You have not given a correct phone number',
                badSecurityAnswer: 'You have not given a correct answer to the security question',
                badDate: 'You have not given a correct date',
                lengthBadStart: 'The input value must be between ',
                lengthBadEnd: ' karakter',
                lengthTooLongStart: 'The input value is longer than ',
                lengthTooShortStart: 'Az input érték nem lehet kevesebb, mint ',
                notConfirmed: 'Input values could not be confirmed',
                badDomain: 'Incorrect domain value',
                badUrl: 'The input value is not a correct URL',
                badCustomVal: 'The input value is incorrect',
                andSpaces: ' and spaces ',
                badInt: 'The input value was not a correct number',
                badSecurityNumber: 'Your social security number was incorrect',
                badUKVatAnswer: 'Incorrect UK VAT Number',
                badStrength: 'The password isn\'t strong enough',
                badNumberOfSelectedOptionsStart: 'You have to choose at least ',
                badNumberOfSelectedOptionsEnd: ' answers',
                badAlphaNumeric: 'The input value can only contain alphanumeric characters ',
                badAlphaNumericExtra: ' and ',
                wrongFileSize: 'The file you are trying to upload is too large (max %s)',
                wrongFileType: 'Only files of type %s is allowed',
                groupCheckedRangeStart: 'Please choose between ',
                groupCheckedTooFewStart: 'Please choose at least ',
                groupCheckedTooManyStart: 'Please choose a maximum of ',
                groupCheckedEnd: ' item(s)',
                badCreditCard: 'The credit card number is not correct',
                badCVV: 'The CVV number was not correct',
                wrongFileDim : 'Incorrect image dimensions,',
                imageTooTall : 'the image can not be taller than',
                imageTooWide : 'the image can not be wider than',
                imageTooSmall : 'the image was too small',
                min : 'min',
                max : 'max',
                imageRatioNotAccepted : 'Image ratio is not accepted'
            };
          $.validate({
            language : myLanguage
          });
        </script>

        <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
        
        <script src="{{asset('js/jquery-ui-1.10.2.js')}}" ></script>

        <script>
            $(document).ready(function(){
                var availableTags = [];
        
                $.ajax({
                       type:'POST',
                       url:'{{url('GetAlHelyszinek')}}',
                       data:{_token:'<?php echo csrf_token() ?>',TeruletID:{{ $model->terulet_id }} },
                       success:function(data) {
                        let i = 0;
                            for(i = 0; i < data.length;i++)
                            {
                                availableTags.push(data[i].nev);
        
                            }
                       }
                    });
                    $( "#cshelyszin1" ).autocomplete({
                    source: availableTags
                });
        
        
            });
        
         </script>
         

<script src="{{asset('js/datetimepicker-bs4.js')}}" type="text/javascript"></script>
<link href="https://unpkg.com/gijgo@1.9.13/css/gijgo.min.css" rel="stylesheet" type="text/css" />

<script>
    $(document).ready(function(){
        $('#cskezdIdejeDatum').datepicker({
            uiLibrary: 'bootstrap4',
            minDate: '{{$teruletKezdesIdeje}}',
            maxDate: '{{$teruletBefejezesIdeje}}'
        });
        $('#csbefIdejeDatum').datepicker({
            uiLibrary: 'bootstrap4',
            minDate: '{{$teruletKezdesIdeje}}',
            maxDate: '{{$teruletBefejezesIdeje}}'
        });
    });

</script>



@endsection
