<style>
    fieldset{all:unset;}
</style>
<div class="col-12 col-md-12">
	<div class="card my-3">
		<div class="card-body">



			<div class="row">
				<div class="col-12 d-flex justify-content-between">
					<h1>Terület beosztása</h1>
				</div>
			</div>
			<div class="container2">


				<div class="row">

					<div class="col-12 col-md-6">
						<div class="card my-3">
							<div class="card-body" style="height:600px;overflow-y:scroll;">

								<div class="form-group">
									<h5>
										Jelentkezők
                                    </h5>
                                    <div class="myBox">

                                        <input id="searchOthers" style="padding: 3px 10px;" type="text" placeholder="Jelentkező keresése.." />

                                    </div>

                                    <div class="myBox">

                                        <select id="searchGroups" style="padding: 3px 10px;" >
                                            <option >--- Elérhető jelige csoportok ---</option>
                                        </select>

										<div class="float-right">
											<button class="btn btn-info  d-none" id="appointment_of_nominees" onclick="sendInput();">Kijelöltek beosztása</button>
										</div>
                                    </div>

									<table class="table table-striped table-hover" id="teruletVezetok">
										<thead>
											<tr>
												<th>
													<span class="custom-checkbox">
														<input type="checkbox" id="selectAll">
														<label for="selectAll"></label>
													</span>
												</th>

												<th>Név</th>
												<th>Műveletek</th>

											</tr>
										</thead>
										<tbody class="addAbleMore"></tbody>
										<tbody style="border-top: 3px solid #333" class="addAble"></tbody>
									</table>
								</div>
							</div>
						</div>
					</div>


					<div class="col-12 col-md-6">
						<div class="card my-3">
							<div class="card-body" style="height:600px;overflow-y:scroll;">

								<div class="form-group">
                                    <h5 >Beosztva</h5>
                                    <p id="GroupCounter" style="text-align: center;"> <span id="actCount">{{$model->BeosztottakSzama}}</span>  / {{$model->tervezettLetszam}} </p>

									<table id="teruletbeosztva" class="table table-striped table-hover">
										<thead>
											<tr>
												<th>
													<span class="custom-checkbox">
														<input type="checkbox" id="selectAll">
														<label for="selectAll"></label>
													</span>
												</th>

												<th>Név</th>
												<th>Műveletek</th>

											</tr>
										</thead>
										<tbody class="added"></tbody>
									</table>
								</div>
							</div>
						</div>
					</div>

				</div>



			</div>
		</div>
	</div>
</div>


<script>
 $(function () { $('[data-toggle="tooltip"]').tooltip() });

	var users = [
		@foreach($users as $user){'id': '{{$user->id}}','name': '{{$user->name}}'},@endforeach
];
	var jelentkezokArray = [@foreach($model->jelentkezokLista as $sz){!! $sz->felhasznalo_id !!}, @endforeach
        @foreach($model->jokerJelentkezoLista as $sz){!! $sz->felhasznalo_id !!}, @endforeach
    ];
     var selectedSzervezokArray = [	@foreach($model->beosztottakListaja as $sz){{$sz->felhasznalo_id}},@endforeach
];

	var renderElements = function(){

		$('.addAble').html(users.map(function(elem) {
			if(
				(jelentkezokArray.includes( parseInt(elem.id) )) && !selectedSzervezokArray.includes(elem.id)
				)
			return `

			<tr id="`+elem.id+`">
				<td>
					<span class="custom-checkbox">
						<input type="checkbox" class="ccbox" id="checkbox`+elem.id+`" name="options[]" value="`+elem.id+`" onchange="inputSelector()">
						<label for="checkbox`+elem.id+`"></label>
					</span>

				</td>
				<td class="username"  >
					<span style="cursor:pointer;" data-toggle="tooltip" onclick="ShowProfile(`+elem.id+`)">`+elem.name+`</span></td>
				<td>
					<i class="material-icons add_box pointer"  data-toggle="tooltip"  data-uid="`+elem.id+`" onclick="UserEventAdd(`+elem.id+`)">add_box</i>
				</td>
			</tr>

			`;
		}));

		$('.added').html(users.map(function(elem) {
			if(selectedSzervezokArray.includes( parseInt(elem.id) ))
			return `

			<tr id="group`+elem.id+`">
				<td>
					<span class="custom-checkbox">
						<input type="checkbox" class="ccbox" id="checkbox`+elem.id+`" name="options[]" value="`+elem.id+`">
						<label for="checkbox`+elem.id+`"></label>
					</span>
				<td class="username"  >
					<span style="cursor:pointer;" data-toggle="tooltip" onclick="ShowProfile(`+elem.id+`)">`+elem.name+`</span></td>
				

				<td>
					<i class="material-icons remove pointer"  data-toggle="tooltip"  data-uid="`+elem.id+`" onclick="UserEventRemove(`+elem.id+`)" title="Eltávolít" >close</i>

				</td>
			</tr>

			`;
		}));


	}

	renderElements();

    /**ezt ki kell szervezni egy js fajlba, mert kismillio helyen kell majd atirni...*/
	$(document).on('keyup', '#searchOthers', function(){
		var searchString = $(this).val();
		if(searchString.length > 2){

			$('.addAbleMore').html(users.map(function(elem) {
				if(
					(elem.name.toLowerCase().includes(searchString.toLowerCase()))
					&& !selectedSzervezokArray.includes(elem.id)
					)
				return `

				<tr id="`+elem.id+`">
					<td>
						<span class="custom-checkbox">
							<input type="checkbox" class="ccbox" id="checkbox`+elem.id+`" name="options[]" value="`+elem.id+`">
							<label for="checkbox`+elem.id+`"></label>
						</span>

					</td>
					<td class="username"  >
					<span style="cursor:pointer;" data-toggle="tooltip" onclick="ShowProfile(`+elem.id+`)">`+elem.name+`</span>
					</td>
				
				
					<td>
						<i class="material-icons add_box pointer"  data-toggle="tooltip"  data-uid="`+elem.id+`" onclick="UserEventAdd(`+elem.id+`)">add_box</i>
					</td>
				</tr>

				`;
			}));

		} else{
			$('.addAbleMore').html('');
		}

	});



    function UserEventAdd(itemid){
    	var terulet_id = {{$model->teruletid}};

        $.ajax({
            type:'POST',
            url:'{{url('TeruletBeosztasa')}}',
            data:{_token: '<?php echo csrf_token() ?>', tid:terulet_id,uid:itemid},
            success:function(data) {
                if (data == 1 )
                            {
                                jelentkezokArray = jelentkezokArray.filter(id => id !== itemid);
                                selectedSzervezokArray.push(itemid);

                                renderElements();jokers(); CounterGrowth();
                            }
							if(data == 2)
							{
								alert("Ez az Önkéntes már be van osztva erre a területre!");
							}
            }
        });
    }

    function UserEventRemove(itemid)
    {

        var terulet_id = {{$model->teruletid}};
        $.ajax({
				type:'POST',
				url:'{{url('TeruletBeosztottEltav')}}',
				data:{_token: '<?php echo csrf_token() ?>', tid: terulet_id ,uid:itemid},
				success:function(data) {
					if (data == 1) {
						selectedSzervezokArray = selectedSzervezokArray.filter(id => id !== itemid);
                        jelentkezokArray.push(itemid);
						renderElements();
                        jokers(); CounterDeacrease();
					}

				}
			});

    }
    function CounterDeacrease()
    {
        let val = document.getElementById('actCount').innerText;
        document.getElementById('actCount').textContent= parseInt(val) - 1;
		
		let areaAssigned =  document.getElementById('areaAssigned').innerText;
		document.getElementById('areaAssigned').textContent = parseInt(areaAssigned) - 1;

		let cbAssignedVols = document.getElementById('cbAssignedVols').innerText;
        document.getElementById('cbAssignedVols').textContent= parseInt(cbAssignedVols) + 1;
    }

    function CounterGrowth()
    {
        let val = document.getElementById('actCount').innerText;
        document.getElementById('actCount').textContent= parseInt(val) + 1;

		let areaAssigned =  document.getElementById('areaAssigned').innerText;
		document.getElementById('areaAssigned').textContent = parseInt(areaAssigned) + 1;

		let cbAssignedVols = document.getElementById('cbAssignedVols').innerText;
        document.getElementById('cbAssignedVols').textContent= parseInt(cbAssignedVols) - 1;
    }


</script>

<script>
    var CsoportosJelentkezok = {!! $CsoportosJelentkezok !!};
    var Jeligek = {!! $JeligeLista !!};
    var searchGroupsSelect = document.getElementById('searchGroups');
    for(let i = 0;i < Jeligek.length;i++)
    {
        let opt = document.createElement('option');
        opt.value = Jeligek[i].id;
        opt.innerHTML = Jeligek[i].jeligeNeve;
        searchGroupsSelect.appendChild(opt);
    }

    document.getElementById("searchGroups").onchange = function() {
        //alert('A kereső fejlesztés alatt!');
        let id = document.getElementById("searchGroups").value;
           
            if(id > 0){
				
				let output = '';
				for(let i =0;i < CsoportosJelentkezok.length ;i++)
				{
					if(CsoportosJelentkezok[i].jeligeID == id )
					{
						let csoportNeve = getJeligeNeve(id);
						for(let j = 0; j < users.length;j++)
						{
							if(CsoportosJelentkezok[i].uid == users[j].id)
							{
								output = output + `<tr id="`+users[j].id+`">
									<td>
										<span class="custom-checkbox">
											<input type="checkbox" class="ccbox" id="checkbox`+users[j].id+`" name="options[]" value="`+users[j].id+`">
											<label for="checkbox`+users[j].id+`"></label>
										</span>

									</td>
									<td class="username"  >
					<span style="cursor:pointer;" data-toggle="tooltip" onclick="ShowProfile(`+users[j].id+`)">`+users[j].name+`</span>
					</td>

									<td>
										<i class="material-icons add_box pointer"  data-toggle="tooltip"  data-uid="`+users[j].id+`" onclick="UserEventAdd(`+users[j].id+`)">add_box</i>
									</td>
								</tr>`;
								
							}
							
						}
						
					} 
				}
				$('.addAbleMore').html(output);

				} else{
				$('.addAbleMore').html('');
				} //ifend

        };

		function getJeligeNeve(id){
			let nev = 0;
				for(let i = 0; i < Jeligek.length; i++ )
				{
					if(Jeligek[i].id == id)
					{
						nev = Jeligek[i].jeligeNeve;
					} 
				}

				return nev;
			}

</script>

@include('assets.beosztasRovidProfile')

