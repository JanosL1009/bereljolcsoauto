@extends('layouts.admin')

@section('content')
<style>

    .hint-text {
        float: left;
        margin-top: 10px;
        font-size: 13px;
    }

    .autocomplete {
  /*the container must be positioned relative:*/
  position: relative;
  display: inline-block;
}
input {
  border: 1px solid transparent;
  background-color: #f1f1f1;
  padding: 10px;
  font-size: 16px;
}
input[type=text] {
  background-color: #f1f1f1;
  width: 100%;
}

.autocomplete-items {
  position: absolute;
  border: 1px solid #d4d4d4;
  border-bottom: none;
  border-top: none;
  z-index: 99;
  /*position the autocomplete items to be the same width as the container:*/
  top: 100%;
  left: 0;
  right: 0;
}
.autocomplete-items div {
  padding: 10px;
  cursor: pointer;
  background-color: #fff;
  border-bottom: 1px solid #d4d4d4;
}
.autocomplete-items div:hover {
  /*when hovering an item:*/
  background-color: #e9e9e9;
}
.autocomplete-active {
  /*when navigating through the items using the arrow keys:*/
  background-color: DodgerBlue !important;
  color: #ffffff;
}
</style>
        <div class="row">
                <div class="col-12 d-flex justify-content-between">
                    <h1>Egyházmegyék szerkesztése</h1>
                </div>
                @if($errors->any())
                <div class="col-12 text-center">
                    <h4  class="alert alert-success" role="alert">Sikeresen módosította az egyházmegyét!</h4>
                </div>
                @endif
                <div class="col-12 col-md-12">

                    <div class="card">
                        <div class="card-body">
                            <h4>Új egyházmegye felvétele</h4>
                            <form class="form" action="{{url('/admin/altalanosbeallitasok/egyhazmegyek/uj_felvetel')}}" method="post">
                                @csrf
                                <div class="form-group">
                                    <label for="Név">Egyhézmegye elnevezése</label>
                                    <input type="text" id="egyhazMegye" name="egyhazMegye" class="form-control">
                                   </div>
                                <div class="form-group">
                                    <div class="autocomplete" style="width:300px;">
                                        <input id="myInput" type="text" name="felekezet" id="felekezet" placeholder="Felekezet" class="form-control">
                                    </div>
                                 </div>
                                <div class="form-group">
                                   <input type="submit" class="btn btn-primary" id="egyhazSbmBtn" value="Felvétel">
                                </div>
                            </form>
                        </div>
                    </div>

                </div>
        </div>


        <div class="card my-3">
                <div class="card-body">
                <div class="table-wrapper">



                    <table class="table table-striped table-hover" id="egyhazmegyekListaja">
                        <thead>
                            <tr>

                                <th>Név
                                  <a href="{{url('/admin/altalanosbeallitasok/egyhazmegyek/nev/asc')}}" class="szuro">
                                    <span class="material-icons">expand_less</span>
                                  </a>
                                  <a href="{{url('/admin/altalanosbeallitasok/egyhazmegyek/nev/desc')}}" class="szuro">
                                    <span class="material-icons">expand_more</span>
                                  </a>
                                </th>

                                <th>Felekezet
                                     <a href="{{url('/admin/altalanosbeallitasok/egyhazmegyek/felekezet/asc')}}" class="szuro">
                                      <span class="material-icons">expand_less</span>
                                    </a>
                                    <a href="{{url('/admin/altalanosbeallitasok/egyhazmegyek/felekezet/desc')}}" class="szuro">
                                      <span class="material-icons">expand_more</span>
                                    </a>
                                  </th>

                                <th>Létrehozva
                                </th>

                                <th>Műveletek</th>
                            </tr>
                        </thead>
                        <tbody>

                            @foreach($egyhazmegyek as $egyhazmegye)
                            <tr data-eid="{{$egyhazmegye->id}}">

                                <td data-label="Név">{{$egyhazmegye->nev}}</td>

                                <td data-label="Felekezet">{{$egyhazmegye->felekezet}}</td>

                                <td data-label="Létrehozva">{{$egyhazmegye->created_at}}</td>

                                <td data-label="Műveletek">
                                    <a href="#modifyEgyhazModal" class="edit modifyModal" data-emid="{{$egyhazmegye->id}}"  data-toggle="modal"><i class="material-icons" data-toggle="tooltip" title="Módosítás">&#xE254;</i></a><!-- ezt paraméteresíteni! -->
                                    <a href="#deleteEgyhazModal" class="delete" data-toggle="modal"><i class="material-icons deltool" data-toggle="tooltip" title="Törlés" data-valesid="{{$egyhazmegye->id}}">&#xE872;</i></a>

                                </td>
                            </tr>
                            @endforeach


                        </tbody>
                    </table>





                    <div class="clearfix float-left">
                        {{ $egyhazmegyek->links() }}
                    </div>
                </div>
            </div>
        </div>


            <!-- Delete Modal HTML -->
            <div id="deleteEgyhazModal" class="modal fade">
                <div class="modal-dialog">
                    <div class="modal-content">

                            <div class="modal-header">
                                <h4 class="modal-title">Egyházmegye törlése</h4>
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                            </div>
                            <div class="modal-body">
                                <p>Biztosan törölni szeretné, ezt az egyházmegyét?</p>
                                <p style="color: #ff0000;" >Ha törli a egyházmegyét, később az adatokat nem tudjuk visszaállítani!</p>
                            </div>
                            <div class="modal-footer">
                                <input type="number" class="d-none" id="esid" name="esid" value="-1">
                                <input type="button" class="btn btn-default" data-dismiss="modal" value="Mégse">
                                <input type="button" id="esemenyTorlesBtn" class="btn btn-danger" value="Törlés">
                            </div>

                    </div>
                </div>
            </div>

            <div id="modifyEgyhazModal" class="modal fade">
                <div class="modal-dialog">
                    <div class="modal-content">

                            <div class="modal-header">
                                <h4 class="modal-title">Egyházmegye módosítása</h4>
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                            </div>
                            <div class="modal-body">
                                <form class="form" action="{{route('egyhazmegye.modositas')}}" method="post">
                                    @csrf
                                    <div class="form-group">
                                        <label for="Név">Egyhézmegye elnevezése</label>
                                        <input type="text" id="modifyegyhazMegye" name="modifyegyhazMegye" class="form-control">
                                       </div>
                                    <div class="form-group">
                                        <div class="autocomplete" style="width:300px;">
                                            <input id="modifyFelekezet" type="text" name="mfelekezet" id="mfelekezet" placeholder="Felekezet" disabled>
                                        </div>
                                     </div>
                                    <div class="form-group d-flex">
                                        <input type="hidden" id="emid" name="emid" value="-1">
                                       <input type="submit" class="btn btn-primary" id="egyhazModifySbmBtn" value="Módosítás">
                                       <input type="button" class="btn btn-danger" data-dismiss="modal" value="Mégse">
                                    </div>
                                </form>

                            </div>


                    </div>
                </div>
            </div>




            <script>
                $(document).ready(function(){

                        $('.deltool').click(function(){
                            let v = $(this).data('valesid'); $('#esid').val(v);
                        });

                        $('#deleteEgyhazModal').click(function(){
                            let omrr = $('#esid').val();

                            $.ajax({
                                    type:'POST',
                                    url:'{{url('/admin/altalanosbeallitasok/egyhazmegye/torles')}}',
                                    data:{_token:'<?php echo csrf_token() ?>', nyid:omrr },
                                    success:function(data) {
                                        if(data == 1) {location.reload();}
                                    }
                                });
                        });

                });


            </script>


@endsection

@section('scriptsection')

<script src="{{ asset('js/jquery.form-validator.min.js') }}"></script>
<script>
    var myLanguage = {

         errorTitle: 'Az űrlap feldolgozása sikertelen.',
         requiredFields: 'You have not answered all required fields',
         badTime: 'You have not given a correct time',
         badEmail: 'You have not given a correct e-mail address',
         badTelephone: 'You have not given a correct phone number',
         badSecurityAnswer: 'You have not given a correct answer to the security question',
         badDate: 'You have not given a correct date',
         lengthBadStart: 'The input value must be between ',
         lengthBadEnd: ' karakter',
         lengthTooLongStart: 'The input value is longer than ',
         lengthTooShortStart: 'Az input érték nem lehet kevesebb, mint ',
         notConfirmed: 'Input values could not be confirmed',
         badDomain: 'Incorrect domain value',
         badUrl: 'The input value is not a correct URL',
         badCustomVal: 'The input value is incorrect',
         andSpaces: ' and spaces ',
         badInt: 'The input value was not a correct number',
         badSecurityNumber: 'Your social security number was incorrect',
         badUKVatAnswer: 'Incorrect UK VAT Number',
         badStrength: 'The password isn\'t strong enough',
         badNumberOfSelectedOptionsStart: 'You have to choose at least ',
         badNumberOfSelectedOptionsEnd: ' answers',
         badAlphaNumeric: 'The input value can only contain alphanumeric characters ',
         badAlphaNumericExtra: ' and ',
         wrongFileSize: 'The file you are trying to upload is too large (max %s)',
         wrongFileType: 'Only files of type %s is allowed',
         groupCheckedRangeStart: 'Please choose between ',
         groupCheckedTooFewStart: 'Please choose at least ',
         groupCheckedTooManyStart: 'Please choose a maximum of ',
         groupCheckedEnd: ' item(s)',
         badCreditCard: 'The credit card number is not correct',
         badCVV: 'The CVV number was not correct',
         wrongFileDim : 'Incorrect image dimensions,',
         imageTooTall : 'the image can not be taller than',
         imageTooWide : 'the image can not be wider than',
         imageTooSmall : 'the image was too small',
         min : 'min',
         max : 'max',
         imageRatioNotAccepted : 'Image ratio is not accepted'
     };

   $.validate({
     language : myLanguage
   });

   function autocomplete(inp, arr) {
  /*the autocomplete function takes two arguments,
  the text field element and an array of possible autocompleted values:*/
  var currentFocus;
  /*execute a function when someone writes in the text field:*/
  inp.addEventListener("input", function(e) {
      var a, b, i, val = this.value;
      /*close any already open lists of autocompleted values*/
      closeAllLists();
      if (!val) { return false;}
      currentFocus = -1;
      /*create a DIV element that will contain the items (values):*/
      a = document.createElement("DIV");
      a.setAttribute("id", this.id + "autocomplete-list");
      a.setAttribute("class", "autocomplete-items");
      /*append the DIV element as a child of the autocomplete container:*/
      this.parentNode.appendChild(a);
      /*for each item in the array...*/
      for (i = 0; i < arr.length; i++) {
        /*check if the item starts with the same letters as the text field value:*/
        if (arr[i].substr(0, val.length).toUpperCase() == val.toUpperCase()) {
          /*create a DIV element for each matching element:*/
          b = document.createElement("DIV");
          /*make the matching letters bold:*/
          b.innerHTML = "<strong>" + arr[i].substr(0, val.length) + "</strong>";
          b.innerHTML += arr[i].substr(val.length);
          /*insert a input field that will hold the current array item's value:*/
          b.innerHTML += "<input type='hidden' value='" + arr[i] + "'>";
          /*execute a function when someone clicks on the item value (DIV element):*/
              b.addEventListener("click", function(e) {
              /*insert the value for the autocomplete text field:*/
              inp.value = this.getElementsByTagName("input")[0].value;
              /*close the list of autocompleted values,
              (or any other open lists of autocompleted values:*/
              closeAllLists();
          });
          a.appendChild(b);
        }
      }
  });
  /*execute a function presses a key on the keyboard:*/
  inp.addEventListener("keydown", function(e) {
      var x = document.getElementById(this.id + "autocomplete-list");
      if (x) x = x.getElementsByTagName("div");
      if (e.keyCode == 40) {
        /*If the arrow DOWN key is pressed,
        increase the currentFocus variable:*/
        currentFocus++;
        /*and and make the current item more visible:*/
        addActive(x);
      } else if (e.keyCode == 38) { //up
        /*If the arrow UP key is pressed,
        decrease the currentFocus variable:*/
        currentFocus--;
        /*and and make the current item more visible:*/
        addActive(x);
      } else if (e.keyCode == 13) {
        /*If the ENTER key is pressed, prevent the form from being submitted,*/
        e.preventDefault();
        if (currentFocus > -1) {
          /*and simulate a click on the "active" item:*/
          if (x) x[currentFocus].click();
        }
      }
  });
  function addActive(x) {
    /*a function to classify an item as "active":*/
    if (!x) return false;
    /*start by removing the "active" class on all items:*/
    removeActive(x);
    if (currentFocus >= x.length) currentFocus = 0;
    if (currentFocus < 0) currentFocus = (x.length - 1);
    /*add class "autocomplete-active":*/
    x[currentFocus].classList.add("autocomplete-active");
  }
  function removeActive(x) {
    /*a function to remove the "active" class from all autocomplete items:*/
    for (var i = 0; i < x.length; i++) {
      x[i].classList.remove("autocomplete-active");
    }
  }
  function closeAllLists(elmnt) {
    /*close all autocomplete lists in the document,
    except the one passed as an argument:*/
    var x = document.getElementsByClassName("autocomplete-items");
    for (var i = 0; i < x.length; i++) {
      if (elmnt != x[i] && elmnt != inp) {
      x[i].parentNode.removeChild(x[i]);
    }
  }
}
/*execute a function when someone clicks in the document:*/
document.addEventListener("click", function (e) {
    closeAllLists(e.target);
});
}


/*An array containing all the country names in the world:*/
var felekeztek = [
    @php
        $egyhazmegyek_groups = $egyhazmegyek->groupBy(function($item){
            return $item->felekezet;
        });
        $groups = $egyhazmegyek_groups->keys()->all();

    @endphp
        @foreach($groups as $felekezet)
            '{{ $felekezet }}',
        @endforeach
 ];
autocomplete(document.getElementById("myInput"), felekeztek);
autocomplete(document.getElementById("modifyEgyhazMegye"), felekeztek);
 </script>

 <script>
     $('.modifyModal').click(function(){
        let emid = $(this).data('emid');
        $('#emid').val(emid);
        let TDParent = this.parentElement;
        let MainParent = TDParent.parentElement;
        let Elements = MainParent.elements;
        console.log(MainParent.firstElementChild.innerText);
        $('#modifyegyhazMegye').val(MainParent.firstElementChild.innerText); //text!!
        $('#modifyFelekezet').val(MainParent.children[1].innerHTML);

     });
 </script>
@endsection
