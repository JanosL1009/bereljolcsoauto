@extends('layouts.admin')

@section('content')
<style>

    .hint-text {
        float: left;
        margin-top: 10px;
        font-size: 13px;
    }
</style>
  <div class="row">
      <div class="col-12 d-flex justify-content-between">
        <h1 class="col-12">Magyarázó szöveg szerkesztése</h1>

      </div>
      <div class="col-12 d-flex justify-content-between">

        <h3>{{ $pageInfo->oldal_menu_nev }} - oldal</h3>
      </div>

<!--
      <div class="col-12 d-flex justify-content-between">
            <a class="btn btn-primary"> vissza gomb lesz</a>
      </div> -->

      <div class="col-12">
        <div class="card my-12">
          <div class="card-body">
            <div class="table-wrapper">
              <form action="{{ url('/admin/altalanosbeallitasok/magyarazoszoveg/feldolgozo') }}" method="post" enctype="multipart/form-data">
                  <div class="form-group">
                      @csrf
                      <input type="hidden" id="MmID" name="MmID" value="{{ $pageInfo->id}}" >
                      <textarea class="form-control" id="Msg" name="Msg" data-validation="required">
                          {!! $pageInfo->leiras !!}
                      </textarea>
                  </div>
                  <div class="form-group">
                    <input type="submit" class="btn btn-primary" value="Mentés" />
                  </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>

@endsection

@section('scriptsection')


<script src="//cdn.ckeditor.com/4.14.0/standard/ckeditor.js" rel="dns-prefetch"></script>
<script src="{{asset('js/ckeditor/filebrowser/plugin.js')}}"></script>
<script src="{{asset('ckeditor/colorbutton')}}"></script>
<!-- ckfinder kell -->
<script>

        CKEDITOR.replace( 'Msg',{
            filebrowserBrowseUrl: '{{url('ckfinder/ckfinder.html')}}',
	        filebrowserUploadUrl: '{{url('ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files')}}'
        });

        CKEDITOR.Msg = function( config ) {
            config.uiColor = '#AADC6E';
            config.extraPlugins = 'colorbutton';
        };

</script>
@endsection
