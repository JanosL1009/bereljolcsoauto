@extends('layouts.admin')


@section('content')
        @if($errors->sikertelenmentes->first())
         <div class="row">
                <div class="col-12">
                    <div class="alert alert-danger" role="alert">
                        <h4  class="alert alert-danger" role="alert">{{$errors->sikertelenmentes->first()}}</h4>
                    </div>
                </div>
         </div>
        @endif

         @if($errors->sikeresmentes->first())
         <div class="row">
                <div class="col-12">
                    <div class="alert alert-success" role="alert">
                        <h4  class="alert alert-success" role="alert">{{$errors->sikeresmentes->first()}}</h4>
                    </div>
                </div>
         </div>
        @endif

       <div class="row">
             <div class="col-12 d-flex justify-content-between">
                        <h1>Profilkép moderációs email üzenet szerkesztése</h1>
              </div>
       </div>

        <div class="row">
            <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <form action="{{route('PostProfilkepModeraciosMail.Inv')}}" method="post">
                            @csrf
                                <div class="form-group">
                                    <label>Tárgy</label>
                                    <input type="text" class="form-control" id="subject" name="subject"  value="{{$msg->sm_name}}"/>
                                </div>
                                <div class="form-group">
                                    <label>Leírás</label>
                                    <textarea class="form-control" name="emailContent" id="emailContent"  style="visibility: hidden; display: none;">{!!$msg->tartalom!!}</textarea>
                                </div>
                                <div class="form-group">
                                     <input type="submit" class="btn btn-primary" value="Módosítás">
                                 </div>
                            </form>
                        </div>
                    </div> 
              </div>
        </div>

    <script src="https://cdn.ckeditor.com/4.13.1/basic/ckeditor.js"></script>

 <script>
         CKEDITOR.replace( 'emailContent' );
 </script>
@endsection