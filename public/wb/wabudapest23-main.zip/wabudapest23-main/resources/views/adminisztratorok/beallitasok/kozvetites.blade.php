@extends('layouts.admin')

@section('content')

<div class="row">
    <div class="col-12">
            <h1>Élő közvetítés - Youtube API beállítása</h1>
    </div>
    
</div>

<div class="row">
    <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <table class="table">
                  
                        <thead>
                          <tr>
                            
                            <th scope="col">Funkció</th>
                            <th scope="col">Művelet</th>
                          </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Menüpont aktiválása az Önkéntesek előtt</td>
                                <td>Engedélyezés</td>
                            </tr>
                            <tr>
                                <td>Csatorna azonosító módosítása (Jelenlegi azonosító: 1232)</td>
                                <td>Módosít</td>
                            </tr>
                        </tbody>
                      </table>
                </div>

            </div>
    </div>
    
</div>


@endsection