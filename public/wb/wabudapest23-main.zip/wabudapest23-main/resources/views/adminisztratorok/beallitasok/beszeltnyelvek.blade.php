@extends('layouts.admin')

@section('content')
<style>

    .hint-text {
        float: left;
        margin-top: 10px;
        font-size: 13px;
    }
</style>
        <div class="row">
                <div class="col-12 d-flex justify-content-between">
                        <h1>Beszélt nyelvek</h1>
                </div>
                <div class="col-3 d-flex justify-content-end">
                  <a href="#UjNyelv" class="btn btn-primary" data-toggle="modal">+ Új nyelv felvétele</a>
                </div>
        </div>


        <div class="card my-3">
                <div class="card-body">
                <div class="table-wrapper">



                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>
                                    <span class="custom-checkbox">
                                        <input type="checkbox" id="selectAll">
                                        <label for="selectAll"></label>
                                    </span>
                                </th>
                                <th>Nyelv neve
                                  <a href="{{url('admin/altalanosbeallitasok/beszeltnyelvek/nev/asc')}}" class="szuro">
                                    <span class="material-icons">expand_less</span>
                                  </a>
                                  <a href="{{url('admin/altalanosbeallitasok/beszeltnyelvek/nev/desc')}}" class="szuro">
                                    <span class="material-icons">expand_more</span>
                                  </a>
                                </th>
                            <!--    <th>Helyszín</th> -->
                                <th>Nyelv rövid jelzése
                                  <a href="{{url('admin/altalanosbeallitasok/beszeltnyelvek/rovidnev/asc')}}" class="szuro">
                                    <span class="material-icons">expand_less</span>
                                  </a>
                                  <a href="{{url('admin/altalanosbeallitasok/beszeltnyelvek/rovidnev/desc')}}" class="szuro">
                                    <span class="material-icons">expand_more</span>
                                  </a>
                                </th>

                                <th>Műveletek</th>
                            </tr>
                        </thead>
                        <tbody>

                            @foreach($nyelvek as $nyelv)
                            <tr data-eid="{{$nyelv->id}}">
                                <td>
                                    <span class="custom-checkbox">
                                        <input type="checkbox" id="checkbox1" name="options[]" value="1">
                                        <label for="checkbox1"></label>
                                    </span>
                                </td>
                                <td data-label="Nyelv neve">{{$nyelv->nyelvNeve}}</td>

                                <td data-label="Nyelv rövid jelzése">{{$nyelv->nyelvRovidJelzese}}</td>

                                <td data-label="Műveletek">
                                    <a href="" class="edit" ><i class="material-icons" data-toggle="tooltip" title="Módosítás">&#xE254;</i></a><!-- ezt paraméteresíteni! -->
                                    <a href="#deleteEmployeeModal" class="delete" data-toggle="modal"><i class="material-icons deltool" data-toggle="tooltip" title="Törlés" data-valesid="{{$nyelv->id}}">&#xE872;</i></a>

                                </td>
                            </tr>
                            @endforeach


                        </tbody>
                    </table>





                    <div class="clearfix float-left">
                            {{ $nyelvek->links() }}
                    </div>
                </div>
            </div>
        </div>


            <!-- Delete Modal HTML -->
            <div id="deleteEmployeeModal" class="modal fade">
                <div class="modal-dialog">
                    <div class="modal-content">

                            <div class="modal-header">
                                <h4 class="modal-title">Nyelv törlése</h4>
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                            </div>
                            <div class="modal-body">
                                <p>Biztosan törölni szeretné, ezt a nyelvet?</p>
                                <p style="color: #ff0000;" >Ha törli a nyelvet, később az adatokat nem tudjuk visszaállítani!</p>
                            </div>
                            <div class="modal-footer">
                                <input type="number" class="d-none" id="esid" name="esid" value="-1">
                                <input type="button" class="btn btn-default" data-dismiss="modal" value="Mégse">
                                <input type="button" id="esemenyTorlesBtn" class="btn btn-danger" value="Törlés">
                            </div>

                    </div>
                </div>
            </div>

            <div id="UjNyelv" class="modal fade">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <form method="post" action="{{url('/admin/altalanosbeallitasok/beszeltnyelvek')}}" id="UjNyelvFelveteleForm" name="UjNyelvFelveteleForm">
                            <div class="modal-header">
                                @csrf
                                <h4 class="modal-title">Új nyelv hozzáadása</h4>
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                            </div>
                            <div class="modal-body">
                                <div class="form-group">
                                    <label for="">Az új nyelv teljes elnevezése</label>
                                    <input type="text" class="form-control" id="NewLangName" name="NewLangName" data-validation="required">
                                </div>
                                <div class="form-group">
                                    <label for="">Az új nyelv rövid elnevezése (max. 5 karakter lehet)</label>
                                    <input type="text" class="form-control" id="NewShortLangName" name="NewShortLangName" data-validation="required">
                                </div>
                             </div>
                            <div class="modal-footer">
                                <input type="button" class="btn btn-default" data-dismiss="modal" value="Mégse">
                                <input type="submit" id="nyelvHozzaadasa" class="btn btn-danger" value="Létrehozás">
                            </div>
                        </form>
                    </div>
                </div>
            </div>


            <script type="text/javascript">
                $(document).ready(function(){

                    $('.deltool').click(function(){
                        let v = $(this).data('valesid'); $('#esid').val(v);
                    });

                    $('#esemenyTorlesBtn').click(function(){
                        let omrr = $('#esid').val(); console.log(omrr);
                        $.ajax({
                                type:'POST',
                                url:'{{url('BeszeltNyelvDelete')}}',
                                data:{_token:'<?php echo csrf_token() ?>', nyid:omrr },
                                success:function(data) {
                                    if(data == 1) {location.reload();}
                                }
                            });
                    });


                    // Activate tooltip
                    $('[data-toggle="tooltip"]').tooltip();

                    // Select/Deselect checkboxes
                    var checkbox = $('table tbody input[type="checkbox"]');
                    $("#selectAll").click(function(){
                        if(this.checked){
                            checkbox.each(function(){
                                this.checked = true;
                            });
                        } else{
                            checkbox.each(function(){
                                this.checked = false;
                            });
                        }
                    });
                    checkbox.click(function(){
                        if(!this.checked){
                            $("#selectAll").prop("checked", false);
                        }
                    });
                });


                </script>

@endsection

@section('scriptsection')
<script src="{{ asset('js/jquery.form-validator.min.js') }}"></script>
<script>
    var myLanguage = {

         errorTitle: 'Az űrlap feldolgozása sikertelen.',
         requiredFields: 'You have not answered all required fields',
         badTime: 'You have not given a correct time',
         badEmail: 'You have not given a correct e-mail address',
         badTelephone: 'You have not given a correct phone number',
         badSecurityAnswer: 'You have not given a correct answer to the security question',
         badDate: 'You have not given a correct date',
         lengthBadStart: 'The input value must be between ',
         lengthBadEnd: ' karakter',
         lengthTooLongStart: 'The input value is longer than ',
         lengthTooShortStart: 'Az input érték nem lehet kevesebb, mint ',
         notConfirmed: 'Input values could not be confirmed',
         badDomain: 'Incorrect domain value',
         badUrl: 'The input value is not a correct URL',
         badCustomVal: 'The input value is incorrect',
         andSpaces: ' and spaces ',
         badInt: 'The input value was not a correct number',
         badSecurityNumber: 'Your social security number was incorrect',
         badUKVatAnswer: 'Incorrect UK VAT Number',
         badStrength: 'The password isn\'t strong enough',
         badNumberOfSelectedOptionsStart: 'You have to choose at least ',
         badNumberOfSelectedOptionsEnd: ' answers',
         badAlphaNumeric: 'The input value can only contain alphanumeric characters ',
         badAlphaNumericExtra: ' and ',
         wrongFileSize: 'The file you are trying to upload is too large (max %s)',
         wrongFileType: 'Only files of type %s is allowed',
         groupCheckedRangeStart: 'Please choose between ',
         groupCheckedTooFewStart: 'Please choose at least ',
         groupCheckedTooManyStart: 'Please choose a maximum of ',
         groupCheckedEnd: ' item(s)',
         badCreditCard: 'The credit card number is not correct',
         badCVV: 'The CVV number was not correct',
         wrongFileDim : 'Incorrect image dimensions,',
         imageTooTall : 'the image can not be taller than',
         imageTooWide : 'the image can not be wider than',
         imageTooSmall : 'the image was too small',
         min : 'min',
         max : 'max',
         imageRatioNotAccepted : 'Image ratio is not accepted'
     };

   $.validate({
     language : myLanguage
   });
 </script>
@endsection
