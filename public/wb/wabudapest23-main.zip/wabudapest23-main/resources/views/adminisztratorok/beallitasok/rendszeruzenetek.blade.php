@extends('layouts.admin')

@section('content')
<style>

    .hint-text {
        float: left;
        margin-top: 10px;
        font-size: 13px;
    }
</style>
        <div class="row">
                <div class="col-12 d-flex justify-content-between">
                        <h1>Rendszer üzenetek</h1>
                </div>

        </div>


        <div class="card my-3">
                <div class="card-body">
                <div class="table-wrapper">



                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>

                                <th><a href="{{url('admin/altalanosbeallitasok/rendszeruzenetek')}}">Rendszerüzenet neve</a>
                                  <a href="{{url('admin/altalanosbeallitasok/rendszeruzenetek/name/asc')}}" class="szuro">
                                    <span class="material-icons">expand_less</span>
                                  </a>
                                  <a href="{{url('admin/altalanosbeallitasok/rendszeruzenetek/name/desc')}}" class="szuro">
                                    <span class="material-icons">expand_more</span>
                                  </a>
                                </th>


                                <th>Műveletek</th>
                            </tr>
                        </thead>
                        <tbody>

                            @foreach($systemMails as $mailsName)
                            <tr>
                                <td data-label="Rendszerüzenet neve">{{$mailsName->sm_name}}</td>
                                 <td data-label="Műveletek">
                                    <a href="{{url('/admin/altalanosbeallitasok/rendszeruzenet/szerkesztes/'.$mailsName->id)}}" target="_blank" class="edit" ><i class="material-icons" data-toggle="tooltip" title="Módosítás">&#xE254;</i></a><!-- ezt paraméteresíteni! -->
                                </td>
                            </tr>
                            @endforeach


                        </tbody>
                    </table>





                    <div class="clearfix float-left">

                    </div>
                </div>
            </div>
        </div>

            <script type="text/javascript">
                $(document).ready(function(){

                    // Select/Deselect checkboxes
                    var checkbox = $('table tbody input[type="checkbox"]');
                    $("#selectAll").click(function(){
                        if(this.checked){
                            checkbox.each(function(){
                                this.checked = true;
                            });
                        } else{
                            checkbox.each(function(){
                                this.checked = false;
                            });
                        }
                    });
                    checkbox.click(function(){
                        if(!this.checked){
                            $("#selectAll").prop("checked", false);
                        }
                    });
                });


                </script>

@endsection

@section('scriptsection')

@endsection
