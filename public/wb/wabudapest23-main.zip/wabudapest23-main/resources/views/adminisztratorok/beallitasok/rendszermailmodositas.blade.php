@extends('layouts.admin')

@section('content')
<style>

    .hint-text {
        float: left;
        margin-top: 10px;
        font-size: 13px;
    }
</style>
        <div class="row">
                <div class="col-12 d-flex justify-content-between">
                        <h1>Rendszer üzenet szerkesztése - cim2</h1>
                </div>

        </div>


        <div class="card my-3">
                <div class="card-body">
                <div class="table-wrapper">
                <form action="{{url('admin/altalanosbeallitasok/rendszeruzenet/modifier')}}" method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        @csrf
                        <input type="hidden" id="MmID" name="MmID" value="{{$systemMessage->id}}" >
                        <textarea class="form-control" name="MailMsg" data-validation="required">
                            {!! $systemMessage->tartalom !!}
                        </textarea>
                    </div>
                    <div class="form-group">
                        <input type="submit" class="btn btn-primary" value="Mentés" />
                    </div>

                </form>
                </div>
            </div>
        </div>

@endsection

@section('scriptsection')


<script src="//cdn.ckeditor.com/4.14.0/standard/ckeditor.js" rel="dns-prefetch"></script>
<script src="{{asset('js/ckeditor/filebrowser/plugin.js')}}"></script>
<script src="{{asset('ckeditor/colorbutton')}}"></script>
<!-- ckfinder kell -->
<script>

        CKEDITOR.replace( 'MailMsg',{
            filebrowserBrowseUrl: '{{url('ckfinder/ckfinder.html')}}',
	        filebrowserUploadUrl: '{{url('ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files')}}'
        });

        CKEDITOR.MailMsg = function( config ) {
            config.uiColor = '#AADC6E';
            config.extraPlugins = 'colorbutton';

        };

</script>

<script src="{{ asset('js/jquery.form-validator.min.js') }}"></script>
<script>
    var myLanguage = {

         errorTitle: 'Az űrlap feldolgozása sikertelen.',
         requiredFields: 'You have not answered all required fields',
         badTime: 'You have not given a correct time',
         badEmail: 'You have not given a correct e-mail address',
         badTelephone: 'You have not given a correct phone number',
         badSecurityAnswer: 'You have not given a correct answer to the security question',
         badDate: 'You have not given a correct date',
         lengthBadStart: 'The input value must be between ',
         lengthBadEnd: ' karakter',
         lengthTooLongStart: 'The input value is longer than ',
         lengthTooShortStart: 'Az input érték nem lehet kevesebb, mint ',
         notConfirmed: 'Input values could not be confirmed',
         badDomain: 'Incorrect domain value',
         badUrl: 'The input value is not a correct URL',
         badCustomVal: 'The input value is incorrect',
         andSpaces: ' and spaces ',
         badInt: 'The input value was not a correct number',
         badSecurityNumber: 'Your social security number was incorrect',
         badUKVatAnswer: 'Incorrect UK VAT Number',
         badStrength: 'The password isn\'t strong enough',
         badNumberOfSelectedOptionsStart: 'You have to choose at least ',
         badNumberOfSelectedOptionsEnd: ' answers',
         badAlphaNumeric: 'The input value can only contain alphanumeric characters ',
         badAlphaNumericExtra: ' and ',
         wrongFileSize: 'The file you are trying to upload is too large (max %s)',
         wrongFileType: 'Only files of type %s is allowed',
         groupCheckedRangeStart: 'Please choose between ',
         groupCheckedTooFewStart: 'Please choose at least ',
         groupCheckedTooManyStart: 'Please choose a maximum of ',
         groupCheckedEnd: ' item(s)',
         badCreditCard: 'The credit card number is not correct',
         badCVV: 'The CVV number was not correct',
         wrongFileDim : 'Incorrect image dimensions,',
         imageTooTall : 'the image can not be taller than',
         imageTooWide : 'the image can not be wider than',
         imageTooSmall : 'the image was too small',
         min : 'min',
         max : 'max',
         imageRatioNotAccepted : 'Image ratio is not accepted'
     };

   $.validate({
     language : myLanguage
   });
 </script>
@endsection
