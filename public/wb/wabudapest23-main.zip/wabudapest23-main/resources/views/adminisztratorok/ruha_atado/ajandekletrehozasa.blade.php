@extends('layouts.admin')


@section('content')
<style>
    .delete{  color: #F44336; } .edit{ color: #FFC107; } .subject{color: #0000FF;} .pointer{cursor: pointer;}
    /* Custom checkbox */
	.custom-checkbox {
		position: relative;
	}
    .pagination {
        float: right;
        margin: 0 0 5px;
    }
    .pagination li a {
        border: none;
        font-size: 13px;
        min-width: 30px;
        min-height: 30px;
        color: #999;
        margin: 0 2px;
        line-height: 30px;
        border-radius: 2px !important;
        text-align: center;
        padding: 0 6px;
    }
    .pagination li a:hover {
        color: #666;
    }
    .pagination li.active a, .pagination li.active a.page-link {
        background: #03A9F4;
    }
    .pagination li.active a:hover {
        background: #0397d6;
    }
	.pagination li.disabled i {
        color: #ccc;
    }
    .pagination li i {
        font-size: 16px;
        padding-top: 6px
    }
    .hint-text {
        float: left;
        margin-top: 10px;
        font-size: 13px;
    }
	.custom-checkbox input[type="checkbox"] {
		opacity: 0;
		position: absolute;
		margin: 5px 0 0 3px;
		z-index: 9;
	}
	.custom-checkbox label:before{
		width: 18px;
		height: 18px;
	}
	.custom-checkbox label:before {
		content: '';
		margin-right: 10px;
		display: inline-block;
		vertical-align: text-top;
		background: white;
		border: 1px solid #bbb;
		border-radius: 2px;
		box-sizing: border-box;
		z-index: 2;
	}
	.custom-checkbox input[type="checkbox"]:checked + label:after {
		content: '';
		position: absolute;
		left: 6px;
		top: 3px;
		width: 6px;
		height: 11px;
		border: solid #000;
		border-width: 0 3px 3px 0;
		transform: inherit;
		z-index: 3;
		transform: rotateZ(45deg);
	}
	.custom-checkbox input[type="checkbox"]:checked + label:before {
		border-color: #03A9F4;
		background: #03A9F4;
	}
	.custom-checkbox input[type="checkbox"]:checked + label:after {
		border-color: #fff;
	}
	.custom-checkbox input[type="checkbox"]:disabled + label:before {
		color: #b8b8b8;
		cursor: auto;
		box-shadow: none;
		background: #ddd;
	}
</style>


    <div class="row">
            <div class="col-12 d-flex justify-content-between">
                    <h1>Új ajándék  létrehozása</h1>
            </div>
            <div class="col-12 d-flex ">
                    <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">

                            </ol>
                     </nav>
                     @include('adminisztratorok/ruha_atado/menu_admin')
            </div>


    </div>

    <div class="row">

            <div class="col-12 col-md-12">
                <div class="card my-3">
                    <div class="card-body">

                    <form action="{{route('ajendekatado.letrehozas')}}" id="newDressFrom" class="col-6 col-md-6" method="POST">
                            @csrf
                            <div class="form-group">
                                <label for="dressnamelabel">Ajándék elnevezése</label>
                                <input type="text" class="form-control" id="DressName" name="DressName" >
                                @error('DressName')
                                <div class="alert alert-danger" role="alert">
                                   Kötelező mező!
                                    </div>
                                @enderror
                            </div>

                            <div class="form-group">
                                <label for="dressStockLabel">Készlet</label>
                                <input type="number" class="form-control" id="DressStock" name="DressStock" value="0">

                            </div>

                            <div class="form-group">
                                <label for="dressStockOutLabel">Kiosztva</label>
                                <input type="number" class="form-control" id="DressStockOut" name="DressStockOut" value="0">

                            </div>

                            <div class="form-group">

                                <input type="submit" class="btn btn-primary" value="Létrehozás">

                            </div>


                        </form>
                    </div>
                </div>
            </div>




    </div>














@endsection
