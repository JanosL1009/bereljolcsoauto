@extends('layouts.admin')

@section('htmlhead')
    <title>Ruha készletezés - NEK ÖMR</title>

    <link href="{{ asset('tokenize2/tokenize2.css') }}" rel="stylesheet">

    <script src="{{ asset('tokenize2/tokenize2.js') }}"></script>

@endsection

@section('content')
<style>
    .delete{  color: #F44336; } .edit{ color: #FFC107; } .subject{color: #0000FF;} .pointer{cursor: pointer;}
    /* Custom checkbox */
	.custom-checkbox {
		position: relative;
	}
    .pagination {
        float: right;
        margin: 0 0 5px;
    }
    .pagination li a {
        border: none;
        font-size: 13px;
        min-width: 30px;
        min-height: 30px;
        color: #999;
        margin: 0 2px;
        line-height: 30px;
        border-radius: 2px !important;
        text-align: center;
        padding: 0 6px;
    }
    .pagination li a:hover {
        color: #666;
    }
    .pagination li.active a, .pagination li.active a.page-link {
        background: #03A9F4;
    }
    .pagination li.active a:hover {
        background: #0397d6;
    }
	.pagination li.disabled i {
        color: #ccc;
    }
    .pagination li i {
        font-size: 16px;
        padding-top: 6px
    }
    .hint-text {
        float: left;
        margin-top: 10px;
        font-size: 13px;
    }
	.custom-checkbox input[type="checkbox"] {
		opacity: 0;
		position: absolute;
		margin: 5px 0 0 3px;
		z-index: 9;
	}
	.custom-checkbox label:before{
		width: 18px;
		height: 18px;
	}
	.custom-checkbox label:before {
		content: '';
		margin-right: 10px;
		display: inline-block;
		vertical-align: text-top;
		background: white;
		border: 1px solid #bbb;
		border-radius: 2px;
		box-sizing: border-box;
		z-index: 2;
	}
	.custom-checkbox input[type="checkbox"]:checked + label:after {
		content: '';
		position: absolute;
		left: 6px;
		top: 3px;
		width: 6px;
		height: 11px;
		border: solid #000;
		border-width: 0 3px 3px 0;
		transform: inherit;
		z-index: 3;
		transform: rotateZ(45deg);
	}
	.custom-checkbox input[type="checkbox"]:checked + label:before {
		border-color: #03A9F4;
		background: #03A9F4;
	}
	.custom-checkbox input[type="checkbox"]:checked + label:after {
		border-color: #fff;
	}
	.custom-checkbox input[type="checkbox"]:disabled + label:before {
		color: #b8b8b8;
		cursor: auto;
		box-shadow: none;
		background: #ddd;
	}
    .text-warning{color:red !important;}
</style>


    <div class="row">
            <div class="col-12 d-flex justify-content-between">
                    <h1>Ruha - részletes beállítások</h1>
            </div>
            <div class="col-12 d-flex ">
                    <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">

                            </ol>
                     </nav>
                     @include('adminisztratorok/ruha_atado/menu_admin')
            </div>

    </div>

    <div class="row">

            <div class="col-6 col-md-6">
                <div class="card my-3">
                    <div class="card-body">
                            <table class="table table-striped table-hover">
                                    <tr>
                                            <th>Ruha neve</th>
                                            <td>{{$dress->ruhaNeve}} <a href="#editDressNameModal"  data-toggle="modal"><i class="material-icons float-right edit"  style="cursor:default;" data-toggle="tooltip" title="Szerkesztés">&#xE254;</i></a></td>
                                    </tr>
                                    
                                    <tr>
                                            <th>Készlet</th>
                                            <td><span id="dressstockin">{{$dress->keszlet}}</span> <a href="#editDressStockModal"  data-toggle="modal"><i class="material-icons float-right edit"  style="cursor:default;" data-toggle="tooltip" title="Szerkesztés">&#xE254;</i></a></td>
                                    </tr>
                                    <tr>
                                            <th>Kiosztva</th>
                                            <td><span id="dressstockout">{{$dress->kiosztva}}</span> <a href="#editDressStockOutModal"  data-toggle="modal"><i class="material-icons float-right edit"  style="cursor:default;" data-toggle="tooltip" title="Szerkesztés">&#xE254;</i></a></td>
                                    </tr>
                            </table>


                    </div>
                </div>
            </div>


            <div class="col-6 col-md-6">
                <div class="card my-3">
                    <div class="card-body">
                        <h4>Programhoz társítás </h4>
                        <select class="tokenize-sample-demo1" id="multipleProgramSelector" multiple>

                            @foreach($selectedPrograms as $program)
                                <option selected value="{{$program['programID']}}">{{$program['programName']}}</option>
                            @endforeach

                                 @foreach($esemenyek as $esemeny)
                                    <option value="{{$esemeny->id}}">{{$esemeny->nev}}</option>
                                 @endforeach

                        </select>

                    </div>
                </div>
            </div>





    </div>

    <div class="row">
        <div class="col-12 col-md-6">
            <div class="card my-3">
                <div class="card-body" style="height:600px;overflow-y:scroll;">

                    <div class="form-group">
                        <h5>Önkéntes lista
                            <input id="searchOthers" style="padding: 3px 10px;" type="text" placeholder="Továbbiak keresése.." />

                        </h5>
                        <table class="table table-striped table-hover" id="teruletVezetok">
                            <thead>
                                <tr>
                                    <th>
                                        <span class="custom-checkbox">
                                            <input type="checkbox" id="selectAll">
                                            <label for="selectAll"></label>
                                        </span>
                                    </th>

                                    <th>Név</th>
                                    <th>Műveletek</th>

                                </tr>
                            </thead>
                            <tbody class="addAbleMore"></tbody>
                            <tbody style="border-top: 3px solid #333" class="addAble"></tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>


        <div class="col-12 col-md-6">
            <div class="card my-3">
                <div class="card-body" style="height:600px;overflow-y:scroll;">

                    <div class="form-group">
                        <h5 >Ruha átadva </h5>
                        <table id="teruletbeosztva" class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th>
                                        <span class="custom-checkbox">
                                            <input type="checkbox" id="selectAll">
                                            <label for="selectAll"></label>
                                        </span>
                                    </th>

                                    <th>Név</th>
                                    <th>Műveletek</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody class="added"></tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div id="editDressNameModal" class="modal fade">
            <div class="modal-dialog">
                <div class="modal-content">
                <form action="{{url('admin/ruha_atado/namemodify')}}" method="POST" >
                        <div class="modal-header">
                            <h4 class="modal-title">A ruha nevének módosítása</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        </div>
                        <div class="modal-body">
                            <p>Biztosan módosítod a ruha nevét?</p>

                            <p><label>Kérjük adja meg az új nevet: </label><input type="text" id="NewDressName" name="NewDressName"></p>
                        </div>
                        <div class="modal-footer">
                        <input type="number" class="d-none" name="dressCode" value="{{$dress->id}}">
                        @csrf
                            <input type="button" class="btn btn-default" data-dismiss="modal" value="Mégse">
                            <input type="submit" id="DressModifySbmBtn" class="btn btn-danger" value="Változtatás">
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div id="editDressStockModal" class="modal fade">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <form action="{{url('admin/ruha_atado/dressstock')}}" method="POST" >
                            <div class="modal-header">
                                <h4 class="modal-title">A ruha készlet kezelése - készlet</h4>
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                            </div>
                            <div class="modal-body">
                                <p>Biztosan módosítod a készleten lévő ruhák számát?</p>
                                <p class="text-warning">Figyelem! A készleten lévő ruhák száma azt jelenti, ami még nincs kiosztva, tehát kiosztható!
                                    A készletezést a rendszer automatikusan kezeli. Ha kiosztunk egy ruhát egy Önkéntesnek a rendszer automatikusan levonja a készletből!

                                </p>
                                <p><label>Kérjük adja meg a készleten lévő ruhák számát: </label><input type="number" id="NewDressStock" name="NewDressStock"></p>
                            </div>
                            <div class="modal-footer">
                            <input type="number" class="d-none" name="dressCode" value="{{$dress->id}}">
                            @csrf
                                <input type="button" class="btn btn-default" data-dismiss="modal" value="Mégse">
                                <input type="submit" id="DresStockModifySbmíBtn" class="btn btn-danger" value="Változtatás">
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <div id="editDressStockOutModal" class="modal fade">
                    <div class="modal-dialog">
                        <div class="modal-content">
                        <form action="{{url('admin/ruha_atado/dressoutstock')}}" method="POST" >
                                <div class="modal-header">
                                    <h4 class="modal-title">A ruha készlet kezelése - kiosztás</h4>
                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                </div>
                                <div class="modal-body">
                                    <p>Biztosan módosítja a kiosztott ruhák számát?</p>
                                    <p class="text-warning">Figyelem! Az újonnan kiosztott ruhák mennyisége automatikusan hozzáadódik az 'Összes' darabszámhoz!</p>
                                    <p><label>Kérjük adja meg az új mennyiséget: </label><input type="number" id="NewDressStockOut" name="NewDressStockOut"></p>
                                </div>
                                <div class="modal-footer">
                                <input type="number" class="d-none"  name="dressCode" value="{{$dress->id}}">
                                @csrf
                                    <input type="button" class="btn btn-default" data-dismiss="modal" value="Mégse">
                                    <input type="submit" id="DressStockModifySbmBtn" class="btn btn-danger" value="Változtatás">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>



@endsection


@section('scriptsection')
<script src="//code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
<script>
        $('.tokenize-sample-demo1, .tokenize-disabled-demo, .tokenize-events-demo').tokenize2();
        $('.tokenize-remote-demo1').tokenize2({
            dataSource: 'remote.php'
        });
        $('.tokenize-limit-demo1').tokenize2({
            tokensMaxItems: 5
        });
        $('.tokenize-limit-demo2').tokenize2({
            tokensMaxItems: 1
        });
        $('.tokenize-ph-demo1').tokenize2({
            placeholder: 'Kérem válasszon egyet'
        });
        $('.tokenize-sortable-demo1').tokenize2({
            sortable: true
        });
        $('.tokenize-custom-demo1').tokenize2({
            tokensAllowCustom: true
        });
        $('.tokenize-events-demo').on('tokenize:tokens:added', function(e){
            console.log(e);

        });

        $('.tokenize-callable-demo1').tokenize2({
            dataSource: function(search, object){
                $.ajax('remote.php', {
                    data: { search: search, start: 1 },
                    dataType: 'json',
                    success: function(data){
                        var $items = [];
                        $.each(data, function(k, v){
                            $items.push(v);
                        });
                        object.trigger('tokenize:dropdown:fill', [$items]);
                    }
                });
            }
        });

        $('.tokenize-override-demo1').tokenize2();
        $.extend($('.tokenize-override-demo1').tokenize2(), {
            dropdownItemFormat: function(v){
                return $('<a />').html(v.text + ' override').attr({
                    'data-value': v.value,
                    'data-text': v.text
                })
            }
        });

        $('#btnClear').on('mousedown touchstart', function(e){
            e.preventDefault();
            $('.tokenize-demo1, .tokenize-demo2, .tokenize-demo3').tokenize2().trigger('tokenize:clear');
        });

        $('.tokenize-remote-modal').tokenize2({
            dataSource: 'remote.php',
            tokensMaxItems: 1
        });

        $('#btn_validation').on('click', function(e){
            e.preventDefault();
            console.log($('.tokenize-remote-modal').get(0).checkValidity());
        });

        $('#multipleProgramSelector').on('tokenize:tokens:add',function(e, value, text, force){
                let eventid = value;
                $.ajax({
                        type:'POST',
                        url:'{{url('DressToPrograms')}}',
                         data:{_token:'<?php echo csrf_token() ?>',e_id :eventid, d_id: {{$dress->id}} },
                         success:function(data) {
                             // if(data == 1) {location.reload();}
                            }
                        });
        });

        $('#multipleProgramSelector').on('tokenize:tokens:remove',function(e, value, text, force){
            $.ajax({
                        type:'POST',
                        url:'{{url('DressRemovePrograms')}}',
                         data:{_token:'<?php echo csrf_token() ?>',e_id :value, d_id: {{$dress->id}} },
                         success:function(data) {
                             // if(data == 1) {location.reload();}
                            }
                        });

        });


        $('#multipleProgramSelector').focusout(function(){

            var v = ('#multipleProgramSelector').val();

        });
    </script>


<script>
    var Dress_Id = {{ $dress->id }};
$(function () { $('[data-toggle="tooltip"]').tooltip() });

	var felhasznalok = [
@foreach(\App\Model\Felhasznalo::all() as $user){ 'email': '{{$user->email}}','birth': '{{$user->szulIdo}}','address': '{{$user->lakcim}}'}, @endforeach ];


	<?php     $jelentkezett = null;	?>

	var users = [
        @foreach(\App\User::all() as $user){'id': '{{$user->id}}','name': '{{$user->name}}','email': '{{$user->email}}'},@endforeach
	].map(function(elem) {

		var birthText = 'Nincs megadva';
		var addressText = 'Nincs megadva';

		var birth = felhasznalok.find(element => element.email == elem.email);

		if(birth){
			birthText = birth.birth;
			addressText = birth.address;
		}

		return {
			'id': parseInt(elem.id),
			'name': elem.name,
			'email': elem.email,
			'birth': birthText,
			'address': addressText
		};
	});
	var szervezokArray = [ @if(isset($jelentkezok)) @foreach($jelentkezok as $user) {{$user->id}}, @endforeach  @endif ];
     var selectedSzervezokArray = [ @foreach($atadva as $atadas) {{$atadas->felhasznalo_id}}, @endforeach ];

	var renderElements = function(){

		$('.addAble').html(users.map(function(elem) {
			if(
				(szervezokArray.includes( parseInt(elem.id) ))
				&& !selectedSzervezokArray.includes(elem.id)
				)
			return `

			<tr id="`+elem.id+`" >
				<td>
					<span class="custom-checkbox">
						<input type="checkbox" id="checkbox1" name="options[]" value="`+elem.id+`">
						<label for="checkbox1"></label>
					</span>

				</td>
				<td>
					<span title="`+elem.birth+` - `+elem.address+`" class="pointer">`+elem.name+`</span></td>
				<td>
					<i class="material-icons add_box pointer"  data-toggle="tooltip"  data-uid="`+elem.id+`" onclick="UserDressAdd(`+elem.id+`)">add_box</i>
				</td>
			</tr>

			`;
		}));

		$('.added').html(users.map(function(elem) {
			if(selectedSzervezokArray.includes( parseInt(elem.id) ))
			return `

			<tr id="group`+elem.id+`">
				<td>
					<span class="custom-checkbox">
						<input type="checkbox" id="checkbox1" name="options[]" value="`+elem.id+`">
						<label for="checkbox1"></label>
					</span>
				</td>
				<td><span title="`+elem.birth+` - `+elem.address+`" class="pointer">`+elem.name+`</span></td>

				<td>
					<i class="material-icons remove pointer"  data-toggle="tooltip"  data-uid="`+elem.id+`" onclick="UserDressRemove(`+elem.id+`)" title="Eltávolít" >close</i>

				</td>
                <td>
                    <button class="btn btn-primary ruhatadvabtn" id="atadvabtn-`+elem.id+`" data-btnval="`+elem.id+`">Átadva</button>
                </td>
			</tr>

			`;
		}));


	}

	renderElements();


	$(document).on('keyup', '#searchOthers', function(){
		var searchString = $(this).val();
		if(searchString.length > 2){

			$('.addAbleMore').html(users.map(function(elem) {
				if(
					(elem.name.toLowerCase().includes(searchString.toLowerCase()) || elem.email.toLowerCase().includes(searchString.toLowerCase()))
					&& !selectedSzervezokArray.includes(elem.id)
					)
				return `

				<tr id="`+elem.id+`">
					<td>
						<span class="custom-checkbox">
							<input type="checkbox" id="checkbox1" name="options[]" value="`+elem.id+`">
							<label for="checkbox1"></label>
						</span>

					</td>
					<td><span title="`+elem.birth+` - `+elem.address+`" class="pointer">`+elem.name+`</span></td>

					<td>
						<i class="material-icons add_box pointer"  data-toggle="tooltip"  data-uid="`+elem.id+`" onclick="UserDressAdd(`+elem.id+`)">add_box</i>
					</td>
				</tr>

				`;
			}));

		} else{
			$('.addAbleMore').html('');
		}

	})

    let keszletezes = function(){
        $.ajax({
				type:'POST',
				url:'{{url('RuhaKeszletInfo')}}',
				data:{_token: '<?php echo csrf_token() ?>', did:Dress_Id },
				success:function(data) {
                   /* console.log("Keszletinfo: "+data[0]['keszlet']);*/
                    $('#dressstockin').html(data[0]['keszlet']);
                    $('#dressstockout').html(data[0]['kiosztva']);
                }
			});
    }

    function UserDressAdd(itemid){
    	let dress_id = {{ $dress->id }};
        $.ajax({
            type:'POST',
            url:'{{url('UserAddToDress')}}',
            data:{_token: '<?php echo csrf_token() ?>', uid:itemid,did: dress_id},
            success:function(data) {
                if (data ==1 ) {
                                selectedSzervezokArray.push(itemid);
                                renderElements();keszletezes();
                            }
            }
        });

    }

    function UserDressRemove(itemid)
    {
    	let dress_id =  {{ $dress->id }};
        $.ajax({
				type:'POST',
				url:'{{url('UserRemoveToDress')}}',
				data:{_token: '<?php echo csrf_token() ?>', uid: itemid ,did: dress_id},
				success:function(data) {
					if (data == 1) {
						selectedSzervezokArray = selectedSzervezokArray.filter(id => id !== itemid);
						renderElements();keszletezes();
					}
				}
			});

    }

    $('.ruhatadvabtn').click(function(){

        let itemid = $(this).data('btnval');
        console.log("Ertek: " + itemid);
        $.ajax({
				type:'POST',
				url:'{{url('MailARuhaAtadasrol')}}',
				data:{_token: '<?php echo csrf_token() ?>', uid: itemid },
				success:function(data) {
                    console.log(data);
					if (data == 1) {
                        $('#atadvabtn-'+itemid).addClass('disabled').html('Értesítve');
					}
				}
			});
    });

    let AtadasEllBetolteskor = function(){
       /* selectedSzervezokArray */
       let MailKuldve; let dress_id = {{ $dress->id }};
       $.ajax({
				type:'POST',
				url:'{{url('RuhaAtadiMailEll')}}',
				data:{_token: '<?php echo csrf_token() ?>', uids: selectedSzervezokArray,did:dress_id },
				success:function(data) {

                        $.each(data, function( index, value ) {
                            $('#atadvabtn-'+value).addClass('disabled').html('Értesítve');
                        });
                      /*  $('#atadvabtn-'+itemid).addClass('disabled').html('Értesítve');*/

				}
			});



    }

    $(document).ready(function(){
        AtadasEllBetolteskor();
    });



</script>

@endsection
