@extends('layouts.admin')

@section('htmlhead')
    <title>Ruha készletezés - NEK ÖMR</title>

    <link href="{{ asset('tokenize2/tokenize2.css') }}" rel="stylesheet">

    <script src="{{ asset('tokenize2/tokenize2.js') }}"></script>

@endsection

@section('content')
<style>
    .delete{  color: #F44336; } .edit{ color: #FFC107; } .subject{color: #0000FF;} .pointer{cursor: pointer;}
    /* Custom checkbox */
	.custom-checkbox {
		position: relative;
	}
    .pagination {
        float: right;
        margin: 0 0 5px;
    }
    .pagination li a {
        border: none;
        font-size: 13px;
        min-width: 30px;
        min-height: 30px;
        color: #999;
        margin: 0 2px;
        line-height: 30px;
        border-radius: 2px !important;
        text-align: center;
        padding: 0 6px;
    }
    .pagination li a:hover {
        color: #666;
    }
    .pagination li.active a, .pagination li.active a.page-link {
        background: #03A9F4;
    }
    .pagination li.active a:hover {
        background: #0397d6;
    }
	.pagination li.disabled i {
        color: #ccc;
    }
    .pagination li i {
        font-size: 16px;
        padding-top: 6px
    }
    .hint-text {
        float: left;
        margin-top: 10px;
        font-size: 13px;
    }
	.custom-checkbox input[type="checkbox"] {
		opacity: 0;
		position: absolute;
		margin: 5px 0 0 3px;
		z-index: 9;
	}
	.custom-checkbox label:before{
		width: 18px;
		height: 18px;
	}
	.custom-checkbox label:before {
		content: '';
		margin-right: 10px;
		display: inline-block;
		vertical-align: text-top;
		background: white;
		border: 1px solid #bbb;
		border-radius: 2px;
		box-sizing: border-box;
		z-index: 2;
	}
	.custom-checkbox input[type="checkbox"]:checked + label:after {
		content: '';
		position: absolute;
		left: 6px;
		top: 3px;
		width: 6px;
		height: 11px;
		border: solid #000;
		border-width: 0 3px 3px 0;
		transform: inherit;
		z-index: 3;
		transform: rotateZ(45deg);
	}
	.custom-checkbox input[type="checkbox"]:checked + label:before {
		border-color: #03A9F4;
		background: #03A9F4;
	}
	.custom-checkbox input[type="checkbox"]:checked + label:after {
		border-color: #fff;
	}
	.custom-checkbox input[type="checkbox"]:disabled + label:before {
		color: #b8b8b8;
		cursor: auto;
		box-shadow: none;
		background: #ddd;
	}
    .text-warning{color:red !important;}
</style>


    <div class="row">
            <div class="col-12 d-flex justify-content-between">
                    <h1>Ajándék - részletes beállítások</h1>
            </div>
            <div class="col-12 d-flex ">
                    <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">

                            </ol>
                     </nav>
                     @include('adminisztratorok/ruha_atado/menu_admin')
            </div>

    </div>

    <div class="row">

            <div class="col-6 col-md-6">
                <div class="card my-3">
                    <div class="card-body">
                            <table class="table table-striped table-hover">
                                    <tr>
                                            <th>Ajándék neve</th>
                                            <td>{{$dress->ajandekNeve??''}} <a href="#editDressNameModal"  data-toggle="modal"><i class="material-icons float-right edit"  style="cursor:default;" data-toggle="tooltip" title="Szerkesztés">&#xE254;</i></a></td>
                                    </tr>
                                    
                                    <tr>
                                            <th>Készlet</th>
                                            <td><span id="dressstockin">{{$dress->keszlet??0}}</span> <a href="#editDressStockModal"  data-toggle="modal"><i class="material-icons float-right edit"  style="cursor:default;" data-toggle="tooltip" title="Szerkesztés">&#xE254;</i></a></td>
                                    </tr>
                                    <tr>
                                            <th>Kiosztva</th>
                                            <td><span id="dressstockout">{{$dress->kiosztva??0}}</span> <a href="#editDressStockOutModal"  data-toggle="modal"><i class="material-icons float-right edit"  style="cursor:default;" data-toggle="tooltip" title="Szerkesztés">&#xE254;</i></a></td>
                                    </tr>
                            </table>


                    </div>
                </div>
            </div>


           





    </div>



    <div id="editDressNameModal" class="modal fade">
            <div class="modal-dialog">
                <div class="modal-content">
                <form action="{{route('ajendekatado.nevmodositas')}}" method="POST" >
                        <div class="modal-header">
                            <h4 class="modal-title">Az ajándék nevének módosítása</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        </div>
                        <div class="modal-body">
                            <p>Biztosan módosítod az ajándék nevét?</p>

                            <p><label>Kérjük adja meg az új nevet: </label><input type="text" id="NewDressName" name="NewDressName"></p>
                        </div>
                        <div class="modal-footer">
                        <input type="number" class="d-none" name="dressCode" value="{{$dress->id??0}}">
                        @csrf
                            <input type="button" class="btn btn-default" data-dismiss="modal" value="Mégse">
                            <input type="submit" id="DressModifySbmBtn" class="btn btn-danger" value="Változtatás">
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div id="editDressStockModal" class="modal fade">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <form action="{{route('ajendekatado.keszletmod')}}" method="POST" >
                            <div class="modal-header">
                                <h4 class="modal-title">Az ajándék készlet kezelése - készlet</h4>
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                            </div>
                            <div class="modal-body">
                                <p>Biztosan módosítod a készleten lévő ajándékok számát?</p>
                                <p class="text-warning">Figyelem! A készleten lévő ajándékok száma azt jelenti, ami még nincs kiosztva, tehát kiosztható!
                                    A készletezést a rendszer automatikusan kezeli. Ha kiosztunk egy ajándékot egy Önkéntesnek a rendszer automatikusan levonja a készletből!

                                </p>
                                <p><label>Kérjük adja meg a készleten lévő ajándékok számát: </label><input type="number" id="NewDressStock" name="NewDressStock"></p>
                            </div>
                            <div class="modal-footer">
                            <input type="number" class="d-none" name="dressCode" value="{{$dress->id??0}}">
                            @csrf
                                <input type="button" class="btn btn-default" data-dismiss="modal" value="Mégse">
                                <input type="submit" id="DresStockModifySbmíBtn" class="btn btn-danger" value="Változtatás">
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <div id="editDressStockOutModal" class="modal fade">
                    <div class="modal-dialog">
                        <div class="modal-content">
                        <form action="{{route('ajendekatado.kiosztmod')}}" method="POST" >
                                <div class="modal-header">
                                    <h4 class="modal-title">A ajándékok készlet kezelése - kiosztás</h4>
                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                </div>
                                <div class="modal-body">
                                    <p>Biztosan módosítja a kiosztott ajándékok számát?</p>
                                    <p class="text-warning">Figyelem! Az újonnan kiosztott ajándékok mennyisége automatikusan hozzáadódik az 'Összes' darabszámhoz!</p>
                                    <p><label>Kérjük adja meg az új mennyiséget: </label><input type="number" id="NewDressStockOut" name="NewDressStockOut"></p>
                                </div>
                                <div class="modal-footer">
                                <input type="number" class="d-none"  name="dressCode" value="{{$dress->id??0}}">
                                @csrf
                                    <input type="button" class="btn btn-default" data-dismiss="modal" value="Mégse">
                                    <input type="submit" id="DressStockModifySbmBtn" class="btn btn-danger" value="Változtatás">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>



@endsection


@section('scriptsection')



@endsection
