@extends('layouts.admin')


@section('content')
    <style>.OutOfStock{color: green;border-radius: 20px;border-style: solid; background-color: green;height: 12px; width: 12px; display: block;}</style>
    <div class="row">
        <div class="col-12">
            <h1>{{$user->name}} ajándék története</h1>
        </div>
          @include('adminisztratorok/ruha_atado/menu_admin')
    </div>

    <div class="row">
       <div class="col-12">
               

                @if($errors->success->first())
                    <div class="col-12 text-center">
                    <h4  class="alert alert-success" role="alert">{{$errors->success->first()}}</h4>
                    </div>
                @endif

                 @if($errors->failed->first())
                    <div class="col-12 text-center">
                    <h4  class="alert alert-danger" role="alert">{{$errors->failed->first()}}</h4>
                    </div>
    
                @endif

                @if($errors->warning->first())
                    <div class="col-12 text-center">
                    <h4  class="alert alert-warning" role="alert">{{$errors->warning->first()}}</h4>
                    </div>
    
                @endif
       </div>
    </div>

    @if(isset($ruhaLista))
        @if(count($ruhaLista) > 0)
                <div class="row">
                    <div class="col-12">
                        <div class="col-12 text-center">
                            
                            <a class="btn btn-warning" href="{{url('/admin/ruha_atado/v2/elismerveny/ajandekelismerveny/'.$user->id)}}" target="_blank">Ajándék átadó elismervény letöltése</a>
                    
                        </div>
                    </div>  
                </div>
        @else 
                <div class="row d-none" id="elismervenyBox">
                    <div class="col-12">
                        <div class="col-12 text-center">
                            <a class="btn btn-warning" href="{{url('/admin/ruha_atado/v2/elismerveny/ajandekelismerveny/'.$user->id)}}"  target="_blank">Ajándék átadó elismervény letöltése</a>
                    
                        </div>
                    </div>  
                </div>
        @endif

         @else 
                <div class="row d-none" id="elismervenyBox">
                    <div class="col-12">
                        <div class="col-12 text-center">
                            <a class="btn btn-warning" href="{{url('/admin/ruha_atado/v2/elismerveny/formaruhatado/'.$user->id)}}">Formaruha átadó elismervény letöltése</a>
                            <a class="btn btn-warning" href="{{url('/admin/ruha_atado/v2/elismerveny/ajandekelismerveny/'.$user->id)}}"  target="_blank">Ajándék átadó elismervény letöltése</a>
                    
                        </div>
                    </div>  
                </div>
                
    @endif

    <div class="row mt-3">
        <div class="col-6">
            <div class="card">
                <table class="table table-striped table-hover">
                    <tbody >
                        <tr>
                            <th> A felhasználó neve:</th>
                            <td><b> {{$user->name}} </b></td>
                        </tr>
                         <tr>
                            <th>  Email címe:</th>
                            <td><b>  {{$user->email}} </b></td>
                        </tr>
                        <!-- <tr>
                            <th>  Profil kitöltöttség:</th>
                            <td>
                                 @if($user['profilvalid'] )
                                    <span class="material-icons" style="color:green;"> check_circle</span> 
                                 @else
                                    <span class="material-icons" style="color:red;">remove_circle</span> 
                                                        
                                 @endif
                                 FEJLESZTÉS ALATT!!!!!!
                            </td>
                        </tr> -->
                        <tr>
                            <th>  Profilkép validálva:</th>
                            <td>
                                @if($user->felhasznalo_data->kepvalidalas == 3 || $user->felhasznalo_data->kepvalidalas == 2)
                                    <span class="material-icons" style="color:red;"> check_circle</span> 
                                @else
                                    <span class="material-icons" style="color:green;">remove_circle</span> 
                                                        
                                @endif
                            </td>
                        </tr>
                         <tr>
                            <th>Pólótípusa:</th>
                            <td>
                                @if($user->felhasznaloinfo_data->polotipus == 0)
                                    {{ 'Női' }}
                                @else
                                    {{ 'Férfi/Unisex' }} 
                                                        
                                @endif
                            </td>
                        </tr>
                        <tr>
                            <th>Pólótípusa:</th>
                            <td>
                                @if(isset($user->felhasznaloinfo_data->polomeret))
                                    {{ $user->felhasznaloinfo_data->polomeret }}
                                                
                                @endif
                            </td>
                        </tr>
                    </tbody>
                </table>
                
            </div>
        </div>

        <div class="col-6">
            <div class="card">
                <div style=" border: 1px solid whitesmoke ;text-align: center;position: relative" id="image"> 
                    <img width="50%" height="50%" id="preview_image" src="{{url('userpic/'.$user->felhasznalo_data->profilkep)}}" />
                </div>
            </div>
        </div>
    </div>

    <div class="row mt-3">
        <div class="col-6">
            <div class="card">
                <table class="table table-striped">
                    <thead>
                        <th>Elnevezés</th>
                        <th>Darabszám</th>
                        <th>Művelet</th>
                    </thead>

                    <tbody>
                      
                        @foreach($osszesRuha as $ruha)
                            <tr id="trrow-{{$ruha->id}}">
                                <td id="elnevezes-{{$ruha->id}}">{{$ruha->ajandekNeve}}</td>
                                <td id="tddb-{{$ruha->id}}">
                                    <input type="number" class="form-control" id="idb-{{$ruha->id}}">
                                </td>
                                <td id="btntd-{{$ruha->id}}">
                                    <button class="btn btn-primary" id="atadogomb-{{$ruha->id}}" onclick="atado({{$ruha->id}});">Átadás</button>
                                </td>
                            </tr>
                          
                        @endforeach
                       
                    </tbody>
                </table>
            </div>
        </div>

        <div class="col-6">
            <div class="card">
                <table class="table table-striped table-hover" id="ruhatortenet">
                    <thead>
                        <tr>
                            <th>Ajándék elnevezése/típus</th>
                            <th>Állapot</th>
                            <th>Átaadás ideje</th>
                            <th>Visszavételezés ideje</th>
                            <th>Műveletek</th>
                        </tr>
                    </thead>
                    <tbody >
                        @if(isset($ruhaLista))
                            @foreach($ruhaLista as $ruha)
                            @if(isset($ruha->Ajandek->ajandekNeve))
                                <tr>
                                    <td>{{$ruha->Ajandek->ajandekNeve}}</td>
                                    <td>
                                        @if(isset($ruha->visszaVetelezesIdeje))
                                           <span style="color: purple; border-radius: 20px; border-style: solid; background-color: purple; height: 12px; width: 12px;display: block;"> </span>
                                       @else
                                            <span style="color: green; border-radius: 20px; border-style: solid; background-color: green; height: 12px; width: 12px;display: block;"> </span>
                                        @endif
                                    </td>
                                    <td>{{$ruha->atadasIdeje}}</td>
                                    <td>{{$ruha->visszaVetelezesIdeje??''}}</td>
                                    <td>
                                        @if(!isset($ruha->visszaVetelezesIdeje))
                                             <a href="{{url('/admin/ajandekok_atado/xhr/ruha_atado/visszavetelezes/ajandek/'.$ruha->id)}}" class="btn btn-link">Vissza</a>
                                       
                                        @endif
                                        

                                    </td>
                                </tr>
                            @endif
                             
                        @endforeach
                        @endif
                    
                    </tbody>
                </table>
            </div>
        </div>

    </div>

    <script>
        function atado(dressid)
        {
           let btnid = 'idb-'+dressid;
           let _db = document.getElementById(btnid).value;

            if(_db < 1)
            {
                alert('A darabszám nem lehet 0 vagy negatív!');
                return 0;
            }

           let uid = {{$user->id}};
          
           $.ajax({
                    method: "POST",
                    url: "{{route('ajandekatado.post')}}",
                    data: {_token:'<?php echo csrf_token() ?>', auid: uid, did: dressid,db:_db },
                    })
                    .done(function( msg ) {
                       
                       if(msg == 4) { alert('Sikertelen átadás');}
                       if(msg == 2) { alert('Nem sikerült a darabszámok mentése');}
                       if(msg == 1) { alert('Hiba a ruha készlet mentésekor!');}
                       if(msg == 0) { alert('Hiba a készletezés során. A készlet elfogyott!');}

                        let result = JSON.parse(msg);

                        if(result[0].ruha_id > 0) { 
                           let itemid = 'trrow-'+dressid;
                           //document.getElementById(itemid).remove();
                           disabler(dressid);
                           InsertNewRow(result[0].ruha_atadoid,result[0].ruha_neve,result[0].atadasIdeje);
                            if(document.getElementById('elismervenyBox'))
                            {
                                document.getElementById('elismervenyBox').classList.remove('d-none');
                            }
                       }
            });
        }
       
       var atAdottRuhak = JSON.parse('{!! $jsonRuhaLista !!}');
        for(let i =0;i < atAdottRuhak.length; i++)
        {
            let tr = 'trrow-'+atAdottRuhak[i].ruhaid;
            document.getElementById(tr).style.backgroundColor = '#d5d5d5';
            let btn = 'atadogomb-'+atAdottRuhak[i].ruhaid;
            document.getElementById(btn).disabled = true;
            let idb = 'idb-'+atAdottRuhak[i].ruhaid;
            document.getElementById(idb).disabled = true;
        }

        function disabler(id)
        {
             let tr = 'trrow-'+id;
            document.getElementById(tr).style.backgroundColor = '#d5d5d5';
            let btn = 'atadogomb-'+id;
            document.getElementById(btn).disabled = true;
            let idb = 'idb-'+id;
            document.getElementById(idb).disabled = true;
        }

        function InsertNewRow(ruhid,ruhaNeve,kiadasIdeje)
        {
           
            let tbodyRef = document.getElementById('ruhatortenet').getElementsByTagName('tbody')[0];
            let newRow = tbodyRef.insertRow();

         
            let dressName = newRow.insertCell();

            // Append a text node to the cell
            let dressNameText = document.createTextNode(ruhaNeve);
            dressName.appendChild(dressNameText);

           
           // Insert a cell at the end of the row
            let allapot = newRow.insertCell();
            let Span = document.createElement('span');
            Span.classList.add('OutOfStock');
            // Append a text node to the cell
            let allapotText = document.createTextNode('');
            allapot.appendChild(Span);


            // Insert a cell at the end of the row
            let atadasCell = newRow.insertCell();

            // Append a text node to the cell
            let newText = document.createTextNode(kiadasIdeje);
            atadasCell.appendChild(newText);


            // Insert a cell at the end of the row
            let visszaCell = newRow.insertCell();

            // Append a text node to the cell
            let visszaText = document.createTextNode('');
            visszaCell.appendChild(visszaText);

            // Insert a cell at the end of the row
            let actionLinkCell = newRow.insertCell();

            // Append a text node to the cell
            let actionLinkText = document.createTextNode('Vissza');
           
            let atag = document.createElement('A');
            atag.innerText = 'Vissza';atag.innerHtml = 'Vissza';
            let link =' {{url('admin/ajandekok_atado/xhr/ruha_atado/visszavetelezes/ajandek')}}';
            atag.href = link+'/'+ruhid;
            atag.classList.add("btn"); atag.classList.add("btn-link");
            actionLinkCell.appendChild(atag);
        } 
    </script> 

@endsection