@extends('layouts.admin')


@section('content')
<style>
    .delete{  color: #F44336; } .edit{ color: #FFC107; } .subject{color: #0000FF;} .pointer{cursor: pointer;}
    /* Custom checkbox */
	.custom-checkbox {
		position: relative;
	}
    .pagination {
        float: right;
        margin: 0 0 5px;
    }
    .pagination li a {
        border: none;
        font-size: 13px;
        min-width: 30px;
        min-height: 30px;
        color: #999;
        margin: 0 2px;
        line-height: 30px;
        border-radius: 2px !important;
        text-align: center;
        padding: 0 6px;
    }
    .pagination li a:hover {
        color: #666;
    }
    .pagination li.active a, .pagination li.active a.page-link {
        background: #03A9F4;
    }
    .pagination li.active a:hover {
        background: #0397d6;
    }
	.pagination li.disabled i {
        color: #ccc;
    }
    .pagination li i {
        font-size: 16px;
        padding-top: 6px
    }
    .hint-text {
        float: left;
        margin-top: 10px;
        font-size: 13px;
    }
	.custom-checkbox input[type="checkbox"] {
		opacity: 0;
		position: absolute;
		margin: 5px 0 0 3px;
		z-index: 9;
	}
	.custom-checkbox label:before{
		width: 18px;
		height: 18px;
	}
	.custom-checkbox label:before {
		content: '';
		margin-right: 10px;
		display: inline-block;
		vertical-align: text-top;
		background: white;
		border: 1px solid #bbb;
		border-radius: 2px;
		box-sizing: border-box;
		z-index: 2;
	}
	.custom-checkbox input[type="checkbox"]:checked + label:after {
		content: '';
		position: absolute;
		left: 6px;
		top: 3px;
		width: 6px;
		height: 11px;
		border: solid #000;
		border-width: 0 3px 3px 0;
		transform: inherit;
		z-index: 3;
		transform: rotateZ(45deg);
	}
	.custom-checkbox input[type="checkbox"]:checked + label:before {
		border-color: #03A9F4;
		background: #03A9F4;
	}
	.custom-checkbox input[type="checkbox"]:checked + label:after {
		border-color: #fff;
	}
	.custom-checkbox input[type="checkbox"]:disabled + label:before {
		color: #b8b8b8;
		cursor: auto;
		box-shadow: none;
		background: #ddd;
	}
</style>


    <div class="row">
            <div class="col-12 d-flex justify-content-between">
                    <h1>Ruha átadó jogosultságok kezelése  </h1>
            </div>
            <div class="col-12 d-flex ">
                    <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">

                            </ol>
                     </nav>
                     @include('adminisztratorok/ruha_atado/menu_admin')
            </div>

    </div>

    <div class="row">

            <div class="col-12 col-md-12">
	<div class="card my-3">
		<div class="card-body">



			<div class="row">
				<div class="col-12 d-flex justify-content-between">
					<h3>Önkéntes beosztása ruha átadónak</h3>
				</div>
			</div>


				<div class="row">

					<div class="col-12 col-lg-6">
						<div class="card my-3">
							<div class="card-body" style="height:600px;overflow-y:scroll;">

								<div class="form-group">
									<h5>
										Jelentkezők
										<input id="searchOthers" style="padding: 3px 10px;" type="text" placeholder="Továbbiak keresése.." />
									</h5>
									<table class="table table-striped table-hover" id="teruletVezetok">
										<thead>
											<tr>
												<th>
													<span class="custom-checkbox">
														<input type="checkbox" id="selectAll">
														<label for="selectAll"></label>
													</span>
												</th>

												<th>Név</th>
												<th>Műveletek</th>

											</tr>
										</thead>
										<tbody class="addAbleMore"></tbody>
										<tbody style="border-top: 3px solid #333" class="addAble"></tbody>
									</table>
								</div>
							</div>
						</div>
					</div>


					<div class="col-12 col-lg-6">
						<div class="card my-3">
							<div class="card-body" style="height:600px;overflow-y:scroll;">

								<div class="form-group">
									<h5 >Beosztva</h5>
									<table id="teruletbeosztva" class="table table-striped table-hover">
										<thead>
											<tr>
												<th>
													<span class="custom-checkbox">
														<input type="checkbox" id="selectAll">
														<label for="selectAll"></label>
													</span>
												</th>

												<th>Név</th>
												<th>Műveletek</th>

											</tr>
										</thead>
										<tbody class="added"></tbody>
									</table>
								</div>
							</div>
						</div>
					</div>

				</div>

		</div>
	</div>
</div>


<script>


	var felhasznalok = [
		@foreach(\App\Model\Felhasznalo::all() as $user)
		{
			'email': '{{$user->email}}',
			'birth': '{{$user->szulIdo}}',
			'address': '{{$user->lakcim}}'
		},
		@endforeach

	];




	var users = [
        @foreach($felhasznalok as $user)
		{
			'id': '{{$user->felhasznalo_id}}',
			'name': '{{$user->name}}',
			'email': '{{$user->email}}'
		},
		@endforeach

	].map(function(elem) {

		var birthText = 'Nincs megadva';
		var addressText = 'Nincs megadva';

		var birth = felhasznalok.find(element => element.email == elem.email);

		if(birth){
			birthText = birth.birth;
			addressText = birth.address;
		}

		return {
			'id': parseInt(elem.id),
			'name': elem.name,
			'email': elem.email,
			'birth': birthText,
			'address': addressText
		};
	});


	var szervezokArray = [

        @foreach($felhasznalok as $sz)
			{{$sz->felhasznalo_id}},
		@endforeach

	];



     var selectedSzervezokArray = [
        @foreach($ruhaAtadok as $sz)
			{{$sz->felhasznalo_id}},
		@endforeach
	];

	var renderElements = function(){

		$('.addAble').html(users.map(function(elem) {
			if(
				(szervezokArray.includes( parseInt(elem.id) ))
				&& !selectedSzervezokArray.includes(elem.id)
				)
			return `

			<tr id="`+elem.id+`" >
				<td>
					<span class="custom-checkbox">
						<input type="checkbox" id="checkbox1" name="options[]" value="`+elem.id+`">
						<label for="checkbox1"></label>
					</span>

				</td>
				<td data-label="Név">
					<span title="`+elem.birth+` - `+elem.address+`" class="pointer">`+elem.name+`</span></td>
				<td data-label="Műveletek">
					<i class="material-icons add_box pointer"  data-toggle="tooltip"  data-uid="`+elem.id+`" onclick="UserEventAdd(`+elem.id+`)">add_box</i>
				</td>
			</tr>

			`;
		}));

		$('.added').html(users.map(function(elem) {
			if(selectedSzervezokArray.includes( parseInt(elem.id) ))
			return `

			<tr id="group`+elem.id+`">
				<td>
					<span class="custom-checkbox">
						<input type="checkbox" id="checkbox1" name="options[]" value="`+elem.id+`">
						<label for="checkbox1"></label>
					</span>
				</td>
				<td data-label="Név"><span title="`+elem.birth+` - `+elem.address+`" class="pointer">`+elem.name+`</span></td>

				<td data-label="Műveletek">
					<i class="material-icons remove pointer"  data-toggle="tooltip"  data-uid="`+elem.id+`" onclick="UserEventRemove(`+elem.id+`)" title="Eltávolít" >close</i>

				</td>
			</tr>

			`;
		}));


	}

	renderElements();


	$(document).on('keyup', '#searchOthers', function(){
		var searchString = $(this).val();
		if(searchString.length > 2){

			$('.addAbleMore').html(users.map(function(elem) {
				if(
					(elem.name.toLowerCase().includes(searchString.toLowerCase()) || elem.email.toLowerCase().includes(searchString.toLowerCase()))
					&& !selectedSzervezokArray.includes(elem.id)
					)
				return `

				<tr id="`+elem.id+`">
					<td>
						<span class="custom-checkbox">
							<input type="checkbox" id="checkbox1" name="options[]" value="`+elem.id+`">
							<label for="checkbox1"></label>
						</span>

					</td>
					<td data-label="Név"><span title="`+elem.birth+` - `+elem.address+`" class="pointer">`+elem.name+`</span></td>

					<td data-label="Műveletek">
						<i class="material-icons add_box pointer"  data-toggle="tooltip"  data-uid="`+elem.id+`" onclick="UserEventAdd(`+elem.id+`)">add_box</i>
					</td>
				</tr>

				`;
			}));

		} else{
			$('.addAbleMore').html('');
		}

	})

    $(document).ready(function(){
        $.ajax({
            type:'POST',
            url:'{{url('getusers')}}',
            data:{_token: '<?php echo csrf_token() ?>'},
            success:function(data) {

                console.log(data);
            }
        });
    });

    function UserEventAdd(itemid){

        $.ajax({
            type:'POST',
            url:'{{url('AddDressController')}}',
            data:{_token: '<?php echo csrf_token() ?>',uid:itemid},
            success:function(data) {
                if (data ==1 ) {
                                selectedSzervezokArray.push(itemid);
                                renderElements();
                            }
                console.log(data);
            }
        });
    }
    function UserEventRemove(itemid)
    {
        $.ajax({
				type:'POST',
				url:'{{url('RemoveDressController')}}',
				data:{_token: '<?php echo csrf_token() ?>', uid:itemid},
				success:function(data) {
					if (data == 1) {
						selectedSzervezokArray = selectedSzervezokArray.filter(id => id !== itemid);
						renderElements();
					}
					console.log(data);
				}
			});

    }

</script>


        </div>















            <script type="text/javascript">
                $(document).ready(function(){
                    // Activate tooltip
                    $('[data-toggle="tooltip"]').tooltip();

                    // Select/Deselect checkboxes
                    var checkbox = $('table tbody input[type="checkbox"]');
                    $("#selectAll").click(function(){
                        if(this.checked){
                            checkbox.each(function(){
                                this.checked = true;
                            });
                        } else{
                            checkbox.each(function(){
                                this.checked = false;
                            });
                        }
                    });
                    checkbox.click(function(){
                        if(!this.checked){
                            $("#selectAll").prop("checked", false);
                        }
                    });
                });
                </script>
@endsection
