@extends('layouts.admin')

@section('content')

<div class="row">
    <div class="col-12">
        <h1>Felhasználó szerinti kereső - fejlesztés alatt</h1>
    </div>
     @include('adminisztratorok/ruha_atado/menu_admin')
</div>

<div class="row">
    <div class="col-12">
        <div class="card">
                            <form id="search" action="{{url ('/admin/ruha_atado/kereso')}}"  method="GET" enctype="multipart/form-data" >
                                @csrf
                                <div class="form-group">
                                         
                                        <input value="{{request()->onkentes_neve}}" type="text" class="form-control col-12 col-md-6 my-2" id="onkentes_neve" name="onkentes_neve"  placeholder="Név">
                                </div>
                            
                                <div class="form-group">
                                       
                                        <input type="email" id="volemail" name="volemail" value="{{request()->volemail}}"  class="form-control col-12 col-md-6 my-2 " placeholder="E-mail cím alapján">
                                </div>
                                <div class="form-group">
                                        <input type="hidden" name="ruhaid" value="">
                                        <input type="submit"  class="btn btn-primary" >
                                </div>
                            </form>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-12">
        <div class="card">
            @isset($talalat)
                <table class="table table-striped table-hover">
                    <thead>
                            <tr>
                                <th></th>
                                <th>Név/E-mail</th>
                                <th>Profil állapot</th>
                            </tr>
                    </thead>
                    <tbody>
                        @foreach($talalat as $user)
                             <tr>
                                <th><img src="{{url('userpic/'.$user['profilkep'])}}" width="94" height="94" /></th>
                                <th>{{$user['nev']}}</th>
                                <th><a href="{{url('/admin/ruha_atado/profilnezo/'.$user['id'])}}" class="btn btn-primary">Ruha átadó</a>
                                <a href="{{url('admin/ajandekok_atado/profilnezo/'.$user['id'])}}" class="btn btn-primary">Ajándék átadó</a>
                                <a href="{{url('admin/tanusitvany/profil/'.$user['id'])}}" class="btn btn-primary" target="_blank">Tanúsítvány</a></th>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            @endisset

            <div class="col-12">
            @isset($talalat)
                    {{$talalat->links()}}
            @endisset
                
            </div>

        </div>
    </div>
</div>

@endsection