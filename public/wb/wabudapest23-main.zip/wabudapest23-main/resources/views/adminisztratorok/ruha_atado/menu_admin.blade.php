@isset($submenuitem)
<div class="gombok">
    <button type="button" id="submenu-item2-dresscontroll" class="btn @if($submenuitem == 1) btn-primary @else btn-secondary @endif"><a href="{{url('admin/ruha_atado/')}}">Jogosultság kezelés</a></button>
    <button type="button" id="submenu-item2-dresscontroll" class="btn @if($submenuitem == 2) btn-primary @else btn-secondary @endif"><a href="{{url('admin/ruha_atado/dresscontrol')}}">Ruhák</a></button>
    <button type="button" id="submenu-item2-dresscontroll" class="btn @if($submenuitem == 4) btn-primary @else btn-secondary @endif"><a href="{{route('ajendekatado.index')}}">Ajándékok</a></button>
    <button type="button" id="submenu-item2-dresscontroll" class="btn @if($submenuitem == 3) btn-primary @else btn-secondary @endif"><a href="{{url('admin/ruha_atado/kereso')}}">Kereső</a></button>

</div>
@else 
<div class="gombok">
 <button type="button" id="submenu-item2-dresscontroll" class="btn  btn-secondary "><a href="{{url('admin/ruha_atado/')}}">Jogosultság kezelés</a></button>
    <button type="button" id="submenu-item2-dresscontroll" class="btn  btn-secondary "><a href="{{url('admin/ruha_atado/dresscontrol')}}">Ruhák</a></button>
    <button type="button" id="submenu-item2-dresscontroll" class="btn  btn-secondary "><a href="{{route('ajendekatado.index')}}">Ajándékok</a></button>
    <button type="button" id="submenu-item2-dresscontroll" class="btn  btn-secondary "><a href="{{url('admin/ruha_atado/kereso')}}">Kereső</a></button>

</div>
@endisset




