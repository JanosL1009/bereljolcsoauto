@extends('layouts.admin')


@section('content')
<style>
    .delete{  color: #F44336; } .edit{ color: #FFC107; } .subject{color: #0000FF;} .pointer{cursor: pointer;}
    /* Custom checkbox */
	.custom-checkbox {
		position: relative;
	}
    .pagination {
        float: right;
        margin: 0 0 5px;
    }
    .pagination li a {
        border: none;
        font-size: 13px;
        min-width: 30px;
        min-height: 30px;
        color: #999;
        margin: 0 2px;
        line-height: 30px;
        border-radius: 2px !important;
        text-align: center;
        padding: 0 6px;
    }
    .pagination li a:hover {
        color: #666;
    }
    .pagination li.active a, .pagination li.active a.page-link {
        background: #03A9F4;
    }
    .pagination li.active a:hover {
        background: #0397d6;
    }
	.pagination li.disabled i {
        color: #ccc;
    }
    .pagination li i {
        font-size: 16px;
        padding-top: 6px
    }
    .hint-text {
        float: left;
        margin-top: 10px;
        font-size: 13px;
    }
	.custom-checkbox input[type="checkbox"] {
		opacity: 0;
		position: absolute;
		margin: 5px 0 0 3px;
		z-index: 9;
	}
	.custom-checkbox label:before{
		width: 18px;
		height: 18px;
	}
	.custom-checkbox label:before {
		content: '';
		margin-right: 10px;
		display: inline-block;
		vertical-align: text-top;
		background: white;
		border: 1px solid #bbb;
		border-radius: 2px;
		box-sizing: border-box;
		z-index: 2;
	}
	.custom-checkbox input[type="checkbox"]:checked + label:after {
		content: '';
		position: absolute;
		left: 6px;
		top: 3px;
		width: 6px;
		height: 11px;
		border: solid #000;
		border-width: 0 3px 3px 0;
		transform: inherit;
		z-index: 3;
		transform: rotateZ(45deg);
	}
	.custom-checkbox input[type="checkbox"]:checked + label:before {
		border-color: #03A9F4;
		background: #03A9F4;
	}
	.custom-checkbox input[type="checkbox"]:checked + label:after {
		border-color: #fff;
	}
	.custom-checkbox input[type="checkbox"]:disabled + label:before {
		color: #b8b8b8;
		cursor: auto;
		box-shadow: none;
		background: #ddd;
	}
</style>


    <div class="row">
            <div class="col-12 d-flex justify-content-between">
                    <h1>Ruhák kezelése </h1>
            </div>
            <div class="col-12 d-flex ">
                    <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">

                            </ol>
                     </nav>
                     @include('adminisztratorok/ruha_atado/menu_admin')
            </div>
            <div class="col-12 d-flex justify-content-end">
                <button type="button" class="btn btn-primary"><a href="{{url('/admin/ruha_atado/uj_ruha')}}">+ Új ruha</a></button>
            </div>
    </div>

    <div class="row">

            <div class="col-12 col-md-12">
	<div class="card my-3">
		<div class="card-body">

                <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>
                                    <span class="custom-checkbox">
                                        <input type="checkbox" id="selectAll">
                                        <label for="selectAll"></label>
                                    </span>
                                </th>
                                <th>Ruha neve
                                  <a href="{{asset('admin/esemenyek/nev/asc')}}" class="szuro">
                                    <span class="material-icons">expand_less</span>
                                  </a>
                                  <a href="{{asset('admin/esemenyek/nev/desc')}}" class="szuro">
                                    <span class="material-icons">expand_more</span>
                                  </a>
                                </th>
                            <!--    <th>Helyszín</th> -->
                                <th>Létrehozás ideje
                                  <a href="{{asset('admin/esemenyek/kezdesDatum/asc')}}" class="szuro">
                                    <span class="material-icons">expand_less</span>
                                  </a>
                                  <a href="{{asset('admin/esemenyek/kezdesDatum/desc')}}" class="szuro">
                                    <span class="material-icons">expand_more</span>
                                  </a>
                                </th>
                                <th>Össz. mennyiség
                                </th>
                                <th>Műveletek</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($dresses as $dress)

                            <tr data-did="{{$dress->id}}">
                                <td>
                                    <span class="custom-checkbox">
                                        <input type="checkbox" id="checkbox1" name="options[]" value="1">
                                        <label for="checkbox1"></label>
                                    </span>
                                </td>
                                <td data-label="Ruha neve">{{$dress->ruhaNeve}}</td>

                                <td data-label="Létrehozás ideje">{{$dress->created_at}}</td>
                                <td  data-label="Össz. mennyiség">{{$dress->keszlet}}</td>
                                <td data-label="Műveletek">
                                    <a href="{{url('admin/ruha_atado/profilvalidalas/'.$dress->id)}}" class="" >Átadáshoz</a>
                                    
                                    <a href="{{url('admin/ruha_atado/reszletek/'.$dress->id)}}" class="edit" ><i class="material-icons" data-toggle="tooltip" title="Módosítás">&#xE254;</i></a>
                                    <a href="#DeleteDress" class="delete" data-toggle="modal"><i class="material-icons deltool" data-toggle="tooltip" title="Törlés" data-dressid="{{$dress->id}}">&#xE872;</i></a>

                                </td>
                            </tr>


                            @endforeach
                        </tbody>
                    </table>

                <div class="clearfix float-left">
                        {{ $dresses->links() }}
                </div>
		</div>
	</div>
</div>




        </div>

        <div id="DeleteDress" class="modal fade">
                <div class="modal-dialog">
                    <div class="modal-content">

                            <div class="modal-header">
                                <h4 class="modal-title">Ruha törlése</h4>
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                            </div>
                            <div class="modal-body">
                                <p>Biztosan törölni szeretné, ezt a ruhát?</p>
                                <p style="color: #ff0000;" >Ha törli a ruhát, később az adatokat nem tudjuk visszaállítani!</p>
                            </div>
                            <div class="modal-footer">
                                <input type="number" class="d-none" id="ddressid" name="ddressid" value="-1">
                                <input type="button" class="btn btn-default" data-dismiss="modal" value="Mégse">
                                <input type="button" id="DressDeleteBtn" class="btn btn-danger" value="Törlés">
                            </div>

                    </div>
                </div>
            </div>

@endsection

@section('scriptsection')
<script type="text/javascript">
    $(document).ready(function(){

        $('.deltool').click(function(){
            let v = $(this).data('dressid'); $('#ddressid').val(v);
        });

        $('#DressDeleteBtn').click(function(){
            let did = $('#ddressid').val();
            $.ajax({
                    type:'POST',
                    url:'{{route('ruha.torles')}}',
                    data:{_token:'<?php echo csrf_token() ?>', id:did },
                    success:function(data) {
                        if(data == 1) {location.reload();}
                    }
                });
        });


        // Activate tooltip
        $('[data-toggle="tooltip"]').tooltip();

        // Select/Deselect checkboxes
        var checkbox = $('table tbody input[type="checkbox"]');
        $("#selectAll").click(function(){
            if(this.checked){
                checkbox.each(function(){
                    this.checked = true;
                });
            } else{
                checkbox.each(function(){
                    this.checked = false;
                });
            }
        });
        checkbox.click(function(){
            if(!this.checked){
                $("#selectAll").prop("checked", false);
            }
        });
    });


    </script>
@endsection
