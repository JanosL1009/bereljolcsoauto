@extends('layouts.admin')


@section('content')
 <div class="row">
            <div class="col-12 d-flex justify-content-between">
                    <h1>Ruha átadó felület - {{$ruha->ruhaNeve}}</h1>
            </div>  
            @include('adminisztratorok/ruha_atado/menu_admin')
</div>


<div class="row">
        <div class="col-6 col-md-6">
                <div class="card my-3">
                    <div class="card-body">
                            <table class="table table-striped table-hover">
                                    <tr>
                                            <th>Ruha neve</th>
                                            <td>{{$ruha->ruhaNeve}} </td>
                                    </tr>
                                    <tr>
                                            <th>Összes</th>
                                            <td> {{$ruha->keszlet + $ruha->kiosztva}} </td>
                                    </tr>
                                    <tr>
                                            <th>Készleten</th>
                                            <td><span id="dressstockin">{{$ruha->keszlet}}</span> </td>
                                    </tr>
                                    <tr>
                                            <th>Kiosztva</th>
                                            <td><span id="dressstockout">{{$ruha->kiosztva}}</span> </td>
                                    </tr>
                            </table>


                    </div>
                </div>
            </div>

            <div class="col-6 col-md-6">
                <div class="card my-3">
                    <div class="card-body">
                                <p><b style="font-size: 16px;">Önkéntes keresése</b></p>
                            <form id="search" ction="{{route('RuhaAtado.Validalas')}}" method="GET" enctype="multipart/form-data" >
                                @csrf
                                <div class="form-group">
                                         
                                        <input value="{{request()->onkentes_neve}}" type="text" class="form-control col-12 col-md-6 my-2" id="onkentes_neve" name="onkentes_neve"  placeholder="Név">
                                </div>
                            
                                <div class="form-group">
                                       
                                        <input type="email" id="volemail" name="volemail" value="{{request()->volemail}}"  class="form-control col-12 col-md-6 my-2 " placeholder="E-mail cím alapján">
                                </div>
                                <div class="form-group">
                                        <input type="hidden" name="ruhaid" value={{$ruha->id}}>
                                        <input type="submit"  class="btn btn-primary" >
                                </div>
                            </form>

                    </div>
                </div>
            </div>

</div>

<div class="row">
        <div class="col-12">
                <div class="card">
                         <h6 style="margin-top: 20px;"></h6>
                    <div class="card-body">
                                <table class="table table-striped table-hover">
                                <thead>
                                <tr>
                                <th>Profilkep</th>
                                <th>Név/E-mail</th>
                                <th>Profil állapot</th>
                                <th>Profilkép validálva</th>
                                <th>Adatlap</th>
                                <th>Nyilatkozat nyomtatás</th>
                                <th>Nyilatkozat nyomtatás2</th>
                                <th></th>
                                </tr>
                                </thead>
                                <tbody>
                                @isset($talalat)
                                        @foreach ($talalat as $user)
                                            <tr>
                                                <td>{{$user['nev']}}</td>
                                                <td>{{$user['email']}}</td>
                                                <td>
                                                        @if($user['profilvalid'] )
                                                               <span class="material-icons" style="color:green;"> check_circle</span> 
                                                        @else
                                                                <span class="material-icons" style="color:red;">remove_circle</span> 
                                                        
                                                        @endif
                                                </td>
                                                <td>
                                                        @if($user['profilkepvalid'] )
                                                               <span class="material-icons" style="color:green;"> check_circle</span> 
                                                        @else
                                                                <span class="material-icons" style="color:red;">remove_circle</span> 
                                                        
                                                        @endif
                                                </td>
                                                <td>
                                                        <a target="_blank" href="{{url('/admin/onkentes_szerkesztese/'.$user['id'])}}">
                                                                <span class="material-icons" style="color:blue;">contact_page</span> 
                                                        </a>
                                                </td>
                                                <td>
                                                        <span class="material-icons">print</span>
                                                </td>
                                                <td>
                                                        <span class="material-icons">print</span>
                                                </td>
                                                <td>
                                                        @if($user['atadva'])
                                                               <button class="btn btn-warning" disabled >Átadva</button>
                                                        @else
                                                                @if($user['profilvalid'] )
                                                                <button class="btn btn-primary" id="atadvabtn-{{$user['id']}}" onclick="UserDressAdd({{$user['id']}});">Átadás</button>
                                                                @else
                                                                        <button class="btn btn-primary" disabled >Átadás</button>
                                                        
                                                                @endif
                                                          @endif

                                                        
                                                        </td>
                                            </tr>
                                        @endforeach
                                        
                                @endisset
                                        
                                </tbody>
                                <div>
                                         @if(isset($talalat))
                                                {{$talalat->links()}}
                                        @endif
                                </div>
                        </div>
                </div>
        </div>
       
</div>

<div class="row">
        <div class="col-12">
        
                         <div class="card">
                <div class="card-body">
                        <table class="table table-striped table-hover">
                                <thead>
                                <tr>
                                        
                                        <th>Név/E-mail</th>
                                        <th>Átadás ideje</th>
                                        <th>Visszavételezés Ideje</th>
                                        <th></th>
                                </tr>
                                </thead>
                                <tbody>
                                        @isset($atadva)
                                                @foreach ($atadva as $User)
                                                        <tr>
                                                                <td>{!! $User['nev'] !!}</td>
                                                                <td>{{$User["atadasIdeje"]}}</td>
                                                                <td>{{$User["visszaIdeje"]}}</td>
                                                                <td>
                                                                        @if($User["visszaIdeje"] != '')
                                                                               <button class="btn btn-primary" disabled >Visszavéve</button>
                                                                        @else
                                                                          <button class="btn btn-primary" id="visszabtn-{{$User['id']}}" onclick="UserDressRemove({{$User['id']}});">Visszavétel</button>
                                                                           
                                                                        @endif
                                                                </td>
                                                        </tr>
                                                @endforeach
                                        @endisset
                                        
                                        
                                </tbody>
                                </table>
                </div>
        </div>
        
       
</div>


<script>
        function UserDressAdd(itemid){
    	let dress_id = {{ $ruha->id }};
        $.ajax({
            type:'POST',
            url:'{{url('UserAddToDress')}}',
            data:{_token: '<?php echo csrf_token() ?>', uid:itemid,did: dress_id},
            success:function(data) {
                
            }
        });

        $.ajax({
				type:'POST',
				url:'{{url('MailARuhaAtadasrol')}}',
				data:{_token: '<?php echo csrf_token() ?>', uid: itemid },
				success:function(data) {
                    console.log(data);
					if (data == 1) {
                        $('#atadvabtn-'+itemid).addClass('disabled').html('Értesítve');
					}
				}
			});


    }

     function UserDressRemove(itemid)
    {
    	let dress_id =  {{ $ruha->id }};
        $.ajax({
				type:'POST',
				url:'{{url('UserRemoveToDress')}}',
				data:{_token: '<?php echo csrf_token() ?>', uid: itemid ,did: dress_id},
				success:function(data) {
					if (data == 1) {
						 $('#visszabtn-'+itemid).addClass('disabled').html('Visszéve');
					}
				}
			});

    }
</script>

@endsection