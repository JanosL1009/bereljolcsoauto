
@extends('layouts.admin')

@section('htmlhead')

<style>
    .bgColor_Red {background-color: red;}
</style>

@endsection

@section('content')
<div class="row">
        <div class="col-12 d-flex justify-content-between">
          <h1>{{$model->esemenyNeve}}  részletei</h1>
        </div>
        <div class="col-12 d-flex justify-content-end">
                <button type="button" class="btn btn-primary">Program szerkesztése</button>
                <button type="button" class="btn btn-primary">+ Új terület hozzáadása</button>
                <button type="button" class="btn btn-primary bgColor_Red">Törlés</button>
        </div>



        <div class="col-12 col-md-6">
              <div class="card my-3">
                      <div class="card-body">
                      <form>
                              <h3 class="colorGr" style="color:green;">Jelentkezzen szereplőnek!</h3>
                              <h5 class="colorGr" style="color:green;">#Passió2020</h5>
                              <p style="font-size: 12px;">
                                      A Passió2020 Európa legnagyobb Passiójátéka, mely 2020. április 4-én, szombaton, 15:00 és 17:00 órai kezdettel kerül bemutatásra a budapesti Papp László Sportarénában 2020 önkéntes közreműködésével.  </p>
                              <p style="font-size: 12px;">
                                      Főszereplőnk egy mai 25 éves fiatalember szemszögén mutatja be Jézus történetét. Az önkéntes szereplők jelmezes résztvevőként a történetbeli Jeruzsálem népét játsszák a Passióban. A közreműködéshez semmilyen előképzettségre nincs szükség, de a részvétel feltétele a próbákon való részvétel, melynek dátumai: 2020 március 21. szombat 9:00-14:00; március 28. szombat 9:00-14:00; április 3. péntek 2x3 óra 9:00-16:00 óra. </p>
                              <p style="font-size: 12px;">
                                      Önkénteseinknek ajándékcsomaggal készülünk, a próbák ideje alatt étkezést biztosítunk. Jelentkezés alsó korhatára: 12 éves kor. Várunk családokat, baráti társaságokat, munkahelyi és vallási közösségeket is! </p>
                      </form>
                    </div>
                    </div>

          <div class="card my-3">
            <div class="card-body">
            <form>
              <div class="form-group">
              </div>
            <div class="row">
              <div class="form-group col-6">
                <label for="dtp_input2" class="control-label">Kezdés dátuma</label>
                <div class="input-group date form_date " data-date="" data-date-format="yyyy MM dd" data-link-field="dtp_input2" data-link-format="yyyy-mm-dd">
                  <input class="form-control" type="text" value="{{$model->kezdesDatuma}}" readonly>
                  <span class="input-group-addon"><span class="glyphicon glyphicon-remove"></span></span>
                            <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span>
                </div>
                        <input type="hidden" id="dtp_input2" value="" />
              </div>
              <div class="form-group col-6">
                <label for="dtp_input3" class="control-label">Kezdés ideje</label>
                <div class="input-group date form_time " data-date="" data-date-format="hh:ii" data-link-field="dtp_input3" data-link-format="hh:ii">
                  <input class="form-control" type="text" value="{{$model->kezdesIdeje}}" readonly>
                  <span class="input-group-addon"><span class="glyphicon glyphicon-remove"></span></span>
                            <span class="input-group-addon"><span class="glyphicon glyphicon-time"></span></span>
                </div>
                        <input type="hidden" id="dtp_input3" value="" />
              </div>
            </div>

            <div class="row">
              <div class="form-group col-6">
                <label for="dtp_input2" class="control-label">Befejezés dátuma</label>
                <div class="input-group date form_date " data-date="" data-date-format="yyyy MM dd" data-link-field="dtp_input4" data-link-format="yyyy-mm-dd">
                  <input class="form-control" type="text" value="{{$model->befejezesDatuma}}" readonly>
                  <span class="input-group-addon"><span class="glyphicon glyphicon-remove"></span></span>
                            <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span>
                </div>
                        <input type="hidden" id="dtp_input2" value="" />
              </div>
              <div class="form-group col-6">
                <label for="dtp_input3" class="control-label">Befejezés ideje</label>
                <div class="input-group date form_time " data-date="" data-date-format="hh:ii" data-link-field="dtp_input5" data-link-format="hh:ii">
                  <input class="form-control" type="text" value="{{$model->befejezesIdeje}}" readonly>
                  <span class="input-group-addon"><span class="glyphicon glyphicon-remove"></span></span>
                            <span class="input-group-addon"><span class="glyphicon glyphicon-time"></span></span>
                </div>
                        <input type="hidden" id="dtp_input3" value="" />
              </div>
            </div>

            <div class="form-group">
              <label for="inputAddress">Helyszín</label>
              <input type="text" class="form-control" id="" value="{{$model->helyszin}}" readonly>
            </div>

            <div class="form-row">
              <div class="form-group col-md-6">
                <label for="inputPassword4">Igényelt önkéntes létszám</label>
                <input type="number" class="form-control" id="" values="{{$model->igenyeltOnkentesLetszam}}" readonly>
              </div>
              <div class="form-group col-md-6">
                <label for="inputEmail4" >Jelentkezők száma</label>
                <input type="number" class="form-control" id="" value="{{$model->jelentkezokSzama}}" readonly>
              </div>
            </div>
<!--
            <div class="form-group">
              <label for="inputAddress">Csoportvezető</label>
              <input type="text" class="form-control" id=""><br>
              <input type="text" class="form-control" id=""><br>
              <input type="text" class="form-control" id=""><br>
              <input type="text" class="form-control" id="">
            </div>


              <div class="form-group">
                <label for="exampleFormControlTextarea1">Leírás</label>
                <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
              </div>
          -->
            </form>
          </div>
          </div>
        </div>

        <div class="col-12 col-md-6">
          <div class="card my-3">
            <div class="card-body">
              <form>
                <div class="form-group">
                  <label for="inputPassword4">Területek</label>
                  @php
                  //$teruletek = $model->Teruletek;
                  @endphp

                </div>
              </form>
            </div>
          </div>

        </div>

      </div>


@endsection
