@extends('layouts.admin')

@section('htmlhead')

<title>NEK ÖMR - Új hírlevél készítő </title>

<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/css/bootstrap-select.css" />


<style>
      .form-error{ color: #ff0000; }  .bootstrap-select:not([class*="col-"]):not([class*="form-control"]):not(.input-group-btn) { width: 100%!important; }
</style>

@endsection

@section('content')
<div class="row">
    <div class="col-12 d-flex justify-content-between">
            <h1>Új hírlevél létrehozása</h1>
    </div>
</div>

<div class="row">

    <div class="card my-3 col-12 col-md-6">

            <div class="card-body">
                <form action="#" method="POST" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="Hírlevél neve">Hírlevél neve</label>
                        <input type="text" class="form-control" id="hirlevelNeve" name="hirlevelNeve">
                    </div>

                    <div class="form-group">
                        <label for="dtp_input2" class="control-label">Kapcsolódó program</label>
                            <select class="selectpicker" multiple  data-live-search="true" id="kapcsolodoProgram" name="kapcsolodoProgram" data-validation="required">
                                <option  disabled value selected>--- Kérem válasszon ---</option>

                            </select>
                            <input type="hidden" id="relatedprograms" name="relatedprograms" value="">
                      </div>

                    <div class="form-group">
                        <label for="Hírlevél tartalma">Tartalom</label>
                        <textarea class="form-control" id="hirlevelTartalma" name="hirlevelTartalma"></textarea>
                    </div>



                    <div class="form-group col-md-6 p-0">
                        <label for="Státusz">Státusz</label>
                        <select class="custom-select" id="HirlevelStatusza" name="HirlevelStatusza" data-validation="required">
                          <option value="0" selected disabled>Válassz ...</option>
                          <option value="1">Aktiv</option>
                          <option value="2">Inaktív</option>
                        </select>
                      </div>


                    <div class="form-grouop">
                        <input type="submit" class="btn btn-primary" value="Létrehozás">
                    </div>
                </form>
            </div>

    </div>
</div>

@endsection

@section('scriptsection')
    <script src="//cdn.ckeditor.com/4.14.0/standard/ckeditor.js" rel="dns-prefetch"></script>
    <script>

        CKEDITOR.replace( 'hirlevelTartalma',{
            filebrowserBrowseUrl: '/omr_nek/public/ckfinder/ckfinder.html',
	        filebrowserUploadUrl: '/omr_nek/public/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files'
        });
        </script>


<script src="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.9/dist/js/bootstrap-select.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.9/js/i18n/defaults-hu_HU.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/js/all.min.js"></script>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css">
<script type="text/javascript">
    var relatedprograms = [];
    $('.selectpicker').change(function(){
        $('#relatedprograms').val($('#kapcsolodoProgram').val());
    });
 </script>
@endsection
