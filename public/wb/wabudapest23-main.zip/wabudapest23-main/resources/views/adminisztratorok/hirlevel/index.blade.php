@extends('layouts.admin')


@section('content')
    <div class="row">
        <div class="col-12 d-flex justify-content-between">
                <h1>Hírlevélküldés</h1>
        </div>
        <div class="col-9 d-flex justify-content-center ">
            <div class="gombok">
                <button type="button" id="submenu-item1-permission" class="btn btn-primary"><a href="#">Összes</a></button>
            </div>
        </div>
        <div class="col-3 d-flex justify-content-end">
            <button type="button" class="btn btn-primary"><a href="{{url('/admin/ujhirlevel')}}">+ Új hírlevél</a></button>
          </div>
    </div>


    <div class="card my-3">
        <div class="card-body">
        <div class="table-wrapper">

                @php
                    // $rendezvenyek = $model->rendezveny;
                     //dd($rendezvenyek);
                @endphp

            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>
                            <span class="custom-checkbox">
                                <input type="checkbox" id="selectAll">
                                <label for="selectAll"></label>
                            </span>
                        </th>
                        <th>Hírlevél neve
                          <a href="{{asset('admin/hirlevel/nev/asc')}}" class="szuro">
                            <span class="material-icons">expand_less</span>
                          </a>
                          <a href="{{asset('admin/hirlevel/nev/desc')}}" class="szuro">
                            <span class="material-icons">expand_more</span>
                          </a>
                        </th>
                        <th>Státusz </th>
                        <th>Műveletek</th>
                    </tr>
                </thead>
                <tbody>


                    <tr data-eid="">
                        <td>
                            <span class="custom-checkbox">
                                <input type="checkbox" id="checkbox1" name="options[]" value="1">
                                <label for="checkbox1"></label>
                            </span>
                        </td>
                        <td data-label="Hírlevél neve"></td>
                        <td  data-label="Státusz"></td>
                        <td data-label="Műveletek">
                            <a href="{{url('admin/hirlevel_szerkesztes/')}}" class="edit" ><i class="material-icons" data-toggle="tooltip" title="Módosítás">&#xE254;</i></a><!-- ezt paraméteresíteni! -->
                            <a href="#deleteEmployeeModal" class="delete" data-toggle="modal"><i class="material-icons deltool" data-toggle="tooltip" title="Törlés" data-valesid="">&#xE872;</i></a>

                        </td>
                    </tr>



                </tbody>
            </table>





            <div class="clearfix float-left">

            </div>
        </div>
    </div>
</div>



@endsection
