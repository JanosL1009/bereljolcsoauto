@extends('layouts.admin')

@section('content')

<div class="row">
    <div class="col-12 d-flex justify-content-between">
        <h1>Élő közvetítés nézettségi adatok</h1>
    </div>
</div>

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <p style="font-size: 18px;font-weight: bold;">Összes néző: {{$allviewer}}</p>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-12 ">
        <div class="card">
            <div class="card-body">
                <table class="table">
                  
                    <thead>
                      <tr>
                        <th scope="col">#</th>
                        <th scope="col">Név</th>
                        <th scope="col">Megtekintés hossza</th>
                      </tr>
                    </thead>
                    <tbody>
                        @php
                            $i = 0;
                        @endphp
                        @foreach ($ytpplayedstats as $stat)
                        <tr>
                            <th scope="row">{{$i}}</th>
                            <td>{{$stat["name"]}}</td>
                            <td>{{$stat['allplayedmin']}}</td>
                           
                        </tr>
                        @php
                        $i = $i + 1;
                        @endphp
                        @endforeach

                       
                    </tbody>
                  </table>
            </div>
        </div>
    </div>
</div>

@if(isset($ytpplayedstats))
<div class="row">
    <div class="col-12">
        <div>
           
             {{$ytpplayedstats->links()}}
         
        
        </div>
    </div>

</div>
@endif

@endsection