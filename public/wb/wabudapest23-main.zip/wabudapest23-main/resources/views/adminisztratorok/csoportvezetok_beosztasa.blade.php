@extends('layouts.admin')

@section('content')



    <div class="row">
            <div class="col-12 d-flex justify-content-between">
                    <h1>Csoportvezető beosztás  </h1>
            </div>
            <div class="col-12 d-flex ">
                    <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                              {!! $model->breadcrumblink !!}
                            </ol>
                     </nav>
            </div>

    </div>

    <div class="row">
        <div class="col-12 col-md-12">
            <div class="card my-12">
                <div class="card-body">
                     <p>INFORMÁCIÓ! Csoportvezetőt kizárólag a csoportba beosztottak közül lehet kinevezni!</p>
                </div>
            </div>
        </div>
    </div>

    <div class="row">

            <div class="col-12 col-md-12">
	<div class="card my-3">
		<div class="card-body">



			<div class="row">
				<div class="col-12 d-flex justify-content-between">
					<h1>Csoportvezető(k) beosztása</h1>
				</div>
			</div>
			<div class="container2">


				<div class="row">

					<div class="col-12 col-md-6">
						<div class="card my-3">
							<div class="card-body" style="height:600px;overflow-y:scroll;">

								<div class="form-group">
									<h5>
										Jelentkezők
									<!--	<input id="searchOthers" style="padding: 3px 10px;" type="text" placeholder="Továbbiak keresése.." /> -->
									</h5>
									<table class="table table-striped table-hover" id="teruletVezetok">
										<thead>
											<tr>
												<th>
													<span class="custom-checkbox">
														<input type="checkbox" id="selectAll">
														<label for="selectAll"></label>
													</span>
												</th>

												<th>Név</th>
												<th>Műveletek</th>

											</tr>
										</thead>
										<tbody class="addAbleMore"></tbody>
										<tbody style="border-top: 3px solid #333" class="addAble"></tbody>
									</table>
								</div>
							</div>
						</div>
					</div>


					<div class="col-12 col-md-6">
						<div class="card my-3">
							<div class="card-body" style="height:600px;overflow-y:scroll;">

								<div class="form-group">
									<h5 >Csoportvezető beosztva</h5>
									<table id="teruletbeosztva" class="table table-striped table-hover">
										<thead>
											<tr>
												<th>
													<span class="custom-checkbox">
														<input type="checkbox" id="selectAll">
														<label for="selectAll"></label>
													</span>
												</th>

												<th>Név</th>
												<th>Műveletek</th>

											</tr>
										</thead>
										<tbody class="added"></tbody>
									</table>
								</div>
							</div>
						</div>
					</div>

				</div>



			</div>
		</div>
	</div>
</div>





        </div>


        <script>

            var felhasznalok = [
                @foreach($model->CsoportTagok as $user){'id': '{{$user->id}}','name': '{{$user->name}}'}, @endforeach
            ];

            var users = [
                @foreach($model->CsoportTagok as $user){'id': '{{$user->id}}','name': '{{$user->name}}'}, @endforeach

            ].map(function(elem) {

                var birthText = 'Nincs megadva';
                var addressText = 'Nincs megadva';

                var birth = felhasznalok.find(element => element.email == elem.email);

                if(birth){
                    birthText = birth.birth;
                    addressText = birth.address;
                }

                return {
                    'id': parseInt(elem.id),
                    'name': elem.name,
                    'email': elem.email,
                    'birth': birthText,
                    'address': addressText
                };
            });



            var szervezokArray = [

                @foreach($model->jelentkezokLista as $sz)
                    {{$sz->felhasznalo_id}},
                @endforeach

            ];



             var selectedSzervezokArray = [

                @foreach(\DB::table('esemeny_szervezok')->where('csoport_id','=',$model->csoportID)->where('szint_id',5)->get() as $sz)
                    {{$sz->felhasznalo_id}},
                @endforeach

            ];

            var renderElements = function(){

                $('.addAble').html(users.map(function(elem) {
                    if( szervezokArray.includes( parseInt(elem.id) )
                        && !selectedSzervezokArray.includes(elem.id)
                         )
                    return `

                    <tr id="`+elem.id+`" >
                        <td>
                            <span class="custom-checkbox">
                                <input type="checkbox" id="checkbox1" name="options[]" value="`+elem.id+`">
                                <label for="checkbox1"></label>
                            </span>

                        </td>
                        <td>
                            <span title="`+elem.birth+` - `+elem.address+`" class="pointer" onclick="ShowProfile(`+elem.id+`)">`+elem.name+`</span></td>
                        <td>
                            <i class="material-icons add_box pointer"  data-toggle="tooltip"  data-uid="`+elem.id+`" onclick="UserEventAdd(`+elem.id+`)">add_box</i>
                        </td>
                    </tr>

                    `;
                }));

                $('.added').html(users.map(function(elem) {
                    if(selectedSzervezokArray.includes( parseInt(elem.id) ))
                    return `

                    <tr id="group`+elem.id+`">
                        <td>
                            <span class="custom-checkbox">
                                <input type="checkbox" id="checkbox1" name="options[]" value="`+elem.id+`">
                                <label for="checkbox1"></label>
                            </span>
                        </td>
                        <td><span title="`+elem.birth+` - `+elem.address+`" class="pointer">`+elem.name+`</span></td>

                        <td>
                            <i class="material-icons remove pointer"  data-toggle="tooltip"  data-uid="`+elem.id+`" onclick="UserEventRemove(`+elem.id+`)" title="Eltávolít" >close</i>

                        </td>
                    </tr>

                    `;
                }));


            }

            renderElements();


            $(document).on('keyup', '#searchOthers', function(){
                var searchString = $(this).val();
                if(searchString.length > 2){

                    $('.addAbleMore').html(users.map(function(elem) {
                        if(
                            (elem.name.toLowerCase().includes(searchString.toLowerCase()) || elem.email.toLowerCase().includes(searchString.toLowerCase()))
                            && !selectedSzervezokArray.includes(elem.id)
                            )
                        return `

                        <tr id="`+elem.id+`">
                            <td>
                                <span class="custom-checkbox">
                                    <input type="checkbox" id="checkbox1" name="options[]" value="`+elem.id+`">
                                    <label for="checkbox1"></label>
                                </span>

                            </td>
                            <td><span title="`+elem.birth+` - `+elem.address+`" class="pointer">`+elem.name+`</span></td>

                            <td>
                                <i class="material-icons add_box pointer"  data-toggle="tooltip"  data-uid="`+elem.id+`" onclick="UserEventAdd(`+elem.id+`)">add_box</i>
                            </td>
                        </tr>

                        `;
                    }));

                } else{
                    $('.addAbleMore').html('');
                }

            })



            function UserEventAdd(itemid){


                // Ha kell:
                var terulet_id = {{$model->teruletID}};
                // A terület id-t szúrd be az esemeny_id mezőbe és akkor a szint alapján lehet szűrni, hogy az most területet eseményt vagy csoportot jelent, csak akkor a törlésnél is figyelni kell, hogy csak azt a szintet törölje (Most így kértem le 150.sorban)

                $.ajax({
                    type:'POST',
                    url:'{{url('CsopVezBeosztas')}}',
                    data:{_token: '<?php echo csrf_token() ?>', tid:terulet_id,uid:itemid,csid:{{$model->csoportID}}},
                    success:function(data) {
                        if (data ==1 ) {
                                        selectedSzervezokArray.push(itemid);
                                        renderElements();
                                    }
                        console.log(data);
                    }
                });

                // Ajax Siker esetén fusson le:
                //selectedSzervezokArray.push(itemid);
                //renderElements();


            }
            function UserEventRemove(itemid)
            {

                var csop_id = {{$model->csoportID}};
                $.ajax({
                        type:'POST',
                        url:'{{url('CsopVezUserRemove')}}',
                        data:{_token: '<?php echo csrf_token() ?>', gid: csop_id ,uid:itemid},
                        success:function(data) {
                            if (data == 1) {
                                selectedSzervezokArray = selectedSzervezokArray.filter(id => id !== itemid);
                                renderElements();
                            }

                        }
                    });

            }

        </script>












            <script type="text/javascript">
                $(document).ready(function(){
                    // Activate tooltip
                    $('[data-toggle="tooltip"]').tooltip();

                    // Select/Deselect checkboxes
                    var checkbox = $('table tbody input[type="checkbox"]');
                    $("#selectAll").click(function(){
                        if(this.checked){
                            checkbox.each(function(){
                                this.checked = true;
                            });
                        } else{
                            checkbox.each(function(){
                                this.checked = false;
                            });
                        }
                    });
                    checkbox.click(function(){
                        if(!this.checked){
                            $("#selectAll").prop("checked", false);
                        }
                    });
                });
                </script>

@include('assets.beosztasRovidProfile')

@endsection
