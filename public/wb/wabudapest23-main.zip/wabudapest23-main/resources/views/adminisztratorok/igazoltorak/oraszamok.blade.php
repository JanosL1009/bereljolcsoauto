@extends('layouts.admin')


@section('content')
        <div class="row">
          <div class="col-12 d-flex justify-content-start">
            <h1>Igazolt órák -{{$user->name??''}} - {{$esemeny->csoport_data->nev??''}}</h1>
            </div>
          </div>  


      <div class="row">
          <div class="col-4 col-md-4">
            <div class="card my-8">
              <div class="card-body">
                <table class="table table-striped">
                    
                    <tbody>
                         <tr>
                            <th>Rendezvény neve</th>
                            <td>{{$esemeny->esemeny_data->nev??''}}</td>
                         </tr>

                          <tr>
                            <th>Kezdete</th>
                            
                            <td>{{$esemeny->esemeny_data->kezdesDatum??''}}</td>
                            
                         </tr>

                         <tr>
                            <th>Vége</th>
                            <td>{{$esemeny->esemeny_data->befejezesDatum??''}}</td>
                         </tr>

                    </tbody>
                  </table>

                  
                 
                   
               </div>
            </div>
          </div>


          <div class="col-4 col-md-4">
            <div class="card my-8">
              <div class="card-body">
                <table class="table table-striped">
                    
                    <tbody>
                         <tr>
                            <th>Terület neve</th>
                            <td>{{$esemeny->terulet_data->nev??''}}</td>
                         </tr>

                          <tr>
                            <th>Kezdete</th>
                            
                            <td>{{$esemeny->terulet_data->kezdesIdopont??''}}</td>
                            
                         </tr>

                         <tr>
                            <th>Vége</th>
                            <td>{{$esemeny->terulet_data->befejezesIdopont??''}}</td>
                         </tr>

                    </tbody>
                  </table>

                  
                 
                   
               </div>
            </div>
          </div>



          <div class="col-4 col-md-4">
            <div class="card my-8">
              <div class="card-body">
                <table class="table table-striped">
                    
                    <tbody>
                         <tr>
                            <th>Csoport neve</th>
                            <td style="color:red;font-weight:bold;">{{$esemeny->csoport_data->nev??''}}</td>
                         </tr>

                          <tr>
                            <th>Kezdete</th>
                            
                            <td>{{$esemeny->csoport_data->kezdesDatuma??''}}</td>
                            
                         </tr>

                         <tr>
                            <th>Vége</th>
                            <td>{{$esemeny->csoport_data->befejezesDatuma??''}}</td>
                         </tr>

                    </tbody>
                  </table>

                  
                 
                   
               </div>
            </div>
          </div>



        </div>

       
            <div class="row mt-5">
                <div class="col-12 col-md-12">
                    <div class="card">
                        <div class="card-body">
                            
                                 <table class="table table-striped">

                    <thead>
                            <tr>
                                <th>Dátum</th>
                                <th>Igazolt óra</th>
                                <th></th>
                            </tr>
                    </thead>

                    <tbody>
                          @isset($orak)
                            @foreach($orak as $ora)
                                  @isset($ora)
                                    <tr>
                                      <td>{{$ora->muszakdatum_data->csoport_date??''}}</td>
                                      <td>{{$ora->teljesitettOraszam??''}}</td>
                                      <td>
                                      @isset($ora->teljesitettOraszam) 
                                        @if($ora->teljesitettOraszam == 0)
                                                  Hiányzás
                                          @else 
                                                  Megjelent
                                          @endif
                                      @endisset
                                       
                                      </td>
                                  </tr>
                                  @endisset
                          
                            @endforeach
                          @endisset

                        
                    </tbody>
                  </table>
                           
                        </div>
                    </div>
                </div>
            </div>

@endsection


