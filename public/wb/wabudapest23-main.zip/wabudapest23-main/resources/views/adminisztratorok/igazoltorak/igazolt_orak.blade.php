@extends('layouts.admin')


@section('content')
        <div class="row">
          <div class="col-12 d-flex justify-content-start">
            <h1>Igazolt órák - {{$user->name}}</h1>
            </div>
          </div>  


      <div class="row">
          <div class="col-12 col-md-12">
            <div class="card my-8">
              <div class="card-body">
                <table class="table table-striped">
                    <thead>
                      <tr>
                        <th>
                          Rendezvény neve
                        </th>
                        <th>Terület</th>
                        <th>Csoport</th>
                        
                        <th></th>
                      </tr>
                    </thead>
                    <tbody>
                    @isset($esemenyek) 
                        @foreach($esemenyek as $esemeny) 

                          @isset($esemeny->csoport_data->id) 
                            @isset($esemeny->terulet_data->nev ) 
                              <tr>
                              <td>{{$esemeny->esemeny_data->nev??''}}</td>
                              <td>{{$esemeny->terulet_data->nev??''}}</td>
                              <td>{{$esemeny->csoport_data->nev??''}}</td>
                              
                              <td><a target="_blank" class="btn btn-link" href="{{url('admin/igazolt_orak/oraszamok/'.$esemeny->csoport_data->id.'/'.$user->id)}}">Megtekintés</a></td>
                          </tr>
                            @endisset
                          @endisset
                          
                         
                        @endforeach
                    @endisset
                       

                    </tbody>
                  </table>

                  
                 
                   
            </div>
            </div>
          </div>



        </div>

        @if($esemenyek->links())
              <div class="row">
                  <div class="col-12">
                    {{$esemenyek->links()}}
                  </div>
              </div>
        @endif


@endsection


