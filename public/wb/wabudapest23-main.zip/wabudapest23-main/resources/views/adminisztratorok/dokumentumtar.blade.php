@extends('layouts.admin')

@section('content')
<div class="row">

    <div class="col-12">
      <div class="card my-3">
        <div class="card-body">
        <form action="{{url('admin/dokumentumtar/docuploads')}}" method="POST" enctype="multipart/form-data" id="doc_upload" name = "doc_upload">
          @csrf
          <div class="form-row">
            <div class="form-group col-md-4">
              <label for="inputEmail4">Dokumentum neve</label>
              <input type="text" class="form-control" id="dokumentumNeve" name="dokumentumNeve" data-validation="required">



            </div>
            <div class="form-group col-md-4">
                <label for="inputEmail4">Megjelenés</label>
                <select class="form-control" id="doksimegjelenes" required="true" name="doksimegjelenes">
                    <option value disabled selected>-- Hol jelenjen meg? --</option>
                    <option value="0">Önkéntesek / Adminisztrátorok</option>
                    <option value="1">Adminisztrátorok</option>

                </select>
              </div>
              <div class="form-group col-md-2 d-flex align-items-end">
                    <input type="file" required="true" class="form-control" id="file" name="file" >

              </div>
                <div class="form-group col-md-2 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary">Feltöltés</button>
                </div>
          </div>

          @if($errors->has('file'))
            <div class="alert alert-danger">A fájl nem lehet nagyobb mint 10MB.</div>
          @endif

        </form>
      </div>
      </div>
    </div>

    <div class="col-12">
      <div class="card my-3">
        <div class="card-body">
          <form method="GET">
            <div class="row">
              <div class="col-12 col-md-8">
                <input class="form-control" type="text" id="searchName" name="searchName" value="{{request()->searchName}}" placeholder="Szűrés névre" />

              </div>
              <div class="col-12 col-md-2">
                <input type="checkbox" {{ request()->searchAdmin?'checked="true"':'' }} name="searchAdmin"> Csak admin
              </div>
              <div class="col-12 col-md-2">
                <button class="btn btn-success">Szűrés</button>
              </div>
            </div>
          </form>

        </div>
      </div>
    </div>

    <div class="col-12 col-md-12">
      <div class="card my-3">
        <div class="card-body">
        <form>
                  <div class="row">
                    <div class="col-12 d-flex justify-content-between">
                      <h1>Dokumentumtár</h1>
                    </div>
                  </div>
                  <div class="container2">
                          <div class="table-wrapper">
                            <div class="d-flex justify-content-end">
                                <div class="d-inline-block dropdown">
                                  <button type="button" data-toggle="dropdown" id="rendezesek" aria-haspopup="true" aria-expanded="false" class="btn-shadow btn btn-primary">
                                    Rendezés
                                  </button>
                                  <div tabindex="-1" role="menu" aria-hidden="true" class="dropdown-menu dropdown-menu-right">
                                    <ul class="nav flex-column">
                                      <li class="nav-item">
                                        <a href="{{url('admin/dokumentumtar/docname/asc')}}" class="szuro nav-link">
                                          Név szerinti rendezés +
                                        </a>
                                      </li>
                                      <li class="nav-item">
                                        <a href="{{url('admin/dokumentumtar/docname/desc')}}" class="szuro nav-link">
                                          Név szerinti rendezés -
                                        </a>
                                      </li>
                                      <li class="nav-item">
                                        <a href="{{url('admin/dokumentumtar/upload/asc')}}" class="szuro nav-link">
                                          Idő szerinti rendezés +
                                        </a>
                                      </li>
                                      <li class="nav-item">
                                        <a href="{{url('admin/dokumentumtar/upload/desc')}}" class="szuro nav-link">
                                          Idő szerinti rendezés -
                                        </a>
                                      </li>
                                      <li class="nav-item">
                                        <a href="{{url('admin/dokumentumtar/visibility/asc')}}" class="szuro nav-link">
                                          Láthatóság szerinti rendezés -
                                        </a>
                                      </li>
                                      <li class="nav-item">
                                        <a href="{{url('admin/dokumentumtar/visibility/desc')}}" class="szuro nav-link">
                                            Láthatóság szerinti rendezés -
                                        </a>
                                      </li>
                                    </ul>
                                  </div>
                                </div>

                              </div>
                              <table class="table table-striped table-hover">
                                  <thead>
                                      <tr>
                                          <th>Dokumentum neve </th>
                                          <th>Feltöltés ideje</th>
                                          <th>Láthatóság</th>
                                          <th>Művelet</th>
                                      </tr>
                                  </thead>
                                  <tbody>


                            @foreach ($model->documentsList as $doc )
                                          <tr>

                                                <td data-label="Dokumentum neve">
                                                  <a href="{{url('/public/files/raw/'.$doc->real_docname)}}" target="_blank">
                                                    {{$doc->docname}}
                                                  </a>
                                                </td>
                                                <td data-label="Feltöltés ideje">{{$doc->uploaded_at}}</td>
                                                @if($doc->visibility_id == 0)
                                                    <td data-label="Láthatóság">{{'Önkéntes/Admin'}}</td>
                                                @else
                                                    <td data-label="Láthatóság">{{'Adminisztrátorok'}}</td>
                                                @endif


                                         <td data-label="Művelet">
                                                <a href="#deleteEmployeeModal" class="delete" data-toggle="modal"><i class="material-icons deltool" id="{{$doc->doc_id}}" data-toggle="tooltip" title="Törlés" data-valesid="{{$doc->doc_id}}">&#xE872;</i></a>
                                          </tr>
                                          @endforeach
                                  </tbody>
                              </table>
                              <div class="clearfix float-left">

                                        {{ $model->documentsList->appends(["searchName" => request()->searchName])->links() }}

                              </div>
                          </div>
                      </div>



                      <script type="text/javascript">
                          $(document).ready(function(){
                              // Activate tooltip
                              $('[data-toggle="tooltip"]').tooltip();

                              // Select/Deselect checkboxes
                              var checkbox = $('table tbody input[type="checkbox"]');
                              $("#selectAll").click(function(){
                                  if(this.checked){
                                      checkbox.each(function(){
                                          this.checked = true;
                                      });
                                  } else{
                                      checkbox.each(function(){
                                          this.checked = false;
                                      });
                                  }
                              });
                              checkbox.click(function(){
                                  if(!this.checked){
                                      $("#selectAll").prop("checked", false);
                                  }
                              });
                          });
                          </script>
        </form>
      </div>
      </div>
    </div>

  </div>

   <!-- Delete Modal HTML -->
   <div id="deleteEmployeeModal" class="modal fade">
        <div class="modal-dialog">
            <div class="modal-content">

                    <div class="modal-header">
                        <h4 class="modal-title">Dokumentum törlése</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    </div>
                    <div class="modal-body">
                        <p><strong>Biztosan törölni szeretné a dokumentumot?</strong></p>
                        <p class="text-danger">Ha töröl egy dokumentumot, később az adatokat nem tudjuk visszaállítani!</p>
                    </div>
                    <div class="modal-footer">
                        <input type="number" class="d-none" id="esid" name="esid" value="-1">
                        <input type="button" class="btn btn-default" data-dismiss="modal" value="Mégse">
                        <input type="button" id="docTorlesBtn" class="btn btn-danger" value="Törlés">
                    </div>

            </div>
        </div>
    </div>

    <script>
         $('.deltool').click(function(){
                        let v = $(this).data('valesid'); $('#esid').val(v);
        });

        $('#docTorlesBtn').click(function(){
                    let omrr = $('#esid').val();
                        $.ajax({
                                type:'POST',
                                url:'{{url('DocAdminDelete')}}',
                                data:{_token:'<?php echo csrf_token() ?>', _esid:omrr },
                                success:function(data) {
                                    if(data == 'valid') {location.reload();}
                                }
                            });
        });

        $('#searchName').focusout(function(){
            if($('#searchName').val() == '')
            {
                let link = "{{url('admin/dokumentumtar')}}";
                window.location.href = link;
            }
            console.log("dfgdf"+$('#searchName').val());
        });
    </script>

  <script src="{{ asset('js/jquery.form-validator.min.js') }}"></script>
  <script>
     var myLanguage = {

          errorTitle: 'Az űrlap feldolgozása sikertelen.',
          requiredFields: 'You have not answered all required fields',
          badTime: 'You have not given a correct time',
          badEmail: 'You have not given a correct e-mail address',
          badTelephone: 'You have not given a correct phone number',
          badSecurityAnswer: 'You have not given a correct answer to the security question',
          badDate: 'You have not given a correct date',
          lengthBadStart: 'The input value must be between ',
          lengthBadEnd: ' karakter',
          lengthTooLongStart: 'The input value is longer than ',
          lengthTooShortStart: 'Az input érték nem lehet kevesebb, mint ',
          notConfirmed: 'Input values could not be confirmed',
          badDomain: 'Incorrect domain value',
          badUrl: 'The input value is not a correct URL',
          badCustomVal: 'The input value is incorrect',
          andSpaces: ' and spaces ',
          badInt: 'The input value was not a correct number',
          badSecurityNumber: 'Your social security number was incorrect',
          badUKVatAnswer: 'Incorrect UK VAT Number',
          badStrength: 'The password isn\'t strong enough',
          badNumberOfSelectedOptionsStart: 'You have to choose at least ',
          badNumberOfSelectedOptionsEnd: ' answers',
          badAlphaNumeric: 'The input value can only contain alphanumeric characters ',
          badAlphaNumericExtra: ' and ',
          wrongFileSize: 'The file you are trying to upload is too large (max %s)',
          wrongFileType: 'Only files of type %s is allowed',
          groupCheckedRangeStart: 'Please choose between ',
          groupCheckedTooFewStart: 'Please choose at least ',
          groupCheckedTooManyStart: 'Please choose a maximum of ',
          groupCheckedEnd: ' item(s)',
          badCreditCard: 'The credit card number is not correct',
          badCVV: 'The CVV number was not correct',
          wrongFileDim : 'Incorrect image dimensions,',
          imageTooTall : 'the image can not be taller than',
          imageTooWide : 'the image can not be wider than',
          imageTooSmall : 'the image was too small',
          min : 'min',
          max : 'max',
          imageRatioNotAccepted : 'Image ratio is not accepted'
      };

    $.validate({
      language : myLanguage
    });


  </script>


@endsection
