@extends('layouts.admin')

@section('content')

<style>
 a.active{background-color: #f9b104 !important;}
 a.active:hover {
   background: #1e315a!important;
 }
</style>
    <div class="row">

        <div class="col-12 d-flex justify-content-between">
            <h1>Dokumentumok</h1>

            @if($errors->any())
                <h4  class="alert alert-danger" role="alert">{{$errors->first()}}</h4>
            @endif

        </div>


        <div class="col-12 col-md-12">
                  <div class="card my-3">
                    <div class="card-body">
                      <div class="row">
                        <div class="col-12 col-md-8">

                          <form method="get" >
                            <div class="d-flex justify-content-between dataszabalyzo datumkiemeles flex-wrap flex-md-nowrap">
                              <input class="form-control mb-2 mb-md-0" type="text" name="searchName" value="{{request()->searchName}}" placeholder="Szűrés névre" />


                                <select class="form-control mb-2 mb-md-0 radius" name="searchProgram" >
                                    <option selected disabled>Válassz egy rendezvényt</option>
                                    @foreach($programs as $program)
                                        @if(request()->searchProgram == $program->id)
                                            <option selected value="{{$program->id}}">{{$program->nev}}</option>
                                        @else
                                            <option value="{{$program->id}}">{{$program->nev}}</option>
                                        @endif

                                    @endforeach
                                </select>


                              <div class="input-group date form_date mb-2 mb-md-0" data-date="" data-date-format="yyyy MM dd" data-link-field="dtp_input2" data-link-format="yyyy-mm-dd">
                                <input type="text" class="form-control" id="datepicker" name="datepicker" value="" placeholder="Szűrés dátumra">
                                <span class="input-group-addon"><span class="glyphicon glyphicon-remove"></span></span>
                      			    <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span>
                              </div>

                              <button type="submit" class="btn btn-success mx-md-2">Szűrés</button>
                            </div>
                          </form>

                        </div>

                        <div class="col">
                            <a href="#MailModal" class=" btn btn-primary mt-3 mt-md-0" data-toggle="modal" >Hiánypótlásra felszólítás</a>
                           <!--
                          <button type="button" id="" class="btn btn-primary">Hiánypótlásra felszólítás</button>
                           -->
                        </div>
                      </div>

                    </div>
                  </div>
                </div>

    <div class="col-12 col-md-12">

        <div class="card my-3">

            <table class="table table-striped">
                <thead>
                <tr>
                    <th scope="col">Feltöltő
                    <a href="#" class="szuro">
                        <span class="material-icons">expand_less</span>
                      </a>
                      <a href="#" class="szuro">
                        <span class="material-icons">expand_more</span>
                      </a>
                    </th>
                    <th scope="col">Dokumentum neve
                      <a href="{{url('admin/onkentes_dokumentumok/docname/asc')}}" class="szuro">
                        <span class="material-icons">expand_less</span>
                      </a>
                      <a href="{{url('admin/onkentes_dokumentumok/docname/desc')}}" class="szuro">
                        <span class="material-icons">expand_more</span>
                      </a>
                    </th>
                    <th scope="col">
                        Program
                    </th>
                    <th scope="col">Feltöltve
                      <a href="{{url('admin/onkentes_dokumentumok/uploaded/asc')}}" class="szuro">
                        <span class="material-icons">expand_less</span>
                      </a>
                      <a href="{{url('admin/onkentes_dokumentumok/uploaded/desc')}}" class="szuro">
                        <span class="material-icons">expand_more</span>
                      </a>
                    </th>
                    <th scope="col">Műveletek</th>
                </tr>
                </thead>
                <tbody>

                @foreach($documents as $d)
                    @if($d->active == 1)
                        <tr>
                            <td data-label="Feltöltő">{{$d->user?$d->user->name:'-'}}</td>
                            <td data-label="Dokumentum neve" class="szotores"><div>{{substr($d->docname, 5)}}</div></td>
                            <td data-label="Kapcsolodó program">{{$d->esemeny_id??'Általános'}}</td>
                            <td data-label="Feltöltve">{{$d->created_at}}</td>
                            <td data-label="Műveletek" class="muveletek">
                                <div class="pb-2" style="clear: both;">
                                    <a href="{{url($d->docname)}}" target="_blank" class="btn btn-primary btn-block">Letöltés</a>
                                </div>
                                <div>
                                    <a onclick="return confirm('Ez a művelet nem vonható vissza. Biztosan törli?')" href="{{url('/admin/onkentes_dokumentumok_delete/' . $d->id)}}" class="btn btn-danger btn-block">Törlés</a>
                                </div>
                            </td>
                        </tr>
                    @endif
                @endforeach
                </tbody>
            </table>

            {{$documents->appends(["searchName" => request()->searchName])->links()}}
        </div>
    </div>
    </div>

    <div id="MailModal" class="modal fade">
        <div class="modal-dialog">
            <div class="modal-content">

              <form method="post" action="{{url('admin/DocWarning/SendMessage')}}" enctype="multipart/form-data">
                    <div class="modal-header">
                        <h4 class="modal-title">Üzenet küldés</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <select id="warningProgram" name="warningProgram">
                                <option selected disabled>--- Kérjük válassz ---</option>
                                @foreach($programs as $program)
                                    <option value="{{$program->id}}">{{$program->nev}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <div class="form-group" >
                                <label for="exampleFormControlTextarea1">Leírás</label>
                                    <textarea class="form-control" name="MsgContent" id="MsgContent"></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        @csrf
                        <input type="button" class="btn btn-default" data-dismiss="modal" value="Mégse">
                        <input type="submit" id="mailsend" class="btn btn-danger" value="Küldés">
                    </div>
                <form>
            </div>
        </div>
    </div>


    <script src="{{asset('js/datetimepicker-bs4.js')}}" type="text/javascript"></script>
<link href="https://unpkg.com/gijgo@1.9.13/css/gijgo.min.css" rel="stylesheet" type="text/css" />
<script>
  $('#datepicker').datepicker({
    uiLibrary: 'bootstrap4'
  });

</script>

@endsection

@section('scriptsection')
    <script src="https://cdn.ckeditor.com/4.13.1/basic/ckeditor.js"></script>

    <script>
            CKEDITOR.replace( 'MsgContent' );
    </script>
@endsection
