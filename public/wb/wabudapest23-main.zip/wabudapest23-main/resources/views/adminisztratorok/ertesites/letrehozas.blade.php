@extends('layouts.admin')

@section('content')

        <div class="row">
                <div class="col-12 d-flex justify-content-between">
                        <h1>Értesítés létrehozása</h1>
                </div>
        </div>


        <div class="card my-3">
                <div class="card-body">
                <div class="table-wrapper">
                    <form action="{{url('/admin/ertesites/letrehozasafeldolgozo/')}}" method="post" enctype="multipart/form-data" id="ertLetrehozoForm">
                        @csrf
                        <div class="form-group">
                            <label for="nev">Értesítés neve</label>
                            <input type="text" class="form-control col-12 col-md-6 my-2 " maxlength="90" id="ertesitesNeve" name="ertesitesNeve">
                        </div>

                        <div class="form-group">
                            <label for="ErtTart">Értesítés tartalma <span style="padding-left:50px;" id="karakterSzamlaloTartalom">0</span>/250</label>
                            <textarea class="form-control col-12 col-md-6 my-2" id="ertesitesTartalma" name="ertesitesTartalma" maxlength="240" onkeyup="areaCounter();">

                            </textarea>
                         </div>

                         <div class="form-check">

                            <input type="checkbox" class="form-check-input" id="SystemErt" name="SystemErt" onclick="NotificationAllUser();">
                            <label for="AllUser"  class="form-check-label" >Rendszerszintű értesítés</label>
                         </div>

                         <div class="form-group" id="esemenyBox">
                            <label for="Esemeny">Rendezvény </label>
                            <select class="form-control" id="Programok" name="Programok">
                                <option selected disabled value="">--- Válassz egy rendezvényt! ---</option>
                                @foreach($esemenyek as $esemeny)
                                    <option value="{{$esemeny->id}}">{{$esemeny->nev}}</option>
                                @endforeach
                            </select>
                         </div>

                         <div class="form-group" id="teruletBox">
                            <label for="Esemeny">Terület </label>
                            <select class="form-control" id="Teruletek" name="Teruletek">
                                <option selected disabled value="-1">--- Válassz egy területet! ---</option>
                            </select>
                         </div>

                         <div class="form-group" id="csoport">
                            <label for="Esemeny">Csoport </label>
                            <select class="form-control" id="Csoportok" name="Csoportok">
                                <option selected disabled value="-1">--- Válassz egy csoportot! ---</option>
                            </select>
                         </div>

                         <input type="submit" class="btn btn-primary" value="Küldés">

                    </form>
                    <section class="" style="margin-top: 50px;">
                        <h4>Leírás</h4>
                        <p>
                            Az értesítés neve és tartalma kötelező!
                        </p>
                        <p>
                            Az értesítés nevének hossza 90 karakter lehet, de legalább 4!
                        </p>
                        <p>
                            Az értesítés tartalmának hossza 250 karakter lehet, de legalább 4!
                        </p>
                        <p>
                            Ha "Rendszerszintű értesítés"-t bekapcsolod (pipálod), akkor mindeki megkapja az értesítést programtól függetlenül.
                            Ha nem pipálod ki, akkor legalább egy programot ki kell választanod, hogy kiknek küldenéd.
                        </p>
                        <p>
                            Az értesítést azonnal megkapják rendszeren belül. Emailt nem küldünk!
                        </p>
                        <p>
                            TIPP: egy program alatt azonnal oszthatsz ki utasításokat, akár területre vagy csoportra bontva!
                        </p>
                    </section>
                </div>
            </div>
        </div>
@endsection

@section('scriptsection')
       <script>
            function areaCounter()
            {
                let tartalom = document.getElementById("ertesitesTartalma").value;
                document.getElementById('karakterSzamlaloTartalom').innerHTML = (parseInt(250)-parseInt(tartalom.length));
            }
            function NotificationAllUser()
            {
                let checkbox = document.getElementById("SystemErt").checked;
                if(checkbox){
                    document.getElementById("Programok").style.display = "None";
                    document.getElementById("Teruletek").style.display = "None";
                    document.getElementById("Csoportok").style.display = "None";
                }
                else{
                    document.getElementById("Programok").style.display = "block";
                    document.getElementById("Teruletek").style.display = "block";
                    document.getElementById("Csoportok").style.display = "block";
                }
            }

            document.getElementById('ertLetrehozoForm').onsubmit = function(){
                let submitValid = false; let ertNevValid = false; let ertTartalom = false;
                let ertesitesNeve = document.getElementById("ertesitesNeve").value;
                let ErtesitesNevenekHossza = ertesitesNeve.length;
                let tartalom = document.getElementById("ertesitesTartalma").value;
                let tartalomHossza = tartalom.length;
                if(ertesitesNeve != "" && (ErtesitesNevenekHossza > 4))
                   { ertNevValid = true;}
                else {
                    alert("Az értesítés neve nem lehet üres és legalább 5 karakter hosszúnak kell lenni! ");
                }

                if(tartalom != "" && (tartalomHossza > 4))
                    ertTartalom = true;
                else {
                    alert("Az értesítés tartalma nem lehet üres és legalább 5 karakter hosszúnak kell lenni! ");
                }

                if(ertNevValid && ertTartalom)
                    submitValid = true;


                return submitValid;
            }

            document.getElementById('Programok').onchange = function(){
                let selectedItem = document.getElementById("Programok").value;
                if(selectedItem > 0)
                {
                    $.ajax({
                        type:'POST',
                        url:'{{url('GetTeruletek')}}',
                        data:{_token:'<?php echo csrf_token() ?>', es_id:selectedItem},
                        success:function(data) {
                        var obj = data;
                        let i = 0;
                            for(i = 0; i < data.length;i++)
                            {
                                $("<option>").attr("value", data[i].id).text(data[i].nev).appendTo("#Teruletek");
                            }
                        }
                    });
                }
            }

            document.getElementById('Teruletek').onchange = function(){
                let selectedItem = document.getElementById("Teruletek").value;
                if(selectedItem > 0)
                {
                    $.ajax({
                        type:'POST',
                        url:'{{url('GetCsoportok')}}',
                        data:{_token:'<?php echo csrf_token() ?>', tid:selectedItem},
                        success:function(data) {
                        var obj = data;
                        let i = 0;
                            for(i = 0; i < data.length;i++)
                            {
                                $("<option>").attr("value", data[i].id).text(data[i].nev).appendTo("#Csoportok");
                            }
                        }
                    });
                }
            }

       </script>
@endsection
