@extends('layouts.admin')

@section('content')
<style>
    .delete{  color: #F44336; } .edit{ color: #FFC107; } .subject{color: #0000FF;}
    /* Custom checkbox */
	.custom-checkbox {
		position: relative;
	}
    .pagination {
        float: right;
        margin: 0 0 5px;
    }
    .pagination li a {
        border: none;
        font-size: 13px;
        min-width: 30px;
        min-height: 30px;
        color: #999;
        margin: 0 2px;
        line-height: 30px;
        border-radius: 2px !important;
        text-align: center;
        padding: 0 6px;
    }
    .pagination li a:hover {
        color: #666;
    }
    .pagination li.active a, .pagination li.active a.page-link {
        background: #03A9F4;
    }
    .pagination li.active a:hover {
        background: #0397d6;
    }
	.pagination li.disabled i {
        color: #ccc;
    }
    .pagination li i {
        font-size: 16px;
        padding-top: 6px
    }
    .hint-text {
        float: left;
        margin-top: 10px;
        font-size: 13px;
    }
	.custom-checkbox input[type="checkbox"] {
		opacity: 0;
		position: absolute;
		margin: 5px 0 0 3px;
		z-index: 9;
	}
	.custom-checkbox label:before{
		width: 18px;
		height: 18px;
	}
	.custom-checkbox label:before {
		content: '';
		margin-right: 10px;
		display: inline-block;
		vertical-align: text-top;
		background: white;
		border: 1px solid #bbb;
		border-radius: 2px;
		box-sizing: border-box;
		z-index: 2;
	}
	.custom-checkbox input[type="checkbox"]:checked + label:after {
		content: '';
		position: absolute;
		left: 6px;
		top: 3px;
		width: 6px;
		height: 11px;
		border: solid #000;
		border-width: 0 3px 3px 0;
		transform: inherit;
		z-index: 3;
		transform: rotateZ(45deg);
	}
	.custom-checkbox input[type="checkbox"]:checked + label:before {
		border-color: #03A9F4;
		background: #03A9F4;
	}
	.custom-checkbox input[type="checkbox"]:checked + label:after {
		border-color: #fff;
	}
	.custom-checkbox input[type="checkbox"]:disabled + label:before {
		color: #b8b8b8;
		cursor: auto;
		box-shadow: none;
		background: #ddd;
	}
</style>
        <div class="row">
                <div class="col-12 d-flex justify-content-between">
                    <h1>Értesítés megtekintése</h1>
                </div>
        </div>

        <div class="row">
            <div class="card my-3">
                <div class="card-body">
                <div class="table-wrapper">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                               <th> Értesítés neve </th>


                                <th> Kiküldés ideje </th>

                                <th>Rendszerszintű értesítés </th>

                                <th> Program </th>

                                <th> Terület  </th>

                                <th> Csoport  </th>

                                <th>Küldte/Létrehozó</th>

                        </tr>

                        </thead>
                        <tbody>
                            <tr>
                                <td> {{$model->ErtesitesNeve}}</td>


                                <td> {{$model->created_at}} </td>

                                <td> @if($model->isAdmin) igen  @else nem @endif </td>

                                <td> {{$model->Program}} </td>


                                <td> {{$model->Terulet}} </td>

                                <td> {{$model->Csoport}} </td>
                                <td>{{$model->LetrehozoNeve}}<td>
                            </tr>



                        </tbody>
                    </table>



                    <section>
                        <p><b>Tartalma: </b></p>
                        <p>
                            {!!  $model->Tartalom !!}
                        </p>
                    </section>





                </div>
            </div>
        </div>
        </div> <!-- row end-->

        <div class="row">
            <div class="card my-3">
                <div class="card-body">
                    <h3>Statisztikai adatok</h3>
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                               <th> Önkéntesek száma</th>


                                <th> Megtekintések száma </th>



                        </tr>

                        </thead>
                        <tbody>
                            <tr>
                                <td> {{$model->OnkentesekSzama}} </td>


                                <td> {{$model->megtekintesekSzama}}</td>


                            </tr>



                        </tbody>
                    </table>

                    <!-- Ez a section csak akkor lesz renderelve, ha legalább Program szintű az ertesites
                        a rendszerszintűnél nem jelenik meg
                    -->
                    <section style="margin-top:25px;">
                        <h3>Vezetők, akik megtekintették az értesítést</h3>
                        <table class="table table-striped table-hover">
                            <thead>
                                <tr>
                                   <th> Koordinátor/vezető neve</th>
                                <!--    <th> Program neve </th>
                                    <th>Terület neve</th>
                                    <th>Csoport neve</th>
                                    <th>Beosztása</th>-->

                            </tr>

                            </thead>
                            <tbody>
                                @foreach($model->VezetokAkikLattak as $user)
                                <tr>
                                    <td tid="{{$user->id}}"> {{$user->name}} </td>
                                  <!--  <td> 70 / 70% </td>
                                    <td> 100 </td>
                                    <td> 70 / 70% </td>
                                    <td> 100 </td>-->


                                </tr>

                                @endforeach

                            </tbody>
                        </table>
                    </section>

                    <section style="margin-top:25px;">
                        <h3>Vezetők, akik NEM tekintették meg az értesítést</h3>
                        <table class="table table-striped table-hover">
                            <thead>
                                <tr>
                                   <th> Koordinátor/vezető neve</th>
                                   <!-- <th> Program neve </th>
                                    <th>Terület neve</th>
                                    <th>Csoport neve</th>
                                    <th>Beosztása</th>-->

                            </tr>

                            </thead>
                            <tbody>
                                @foreach ($model->vezetokAkikNemLattak as $user)

                                <tr>
                                    <td tid="{{$user->id}}"> {{$user->name}} </td>
                                 <!--   <td> 70 / 70% </td>
                                    <td> 100 </td>
                                    <td> 70 / 70% </td>
                                    <td> 100 </td> -->


                                </tr>

                                @endforeach

                            </tbody>
                        </table>
                    </section>

                </div>
            </div>
        </div>



@endsection
