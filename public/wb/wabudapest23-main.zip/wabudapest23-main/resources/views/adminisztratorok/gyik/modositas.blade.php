@extends('layouts.admin')

@section('content')
<style>

    .hint-text {
        float: left;
        margin-top: 10px;
        font-size: 13px;
    }
</style>
        <div class="row">
            <div class="col-12 d-flex justify-content-between">
                <h1>{{$gyik->id}}. számú GyIK módosítása</h1>
            </div>
            <div class="col-12 col-md-12">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item active" aria-current="page">Gyakran ismételt kérdések:</li>
                          <li class="breadcrumb-item"><a href="{{route('gyik.lista')}}">Lista</a></li>
                          <li class="breadcrumb-item"><a href="{{route('gyik.letrehozas')}}">Új GyIK létrehozása</a></li>
                         </ol>
                      </nav>
            </div>

          <div class="col-12 col-md-12">
            <div class="card my-3">
              <div class="card-body">
                
              <form action="{{route('gyik.frissites_form',['id' => $gyik->id])}}" method="POST" enctype="multipart/form-data" id="gyik_hozzaadas_form" name = "gyik_hozzaadas_form">
                @csrf
                <div class="form-row">
                    <div class="form-group col-md-12">
                        <label for="inputEmail4">Kérdés:</label>
                        <input type="text" class="form-control" id="gyik_kerdes" name="gyik_kerdes" data-validation="required" value="{{$gyik->kerdes}}">
                        
                    </div>
                </div>
                <hr>
                <div class="form-row">
                  <div class="form-group col-md-12">
                      <label for="Kulcsszavak">Kulcsszavak:</label>
                      <input type="text" class="form-control" id="gyik_kulcsszavak" name="gyik_kulcsszavak" data-validation="required" value="{{$gyik->kulcsszavak}}">
                      
                  </div>
              </div>
              <hr>
                <div class="form-row">
                  <div class="form-group col-md-12">
                    <label for="inputEmail4">Válasz:</label>
                    <textarea class="form-control" id="gyik_valasz" name="gyik_valasz" data-validation="required" >
                       {{$gyik->valasz}}
                    </textarea>
                </div>
                </div>

                <hr>

                <div class="form-row">
                    <div class="form-group col-md-12">
                        <button  type="submit" class="btn btn-primary">Mentés</button>
                      </div>
                </div>
               
              </form>
            </div>
            </div>
          </div>

          

        </div>
      
    
        <script src="{{ asset('js/jquery.form-validator.min.js') }}"></script>
        <script>
           var myLanguage = {

                errorTitle: 'Az űrlap feldolgozása sikertelen.',
                requiredFields: 'You have not answered all required fields',
                badTime: 'You have not given a correct time',
                badEmail: 'You have not given a correct e-mail address',
                badTelephone: 'You have not given a correct phone number',
                badSecurityAnswer: 'You have not given a correct answer to the security question',
                badDate: 'You have not given a correct date',
                lengthBadStart: 'The input value must be between ',
                lengthBadEnd: ' karakter',
                lengthTooLongStart: 'The input value is longer than ',
                lengthTooShortStart: 'Az input érték nem lehet kevesebb, mint ',
                notConfirmed: 'Input values could not be confirmed',
                badDomain: 'Incorrect domain value',
                badUrl: 'The input value is not a correct URL',
                badCustomVal: 'The input value is incorrect',
                andSpaces: ' and spaces ',
                badInt: 'The input value was not a correct number',
                badSecurityNumber: 'Your social security number was incorrect',
                badUKVatAnswer: 'Incorrect UK VAT Number',
                badStrength: 'The password isn\'t strong enough',
                badNumberOfSelectedOptionsStart: 'You have to choose at least ',
                badNumberOfSelectedOptionsEnd: ' answers',
                badAlphaNumeric: 'The input value can only contain alphanumeric characters ',
                badAlphaNumericExtra: ' and ',
                wrongFileSize: 'The file you are trying to upload is too large (max %s)',
                wrongFileType: 'Only files of type %s is allowed',
                groupCheckedRangeStart: 'Please choose between ',
                groupCheckedTooFewStart: 'Please choose at least ',
                groupCheckedTooManyStart: 'Please choose a maximum of ',
                groupCheckedEnd: ' item(s)',
                badCreditCard: 'The credit card number is not correct',
                badCVV: 'The CVV number was not correct',
                wrongFileDim : 'Incorrect image dimensions,',
                imageTooTall : 'the image can not be taller than',
                imageTooWide : 'the image can not be wider than',
                imageTooSmall : 'the image was too small',
                min : 'min',
                max : 'max',
                imageRatioNotAccepted : 'Image ratio is not accepted'
            };

          $.validate({
            language : myLanguage
          });
        </script>
        
<script src="//cdn.ckeditor.com/4.14.0/standard/ckeditor.js" rel="dns-prefetch"></script>
<script src="{{asset('js/ckeditor/filebrowser/plugin.js')}}"></script>
<script>

  CKEDITOR.replace( 'gyik_valasz',{
    uiColor: '#3490dc',
      filebrowserBrowseUrl: '/omr_nek/public/ckfinder/ckfinder.html',
    filebrowserUploadUrl: '/omr_nek/public/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files'
  });

  
  </script>
@endsection
