@extends('layouts.admin')

@section('content')

@if($errors->sikerletrehozas->first())
<div class="col-12 col-md-12 text-center">
  <h4  class="alert alert-success" role="alert">{{$errors->sikerletrehozas->first()}}</h4>
</div>
@endif

@if($errors->sikermodositas->first())
<div class="col-12 col-md-12 text-center">
  <h4  class="alert alert-success" role="alert">{{$errors->sikermodositas->first()}}</h4>
</div>
@endif


@if($errors->letrehozoashiba->first())
<div class="col-12 col-md-12 text-center">
  <h4  class="alert alert-danger" role="alert">{{$errors->letrehozoashiba->first()}}</h4>
</div>
@endif

<div class="col-12 col-md-12 text-center d-none" id="sikertorles">
  <h4  class="alert alert-success" role="alert">Sikeresen törlés!</h4>
</div>

<div class="col-12 col-md-12">
    <div class="card my-3">
      <div class="card-body">
        <div class="row">
            <div class="col-12 d-flex justify-content-between">
              <h1>Gyakran ismételt kérdések listája</h1>
            </div>

            <div class="col-12 col-md-12">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item active" aria-current="page">GYIK kezelése:</li>
                      <li class="breadcrumb-item"><a href="{{route('gyik.letrehozas')}}">Létrehozás</a></li>
                     </ol>
                  </nav>
        </div>

          </div>
          <div class="table-wrapper">
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                       
                        <th>#ID</th>
                        <th>GYIK kérdés</th>
                        <th>Megtekintés/Módosítás</th>
                        <th>Törlés</th>
                    </tr>
                </thead>
                <tbody>

                    @if(isset($gyikLista))
                        @foreach($gyikLista as $gyik)
                        <tr>
                            <td>{{$gyik->id}}</td>
                            <td>{{$gyik->kerdes}}</td>
                            
                            <td><a href="{{route('gyik.modositas',['id' => $gyik->id])}}"><i class="material-icons edit" data-toggle="tooltip" title="Módosítás">&#xE254;</i></a></td>
                            <td>
                              <a href="#deleteGyikModal" class="delete" data-toggle="modal"><i class="material-icons deltool" data-toggle="tooltip" title="" data-valesid="{{$gyik->id}}" data-original-title="Törlés"></i></a>
                            </td>
                          </tr>
                        @endforeach
                    @endif
                    
                       
                            
                      

                </tbody>
            </table>
            <div class="clearfix float-left">
                <ul class="pagination">
                    {{$gyikLista->links()}}
                </ul>
            </div>
          </div>


      </div>
    </div>
</div>

 <!-- Delete Modal HTML -->
 <div id="deleteGyikModal" class="modal fade">
  <div class="modal-dialog">
      <div class="modal-content">

              <div class="modal-header">
                  <h4 class="modal-title">GYIK törlése</h4>
                  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
              </div>
              <div class="modal-body">
                  <p>Biztosan törölni szeretné, ezt a GYIK-et?</p>
                  <p style="color: #ff0000;" >Ha törli a GYIK-et, később az adatokat nem tudjuk visszaállítani!</p>
              </div>
              <div class="modal-footer">
                  <input type="number" class="d-none" id="esid" name="esid" value="-1">
                  <input type="button" class="btn btn-default" data-dismiss="modal" value="Mégse">
                  <input type="button" id="esemenyTorlesBtn" class="btn btn-danger" value="Törlés">
              </div>

      </div>
  </div>
</div>

<script>
  $(document).ready(function(){

    $('.deltool').click(function(){
                        let v = $(this).data('valesid'); $('#esid').val(v);
                    });

                    $('#esemenyTorlesBtn').click(function(){
                        let omrr = $('#esid').val();
                        $.ajax({
                                type:'POST',
                                url:'{{url('/admin/gyik/torles')}}',
                                data:{_token:'<?php echo csrf_token() ?>', _esid:omrr },
                                success:function(data) {
                                    if(data == 1) {
                                      $('#sikertorles').show();
                                      setTimeout(function(){
                                        location.reload(true);
                                      },2000);
                                    }
                                }
                            });
                    });
  })
  ;
</script>
@endsection