@extends('layouts.admin')

@section('content')

<div class="row">
    <div class="col-12 d-flex justify-content-between">
        <h1>Jelentkezések és jelentkezés módosítás - {{$user->name}}</h1>
    </div>
</div>

<div class="row">
    <div class="col-12">
        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#deleteEmployeeModal">JELENTKEZÉS</button>
    </div>
</div>

@if($errors->failed->first())
    <div class="alert alert-danger" role="alert">
  {{$errors->failed->first()}}
</div>
@endif

@if($errors->success->first())
    <div class="alert alert-success" role="alert">
  {{$errors->success->first()}}
</div>
@endif

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <table class="table table-striped">
                    <thead>
                        <th title="Rendezvény azonosító">ID</th>
                        <th title="RPrioritás">P</th>
                        <th title="Joker">J</th>
                        <th>Rendezvény</th>
                        <th>Terület</th>
                        <th>Csoport</th>
                        <th>Jelentkezés ideje</th>
                        <th>Művelet</th>
                    </thead>
                    <tbody>
                        
                        @foreach($datas as $data)

                            
                                <tr id="{{$data['j_id']}}" data-rid="rendid-{{$data['esemeny_id']}}" data-tid="{{$data['terulet_id']}}">
                                    <td>{{$data['esemeny_id']}}</td>
                                    <td>{{$data['priority']}}</td>
                                    <td>{{$data['joker']}}</td>
                                    <td>{{$data['esemeny_nev']}}</td>
                                    <td>{{$data['terulet_nev']}}</td>
                                    <td>{{$data['csoport_nev']}}</td>
                                    <td>{{$data['jelentkezesIdeje']}}</td>
                                    <td>
                                    <span href="#areaModificationModal" data-toggle="modal" onclick="jsareamodification('{{$data['j_id']}}')" style="cursor:pointer;">Módosítás</span>
                                    </td>
                                </tr>
                            
                        
                        
                        @endforeach

                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


<!-- modosito -->
<div id="areaModificationModal" class="modal fade">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form action="{{url('onkentes/aremodification')}}" method="POST" >
                        <div class="modal-header">
                            <h4 class="modal-title">Terület módosítása</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        </div>
                        <div class="modal-body" style="color:#000;">
                            <p>FIGYELEM! Amennyiben a terület lezárásra kerül NEM tudod módosítani!</p>
                            <div class="form-group">
                                <select id="newarea" name="newarea" class="custom-select">
                                    <option value disabled selected>---  Kérünk, válassz egy új területet! ---</option>
                                </select>
                            </div>
                        </div>
                        <div class="modal-footer">
                        <input type="number" class="d-none" id="jidt" name="jidt" >
                        @csrf
                            <input type="button" class="btn btn-default" data-dismiss="modal" value="Mégse">
                            <input type="submit" id="AreaModSbm" class="btn btn-danger" value="Módosít">
                        </div>
                    </form>
                </div>
            </div>
        </div> <!-- modosito vege-->

<script>
 function jsareamodification(jid)
        {
            $('#jidt').val(jid);
            console.log("cscsd"+$('#jidt').val());
            $.ajax({
              type:'POST',
              url:'{{url('AreasForJid')}}',
              data:{_token:'<?php echo csrf_token() ?>', jid:jid },
              success:function(data) {
                  console.log(data);
                  $('#newarea').empty();
                  $("<option>").attr("value", -1).text("- Kérünk, válassz egy új területet! -").appendTo("#newarea");   
               var obj = data;
               let i = 0;
                   for(i = 0; i < data.length;i++)
                   {
                   $("<option>").attr("value", data[i].id).text(data[i].nev).appendTo("#newarea");
                  }

              }
           });
        }
</script>

<!-- Delete Modal HTML -->
<div id="deleteEmployeeModal" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="{{url('admin/onkentes/teruletJelentkezes')}}" name="jelentkezoForm" id="jelentkezoForm" method="POST" onsubmit="return validateForm()">
                @csrf
                <div class="modal-header">
                    <h4 class="modal-title">Jelentkezés</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                </div>
                <div class="modal-body">

                    <div class="form-group" id="applyBox1">
                        <label for="">Válaszd ki a rendezvényt: </label>
                        <select class="form-control col-6" id="rendezveny" name="rendezveny">
                            <option selected disabled value>- Kérjük, válassz -</option>
                            @foreach($esemenyek as $esemeny)
                                <option value="{{$esemeny->id}}">{{$esemeny->nev}}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="">Válaszd ki a területet: </label>
                        <select class="form-control col-6" id="terulet" name="terulet">
                            <option selected disabled value>- Kérjük, válassz -</option>
                           
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="">Prioritás</label>
                        <select class="form-control col-6" id="priority" name="priority">
                            <option selected disabled value>- Kérjük, válassz -</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                        </select>
                    </div>
                    <div class="form-group">

                        <label>
                            <input type="checkbox" name="other" />
                            Joker  jelentkező
                        </label>
                    </div>
                    <div class="col-12 d-flex justify-content-between card my-3">
                        <h5>Csoportos jelentkezés</h5>
                        <label>Kérjük, add meg a jeligét, amit választottatok. A mező automatikusan megjeleníti az elérhető jeligéket, amint elkezded begépelni. A <i>‘Jelige létrehozása’</i> gombra kattintva tudsz létrehozni jeligét.</label>
                         </div>
                    <div class="form-group">

                        <label>Jelige keresése és kiválasztása: </label>
                        <input  id="jelige" name="jelige" autocomplete="on">
                        <br>
                        <span id="empty-message" class="float-right mr-5" style="color:red;"></span>
                    </div>
                </div>
                <div class="modal-footer">
                    <input type="number" class="d-none" id="uid" name="uid" value="{{$user->id}}">
                    <input type="button" class="btn btn-default" data-dismiss="modal" value="Mégse">
                    <input type="submit" id="esemenyTorlesBtn" class="btn btn-danger" value="Jelentkezés">
                </div>
            </form>
            <script>
                function validateForm() {
                    let jel1 = document.getElementById('elsoTerulet').value;
                    let jel2 = document.getElementById('masodikTerulet').value;
                    let jel3 = document.getElementById('harmadikTerulet').value;
                    let warningSpan = '<span style="color: red;">Kötelező</span>';
                    let FormValid = true;
                    if(jel1 == "")
                    {
                        document.getElementById('elsoTerulet').style.borderStyle = 'solid';
                        document.getElementById('elsoTerulet').style.borderColor = 'red';
                        FormValid = false;

                    }
                    if(jel2 == "")
                    {
                        document.getElementById('masodikTerulet').style.borderStyle = 'solid';
                        document.getElementById('masodikTerulet').style.borderColor = 'red';

                        FormValid = false;
                    }
                    if(jel3 == "")
                    {
                        document.getElementById('harmadikTerulet').style.borderStyle = 'solid';
                        document.getElementById('harmadikTerulet').style.borderColor = 'red';

                        FormValid = false;
                    }

                    if(FormValid)
                    {
                        return true;
                    }
                    else
                    {
                        alert('Mind három terület kiválasztása kötelező!');
                        return false;
                    }

                    return FormValid;
                }

                $("#jelige").focus(function(){
        var jeligeTag = [];
        $.ajax({
                        type:'POST',
                        url:'{{url('getJeligekAdmin')}}',
                        data:{_token:'<?php echo csrf_token() ?>',uid:{{$user->id}} },
                        success:function(data) {
                        // var obj = JSON.parse(data);
                        let i = 0;
                            for(i = 0; i < data.length;i++)
                            {
                                jeligeTag.push(data[i].jeligeNeve.toUpperCase());
                            }
                        }
            });
            $("#jelige").autocomplete({
            source: jeligeTag,
            response: function(event, ui) {
            // ui.content is the array that's about to be sent to the response callback.
            if (ui.content.length === 0) {
                    $("#empty-message").text("Nem található ilyen jelige.");
                     } else {
                    $("#empty-message").empty();
                }
            }
        });
    });

            $('#rendezveny').change(function(){
                let es = document.getElementById('rendezveny').value;
                console.log(es);
                $('#terulet').empty();
                $.ajax({
                        type:'POST',
                        url:'{{route('Admin.TeruletekVissza')}}',
                        data:{_token:'<?php echo csrf_token() ?>',esid:es },
                        success:function(data) {
                        // var obj = JSON.parse(data);
                        let i = 0;
                            for(i = 0; i < data.length;i++)
                            {
                            $("<option>").attr("value", data[i].id).text(data[i].nev).appendTo("#terulet");
                            }
                        }
                       
                });
            });

            </script>
        </div>
    </div>
</div>
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
@endsection