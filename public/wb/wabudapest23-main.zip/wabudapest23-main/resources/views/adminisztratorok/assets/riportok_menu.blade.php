<div class="gombok">
    <button type="button" id="submenu-item1-permission" class="btn @if($model->getViewerURL() == 'index') btn-primary  @else btn-secondary @endif"><a href="{{url('admin/riportok/index')}}">Riportok</a></button>
    <button type="button" id="submenu-item1-permission" class="btn @if($model->getViewerURL() == "felhasznalok") btn-primary  @else btn-secondary @endif"><a href="{{url('admin/riportok/felhasznalok')}}">Felhasználók</a></button>
    <button type="button" id="submenu-item1-permission" class="btn @if($model->getViewerURL() == "onkentesek") btn-primary  @else btn-secondary @endif"><a href="#">Önkéntesek</a></button>
</div>