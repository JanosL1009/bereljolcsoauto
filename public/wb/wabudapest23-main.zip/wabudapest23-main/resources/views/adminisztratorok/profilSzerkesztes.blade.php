@extends('layouts.admin') 

@section('htmlhead')
<script src="https://cdn.jsdelivr.net/npm/exif-js"></script>
@endsection

@section('content')
<style>
    .myLink {
        color: blue;
    }
    .myalert{color:red;}
    .panel-heading{
	border: 1px solid red;
}

.panel-body{
/*	border: 1px solid black;*/
display: 'none';
}

</style>

<form class="form" id="onkentesszerk" name="onkentesszerk" action="{{route('admin.profilszerk')}}" method="post" enctype="multipart/form-data">
    <div class="row">
        @csrf

        <div class="col-12 d-flex justify-content-start">
            <h1>Profil szerkesztése</h1>
        </div>

        @if($errors->any())
        <div class="col-12 text-center">
          <h4  class="alert alert-danger" role="alert">{{$errors->first()}}</h4>
        </div>
        
      @endif

       @if($errors->profilkep->first())
        <div class="col-12 text-center">
          <h4  class="alert alert-danger" role="alert">{{$errors->profilkep->first()}}</h4>
        </div>
        
      @endif
   
        @if($errors->checkprofile->first())
        <div class="col-12 text-center">
          <h4  class="alert alert-danger" role="alert">{{$errors->checkprofile->first()}}</h4>
        </div>
        
      @endif

    @if($errors->telszam->first())
    <div class="col-12 text-center">
      <h4  class="alert alert-danger" role="alert">{{$errors->telszam->first()}}</h4>
    </div>
    
  @endif
  @if($errors->szulido->first())
  <div class="col-12 text-center">
    <h4  class="alert alert-danger" role="alert">{{$errors->szulido->first()}}</h4>
  </div>
  
@endif
  @if($errors->egyebures->first())
    <div class="col-12 text-center">
      <h4  class="alert alert-danger" role="alert">{{$errors->egyebures->first()}}</h4>
    </div>
    
  @endif

  @if($errors->lakcim_telepules->first())
    <div class="col-12 text-center">
      <h4  class="alert alert-danger" role="alert">{{$errors->lakcim_telepules->first()}}</h4>
    </div>
    
  @endif

@if($errors->nyelv1->first())
    <div class="col-12 text-center">
      <h4  class="alert alert-danger" role="alert">{{$errors->nyelv1->first()}}</h4>
    </div>
    
  @endif

  @if($errors->nyelv2->first())
    <div class="col-12 text-center">
      <h4  class="alert alert-danger" role="alert">{{$errors->nyelv2->first()}}</h4>
    </div>
    
  @endif

  @if($errors->nyelv3->first())
  <div class="col-12 text-center">
    <h4  class="alert alert-danger" role="alert">{{$errors->nyelv3->first()}}</h4>
  </div>
  
@endif

@if($errors->nyelv4->first())
  <div class="col-12 text-center">
    <h4  class="alert alert-danger" role="alert">{{$errors->nyelv4->first()}}</h4>
  </div>
  
@endif

@if($errors->nyelv5->first())
  <div class="col-12 text-center">
    <h4  class="alert alert-danger" role="alert">{{$errors->nyelv5->first()}}</h4>
  </div>
  
@endif
    <!--
        <div class="col-12 d-flex justify-content-start">
            <div class="card my-3">
              <div class="card-body">
              
              </div>
            </div>
        </div> -->



        <div class="col-12 col-xl-6">
            <div class="card my-3">
                <div class="card-body">
                    <!--  <form> -->

                    <div class="form-group">
                        <label for="inputAddress">Név</label>
                        <input type="text" class="form-control" id="userfullname" name="userfullname" value="{{$model->GetTeljesNev()}}" readonly>
                        <span style="font-size: 9px;">A rendszer tölti ki automatikusan a Vezetéknév, Keresztnév és 2. keresztnév inputok alapján!</span>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="titulusLabel">Titulus/Előtag</label>
                            <select id="nevelotag" name="nevelotag" class="form-control" style="width: 225px">
                                <option selected value="none">--Nem kötelező--</option>
                                <option value="dr." @if($nevelotag == "dr.") selected @endif>dr</option>
                                <option value="Dr." @if($nevelotag == "Dr.") selected @endif>Dr</option>
                                <option value="Ifj." @if($nevelotag == "Ifj.") selected @endif>Ifj.</option>
                                <option value="Id." @if($nevelotag == "Id.") selected @endif>Id.</option>
                                <option value="Özv." @if($nevelotag == "Özv.") selected @endif>Özv.</option>
                            </select>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="vezeteknevLabel">Vezetéknév*</label>
                            <input type="text" class="form-control" id="vezeteknev" name="vezeteknev" value="{{$model->Vezeteknev}}" data-validation="required">
                          
                            <span class="d-none" id="errVezNev">
                                <span class="myalert">Kötelező mező!</span>
                            </span>
                       
                        </div>
                    </div>

                    <div class="form-row">
                        
                        <div class="form-group col-md-6">
                            <label for="vezeteknevLabel">Keresztnév*</label>
                            <input type="text" class="form-control" id="kozepsonev" name="kozepsonev" value="{{$model->Kozepsonev}}" data-validation="required">
                            <span class="d-none" id="errKerNev">
                                <span class="myalert">Kötelező mező!</span>
                            </span>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="keresztnevLabel" style="font-size:14px;">Keresztnév 2.</label>
                            <input type="text" class="form-control" id="keresztnev" name="keresztnev" value="{{$model->Keresztnev}}">
                            
                        </div>
                    </div>
                    <hr>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="inputPassword4">Telefonszám*</label>
                            <input type="number" class="form-control" minlength="9" maxlength="15" id="telszam" name="telszam" value="{{$model->Telefonszam}}"  data-validation="required">
                            <span style="color: red;" id="uzenet"></span>
                            <span class="d-none" id="errTelNev">
                                <span class="myalert">Kötelező mező!</span>
                            </span>
                        </div>
                        
                    <div class="form-group col-md-6">
                        <label for="inputAddress2">E-mail</label>
                        <input type="text" class="form-control" id="sajatEmailCim" name="sajatEmailCim" placeholder="{{$model->email}}" data-validation="email" value="{{$model->email}}" readonly>
                    </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-12">
                            <sub>Formátum: 00 és országkód pl. 0036; 0049; csak számokat tartalmazhat, szóköz/pervonal/kötőjel nélkül!</sub>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-12">
                            <label for="inputCity">Születési idő*</label><br>
                            <div class="d-flex justify-content-start pr-2">
                                
                                <div class="form-group">
                                  <select  id="szuletesiIdoEv" name="szuletesiIdoEv" class="form-control" data-validation="required">
                                      <option disabled selected>Év</option>
                                      
                                  </select>
                                <span class="d-none" id="errSzulEv">
                                    <span class="myalert">Kötelező mező!</span>
                                </span>
                                </div>
                                <div class=" form-group">
                                  <select  id="szuletesiIdoHo" name="szuletesiIdoHo" class="form-control" s>
                                      <option disabled selected>Hó</option>
                                  </select>
                                  <span class="d-none" id="errSzulHo">
                                    <span class="myalert">Kötelező mező!</span>
                                </span>
                                </div>
                                <div class="form-group">
                                  <select  id="szuletesiIdoNap" name="szuletesiIdoNap" class="form-control" >
                                      <option disabled selected>Nap</option>
                                  </select>
                                  <span class="d-none" id="errSzulNap">
                                    <span class="myalert">Kötelező mező!</span>
                                </span>
                              </div>
                            </div>

                        </div>
                        
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-6 col-sm-6">
                            <label for="inputState">Születési hely*</label>
                            <input type="text" class="form-control" id="szulhely" name="szulhely" value="{{$model->szulhely}}" placeholder="{{$model->szulhely}}" data-validation="required">
                            <span class="d-none" id="errSzulHely">
                                <span class="myalert">Kötelező mező!</span>
                            </span>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="inputEmail4">Életkor</label>
                            @if($model->EletKor == 1)
                            <input class="form-control" type="number" id="age" name="age" value="" readonly /> @else
                            <input class="form-control" type="number" id="age" name="age" value="{{ $model->EletKor }}" readonly /> @endif
                            <span style="font-size: 9px;">A rendszer számolja ki!</span>

                        </div>

                        <div class="form-group col-md-6">
                            <label for="inputEmail4">Neme*</label>
                            <select class="form-control" id="userneme" name="userneme" data-validation="required">
                                <option disabled selected value>--- Kérem válasszon ---</option>
                                <option value="1" @if($model->Neme_id == 1) selected="selected" @endif>Nő</option>
                                <option value="0" @isset($model->Neme_id)@if($model->Neme_id == 0) selected="selected" @endif @endisset>Férfi</option>


                            </select>
                            <span class="d-none" id="errNeme">
                                <span class="myalert">Kötelező mező!</span>
                            </span>
                        </div>

                    </div>
                    <hr>
                    <div class="form-row">
                            <div class="form-group col-md-6">
                                    <label for="inputEmail4">Anyja neve*</label>

                            <input class="form-control" type="text" id="mothername" name="mothername" value="{{$model->anyjaneve}}" data-validation="required"/>
                            <span class="d-none" id="errAnyjaNeve">
                                <span class="myalert">Kötelező mező!</span>
                            </span>
                            </div>

                    </div>
                    <div class="form-row">
                            <div class="form-group col-md-6">
                                    <label for="inputEmail4">Állampolgárság*</label>
                                <!--
                                    <input class="form-control" type="text" id="nationality" name="nationality" value="{{$model->allampolgarsag}}" data-validation="required"/>
                            -->
                            <select class="form-control" id="nationality" name="nationality" >
                                <option disabled selected>--Kérem válasszon--</option>
                                @foreach ($allampolgarsagLista as $elem)
                                <option value="{{$elem->id}}" @if($model->allampolgarsag == $elem->id) selected  @endif>{{$elem->allampolgarsag}}</option>
                                       
                                @endforeach
                                       
                                        
                                </select>
                                <span class="d-none" id="errAllampolg">
                                    <span class="myalert">Kötelező mező!</span>
                                </span>
                            </div>

                            <div class="form-group col-md-6">
                                    <label for="inputEmail4">Személyi igazolvány szám*</label>

                                    <input class="form-control" type="text" id="szemigszam" name="szemigszam" value="{{ $model->szemigszam }}" data-validation="required"/>
                                    <span class="d-none" id="errSzemIgSzam">
                                        <span class="myalert">Kötelező mező!</span>
                                    </span>
                            </div>

                    </div>

                    <!--   </form>-->
                </div>
            </div>

            <div class="card my-3">
                <div class="card-body">
                    <h5 class="card-title">Állandó lakcím</h5>
                    <!-- <form> -->
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="inputEmail4">Ország*</label>

                            <select class="form-control" id="al_lakcim_orszag" name="al_lakcim_orszag" data-validation="required">
                                <option disabled value="111" selected>--- Ország választás ---</option>
                                {!! $model->all_lakcim_orszag !!}
                            </select>
                            <span class="d-none" id="errAllando1">
                                <span class="myalert">Kötelező mező!</span>
                            </span>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="inputPassword4">Megye*</label>

                            <select class="form-control" id="al_lakcim_megye" name="al_lakcim_megye" data-validation="required">
                                <option disabled  value="111" selected>--- Megye választás ---</option>
                                {!! $model->Megye_AllLakcim !!}
                            </select>
                            <span class="d-none" id="errAllando2">
                                <span class="myalert">Kötelező mező!</span>
                            </span>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="inputEmail4">Település*</label>
                            <input type="text" class="form-control" id="al_lakcim_telepules" name="al_lakcim_telepules" value="{{$model->all_lakcim_telepules}}" data-validation="required">
                            <span class="d-none" id="errAllando3">
                                <span class="myalert">Kötelező mező!</span>
                            </span>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="inputPassword4">Irányítószám*</label>
                            <input type="text" class="form-control" id="al_lakcim_irszam" name="al_lakcim_irszam" value="{{$model->all_lakcim_irszam}}" minlength="2" maxlength="14" data-validation="required">
                            <span class="d-none" id="errAllando4">
                                <span class="myalert">Kötelező mező!</span>
                            </span>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-12">
                            <label for="inputPassword4">Utca, házszám (emelet, ajtó)*</label>
                            <input type="text" class="form-control" id="al_lakcim_utca" name="al_lakcim_utca" value="{{$model->all_lakcim_utca}}" data-validation="required">
                            <span class="d-none" id="errAllando5">
                                <span class="myalert">Kötelező mező!</span>
                            </span>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-12">
                            <input type="checkbox" name="isTartLakcim" id="isTartLakcim" value="TartAzonos"> A tartózkodási helyem azonos az állandó lakcímemmel. </div>
                    </div>

                    <!--  </form> -->
                </div>
            </div>

            <div class="card my-3" id="tartozkodasiBox">
                <div class="card-body">
                    <h5 class="card-title">Tartózkodási hely</h5>
                    <form>

                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="inputPassword4">Ország*</label>

                                <select class="form-control" id="tart_lakcim_orszag" name="tart_lakcim_orszag" data-validation="required">
                                    <option disabled  value selected>--- Ország választás ---</option>
                                    {!! $model->tart_lakcim_orszag !!}
                                </select>
                                <span class="d-none" id="errTart1">
                                    <span class="myalert">Kötelező mező!</span>
                                </span>
                            </div>

                            <div class="form-group col-md-6">
                                <label for="inputPassword4">Megye*</label>

                                <select class="form-control" id="tart_lakcim_megye" name="tart_lakcim_megye" data-validation="required">
                                    <option disabled value selected>--- Megye választás ---</option>
                                    {!! $model->Megye_TartLakcim !!}
                                </select>
                                <span class="d-none" id="errTart2">
                                    <span class="myalert">Kötelező mező!</span>
                                </span>
                            </div>
                        </div>

                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="inputEmail4">Település*</label>
                                @if($model->tart_lakcim_telepules != '0')
                                <input type="text" class="form-control" id="tart_lakcim_telepules" name="tart_lakcim_telepules" value="{{$model->tart_lakcim_telepules}}" data-validation="required">
                                <span class="d-none" id="errTart3">
                                    <span class="myalert">Kötelező mező!</span>
                                </span>
                                @else
                                <input type="text" class="form-control" id="tart_lakcim_telepules" name="tart_lakcim_telepules" value="" data-validation="required">
                                <span class="d-none" id="errTart3">
                                    <span class="myalert">Kötelező mező!</span>
                                </span>
                                @endif
                             </div>
                            <div class="form-group col-md-6">
                                <label for="inputPassword4">Irányítószám*</label>
                                <input type="text" class="form-control" id="tart_lakcim_irszam" name="tart_lakcim_irszam" minlength="2" maxlength="14" value="{{$model->tart_lakcim_irszam}}" data-validation="required">
                                <span class="d-none" id="errTart4">
                                    <span class="myalert">Kötelező mező!</span>
                                </span>
                            </div>
                        </div>

                        <div class="form-row">

                            <div class="form-group col-md-12">
                                <label for="inputPassword4">Utca, házszám (emelet, ajtó)*</label>
                                <input type="text" class="form-control" id="tart_lakcim_utca" name="tart_lakcim_utca" value="{{$model->tart_lakcim_utca}}" data-validation="required">
                                <span class="d-none" id="errTart5">
                                    <span class="myalert">Kötelező mező!</span>
                                </span>
                            </div>
                        </div>

                    </form>
                </div>
            </div>

            <div class="card my-3" id="AltKerdesekBox">
                <div class="card-body">
                    <h5 class="card-title">Általános kérdések</h5>

                    <div class="form-row">
                        <div class="form-group col-md-12">
                            <label>Önkénteskedik-e Ön jelenleg más szervezet(ek)nél?*</label>
                           

                            <select class="form-control col-md-4" id="masSzervezetTagja" name="masSzervezetTagja">
                                <option disabled selected value>-- Kérem válasszon --</option>



                                @if (!isset($model->masSzervezetTagja ))
                                    <option value="1" >Igen</option>
                                    <option value="0">Nem</option>
                                @else
                                    @if ($model->masSzervezetTagja)
                                    <option value="1" selected>Igen</option>
                                    <option value="0">Nem</option>
                                    @endif
                                    @if ($model->masSzervezetTagja == false)
                                        <option  value="1" >Igen</option>
                                        <option value="0" selected>Nem</option>
                                    @endif
                                @endif



                            </select>

                            @if($model->masSzervezetTagja)
                                <div class="dinamikusSzervezetMegj">
                                    <label>A szervezet(ek) neve(i)</label>
                                    <input type="text" class="form-control" id="egyebSzervezet" name="egyebSzervezet" value="{{$model->MasSzervezetNeve}}">
                                    <span class="d-none" id="errszervezet">
                                        <span class="myalert">Kötelező mező!</span>
                                    </span>
                                </div>

                            @else
                                <div id="rejtettSzervezet" class="dinamikusSzervezetMegj" style="display: none;">
                                    <label>A szervezet(ek) neve(i)</label>
                                    <input type="text" class="form-control" id="egyebSzervezet" name="egyebSzervezet" value="{{$model->MasSzervezetNeve}}">
                                    <span class="d-none" id="errszervezet">
                                        <span class="myalert">Kötelező mező!</span>
                                    </span>
                                </div>
                            @endif


                        </div>



                    </div>
                    <hr>
                    <div class="form-row">
                        <div class="form-group col-md-12">
                            <label>Tagja-e Ön civil szervezetnek vagy valamilyen közösségnek?*</label>


                            <select class="form-control col-md-4" id="masCivilSzervezetTagja" name="masCivilSzervezetTagja">
                                <option disabled selected value>-- Kérem válasszon --</option>
                                @if(!isset($model->CivilSzervezetTagja))
                                <option value="1">Igen</option>
                                <option value="0">Nem</option>
                                
                                @else
                                  <option value="1" @if($model->CivilSzervezetTagja) selected @endif >Igen</option>
                                 <option value="0" @if(!$model->CivilSzervezetTagja) selected @endif>Nem</option>
                            
                                @endif
                                
                            </select>

                            @if($model->CivilSzervezetTagja)
                            <div class="dinamikusSzervezetMegjCivil">
                                <label>A szervezet(ek) neve(i)</label>
                                <input type="text" class="form-control" id="civilSzervezet" name="civilSzervezet" value="{{$model->CivilSzervezetNeve}}">
                                <span class="d-none" id="errCivil">
                                    <span class="myalert">Kötelező mező!</span>
                                </span>
                            </div>

                            @else
                            <div id="rcivil" class="dinamikusSzervezetMegjCivil" style="display: none;">
                                <label>A szervezet(ek) neve(i)</label>
                                <input type="text" class="form-control" id="civilSzervezet" name="civilSzervezet" value="{{$model->CivilSzervezetNeve}}">
                                <span class="d-none" id="errCivil">
                                    <span class="myalert">Kötelező mező!</span>
                                </span>
                            </div>
                            @endif

                        </div>
                    </div>

                    <hr>
                    <div class="form-row">
                        <div class="form-group col-md-12">
                            <label>Tagja-e valamelyik egyházközösségnek?* </label>


                                    <div class="dinamikusEgyhazMegj" id="Felekezet">
                                        <select class="form-control col-md-12" id="Felekezetek" name="Felekezetek" data-validation="required" onchange="select_egyhazkozosseg();">
                                            <option disabled  selected value="none">Kérem válasszon</option>
                                            @foreach($felekezetek as $felekezet)
                                                <option value="{{$felekezet}}">{{$felekezet}}</option>
                                            @endforeach
                                        </select>
                                    </div>

                                    <div class="dinamikusEgyhazMegj d-none" id="EgyhazMegye">
                                        <select class="form-control col-md-12" id="egyhazmegyek" name="egyhazmegyek" >
                                            <option disabled  selected  value="none">Kérem válasszon</option>
                                        </select>
                                    </div>

                                    <div id="Egyebinput" class="d-none">
                                        <input type="text" id="egyhazinput" name="egyhazinput" class="form-control col-md-12" data-validation="required">
                                    </div>

                        </div>
                    </div>


                </div>
            </div>

        </div>

        <div class="col-12 col-xl-6">

            <div class="card my-3">
                <div class="card-body">
                    <div class="form-group">
                        <label for="profileKep">Profilkép feltöltés*</label>
                       
                        <div style=" border: 1px solid whitesmoke ;text-align: center;position: relative" id="image">
                            <img width="300" height="300" id="preview_image" src="{{url('userpic/'.$model->profilpic)}}" />
                            <i id="loading" class="fa fa-spinner fa-spin fa-3x fa-fw" style="position: absolute;left: 40%;top: 40%;display: none"></i>
                        </div>
                   
                    <p>
                        <a href="javascript:changeProfile()" style="text-decoration: none;">
                            <i class="glyphicon glyphicon-edit"></i> Változtatás
                        </a>&nbsp;&nbsp;

                    </p>
                    <input type="file" id="file" style="display: none" />
                    <input type="hidden" id="file_name" />
                   

<!--uj kep feltolto  -->

<div class="panel-body">
    <input type="file" name="upload_image" id="upload_image" style="display: none;"/>
    <div id="uploaded_image" ></div>

    <br>
    
</div>
<div id="uploadimageModal" class="modal" role="dialog">
	
           
    <div class="modal-header">
       
        <h4 class="modal-title">Profilkép szerkesztés</h4> <button type="button" class="close" data-dismiss="modal">&times;</button>
    </div>
    <div class="modal-body">
        <div id="image_demo" ></div>
        <button class="btn btn-success crop_image">Kivágás</button>
    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Bezárás</button>
    </div>
    

</div>


<!--  -->
                </div>
            </div>
        </div>
            <div class="card my-3">
                <div class="card-body">
                    <p>Önkéntes óráim száma: <input class="form-control" type="number" readonly value="{{$model->onkentesOrakSzama}}"></p>
                    <span style="font-size: 9px;">A rendszer számolja ki.</span>
                </div>
            </div>

            <div class="card my-3">
                <div class="card-body">

                    <div class="form-group">
                        <label for="inputAddress">Jelenleg főtevékenységként mivel foglalkozik?*</label>
                        <select class="form-control" id="tevekenyseg" name="tevekenyseg" >
                            <option disabled selected value="none">Kérem válasszon</option>

                            {!! $model->foteveknyseg !!}

                        </select>
                        <section id="fotevekenysegem">
                            {!! $model->fotevekenysegHTML !!}
                        </section>
                        <span class="d-none" id="errTev">
                            <span class="myalert">Kötelező mezők!</span>
                        </span>
                    </div>
                    <hr>
                    <div class="form-group">
                        <label for="inputPassword4">Ön fogyatékossággal élő személy?*</label>
                        <select class="form-control col-12 col-md-6" id="fogyatekossag" name="fogyatekossag" data-validation="required">
                            <option disabled selected value>Kérem válasszon</option>

                            @if(isset($model->fogyatekossag) )
                                @switch($model->fogyatekossag )
                                    @case(0)
                                        <option value="1">Igen</option>
                                        <option value="0" selected="selected">Nem</option>
                                        @break
                                    @case(1)
                                        <option value="1" selected="selected">Igen</option>
                                        <option value="0">Nem</option>
                                    @break

                                @endswitch
                            @else
                                <option value="1">Igen</option>
                                <option value="0">Nem</option>
                            @endif





                        </select>
                        <!-- commit msg: profil urlap javitas -->
                        @if(isset($model->fogyatekossag))
                            @switch($model->fogyatekossag )
                                @case(1)
                                    <div class="fogyMegj">
                                        <label style="font-size:12px;">Amennyiben igen, kérem, jelezze felénk fogyatékossága típusát és fokát; és önkéntes közreműködése során esetleges különleges igényeit!</label>
                                        <input type="text" class="form-control" id="fogyLeirasa" name="fogyLeirasa" value="{{$model->FogyLeirasa}}" />
                                        <span class="d-none" id="errFogy">
                                            <span class="myalert">Kötelező mező!</span>
                                        </span>
                                    </div>
                                    @break
                                @case(0)
                                <div class="fogyMegj d-none">
                                    <label style="font-size:12px;">Amennyiben igen, kérem, jelezze felénk fogyatékossága típusát és fokát; és önkéntes közreműködése során esetleges különleges igényeit!
                                    </label>
                                    <input type="text" class="form-control" id="fogyLeirasa" name="fogyLeirasa" value="" />
                                    <span class="d-none" id="errFogy">
                                        <span class="myalert">Kötelező mező!</span>
                                    </span>
                                </div>
                                    @break


                             @endswitch
                        @else

                            <div class="fogyMegj d-none">
                                <label style="font-size:12px;">Amennyiben igen, kérem, jelezze felénk fogyatékossága típusát és fokát; és önkéntes közreműködése során esetleges különleges igényeit!
                                </label>
                                <input type="text" class="form-control" id="fogyLeirasa" name="fogyLeirasa" value="" />
                                <span class="d-none" id="errFogy">
                                    <span class="myalert">Kötelező mező!</span>
                                </span>
                            </div>
                        @endif




                    </div>
                    <hr>
                    <div class="form-group py-2">
                        <label for="inputPassword5">Pólómérete?*</label>
                        <br>
                        <select class="form-control col-12 col-md-6" id="userpolomeret" name="userpolomeret">
                            <option disabled selected value>Kérem válasszon</option>
                            {!! $model->polomeret !!}
                        </select>
                        <span class="d-none" id="errPolo">
                            <span class="myalert">Kötelező mező!</span>
                        </span>
                    </div>
                    <hr>
                    <div class="form-group py-2">
                            <label for="inputPassword5">Póló típusa?*</label>
                            <br>
                            <select class="form-control col-12 col-md-6" id="userpolotipusa" name="userpolotipusa" data-validation="required">
                                    <option disabled selected value>Kérem válasszon</option>
                                    {!! $model->GetHTMLPolotipusa() !!}
                            </select>

                    </div>
                    <hr>
                    <div class="form-group py-2 checkboxok">
                      <label for="basic-url">Kérem, jelezze különleges étkezési igényét!*</label><br>

                        {!! $model->EtkezesHTMLOutput !!}

                    </div>
                    <hr>
                    <div class="form-group py-2 radioboxok">
                      <label for="basic-url">Önkéntes közreműködéséről kér-e igazolást? </label><br>
                      <input type="radio" id="nem" name="igazolas" @if($model->igazolasIgenyID == 0) {{ __('checked') }}  @endif value="0" onchange="SetIgazolas();">
                      <label for="male">Nem</label><br>
                      <input type="radio" id="igen-alt" name="igazolas" value="1" @if($model->igazolasIgenyID == 1) {{ __('checked') }}  @endif onchange="SetIgazolas();">
                      <label for="female">Igen, önkéntességről általában</label><br>
                      <input type="radio" id="igen-szakmai" name="igazolas" value="2" @if($model->igazolasIgenyID == 2) {{ __('checked') }}  @endif onchange="SetIgazolas();">
                      <label for="other">Igen, szakmai gyakorlathoz</label><br>
                      <input type="radio" id="iksz" name="igazolas" value="3" @if($model->igazolasIgenyID == 3) {{ __('checked') }}  @endif onchange="SetIgazolas();">
                      <label for="other">Igen, iskolai közösségi szolgálathoz (IKSZ)</label><br>
                      <input type="radio" id="ig_egyeb" name="igazolas" value="4" @if($model->igazolasIgenyID == 4) {{ __('checked') }}  @endif onchange="SetIgazolas();">
                      <label for="other">Egyéb</label><br>
                        @if($model->igazolasIgenyID == 4)
                        <div id="ifIgazolasOther" >
                            <label id="otherLabel1" for="other">Kérlek írd be egyéb igényed: </label><br>
                            <input type="text" id="egyedIgIgeny" name="egyedIgIgeny" class="form-control" aria-label="egyeb-igeny-igazolas" value="{{$model->igazolasIgenyLeiras}}">
                        </div>
                        @else
                        <div id="ifIgazolasOther" style="display: none;">
                            <label id="otherLabel1" for="other">Kérlek írd be egyéb igényed: </label><br>
                            <input type="text" id="egyedIgIgeny" name="egyedIgIgeny" class="form-control" aria-label="egyeb-igeny-igazolas" value="">
                        </div>
                        @endif

                      <br>
                    </div>
                    <hr>
                    <div class="form-group py-2 radioboxok">
                        <label for="basic-url">Szállást kér? </label><br>
                        <input type="radio" id="SzallasIgen" name="szallastIgenyel" value="1" @if($szallastIgenyel == 1) checked @endif>
                      <label for="igen">Igen</label><br>
                      <input type="radio" id="SzallasNem" name="szallastIgenyel" value="0" @if($szallastIgenyel == 0 || empty($szallastIgenyel)) checked @endif>
                      <label for="nem">Nem</label><br>
                    </div>


                </div>
            </div>

            <div class="card my-3">
                <div class="card-body">
                    <h5 class="card-title">Nyelvismeret</h5>

                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="inputEmail4">Nyelv 1</label>
                            <select class="form-control"  id="nyelv1" name="nyelv1" @if(strlen($model->nyelv1) < 3) onchange="DefLangChecker('nyelv2','nyelv3','nyelv4','nyelv5',this)" @endif>
                                <option disabled selected value>--- Kérjük válasszon ---</option>
                            </select>

                        </div>
                        <div class="form-group col-md-6">
                            <label for="inputEmail4">Nyelvtudás szintje</label>
                            <select class="form-control" id="nyelv1szint" name="nyelv1szint" >
                                <option disabled selected value>Kérem válasszon</option>
                                {{!! $model->nyelv1szint !!}}
                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="inputEmail4">Nyelv 2</label>
                            <select class="form-control"  id="nyelv2" name="nyelv2" @if(strlen($model->nyelv2) < 3) onchange="DefLangChecker('nyelv1','nyelv3','nyelv4','nyelv5',this)" @endif>
                                <option disabled selected value>--- Kérjük válasszon ---</option>
                            </select>

                        </div>
                        <div class="form-group col-md-6">
                            <label for="inputEmail4">Nyelvtudás szintje</label>
                            <select class="form-control" id="nyelv2szint" name="nyelv2szint" >
                                <option disabled selected value>Kérem válasszon</option>
                                {{!! $model->nyelv2szint !!}}
                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="inputEmail4">Nyelv 3</label>
                            <select class="form-control"  id="nyelv3" name="nyelv3" @if(strlen($model->nyelv3) < 3) onchange="DefLangChecker('nyelv2','nyelv1','nyelv4','nyelv5',this)" @endif>
                                <option disabled selected value>--- Kérjük válasszon ---</option>
                            </select>

                        </div>
                        <div class="form-group col-md-6">
                            <label for="inputEmail4">Nyelvtudás szintje</label>
                            <select class="form-control" id="nyelv3szint" name="nyelv3szint" >
                                <option disabled selected value>Kérem válasszon</option>
                                {{!! $model->nyelv3szint !!}}
                            </select>
                        </div>
                    </div>


                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="inputEmail4">Nyelv 4</label>
                            <select class="form-control"  id="nyelv4" name="nyelv4" @if(strlen($model->nyelv4) < 3) onchange="DefLangChecker('nyelv2','nyelv3','nyelv1','nyelv5',this)" @endif>
                                <option disabled selected value>--- Kérjük válasszon ---</option>
                            </select>

                        </div>
                        <div class="form-group col-md-6">
                            <label for="inputEmail4">Nyelvtudás szintje</label>
                            <select class="form-control" id="nyelv4szint" name="nyelv4szint">
                                <option disabled selected value>Kérem válasszon</option>
                                {{!! $model->nyelv4szint !!}}
                            </select>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="inputEmail4">Nyelv 5</label>
                            <select class="form-control"  id="nyelv5" name="nyelv5" @if(strlen($model->nyelv5) < 3) onchange="DefLangChecker('nyelv2','nyelv3','nyelv4','nyelv1',this)" @endif>
                                <option disabled selected value>--- Kérjük válasszon ---</option>
                            </select>

                        </div>
                        <div class="form-group col-md-6">
                            <label for="inputEmail5">Nyelvtudás szintje</label>
                            <select class="form-control" id="nyelv5szint" name="nyelv5szint">
                                <option disabled selected value>Kérem válasszon</option>
                                {{!! $model->nyelv5szint !!}}
                            </select>
                        </div>
                    </div>

                </div>
            </div>
        </div>

        <div class="col-12">
            <div class="card my-3">
                <div class="card-body">
                    <div class="col-12 ">
                        <label class="error">Figyelem! Az adatkezelési szabályzat elfogadása kötelező!</label><br/>
                        <input type="checkbox" name="isgdpr" id="isGDPR" data-validation="required" data-validation-error-msg="A hozzájárulás elfogadása nélkül nem tudja menteni a profilja adatainak változását! Kérjük, fogadja el a hozzájárulást." > Elfogadom az <a class="myLink" target="_blank" href="{{asset('files/pdf/OMR_Fiok_letrehozasa_Adatvedelmi_tajekoztato_1_2021_03.pdf')}}">Adatkezelési tájékoztató dokumentumot.</a>
                        <br>

                    </div>

                </div>
            </div>
        </div>



        <div class="col-12 d-flex justify-content-end">
            <button type="submit" id="sbmbtn" class="btn btn-primary">Profil adatok mentése</button>

        </div>
    </div>

</form>

<div class="row">
    <div class="col-12 d-flex">
        <a href="#PswdChangeBox" class="btn btn-primary" data-toggle="modal"><i class="material-icons" data-toggle="tooltip" title="Jelszó változtatása" ></i>Jelszó változtatása</a>
    </div>
</div>

<div id="PswdChangeBox" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="onkentes/jelszovaltoztatas" id="psdwchangebox"  method="POST" enctype="multipart/form-data">
               @csrf
                <div class="modal-header">
                    <h4 class="modal-title">Jelszó változtatás</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                </div>
                <div class="modal-body">
                    <p>Biztosan megváltoztatja a jelszavát?</p>
                    <div class="form-group">
                        <label>Régi jelszó</label>
                        <input type="password" class="form-control" id="oldPwd" name="oldPwd">
                    </div>
                    <div class="form-group">
                        <label>Új jelszó</label>
                        <input type="password" id="newPwd" class="form-control" name="newPwd">
                    </div>
                    <div class="form-group">
                        <label>Új jelszó ismét</label>
                        <input type="password" id="renewPwd" class="form-control" name="renewPwd">
                    </div>
                </div>
                <div class="modal-footer">
                    <input type="button" class="btn btn-default" data-dismiss="modal" value="Mégse">
                    <input type="submit" id="xhangePswd" class="btn btn-danger" value="Változtatás">
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    $("input#isTartLakcim").change(function() {
        let isTart = $("input#isTartLakcim").is(":checked");
        if (isTart) {
            $("#tartozkodasiBox").hide();

        } else {

            $("#tartozkodasiBox").show();
        }
    });
    $("select#al_lakcim_orszag").change(function() {
        let selecValue = $("select#al_lakcim_orszag").val();

        if (selecValue != 109) {
            let i;
            for (i = 0; i < 21; i++) {
                $("#al_lakcim_megye option[value='" + i + "']").hide();
                $("#al_lakcim_megye option[value='21']").show();
                $("#al_lakcim_megye").val("21");
            }
        } else {

           let i;
            for (i = 0; i < 21; i++) {
                $("#al_lakcim_megye option[value='" + i + "']").show();
            }
            $("#al_lakcim_megye option[value='" + 21 + "']").hide();
            $("#al_lakcim_megye").val("111");
        }

    });
    $("select#tart_lakcim_orszag").change(function() {
        let selecValue = $("select#tart_lakcim_orszag").val();

        if (selecValue != 109) {
            let i;
            for (i = 0; i < 21; i++) {
                $("#tart_lakcim_megye option[value='" + i + "']").hide();
                $("#tart_lakcim_megye option[value='21']").show();
                $("#tart_lakcim_megye").val("21");
            }
        } else {

           let i;
            for (i = 0; i < 21; i++) {
                $("#tart_lakcim_megye option[value='" + i + "']").show();
            }
            $("#tart_lakcim_megye option[value='" + 21 + "']").hide();
            $("#tart_lakcim_megye").val("111");
        }

    });

    $('#fogyatekossag').change(function() {
        let fogy = document.getElementById('fogyatekossag').value;
        if (fogy  == 1) { $('.fogyMegj').removeClass('d-none'); }
        if(fogy  == 0) { $('.fogyMegj').addClass('d-none');}
    });
</script>

<script>

function check()
{
/* ez nem jó ...
    let telszam = document.getElementById('telszam');
    let uzenet = document.getElementById('uzenet');
	  // let telszamformatum = /^\+?([0]{2})\)?[-. ]?([0-9]{2})[-. ]?([0-9]{4})[-. ]?([0-9]{5})$/;
	  let telszamformatum = /^\+?([0]{2})\)?[-. ]?.*$/;
    // console.log(telszam.value.match(telszamformatum));
	if(telszam.value.match(telszamformatum))
        {
		console.log('jó érték');
		uzenet.innerHTML = ""
		return true;
        }
      else
        {
        uzenet.innerHTML = "Nem jó formátumban adtad meg!"
        return false;
        }
*/
	}




</script>

<script type="text/javascript">
    function ddd() {
        /*profilepic*/
        let finput = $("#fileinput").val();
        console.log(finput);
        $('#profilepic').attr('src', finput);
    }

    function changeProfile() {
        $('#upload_image').click();
    }
   
    function upload(img) {
        var form_data = new FormData();
        form_data.append('file', img);
        form_data.append('_token', '{{csrf_token()}}');
        $('#loading').css('display', 'block');
        $.ajax({
            url: "{{url('ajax-image-upload')}}",
            data: form_data,
            type: 'POST',
            contentType: false,
            processData: false,
            success: function(data) {
                if (data.fail) {
                    $('#preview_image').attr('src', '{{asset('images/noimage.jpg ')}}');
                    alert(data.errors['file']);
                } else {
                    $('#file_name').val(data);
                    $('#preview_image').attr('src', '{{asset('userpic')}}/' + data);
                    $('#avatarpic').attr('src', '{{asset('userpic')}}/' + data);
                  /*  location.reload();*/
               }
                $('#loading').css('display', 'none');
            },
            error: function(xhr, status, error) {
                alert(xhr.responseText);
                $('#preview_image').attr('src', '{{asset('images / noimage.jpg ')}}');
            }
        });
    }
</script>



<script type="text/javascript">
    $(document).ready(function() {
        let szulDatum = '{{ $model->szulido }}';
        let szulDatumDarabok = szulDatum.split('-');
        let szulEv = szulDatumDarabok[0];let szulHo = szulDatumDarabok[1];let szulNap = szulDatumDarabok[2];
        console.log(szulEv);
        
        for(let i = 1930; i < 2009;i++)
        {
            if(szulEv == i)
            {//selected
                let x = document.getElementById("szuletesiIdoEv");
                let option = document.createElement("option");
                option.text =i; option.value = i; option.id = "ev-"+i;
                x.add(option);
                document.getElementById("ev-"+i).selected = true;
            }
            else //not selected 
            {
                let x = document.getElementById("szuletesiIdoEv");
                let option = document.createElement("option");
                option.text =i; option.value =i;option.id = "ev-"+i;
                x.add(option);
            }
        }

        for(let i = 1; i < 13;i++)
        {
            if(szulHo == i)
            {//selected
                
                    let x = document.getElementById("szuletesiIdoHo");
                    let option = document.createElement("option");
                    option.text =i; option.value = i; option.id = "ho-"+i;
                    x.add(option);
                document.getElementById("ho-"+i).selected = true;
            }
            else //not selected 
            {
                let x = document.getElementById("szuletesiIdoHo");
                let option = document.createElement("option");
                option.text =i; option.value =i;option.id = "ho-"+i;
                x.add(option);
            }
        }

        for(let i = 1; i < 32;i++)
        {
            if(szulNap == i)
            {//selected
                let x = document.getElementById("szuletesiIdoNap");
                let option = document.createElement("option");
                option.text =i; option.value = i; option.id = "nap-"+i;
                x.add(option);
                document.getElementById("nap-"+i).selected = true;
            }
            else //not selected 
            {
                let x = document.getElementById("szuletesiIdoNap");
                let option = document.createElement("option");
                option.text =i; option.value =i;option.id = "nap-"+i;
                x.add(option);
            }
        }


        $('#masSzervezetTagja').change(function() {
            let szervezet = $('#masSzervezetTagja').val();
            if (szervezet == 1) {
                $('div.dinamikusSzervezetMegj').show();
                $("#egyebSzervezet").prop('required',true);
            }
            else
            {
                $('div.dinamikusSzervezetMegj').hide(); $("#egyebSzervezet").prop('required',false);
            }
        });

        $('#masCivilSzervezetTagja').change(function() {
            let szervezet = $('#masCivilSzervezetTagja').val();
            if (szervezet == 1) {
                $('div.dinamikusSzervezetMegjCivil').show(); $("#civilSzervezet").prop('required',true);
            }
            else
            {
                $('div.dinamikusSzervezetMegjCivil').hide(); $("#civilSzervezet").prop('required',false);
            }
        });

        $('#tevekenyseg').change(function() {
            let tevekenyseg = $('#tevekenyseg').val();

            switch (tevekenyseg) {
                case "1":
                    $("#fotevekenysegem").empty();
                    let txt2 = $("<p></p>").text("Kérem, adja meg intézménye teljes nevét és címét! *");
                    let inputfield_foiskiskneve = '<input class="form-control" type="text" id="foisk" name="foisk" >';
                    let txt3 = $("<p></p>").text("Tanulmányi területének(szak) neve? *");
                    let inputfield_foiskosztaly = '<input class="form-control" type="text" id="szakneve" name="szakneve"/>';
                    let txt44 = $("<p></p>").text("Hányadik évfolyamba jár? *");
                    let inputfield_foiskosztaly2 = '<input class="form-control" type="number" id="evfolyam" name="evfolyam"min="0" max="7"/>';
                    $("#fotevekenysegem").append(txt2, inputfield_foiskiskneve, txt3, inputfield_foiskosztaly, txt44, inputfield_foiskosztaly2);
                    break;
                case "2":
                    $("#fotevekenysegem").empty();
                    let txt4 = $("<p></p>").text("Kérem, adja meg intézménye teljes nevét és címét! *");
                    let inputfield_koziskneve = '<input class="form-control" type="text" id="kozepisk" name="kozepisk" data-validation="required"/>';
                    let txt5 = $("<p></p>").text("Hányadik osztályba jár? *");
                    let inputfield_kozosztaly = '<input class="form-control" type="number" id="kozepiskoszt" name="kozepiskoszt" min="1" max="16" data-validation="required"/> ';
                    $("#fotevekenysegem").append(txt4, inputfield_koziskneve, txt5, inputfield_kozosztaly);
                    break;
                case "3":
                    $("#fotevekenysegem").empty();
                    let txt6 = $("<p></p>").text("Kérem, adja meg intézménye teljes nevét és címét! *");
                    let inputfield_altiskneve = '<input class="form-control" type="text" id="altisk" name="altisk" data-validation="required"/>';
                    let txt7 = $("<p></p>").text("Hányadik osztályba jár? *");
                    let inputfield_altosztaly = '<input class="form-control" type="number" id="altiskoszt" name="altiskoszt" data-validation="required" min="1" max="8"/>';
                    $("#fotevekenysegem").append(txt6, inputfield_altiskneve, txt7, inputfield_altosztaly);
                    break;
                case "4":
                    $("#fotevekenysegem").empty();
                    let txt8 = $("<p></p>").text("Kérem, adja meg intézménye teljes nevét és címét! ");
                    let munkahelyneve = '<input class="form-control" type="text" id="munkahely" name="munkahely" />';
                    let txt9 = $("<p></p>").text("Kérem, adja meg munkakörét/beosztását.*");
                    let beosztas = '<input class="form-control" type="text" id="munkakor" name="munkakor" data-validation="required"/>';
                    $("#fotevekenysegem").append(txt8,munkahelyneve,txt9, beosztas);
                    break;
                default:
                    $("#fotevekenysegem").empty();
                    break;
            }
        });

    });

    $('#szuletesiIdoHo').change(function(){
       
        $("#szuletesiIdoNap option").remove();
        let LeapYear = false;
            let selectedEv = document.getElementById("szuletesiIdoEv").value;
            if(selectedEv % 4 == 0)
            {
                LeapYear = true;
            }
            let selectedHo = document.getElementById("szuletesiIdoHo").value;
            console.log("szul ho valtozott " + selectedEv);

            let def = document.getElementById("szuletesiIdoNap");
                let defopt = document.createElement("option");
                defopt.text ="Nap"; defopt.value =0;defopt.id = "nap-0";
                def.add(defopt);

        for(let i = 1; i < 32;i++)
        {
            
            if(LeapYear && selectedHo == 2)
            {
                if(i == 30) break;
            }
            else { if(i == 29 && selectedHo == 2) break; }

            if(selectedHo == 4 && i == 31) break;
            if(selectedHo == 6 && i == 31) break;
            if(selectedHo == 9 && i == 31) break;
            if(selectedHo == 11 && i == 31) break;

                let x = document.getElementById("szuletesiIdoNap");
                let option = document.createElement("option");
                option.text =i; option.value =i;option.id = "nap-"+i;
                x.add(option);
            
        }
    });



</script>



@endsection

@section('scriptsection')
    <script>
        var spokenLangs = {!!$model->BeszelhetoNyelvek!!};
        let nyelv1 = @if(strlen($model->nyelv1) > 3) '{{$model->nyelv1}}' @else 'undefined' @endif;
        let nyelv2 = @if(strlen($model->nyelv2) > 3) '{{$model->nyelv2}}' @else 'undefined' @endif;
        let nyelv3 = @if(strlen($model->nyelv3) > 3) '{{$model->nyelv3}}' @else 'undefined' @endif;
        let nyelv4 = @if(strlen($model->nyelv4) > 3) '{{$model->nyelv4}}' @else 'undefined' @endif;
        let nyelv5 = @if(strlen($model->nyelv5) > 3) '{{$model->nyelv5}}' @else 'undefined' @endif;

        $(document).ready(function(){
                for(let i = 0; i < spokenLangs.length;i++)
            {
                if(nyelv1 == spokenLangs[i]["nyelvNeve"])
                {
                    $('#nyelv1').append(new Option(spokenLangs[i]["nyelvNeve"], spokenLangs[i]["nyelvNeve"],false,true));
                }
                else
                {
                    if(nyelv1 != spokenLangs[i]["nyelvNeve"] && nyelv2 != spokenLangs[i]["nyelvNeve"] && nyelv3 != spokenLangs[i]["nyelvNeve"] && nyelv4 != spokenLangs[i]["nyelvNeve"] && nyelv5 != spokenLangs[i]["nyelvNeve"])
                    {
                        $('#nyelv1').append(new Option(spokenLangs[i]["nyelvNeve"], spokenLangs[i]["nyelvNeve"]));
                    }
                   
                }

                if(nyelv2 == spokenLangs[i]["nyelvNeve"])
                {
                    if(nyelv1 != spokenLangs[i]["nyelvNeve"])
                    {
                        $('#nyelv2').append(new Option(spokenLangs[i]["nyelvNeve"], spokenLangs[i]["nyelvNeve"],false,true));
               
                    }
                }
                else
                {
                    if(nyelv1 != spokenLangs[i]["nyelvNeve"] && nyelv2 != spokenLangs[i]["nyelvNeve"] && nyelv3 != spokenLangs[i]["nyelvNeve"] && nyelv4 != spokenLangs[i]["nyelvNeve"] && nyelv5 != spokenLangs[i]["nyelvNeve"])
                   
                    {
                        $('#nyelv2').append(new Option(spokenLangs[i]["nyelvNeve"], spokenLangs[i]["nyelvNeve"]));
                    }
                    
                }
                if(nyelv3 == spokenLangs[i]["nyelvNeve"])
                {
                    $('#nyelv3').append(new Option(spokenLangs[i]["nyelvNeve"], spokenLangs[i]["nyelvNeve"],false,true));
                }
                else
                {
                    if(nyelv1 != spokenLangs[i]["nyelvNeve"] && nyelv2 != spokenLangs[i]["nyelvNeve"] && nyelv3 != spokenLangs[i]["nyelvNeve"] && nyelv4 != spokenLangs[i]["nyelvNeve"] && nyelv5 != spokenLangs[i]["nyelvNeve"])
                    {
                        $('#nyelv3').append(new Option(spokenLangs[i]["nyelvNeve"], spokenLangs[i]["nyelvNeve"]));
                    }
                    
                }
                if(nyelv4 == spokenLangs[i]["nyelvNeve"])
                {
                    $('#nyelv4').append(new Option(spokenLangs[i]["nyelvNeve"], spokenLangs[i]["nyelvNeve"],false,true));
                     }
                else
                {
                    if(nyelv1 != spokenLangs[i]["nyelvNeve"] && nyelv2 != spokenLangs[i]["nyelvNeve"] && nyelv3 != spokenLangs[i]["nyelvNeve"] && nyelv5 != spokenLangs[i]["nyelvNeve"])
                    {
                        $('#nyelv4').append(new Option(spokenLangs[i]["nyelvNeve"], spokenLangs[i]["nyelvNeve"]));
                    }
                   
                }

                if(nyelv5 == spokenLangs[i]["nyelvNeve"])
                {
                    $('#nyelv5').append(new Option(spokenLangs[i]["nyelvNeve"], spokenLangs[i]["nyelvNeve"],false,true));
                }
                else
                {
                    if(nyelv1 != spokenLangs[i]["nyelvNeve"] && nyelv2 != spokenLangs[i]["nyelvNeve"] && nyelv3 != spokenLangs[i]["nyelvNeve"] && nyelv4 != spokenLangs[i]["nyelvNeve"] && nyelv5 != spokenLangs[i]["nyelvNeve"])
                    {
                        $('#nyelv5').append(new Option(spokenLangs[i]["nyelvNeve"], spokenLangs[i]["nyelvNeve"]));
                    }
                   
                }
                }
            
           

                let selectedLakcimOrsz = $("select#al_lakcim_orszag").val();
                if(selectedLakcimOrsz == 109)
                {
                    $("#al_lakcim_megye option[value='" + 21 + "']").hide();
                }
                else
                {
                    let i;
                    for (i = 0; i < 21; i++) {
                        $("#al_lakcim_megye option[value='" + i + "']").hide();

                    }
                }

                let selectedTartOrsz = $("select#tart_lakcim_orszag").val();
                if(selectedTartOrsz == 109)
                {
                    $("#tart_lakcim_megye option[value='" + 21 + "']").hide();
                }
                else
                {
                    let i;
                    for (i = 0; i < 21; i++) {
                        $("#tart_lakcim_megye option[value='" + i + "']").hide();

                    }
                }


                let selectedAllIrsz = $("#al_lakcim_irszam").val();let selectedTartIrsz = $("#tart_lakcim_irszam").val();
                let notNUll = false;

                if(parseInt(selectedAllIrsz) > 1009 && parseInt(selectedTartIrsz) > 1009)
                {notNUll = true;}
                else
                {
                   // console.log("dsfs:" + selectedTartIrsz);
                   // alert('Az irányítószám nem megfelelő! Kérjük ellenőrizze!');
                }
                console.log("notnull: " + notNUll);
               /*hide tart_lakcim_box*/
               notNUll = true;
               if(notNUll)
               {

                    let selectedAllMegye = $("select#al_lakcim_megye").val();
                    let selectedAllTel = $("#al_lakcim_telepules").val();let selectedTartTel = $("#tart_lakcim_telepules").val();

                    let selectedAllLakcim= $("#al_lakcim_utca").val();

                    let selectedTartMegye = $("select#tart_lakcim_megye").val();

                    let selectedTartLakcim= $("#tart_lakcim_utca").val();
                    let Megye = false; let Irsz = false; let Lakcim = false; let Telepules = false;

                    if(parseInt(selectedAllIrsz) == parseInt(selectedTartIrsz))
                    {Irsz = true; }
                    if(selectedAllTel == selectedTartTel)
                    {Telepules = true;}
                    if(selectedAllMegye == selectedTartMegye)
                    {Megye = true;}
                    if(selectedAllLakcim == selectedTartLakcim)
                    {Lakcim = true;}

                    if(Megye && Irsz && Lakcim && Telepules)
                    {

                        $('#tartozkodasiBox').hide();
                        document.getElementById("isTartLakcim").checked = true;

                    }
               }
               else {console.log("hiba");}
        });

        function SetIgazolas()
        {

            let igazolas_value = document.getElementById('ig_egyeb').checked;
            if(igazolas_value)
            {
                 document.getElementById('ifIgazolasOther').style.display = 'block';
            }
            else
            {document.getElementById('ifIgazolasOther').style.display = 'none';}
        }

        var kozosseg = JSON.parse(@php echo json_encode($egyhazmegyek) @endphp);

        function select_egyhazkozosseg()
        {
            let felekezet = document.getElementById('Felekezetek').value;

            var romaikat = [];
            var gorogkat = [];
            for(let i = 0; i < Object.keys(kozosseg).length;i++)
            {
                if(kozosseg[i].felekezet == 'Görög Katolikus Egyház')
                {
                    gorogkat.push(kozosseg[i].nev);
                }
                if(kozosseg[i].felekezet == 'Római Katolikus Egyház')
                {
                    romaikat.push(kozosseg[i].nev);
                }
            }
            switch(felekezet)
            {
                case 'Római Katolikus Egyház':
                    document.getElementById('Egyebinput').classList.add('d-none');
                    $('#egyhazmegyek').empty().append(new Option("Kérem válasszon",'none',true));
                    for(let i = 0; i < romaikat.length;i++)
                    {

                        $('#egyhazmegyek').append(new Option(romaikat[i], romaikat[i]));
                    }
                    $('#EgyhazMegye').removeClass('d-none');
                    $('#egyhazmegyek').removeClass('d-none');
                    document.getElementById('egyhazmegyek').dataset.validation = "required";
                break;
                case 'Görög Katolikus Egyház':
                    $('#egyhazmegyek').empty().append(new Option("Kérem válasszon",'none',true));
                    document.getElementById('Egyebinput').classList.add('d-none');
                    for(let i = 0; i < gorogkat.length;i++)
                    {

                        $('#egyhazmegyek').append(new Option(gorogkat[i], gorogkat[i]));
                    }
                    $('#EgyhazMegye').removeClass('d-none');
                    $('#egyhazmegyek').removeClass('d-none');
                    document.getElementById('egyhazmegyek').dataset.validation = "required";
                break;

                case 'Egyéb':
                document.getElementById('egyhazmegyek').classList.add('d-none');
                    $('#Egyebinput').removeClass('d-none'); $("select#egyhazmegyek").removeData('validation');
                break;

                case 'egyéb':document.getElementById('egyhazmegyek').classList.add('d-none');

                    $('#Egyebinput').removeClass('d-none'); $("select#egyhazmegyek").removeData('validation');
                break;
                default:
                document.getElementById('Egyebinput').classList.add('d-none');
                document.getElementById('egyhazmegyek').classList.add('d-none');
                $("select#egyhazmegyek").removeData('validation');
                    $("#egyhazinput").removeData('validation');
                break;

            }
        }

        var valasztottEgyhaz = JSON.parse('{!! $valasztottEgyhazMegye !!}');
        var felekezet = null;

        $(document).ready(function(){

            if(valasztottEgyhaz != null)
            {
                for(let i = 0; i < Object.keys(kozosseg).length;i++)
            {
                if(parseInt(kozosseg[i].id) == parseInt(valasztottEgyhaz.egyhazmegye_id))
                {
                    felekezet = kozosseg[i];

                }

            }

            switch(felekezet.felekezet)
            {
                case 'Római Katolikus Egyház':
                    $("select#Felekezetek").val(felekezet.felekezet);
                    select_egyhazkozosseg();
                     $("select#egyhazmegyek").val(felekezet.nev);$("#EgyhazMegye").removeClass('d-none');
                     //data-validation="required"
                     $("select#egyhazmegyek").data('validation','required');
                break;
                case 'Görög Katolikus Egyház':
                    $("select#Felekezetek").val(felekezet.felekezet);
                    select_egyhazkozosseg();
                    $("select#egyhazmegyek").val(felekezet.nev);$("#EgyhazMegye").removeClass('d-none');
                    $("select#egyhazmegyek").data('validation','required');
                break;

                case 'Egyéb':
                    $("#egyhazinput").val(felekezet.egyhazmegye_id);
                    $("select#Felekezetek").val(felekezet.felekezet);
                    $("select#egyhazmegyek").removeData('validation');
                    document.getElementById('Egyebinput').classList.remove('d-none');
                    document.getElementById('egyhazinput').value = valasztottEgyhaz.egyebInputValue;
                break;
                case 'Nem tartozom felekezethez':
                $("select#Felekezetek").val('Nem tartozom felekezethez');
                    
                break;

                case 'egyéb':document.getElementById('egyhazmegyek').classList.add('d-none');
                     $("select#Felekezetek").val(felekezet.felekezet);
                    $("select#egyhazmegyek").removeData('validation');
                    document.getElementById('Egyebinput').classList.remove('d-none');
                    document.getElementById('egyhazinput').value = valasztottEgyhaz.egyebInputValue;
                break;
                default:
                    $("select#egyhazmegyek").val('Nem tartozom felekezethez');
                    $("select#egyhazmegyek").removeData('validation');
                    $("#egyhazinput").removeData('validation');
                break;

            }
            }
           
        });


    </script>

<script>
    function DefLangChecker(List1,List2,List3,List4,ActList)
    {
        let l1 = document.getElementById(List1);
        let l2 = document.getElementById(List2);
        let l3 = document.getElementById(List3);
        let l4 = document.getElementById(List4);

        for (let i=0; i<l1.length; i++) {
            if (l1.options[i].value == ActList.value)
                l1.remove(i);
        }

        for (let i=0; i<l2.length; i++) {
            if (l2.options[i].value == ActList.value)
                l2.remove(i);
        }

        for (let i=0; i<l3.length; i++) {
            if (l3.options[i].value == ActList.value)
                l3.remove(i);
        }

        for (let i=0; i<l4.length; i++) {
            if (l4.options[i].value == ActList.value)
                l4.remove(i);
        }

        //l1.remove(ActList.selectedIndex);l2.remove(ActList.selectedIndex);l3.remove(ActList.selectedIndex);l4.remove(ActList.selectedIndex);
    }

</script>

<script>
    $(document).ready(function() {
  $(window).keydown(function(event){
    if(event.keyCode == 13) {
      event.preventDefault();
      return false;
    }
  });
});
</script>


@if($errors->cpv->first())

<script>
    var validateJson = JSON.parse(' {!! $errors->cpv->first() !!}');
    var formvalid = validateJson.IsFormValid;
    var emptyFieldList = validateJson.EmptyFieldsList;
    var msg = validateJson.message;
    for(let i = 0; i < emptyFieldList.length;i++)
    {   
        if(emptyFieldList[i] == "vezeteknev") {
            document.getElementById('errVezNev').classList.remove('d-none');
        }
        
        if(emptyFieldList[i] == "keresztnev") {
            document.getElementById('errKerNev').classList.remove('d-none'); 
        }
        if(emptyFieldList[i] == "telefonszam") {
            document.getElementById('errTelNev').classList.remove('d-none'); 
        }
        if(emptyFieldList[i] == "szulev") {
            document.getElementById('errSzulEv').classList.remove('d-none'); 
        }
        if(emptyFieldList[i] == "szulhonap") {
            document.getElementById('errSzulHo').classList.remove('d-none'); 
        }
        if(emptyFieldList[i] == "szulnap") {
            document.getElementById('errSzulNap').classList.remove('d-none'); 
        }
        if(emptyFieldList[i] == "szulhely") {
            document.getElementById('errSzulHely').classList.remove('d-none'); 
        }
        if(emptyFieldList[i] == "neme") {
            document.getElementById('errNeme').classList.remove('d-none'); 
        }
        if(emptyFieldList[i] == "anyjaneve") {
            document.getElementById('errAnyjaNeve').classList.remove('d-none'); 
        }
        if(emptyFieldList[i] == "errAllampolg") {
            document.getElementById('errAnyjaNeve').classList.remove('d-none'); 
        }
        if(emptyFieldList[i] == "szemigszam") {
            document.getElementById('errSzemIgSzam').classList.remove('d-none'); 
        }
        if(emptyFieldList[i] == "allando_orszag") {
            document.getElementById('errAllando1').classList.remove('d-none'); document.getElementById('errAllando2').classList.remove('d-none');
            document.getElementById('errAllando3').classList.remove('d-none'); document.getElementById('errAllando4').classList.remove('d-none');  
            document.getElementById('errAllando5').classList.remove('d-none'); 
        }
        if(emptyFieldList[i] == "tartlakcim") {
            document.getElementById('errTart1').classList.remove('d-none'); document.getElementById('errTart2').classList.remove('d-none');
            document.getElementById('errTart3').classList.remove('d-none'); document.getElementById('errTart4').classList.remove('d-none');  
            document.getElementById('errTart5').classList.remove('d-none'); 
        }

        if(emptyFieldList[i] == "szervezeterror") {
            document.getElementById('errszervezet').classList.remove('d-none'); 
        }

        if(emptyFieldList[i] == "foteverror") {
            document.getElementById('errTev').classList.remove('d-none'); 
        }

        if(emptyFieldList[i] == "civilerror") {
            document.getElementById('errCivil').classList.remove('d-none'); 
        }
    }
    if(!formvalid)
    {
       
    }
    $(document).ready(function(){
        console.log(msg);
        $('#ErrorMessages').append(msg);
        $( "#myerrorModal" ).modal('show');
    });
    
</script>
                                     

<div  class="modal fade"   id="myerrorModal" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Sikertelen profil mentés!</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body" style="color: red;">
            <section id="ErrorMessageBox">
                <ul id="ErrorMessages">

                </ul>
            </section>
        </div>
        <div class="modal-footer">
          
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Értem</button>
        </div>
      </div>
    </div>
  </div>


@endif

@if($errors->oldInputs->first())

<script>
let inputFields = JSON.parse(' {!! $errors->oldInputs->first() !!}');

$(document).ready(function (){
            $('#nevelotag').val(inputFields["nevelotag"]);
            $('#telszam').val(inputFields["telszam"]);
            $('#szulhely').val(inputFields["szulhely"]);
            $('#kozepsonev').val(inputFields["kozepsonev"]);
            $('#mothername').val(inputFields["mothername"]);
            $('#szuletesiIdoEv').val(inputFields["szuletesiIdoEv"]);
            $('#szuletesiIdoHo').val(inputFields["szuletesiIdoHo"]);
            $('#szuletesiIdoNap').val(inputFields["szuletesiIdoNap"]);
            $('#vezeteknev').val(inputFields["vezeteknev"]);
            $('#userneme').val(inputFields["userneme"]);
            $('#nationality').val(inputFields["nationality"]);
            $('#szemigszam').val(inputFields["szemigszam"]);
            $('#al_lakcim_orszag').val(inputFields["al_lakcim_orszag"]);
            $('#al_lakcim_megye').val(inputFields["al_lakcim_megye"]);
            $('#al_lakcim_telepules').val(inputFields["al_lakcim_telepules"]);
            $('#al_lakcim_irszam').val(inputFields["al_lakcim_irszam"]);
            $('#al_lakcim_utca').val(inputFields["al_lakcim_utca"]);  
            $('#nyelv1').val(inputFields["nyelv1"]);
            $('#nyelv2').val(inputFields["nyelv2"]);
            $('#nyelv3').val(inputFields["nyelv3"]);
            $('#nyelv4').val(inputFields["nyelv4"]);
            $('#nyelv5').val(inputFields["nyelv5"]);
            $('#nyelv1szint').val(inputFields["nyelv1szint"]);
            $('#nyelv2szint').val(inputFields["nyelv2szint"]);
            $('#nyelv3szint').val(inputFields["nyelv3szint"]);
            $('#nyelv4szint').val(inputFields["nyelv4szint"]);
            $('#nyelv5szint').val(inputFields["nyelv5szint"]);



            $('#igazolas').val(inputFields["igazolas"]);



            $('#egyhazmegyek').val(inputFields["egyhazmegyek"]);
           
            console.log(inputFields["tevekenyseg"]);
            if(inputFields["tevekenyseg"] != 'undefined') 
            {
                $('#tevekenyseg').val(inputFields["tevekenyseg"]);
            }
            else {
                $('#tevekenyseg').val('none');
            }

            $('#userpolomeret').val(inputFields["userpolomeret"]);
            $('#userpolotipusa').val(inputFields["userpolotipusa"]);



            $('#fogyatekossag').val(inputFields["fogyatekossag"]);
            if(inputFields["fogyatekossag"] == "1")
            {
                $('.fogyMegj').removeClass('d-none');
                $('#fogyLeirasa').val(inputFields["fogyLeirasa"]);
            }
            

             if(inputFields["isTartLakcim"] == "TartAzonos")
            {
                 document.getElementById("isTartLakcim").checked = true;
                 $('#tart_lakcim_orszag').val(inputFields["al_lakcim_orszag"]);
                $('#tart_lakcim_megye').val(inputFields["al_lakcim_megye"]);
                $('#tart_lakcim_telepules').val(inputFields["al_lakcim_telepules"]);
                $('#tart_lakcim_irszam').val(inputFields["al_lakcim_irszam"]);
                $('#tart_lakcim_utca').val(inputFields["al_lakcim_utca"]);
                $('#isTartLakcim').val(inputFields["isTartLakcim"]);
            }
            else {document.getElementById("isTartLakcim").checked = true;
                $('#tart_lakcim_orszag').val(inputFields["tart_lakcim_orszag"]);
                $('#tart_lakcim_megye').val(inputFields["tart_lakcim_megye"]);
                $('#tart_lakcim_telepules').val(inputFields["tart_lakcim_telepules"]);
                $('#tart_lakcim_irszam').val(inputFields["tart_lakcim_irszam"]);
                $('#tart_lakcim_utca').val(inputFields["tart_lakcim_utca"]);
                $('#isTartLakcim').val(inputFields["isTartLakcim"]);
            }
           
            if(inputFields["tevekenyseg"] == 1)
            {
                let txt2 = $("<p></p>").text("Kérem, adja meg intézménye teljes nevét és címét! *");
                    let inputfield_foiskiskneve = '<input class="form-control" type="text" id="foisk" name="foisk" >';
                    let txt3 = $("<p></p>").text("Tanulmányi területének(szak) neve? *");
                    let inputfield_foiskosztaly = '<input class="form-control" type="text" id="szakneve" name="szakneve"/>';
                    let txt44 = $("<p></p>").text("Hányadik évfolyamba jár? *");
                    let inputfield_foiskosztaly2 = '<input class="form-control" type="number" id="evfolyam" name="evfolyam"min="0" max="7"/>';
                    $("#fotevekenysegem").append(txt2, inputfield_foiskiskneve, txt3, inputfield_foiskosztaly, txt44, inputfield_foiskosztaly2);
                    $('#foisk').val(inputFields["foisk"]);
                    $('#szakneve').val(inputFields["szakneve"]);
                    $('#evfolyam').val(inputFields["evfolyam"]);
            }
            if(inputFields["tevekenyseg"] == 2 )
            {
                let txt4 = $("<p></p>").text("Kérem, adja meg intézménye teljes nevét és címét! *");
                    let inputfield_koziskneve = '<input class="form-control" type="text" id="kozepisk" name="kozepisk" data-validation="required"/>';
                    let txt5 = $("<p></p>").text("Hányadik osztályba jár? *");
                    let inputfield_kozosztaly = '<input class="form-control" type="number" id="kozepiskoszt" name="kozepiskoszt" min="1" max="16" data-validation="required"/> ';
                    $("#fotevekenysegem").append(txt4, inputfield_koziskneve, txt5, inputfield_kozosztaly);
                    $('#kozepisk').val(inputFields["kozepisk"]);
                    $('#kozepiskoszt').val(inputFields["kozepiskoszt"]);

            }
            if(inputFields["tevekenyseg"] == 3)
            {
                    $("#fotevekenysegem").empty();
                    let txt6 = $("<p></p>").text("Kérem, adja meg intézménye teljes nevét és címét! *");
                    let inputfield_altiskneve = '<input class="form-control" type="text" id="altisk" name="altisk" data-validation="required"/>';
                    let txt7 = $("<p></p>").text("Hányadik osztályba jár? *");
                    let inputfield_altosztaly = '<input class="form-control" type="number" id="altiskoszt" name="altiskoszt" data-validation="required" min="1" max="8"/>';
                    $("#fotevekenysegem").append(txt6, inputfield_altiskneve, txt7, inputfield_altosztaly);
                    $('#altisk').val(inputFields["altisk"]);
                    $('#altiskoszt').val(inputFields["altiskoszt"]);

            }
            if(inputFields["tevekenyseg"] == 4)
            {
                let txt8 = $("<p></p>").text("Kérem, adja meg intézménye teljes nevét és címét! ");
                    let munkahelyneve = '<input class="form-control" type="text" id="munkahely" name="munkahely" />';
                    let txt9 = $("<p></p>").text("Kérem, adja meg munkakörét/beosztását.*");
                    let beosztas = '<input class="form-control" type="text" id="munkakor" name="munkakor" data-validation="required"/>';
                    $("#fotevekenysegem").append(txt8,munkahelyneve,txt9, beosztas);
                    $('#munkahely').val(inputFields["munkahely"]);
                    $('#munkakor').val(inputFields["munkakor"]);
              
            }
            if(inputFields["fogyatekossag"] == 1)
                {
                    $('#fogyatekossag').val(inputFields["fogyatekossag"]);
                    let szoveg = `<div class="fogyMegj">
                                        <label style="font-size:12px;">Amennyiben igen, kérem, jelezze felénk fogyatékossága típusát és fokát; és önkéntes közreműködése során esetleges különleges igényeit!</label>
                                        <input type="text" class="form-control" id="fogyLeirasa" name="fogyLeirasa" value="`+inputFields["fogyLeirasa"]+`" />
                                        <span class="d-none" id="errFogy">
                                            <span class="myalert">Kötelező mező!</span>
                                        </span>
                                    </div>`;
                    $("#fogyatekossag").append(szoveg);
                }
                else
                {
                    $('#fogyatekossag').val(inputFields["fogyatekossag"]);
                }
                
                if(inputFields["masSzervezetTagja"] == 1)
                {
                    $('#masSzervezetTagja').val(inputFields["masSzervezetTagja"]);
                   
                    document.getElementById('rejtettSzervezet').style.display = "block";
                    $('#egyebSzervezet').val(inputFields["egyebSzervezet"]);
                    
                                                           
                }
                else
                {
                    $('#masSzervezetTagja').val(inputFields["masSzervezetTagja"]);
                }


                if(inputFields["masCivilSzervezetTagja"] == 1)
                {
                    $('#masCivilSzervezetTagja').val(inputFields["masCivilSzervezetTagja"]);

                    document.getElementById('rcivil').style.display = "block";
                    $('#civilSzervezet').val(inputFields["civilSzervezet"]);
                }
                else
                {
                    $('#masCivilSzervezetTagja').val(inputFields["masCivilSzervezetTagja"]);
                }

                 var romaikat = [];
                    var gorogkat = [];
                    for(let i = 0; i < Object.keys(kozosseg).length;i++)
                    {
                        if(kozosseg[i].felekezet == 'Görög Katolikus Egyház')
                        {
                            gorogkat.push(kozosseg[i].nev);
                        }
                        if(kozosseg[i].felekezet == 'Római Katolikus Egyház')
                        {
                            romaikat.push(kozosseg[i].nev);
                        }
                    }
                   
                if(inputFields["Felekezetek"] == "Egyéb")
                {
                     $('#Felekezetek').val(inputFields["Felekezetek"]);
                    $('#Egyebinput').removeClass("d-none");
                    document.getElementById('egyhazinput').style.display = "block";
                    $('#egyhazinput').val(inputFields["egyhazinput"]);
                    
                }
               

                if(inputFields["Felekezetek"] == "Római Katolikus Egyház")
                {
                    $('#Felekezetek').val(inputFields["Felekezetek"]);
                   $('#EgyhazMegye').removeClass("d-none");
                    $('#egyhazmegyek').empty().append(new Option("Kérem válasszon",'none',true));
                    for(let i = 0; i < romaikat.length;i++)
                    {
                        $('#egyhazmegyek').append(new Option(romaikat[i], romaikat[i]));
                    }
                        $('#egyhazmegyek').val(inputFields["egyhazmegyek"]);
                }
                

                   if(inputFields["Felekezetek"] == "Görög Katolikus Egyház")
                {
                    $('#Felekezetek').val(inputFields["Felekezetek"]);
                   $('#EgyhazMegye').removeClass("d-none");
                    $('#egyhazmegyek').empty().append(new Option("Kérem válasszon",'none',true));
                    for(let i = 0; i < gorogkat.length;i++)
                    {

                        $('#egyhazmegyek').append(new Option(gorogkat[i], gorogkat[i]));
                    }

                        $('#egyhazmegyek').val(inputFields["egyhazmegyek"]);
                }

                if(inputFields["Felekezetek"] == "Nem tartozom felekezethez")
                {
                    $('#Felekezetek').val(inputFields["Felekezetek"]);
                  
                }
               


            if(inputFields["igazolas"]== 0)
            {
                document.getElementById("nem").checked = true;
            }
            if(inputFields["igazolas"]== 1)
            {
                document.getElementById("igen-alt").checked = true;
            }
            if(inputFields["igazolas"]== 2)
            {
                document.getElementById("igen-szakmai").checked = true;
            }
            if(inputFields["igazolas"]== 3)
            {
                document.getElementById("iksz").checked = true;
            }
            if(inputFields["igazolas"]== 4)
            {
                document.getElementById("ig_egyeb").checked = true;
            }
            if(inputFields["etkezes"]== 1)
            {
                document.getElementById("normal").checked = true;
            }
            if(inputFields["etkezes"]== 2)
            {
                document.getElementById("laktozz").checked = true;
            }
}); 

</script>

@endif

<link href="https://cdnjs.cloudflare.com/ajax/libs/croppie/2.6.5/croppie.css" rel="stylesheet">
		<script src="https://cdnjs.cloudflare.com/ajax/libs/croppie/2.6.5/croppie.js" ></script>
        <script>
		/* js beallito fajl*/
			$image_crop = $('#image_demo').croppie({
    enableExif: true,
    viewport: {
      width:300,
      height:300,
      type:'square' //circle
    },
    boundary:{
      width:450,
      height:450
    },
    customClass: 'crop-area',
    showZoomer: true,
    enableResize: true,
    enableOrientation: false,
    mouseWheelZoom: 'ctrl'
    
  });

  $('#upload_image').on('change', function(){
    var reader = new FileReader();
    reader.onload = function (event) {
      $image_crop.croppie('bind', {
        url: event.target.result
      }).then(function(){
        console.log('jQuery bind complete');
      });
    }
    reader.readAsDataURL(this.files[0]);
    $('#uploadimageModal').modal('show');
  });

$('.crop_image').on('click', function (event) {
	$image_crop.croppie('result', {
		type: 'blob',
		format: 'jpeg',
		//type: 'canvas',
		//size: 'viewport'
		size: {width: 300, height: 300}
	}).then(function (response) {
        const formData = new FormData();
	    formData.append('file', response,'file.jpg');
        formData.append('_token', '{{csrf_token()}}');
        $.ajax({
            url: "{{url('ajax-image-upload')}}",
            data: formData,
            type: 'POST',
            contentType: false,
            processData: false,
            success: function(data) {
                if (data.fail) {
                    $('#preview_image').attr('src', '{{url('images/noimage.jpg ')}}');
                    alert(data.errors['file']);
                } else {
                    $('#file_name').val(data);
                    $('#preview_image').attr('src', '{{url('userpic')}}/' + data);
                    $('#avatarpic').attr('src', '{{url('userpic')}}/' + data);
                  /*  location.reload();*/
               }
                $('#loading').css('display', 'none');
            },
            error: function(xhr, status, error) {
                alert(xhr.responseText);
                $('#preview_image').attr('src', '{{url('images/noimage.jpg ')}}');
            }
        });
		$('#preview_image').attr('src', response);
		$('#uploadimageModal').modal('hide');

	});
    return false;
});
  


/*
$('.btn-add').on('click', function (response) { 
		$.ajax({
        url:"upload.php",
        type: "POST",
        data:{"image": response},
        success:function(data)
        {
          //$('#uploadimageModal').modal('hide');
          //$('#uploaded_image').html(data);
		  alert(data);
        }
      });

}); 
*/
		</script>
       
@endsection
