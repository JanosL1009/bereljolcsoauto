@extends('layouts.app')


@section('content')
<div class="row">
        <div class="col-12 d-flex justify-content-between">
          <h1>Felhasználók</h1>
          <button type="button" class="btn btn-primary">+ Új hozzáadása</button>
        </div>
        <div class="col-12 d-flex justify-content-center">
          <div class="gombok">
            <button type="button" class="btn btn-primary">Önkéntesek</button>
            <button type="button" class="btn btn-secondary">vezetők</button>
            <button type="button" class="btn btn-secondary">adminok</button>
          </div>
        </div>
        <div class="col-12">
          <div class="card my-3">
            <table class="table table-striped">
              <thead>
                <tr>
                  <th scope="col">Név</th>
                  <th scope="col">Email</th>
                  <th scope="col">ID</th>
                </tr>
              </thead>
              <tbody>
                <tr data-href="http://tutorialsplane.com">
                  <th>Perényi Szilvia</th>
                  <td>sperenyi@hotmail.com</td>
                  <td>17</td>
                </tr>
                <tr data-href="http://tutorialsplane.com">
                  <th>Erdélyi Balázs</th>
                  <td>erdelyi.balazs1979@gmail.com</td>
                  <td>10</td>
                </tr>
                <tr data-href="http://tutorialsplane.com">
                  <th>Dul Anita</th>
                  <td>1213da@gmail.com</td>
                  <td>60</td>
                </tr>
                <tr data-href="http://tutorialsplane.com">
                  <th>Általános jelentkezés</th>
                  <td>altalanos@mi.hu</td>
                  <td>44</td>
                </tr>
                <tr data-href="http://tutorialsplane.com">
                  <th>Általános helyzet</th>
                  <td>miahelyzet@hatsemmi.hu</td>
                  <td>1</td>
                </tr>
              </tbody>
            </table>
          </div>
          <nav aria-label="...">
            <ul class="pagination pagination-sm justify-content-center">
              <li class="page-item active" aria-current="page">
                <span class="page-link">
                  1
                  <span class="sr-only">(current)</span>
                </span>
              </li>
              <li class="page-item"><a class="page-link" href="#">2</a></li>
              <li class="page-item"><a class="page-link" href="#">3</a></li>
            </ul>
          </nav>
        </div>

      </div>


@endsection
