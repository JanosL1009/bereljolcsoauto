@extends('layouts.admin')


@section('content')
    <style>.OutOfStock{color: green;border-radius: 20px;border-style: solid; background-color: green;height: 12px; width: 12px; display: block;}</style>
    <div class="row">
        <div class="col-12">
            <h1>{{$user->name}} ajándék története</h1>
        </div>
          @include('adminisztratorok/ruha_atado/menu_admin')
    </div>

   


    <div class="row mt-3">
        <div class="col-6">
            <div class="card">
                <table class="table table-striped table-hover">
                    <tbody >
                        <tr>
                            <th> A felhasználó neve:</th>
                            <td><b> {{$user->name}} </b></td>
                        </tr>
                         <tr>
                            <th>  Email címe:</th>
                            <td><b>  {{$user->email}} </b></td>
                        </tr>
                      
                       <tr>
                            <th>Óraszám:</th>
                            <td>
                                    <b>  {{$user->felhasznalo_data->onkentesOrakSzama}} </b>
                            </td>
                        </tr>
                         <tr>
                            <th>Jelölt tanúsítvány forma:</th>
                            <td>
                                    <b>  {{$igazolas}} </b>
                            </td>
                        </tr>
                        
                    </tbody>
                </table>
                
            </div>
        </div>

        <div class="col-6">
            <div class="card">
                <div style=" border: 1px solid whitesmoke ;text-align: center;position: relative" id="image"> 
                    <img width="50%" height="50%" id="preview_image" src="{{url('userpic/'.$user->felhasznalo_data->profilkep)}}" />
                </div>
            </div>
        </div>
    </div>

    <div class="row mt-3">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form action="{{route('admin.tanusitvany.nyomtatas')}}" method="post" class="form-inline">
                        @csrf
                        <div class="form-group">
                            <label for="igazolas">Igazolás választása: </label>
                                <select class="form-control" id="igazolas" name="igazolas">
                                    <option selected disabled>Nyomtatvány választása</option>
                                    <option value="2">Önkéntes, általános igazolás</option>
                                    <option value="3">IKSZ igazolás</option>
                                </select>
                        </div>  
                        <div class="form-group">
                            <input type="hidden"  value="{{$user->id}}" name="userid" id="userid">
                            <input type="submit" class="btn btn-primary" value="Letöltés">
                        </div>  
                    </form>
                </div>
            </div>
        </div>

    </div>

@endsection