@extends('layouts.admin')

@section('content')
<style>

    .hint-text {
        float: left;
        margin-top: 10px;
        font-size: 13px;
    }
    select {
      -webkit-border-radius: 20px;
      -moz-border-radius: 20px;
      border-radius: 20px;
    }
</style>
<div class="row">

  <div class="col-12 col-md-12">
    <div class="card my-3">
      <div class="card-body">
        <form action="{{url ('/admin/onkentes_keresese')}}" method="GET" enctype="multipart/form-data" id="onkentes_keresese" name = "onkentes_keresesem">

          <div class="row">
            <div class="col-12 d-flex justify-content-between">
              <h1>Nevek</h1>
            </div>
          </div>

          <div class="col-12">
            <div class="d-flex flex-wrap">
              <input value="{{request()->onkentes_neve}}"
                     type="text"
                     class="form-control col-12 col-md-6 my-2"
                     id="onkentes_neve"
                     name="onkentes_neve"
                     placeholder="Név">
              <input value="{{request()->onkentes_kora}}"
                     type="number"
                     class="form-control col-12 col-md-6 my-2 " id="onkentes_kora"
                     name="onkentes_kora"
                     placeholder="Kor">

              <select class="form-control col-12 col-md-6 my-2 " id="rendezveny" name="rendezveny" style="border-radius; -webkit-border-radius: 20px;
              -moz-border-radius: 20px;">
                <option disabled selected value>Rendezvény</option>
                @foreach($model->programok as $program)
                <option value="{{$program->id}}">{{$program->nev}}</option>
                @endforeach
              </select>

              <select class="form-control col-12 col-md-6 my-2 " id="terulet" name="terulet" style="border-radius; -webkit-border-radius: 20px;
                -moz-border-radius: 20px;">
                    <option disabled selected value>Terület</option>

              </select>


            </div>
            <hr>
            <div class="d-flex flex-wrap">
              <input type="email" id="volemail" name="volemail" value="{{request()->volemail}}"  class="form-control col-12 col-md-6 my-2 " placeholder="E-mail cím alapján">
            </div>

            <button type="submit" class="btn btn-primary">Keresés</button>
        </form>
        <hr>
        <div>
            @if(isset($szemelyek))
                <p>Találat: {{$szemelyek->total()}} </p>
            @endif
        </div>
          </div>

          <div class="table-wrapper mt-4">
            <table class="table table-striped table-hover">
                <thead>
                  <tr>
                    <th>Profilkep</th>
                    <th>Név</th>
                    <th>Jogosultság</th>
                  </tr>
                </thead>
                <tbody>
                    @if(isset($szemelyek))
                        @foreach ($szemelyek as $szemely)

                        @php
                            $profilkep = $szemely['profilkep']??'blank-profile-pic-omr.png';
                        @endphp

                        <tr>
                            <td><img src="{{url('userpic/'.$profilkep)}}" width="94" height="94" /></td>
                            <td data-label="Név">
                            <a target="_blank" href="{{url('/admin/onkentes_szerkesztese/'.$szemely['id'])}}">
                                <strong>{{$szemely['nev']}}</strong>
                            </a>
                                <br/>
                                Született: {{$szemely['szulIdo']??null}}
                                <br/>
                                Cím:    {{$szemely['lakcim']??null}}
                            </td>
                            <td data-label="Jogosultság">
                                    <a class="btn-link" target="_blank" href="{{url('/admin/onkentes_szerkesztese/'.$szemely['id'])}}">Felhasználó módosítása</a>
                                    <br><label>{{$szemely['jogosultsag']}}</label>
                                    <br><a class="btn-link" target="_blank" href="{{url('admin/akkreditacio/profil/'.$szemely['id'])}}">Akkreditációs adatlap</a>
                                    <br><a class="btn-link" target="_blank" href="{{url('admin/jelentkezes/terulet/'.$szemely['id'])}}">Jelentkezések</a>
                                    <br><a class="btn-link" target="_blank" href="{{route('igazoltorak.admin.index',['UserID' => $szemely['id'] ])}}">Igazolt órák</a>
                            </td>
                        </tr>

                    @endforeach
                  @endif
              </tbody>
            </table>

            <div class="clearfix float-left">
                @if(isset($szemelyek))
                 {{$szemelyek->links()}}
                @endif

            </div>
          </div>

  </div>
</div>
</div>

</div>

        <script src="{{ asset('js/jquery.form-validator.min.js') }}"></script>
        <script>
           var myLanguage = {

                errorTitle: 'Az űrlap feldolgozása sikertelen.',
                requiredFields: 'You have not answered all required fields',
                badTime: 'You have not given a correct time',
                badEmail: 'You have not given a correct e-mail address',
                badTelephone: 'You have not given a correct phone number',
                badSecurityAnswer: 'You have not given a correct answer to the security question',
                badDate: 'You have not given a correct date',
                lengthBadStart: 'The input value must be between ',
                lengthBadEnd: ' karakter',
                lengthTooLongStart: 'The input value is longer than ',
                lengthTooShortStart: 'Az input érték nem lehet kevesebb, mint ',
                notConfirmed: 'Input values could not be confirmed',
                badDomain: 'Incorrect domain value',
                badUrl: 'The input value is not a correct URL',
                badCustomVal: 'The input value is incorrect',
                andSpaces: ' and spaces ',
                badInt: 'The input value was not a correct number',
                badSecurityNumber: 'Your social security number was incorrect',
                badUKVatAnswer: 'Incorrect UK VAT Number',
                badStrength: 'The password isn\'t strong enough',
                badNumberOfSelectedOptionsStart: 'You have to choose at least ',
                badNumberOfSelectedOptionsEnd: ' answers',
                badAlphaNumeric: 'The input value can only contain alphanumeric characters ',
                badAlphaNumericExtra: ' and ',
                wrongFileSize: 'The file you are trying to upload is too large (max %s)',
                wrongFileType: 'Only files of type %s is allowed',
                groupCheckedRangeStart: 'Please choose between ',
                groupCheckedTooFewStart: 'Please choose at least ',
                groupCheckedTooManyStart: 'Please choose a maximum of ',
                groupCheckedEnd: ' item(s)',
                badCreditCard: 'The credit card number is not correct',
                badCVV: 'The CVV number was not correct',
                wrongFileDim : 'Incorrect image dimensions,',
                imageTooTall : 'the image can not be taller than',
                imageTooWide : 'the image can not be wider than',
                imageTooSmall : 'the image was too small',
                min : 'min',
                max : 'max',
                imageRatioNotAccepted : 'Image ratio is not accepted'
            };

          $.validate({
            language : myLanguage
          });
        </script>
@endsection

@section('scriptsection')
        <script>
          $(document).ready(function(){
            let volmail = $('#volemail').val();
            if(volmail.length > 0)
            {
              console.log("fut");
              $('#onkentes_neve').prop('disabled',true);
              $('#onkentes_kora').prop('disabled',true);
              $('#rendezveny').prop('disabled',true);
              $('#terulet').prop('disabled',true);
            }
          });

          $('#volemail').on('keyup',function(){
            let fieldCounter = $('#volemail').val();
            if(fieldCounter.length > 0)
            {
              $('#onkentes_neve').prop('disabled',true);
              $('#onkentes_kora').prop('disabled',true);
              $('#rendezveny').prop('disabled',true);
              $('#terulet').prop('disabled',true);
            }
            else
            {
              $('#onkentes_neve').prop('disabled',false);
              $('#onkentes_kora').prop('disabled',false);
              $('#rendezveny').prop('disabled',false);
              $('#terulet').prop('disabled',false);
            }
          });
            $('#rendezveny').change(function(){
                let v = $('#rendezveny').val();

                $.ajax({
                        type:'POST',
                        url:'{{url('GetTeruletek')}}',
                        data:{_token: '<?php echo csrf_token() ?>', es_id: v},
                        success:function(data) {
                            console.log(data);
                            $("#terulet option").remove();
                            $("<option>").attr("value", "-0").text("Terület választása").appendTo("#terulet");
                            for(i = 0; i < data.length;i++)
                            {
                               console.log(data[i].nev);
                               $("<option>").attr("value", data[i].id).text(data[i].nev).appendTo("#terulet");
                            }
                        }
                    });
             });
        </script>
@endsection
