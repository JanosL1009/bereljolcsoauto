@extends('layouts.admin')


@section('content')
 <style>.OutOfStock{color: green;border-radius: 20px;border-style: solid; background-color: green;height: 12px; width: 12px; display: block;}</style>
    <div class="row">
        <div class="col-12">
            <h1>{{$user->name}}- akkreditáció</h1>
        </div>
        
    </div>

    <div class="row">
       <div class="col-12">
               

                @if($errors->success->first())
                    <div class="col-12 text-center">
                    <h4  class="alert alert-success" role="alert">{{$errors->success->first()}}</h4>
                    </div>
                @endif

                 @if($errors->failed->first())
                    <div class="col-12 text-center">
                    <h4  class="alert alert-danger" role="alert">{{$errors->failed->first()}}</h4>
                    </div>
    
                @endif

                @if($errors->warning->first())
                    <div class="col-12 text-center">
                    <h4  class="alert alert-warning" role="alert">{{$errors->warning->first()}}</h4>
                    </div>
    
                @endif
       </div>
    </div>

    

    <div class="row mt-3">
        <div class="col-6">
            <div class="card">
                  <form action="{{route('Akkred.Profil.Post')}}" method="post">
                  @csrf
                  <input type="hidden" name="uid" value="{{$user->id??0}}">
                  <input type="hidden" name="bid" value="{{$user->szulIdo??0}}">
                  <input type="hidden" name="nev" value="{{$user->id??0}}">
                        <table class="table table-striped table-hover">
                            <tbody>
                                <tr>
                                    <th> A felhasználó neve:</th>
                                    <td><b>{{$user->name??''}}</b></td>
                                </tr>
                                <tr>
                                    <th>  Születési ideje:</th>
                                    <td><b>{{$user->szulIdo??''}}</b></td>
                                </tr>

                                <tr>
                                    <th>  QR: @error('qr') <span class="alert-danger">Kötelező mező</span> @enderror</th>
                                    <td>
                                        <input type="text" id="qr" name="qr" class="form-control" value="{{$user->qr??''}}">
                                    </td>
                                </tr>

                                <tr>
                                    <th>  QR Link: @error('qrlink') <span class="alert-danger">Kötelező mező</span> @enderror</th>
                                    <td>
                                        <input type="text" id="qrlink" name="qrlink" class="form-control" value="{{$user->qrlink??''}}">
                                        </td>
                                </tr>

                                <tr>
                                    <th>  Kártyaszám:</th>
                                    <td>
                                        <input type="text" id="cardnumber" name="cardnumber" class="form-control" value="{{$user->card_number??''}}">
                                    </td>
                                </tr>

                                <tr>
                                    <th>  Státusz:</th>
                                    <td>
                                        <select class="form-control" name="status">
                                            <option value="0" default @if($user->status == 0) selected @endif>Nincs kész</option>
                                            <option value="1" @if($user->status == 1) selected @endif>Kész</option>
                                        </select>
                                    </td>
                                </tr>

                                 <tr>
                                    <th>  Átvette:</th>
                                    <td>
                                        <select class="form-control" name="atvette">
                                            <option value="0" default @if($user->atvette == 0 || !isset($user->atvette)) selected @endif>Nem</option>
                                            <option value="1" @if($user->atvette == 1) selected @endif>Igen</option>
                                        </select>
                                    </td>
                                </tr>

                                <tr>
                                    <td colspan="2"> 
                                        <input class="btn btn-primary" type="submit" value="Mentés">
                                    </td>
                                    
                                </tr>

                            </tbody>
                        </table>
                </form>
            </div>
        </div>

        <div class="col-6">
            <div class="card">
                <div style=" border: 1px solid whitesmoke ;text-align: center;position: relative" id="image"> 
                    <img width="50%" height="50%" id="preview_image" src="{{url('userpic/'.$user->profilkep)}}" />
                </div>
            </div>
        </div>
    </div>

    <div class="row mt-3">
        
           <div class="col-12">
                    <form action="#" method="post">
                    
                    </form>
           </div>
      

    </div>


@endsection