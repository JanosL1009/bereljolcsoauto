@extends('layouts.admin')

@section('content')

<div class="row">
    <div class="col-12">
        <h1>Profilkép validálás</h1>
    </div>
</div>
<div class="row">
    <div class="col-12">
        <button class="btn btn-warning" onclick="location.reload();">FRISSÍTÉS</button>
        <h5 style="margin-top: 15px;">Ennyi van még:{{$count}}</h5>
        <h5 style="margin-top: 15px;">Érvényes:{{$ervenyes}}</h5>
    </div>
    
</div>
<div class="row" style="margin-top: 30px;">
    @foreach($users as $user)
        <div class="card" id="{{$user->id}}">
            <div class="card-body">
                 <div class="form-group">
                      <a href="{{url('/admin/onkentes_szerkesztese/'.$user->id)}}" target="_blank" class="btn btn-warning"  >Tovább az adatlaphoz</a>
                  </div>
                <img src="{{url('userpic/'.$user->profilkep)}}"  class="img-thumbnail" width="310px" height="310px">
                 <div class="form-group">
                              <button class="btn btn-primary"  id="validbtn-{{$user->id}}" onclick="valid({{$user->id}});">Megfelelő profilkép</button>
                              <button href="#" class="btn btn-danger" id="invalidbtn-{{$user->id}}" data-uid="{{$user->id}}" onclick="invalid({{$user->id}});">Nem megfelelő</button>
                  </div>
            </div>
        </div>

    @endforeach

    
</div>
<div class="row" style="margin-top: 30px;">
    <div class="col-12">
        <button class="btn btn-warning" onclick="location.reload();">FRISSÍTÉS</button>
        
    </div>
</div>


<script>

    function valid(uid)
    {
                          
                           let btnv = '#validbtn-'+uid;  let btninv = '#invalidbtn-'+uid;
                              $.ajax({
                                        type:'POST',
                                        url:'{{route('Moderate.Pic')}}',
                                        data:{_token:'<?php echo csrf_token() ?>', id:uid,vstatus: 1 },
                                        success:function(data) {
                                            console.log(data);
                                            if(data == 1)
                                            {
                                                $(btnv).addClass('disabled');$(btninv).addClass('disabled');
                                            }
                                        }
                                    });
           
    }

   
function invalid(uid)
{
    let btnv = '#validbtn-'+uid;  let btninv = '#invalidbtn-'+uid;
                        $.ajax({
                                type:'POST',
                                url:'{{route('Moderate.Pic')}}',
                                data:{_token:'<?php echo csrf_token() ?>', id:uid,vstatus: 2 },
                                success:function(data) {
                                    console.log(data);
                                  if(data == 1)

                                            {
                                                console.log(uid);
                                                $(btnv).addClass('disabled');$(btninv).addClass('disabled');
                                            }
                                }
                            });
}
    
    
                        
  
</script>
@endsection