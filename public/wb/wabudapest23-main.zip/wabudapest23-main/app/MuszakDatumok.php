<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MuszakDatumok extends Model
{
    protected $table = "muszak_datumok";
}
