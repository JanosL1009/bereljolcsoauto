<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FelhasznaloInfo extends Model
{
    //
    protected $table = 'felhasznaloinfo';

    protected $primaryKey = 'felhasznaloinfoid';

}
