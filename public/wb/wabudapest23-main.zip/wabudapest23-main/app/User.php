<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Support\Facades\DB;
use App\Notifications\VerifyEmail;
use App\Notifications\ResetPassword;
use App\FelhasznaloInfo;
use App\Esemeny;
use App\FelhasznaloFeladat;
use App\SzemelyesAdatok;
use Illuminate\Support\Carbon;

class User extends Authenticatable implements  MustVerifyEmail
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'id','name', 'email','titulus','elotag', 'email_verified_at' ,'password','blocked','modifier'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public function felhasznalo_data()
    {
        return $this->hasOne('App\Model\Felhasznalo', 'id', 'id');
    }

    public function felhasznaloinfo_data()
    {
        return $this->hasOne('App\FelhasznaloInfo', 'felhasznalo_id', 'id');
    }

    public function jogosultsag_data()
    {
        return $this->hasOne('App\Jogosultsag', 'id');
    }

    public function felhasznalo_feladat()
    {
        return $this->hasOne('App\FelhasznaloFeladat', 'felhasznalo_id','id');
    }

    public function FelhasznaloFeladat()
    {
        return $this->hasOne('App\FelhasznaloFeladat', 'felhasznalo_id','id');
    }

    public function szemelyesadatok_data()
    {
        return $this->hasOne('App\SzemelyesAdatok','felhasznalo_id', 'id');
    }

    public function allandolakcim_data()
    {
        return $this->hasOne('App\AllandoLakcim','felhasznaloid', 'id');
    }

    public function tartozkodasicim_data()
    {
        return $this->hasOne('App\TartozkodasiLakcim','felhasznaloid', 'id');
    }

    public function egyebszervezet_data()
    {
        return $this->hasOne('App\EgyebSzervezetTagja','felhasznalo_id', 'id');
    }

    public function civilszervezet_data()
    {
        return $this->hasOne('App\CivilSzervezetTagja','felhasznalo_id', 'id');
    }

    public function egyhazmegye_data()
    {
        return $this->hasOne('App\UserEgyhazmegye','felhasznalo_id', 'id');
    }


    public function Ruha()
    {
        return $this->hasMany('App\RuhaAtadoAtvetel','felhasznalo_id', 'id');
    }

    /**
     *
     */
    public function teljesitettOra(int $CsoportID,int $MuszakDatumID)
    {
        $t =  $this->hasOne('App\Munkafelvetel', 'felhasznalo_id', 'id')->
            where('muszak_datum_id', $MuszakDatumID)->where('csoport_id', $CsoportID)->first();

            if(isset($t->teljesitettOraszam))
            {
                return $t->teljesitettOraszam;
            }
            else
                return 0;
    }

    public function sendEmailVerificationNotification()
    {
        $this->notify(new VerifyEmail);
    }

    public function sendPasswordResetNotification($token)
    {
       $this->notify(new ResetPassword($token));
    }

    public static function getJelentkezeseim(int $UserId)
    {
        $jelentkezesek = DB::table('felhasznalo_feladat')->join('esemeny','felhasznalo_feladat.esemeny_id','=','esemeny.id')->join('terulet','felhasznalo_feladat.terulet_id','=','terulet.id')->where('felhasznalo_feladat.felhasznalo_id','=',$UserId )->select('jelentkezesID','esemeny.id','esemeny.nev as esemenyneve','esemeny.kezdesDatum','terulet.nev','terulet.teruletAktiv')->get();

        return $jelentkezesek;

    }

    public function AccountActicvate()
    {
        $this->attributes['email_verified_at'] = Carbon::now();
    }

}
