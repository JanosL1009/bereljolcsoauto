<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EgyebSzervezetTagja extends Model
{
    protected $table = "egyeb_szervezet";
    protected $primaryKey = "sz_id";
}
