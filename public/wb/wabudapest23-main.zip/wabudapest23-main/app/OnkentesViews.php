<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OnkentesViews extends Model
{
    protected $table = 'onkentesviews';
}
