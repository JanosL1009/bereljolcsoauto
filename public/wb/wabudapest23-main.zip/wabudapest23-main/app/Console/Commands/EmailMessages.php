<?php

namespace App\Console\Commands;

use Illuminate\Support\Facades\Artisan;
use Illuminate\Console\Command;
use Illuminate\Console\Scheduling\Schedule;
use  App\Http\Controllers\Msg\OmrEmail;
use App\Hirlevel;
use App\HirlevelCsoportTarsitas;
use App\HirlevelUsers;
use App\User;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;

class EmailMessages extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'command:bulkmails';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Tomeges email kuldo';

    protected $HirlevelCsoportTarsitas;
    protected $Hirlevel;
    protected $HirlevelUsers;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {

        parent::__construct();

       // $pdo = DB::connection()->getPdo();

        //$this->Hirlevel =  DB::table('hirlevelek')->where('active',1)->first();
     /*   $this->Hirlevel = Hirlevel::where('active',1)->oldest()->first();
        $this->HirlevelCsoportTarsitas = HirlevelCsoportTarsitas::where('hirlevel_id',$this->Hirlevel->id)
        ->where('teljesitve',0)
        ->first();

        $this->HirlevelUsers = HirlevelUsers::where('teljesitve',0)->
        where('HCsT_id',$this->HirlevelCsoportTarsitas->id)->take(20)->get();*/
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        /* $UsersMail = User::whereIn('id',$this->getBulkMailsHandler())->get();

        foreach($UsersMail as $user)
        {
            $actDate = Carbon::now();
            OmrEmail::SendMailAnUser($user->email,$this->Hirlevel->msgContent);
            $this->Hirlevel->lastSendTime =  $actDate;
            $this->Hirlevel->save();

            $actUserMail = HirlevelUsers::where('user_id')->first();
            $actUserMail->teljesitve = 1;
            $actUserMail->teljesitesIdeje = $actDate;
            $actUserMail->modosito = 0; //0: cron
            $actUserMail->save();

            $this->Hirlevel->lastSendTime = $actDate;
            $this->Hirlevel->modosito = 0; //0: cron
            $this->Hirlevel->save();
        }
*/
        $systemMail = "OMR NEK tomeges mail kuldo cron lefutott: ".Carbon::now();
        OmrEmail::SendMailAnUser('lakatos.janos@csbo.hu',$systemMail);

    }

    /**
     * Tomeges email kuldest kezeli. Hirlevel adatbazis tablaba megy de valojaban nem normalisa hirlevel
     * mert nem  folyamatos hirlevel tamogatosrol van szo, hanem programokkal kapcsolatos rendszeruzenetekről.
     * Magyarul nem ajánlatok kuldesere hivatott.
     *
     * @return Array[int] Visszater egy tombbel, ami tartalmazza a user id-kat
     */
    protected function getBulkMailsHandler()
    {
         return $this->HirlevelUsers->pluck('user_id')->toArray();
    }
    //dd( $HirlevelCsoportTarsitas,$HirlevelUsers); lekérés rendben
        //dd($HirlevelUsers->pluck('user_id')->toArray()); a lekert user id-k rendben!
        /** Pelda eredmeny:
         * array:8 [▼
               * 0 => 1300
               * 1 => 1305
               *2 => 1309
               * 3 => 1320
               * 4 => 1322
               * 5 => 1331
               * 6 => 1333
               * 7 => 1335
               * ]
         */


    /**
     * Fejleszthetőség: leiratkozas mezokkel lehet boviteni a DB tablat es akkor valos hirlevel kuldesre is alkalmas
     * (fel- és leiratkozásra)
     */

}
