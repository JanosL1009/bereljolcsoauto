<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TeruletCsoportositasAzonositok extends Model
{
    protected $table = 'terulet_csoportositas_azonositok';


}
