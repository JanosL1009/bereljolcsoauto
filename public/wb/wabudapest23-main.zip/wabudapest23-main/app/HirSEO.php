<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HirSEO extends Model
{
    protected $table = 'hir_seo';

    protected $primaryKey = 'hs_id';

    /**
     * Visszater a Hir-el
     */
    public function Hir()
    {
        return $this->belongsTo('App\Hir','hir_id');
    }

}
