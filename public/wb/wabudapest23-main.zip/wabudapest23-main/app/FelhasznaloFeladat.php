<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class FelhasznaloFeladat extends Model
{
    //
    protected $table = 'felhasznalo_feladat';

    protected $primaryKey = 'jelentkezesID';

    public function  user_data()
    {
        return $this->hasOne('App\User', 'id', 'felhasznalo_id');
    }

    public function felhasznalok_data()
    {
        return $this->hasOne('App\Model\Felhasznalo', 'id', 'felhasznalo_id');
    }

    public function szemelyesadatok_data()
    {
        return $this->hasOne('App\SzemelyesAdatok', 'felhasznalo_id', 'felhasznalo_id');
    }

    public function esemeny_data()
    {
        return $this->hasOne('App\Esemeny', 'id', 'esemeny_id');
    }

    public function terulet_data()
    {
        return $this->hasOne('App\Terulet', 'id', 'terulet_id');
    }

    public function csoport_data()
    {
        return $this->hasOne('App\Csoport', 'id', 'csoport_id');
    }

    public function munkafelvetel_data()
    {
        return $this->hasOne('App\Munkafelvetel', 'felhasznalo_id', 'felhasznalo_id');
    }

    public function MuszakIgazolas(int $UserID,int $CsoportID,int $MuszakDatumId)
    {
        $res = DB::table('munkafelvetel')->where('felhasznalo_id',$UserID)->where('csoport_id',$CsoportID)->
        where('muszak_datum_id', $MuszakDatumId)->first()->muszak_datum_id??null;

        return $res;
    }

    public function TeljesitettOraszam(int $UserID,int $CsoportID,int $MuszakDatumId)
    {
        $res = DB::table('munkafelvetel')->where('felhasznalo_id',$UserID)->where('csoport_id',$CsoportID)->
        where('muszak_datum_id', $MuszakDatumId)->first()->teljesitettOraszam??null;

        return $res;
    }


}
