<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EsemenyTelepules extends Model
{
    protected $table = "esemeny_telepules";
}
