<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Importhoz extends Model
{
    protected $table = "importhoz";
    protected $primaryKey = 'felhasznalo_id';
}
