<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AjandekokAtadoAtvetel extends Model
{
    protected $table = 'ajandekatado_atvatel';

    public function Ajandek()
    {
        return $this->hasOne('App\Ajandekok','id', 'ruha_id');
    }


}
