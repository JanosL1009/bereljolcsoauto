<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Egyhazmegyek extends Model
{
    protected $table = 'egyhazmegyek';



}
