<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SzemelyesAdatok extends Model
{
    protected $table = "szemelyesadatok";
}
