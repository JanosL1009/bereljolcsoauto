<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class TeruletCsoportositas extends Model
{
    protected $table = 'terulet_csoportositas';

    public function getTeruletAzonositok()
    {

        return $this->hasMany('App\TeruletCsoportositasAzonositok','terulet_csoport_id','id');
    }
}
