<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Fosuli extends Model
{
    protected $table = "fosuli";
    protected $fillable = ["felhasznalo_id","intezmeny_neve","szak","evfolyam","modosito","created_at","updated_at"];

    protected $primaryKey = "egyetemID";

}
