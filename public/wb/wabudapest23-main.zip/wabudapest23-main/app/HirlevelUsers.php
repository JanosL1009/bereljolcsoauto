<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HirlevelUsers extends Model
{
    protected $table = 'HirlevelUsers';
}
