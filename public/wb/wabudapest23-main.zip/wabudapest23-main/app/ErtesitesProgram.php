<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ErtesitesProgram extends Model
{
    protected $table = "ertesites_program";
}
