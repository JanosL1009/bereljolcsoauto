<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserEgyhazmegye extends Model
{
    protected $table ="user_egyhazmegye";

    protected $fillable = ['felhasznalo_id','egyhazmegye_id','egyebInputValue','nemTag','modosito'];

    public function user()
    {
        return $this->belongsTo('App\User','felhasznalo_id');
    }

    public function egyhazmegye()
    {
        return $this->belongsTo('App\Egyhazmegyek','egyhazmegye_id');
    }
}
