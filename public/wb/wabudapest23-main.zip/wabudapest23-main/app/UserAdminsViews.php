<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 * Az adminisztraotrok altal latogatott oldalakat tarolja
 */
class UserAdminsViews extends Model
{
    protected $table = 'useradminsviews';
}
