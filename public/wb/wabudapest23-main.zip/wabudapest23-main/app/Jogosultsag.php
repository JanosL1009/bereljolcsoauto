<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Jogosultsag extends Model
{
   /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $table = 'jogosultsag';

    public function felhasznalo()
    {
        return $this->belongsTo('App\User','id');
    }

    public function Felhasznaloiszintek()
    {
        return $this->hasMany('App\FelhasznloSzintek','id','felhasznaloszint_id');
    }


}
