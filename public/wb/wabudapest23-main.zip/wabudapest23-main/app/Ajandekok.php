<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ajandekok extends Model
{
    protected $table = 'ajandekok';
}
