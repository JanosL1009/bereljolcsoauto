<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HirlevelCsoportTarsitas extends Model
{
    protected $table = 'HirlevelCsoportTarsitas';
}
