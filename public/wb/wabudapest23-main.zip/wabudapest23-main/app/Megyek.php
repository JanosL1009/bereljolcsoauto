<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Megyek extends Model
{
    protected $table = "megyek";

    protected $primaryKey = "megye_id";
}
