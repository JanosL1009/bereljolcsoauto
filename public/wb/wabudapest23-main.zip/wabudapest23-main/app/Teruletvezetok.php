<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Teruletvezetok extends Model
{
    protected $table = "teruletvezetok";

    protected $fillable =  array('felhasznalo_id','megjegyzes','letrehozo', 'modosito');

    public function user()
    {
        return $this->belongsTo('App\User','felhasznalo_id');
    }


    public function felhasznalo()
    {
        return $this->belongsTo('App\Model\Felhasznalo','felhasznalo_id');
    }

    /**
     *
     */
    public function megjegyzes()
    {
        return $this->belongsTo('App\TeruletvezetoNote','felhasznalo_id');
    }


}
