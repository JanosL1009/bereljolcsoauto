<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DataSync extends Model
{
    protected $table = 'rentitsync';
}
