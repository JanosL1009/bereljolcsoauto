<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Edubase extends Model
{
    protected $table = 'edubase';

    public $fillable = ['felhasznalo_id','eduid','eduusername','loginlink','valid_link','firstedulogin','educount'];

    
}
