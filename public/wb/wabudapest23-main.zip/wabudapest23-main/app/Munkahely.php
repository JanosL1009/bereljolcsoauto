<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Munkahely extends Model
{

    protected $table = 'munkahely';
    protected $fillable = ['felhasznalo_id','intezmenyneve','beosztasa','datetime'];

    protected $primaryKey = 'm_id';

}
