<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Munkafelvetel extends Model
{
    protected $table = "munkafelvetel";

    public function felhasznalo_data()
    {
        return $this->hasOne('App\Model\Felhasznalo', 'id', 'felhasznalo_id');
    }

    public function user_data()
    {
        return $this->hasOne('App\User', 'id', 'felhasznalo_id');
    }

    public function muszakdatum_data()
    {
        return $this->hasOne('App\MuszakDatumok', 'id', 'muszak_datum_id');
    }
}
