<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PagesDetails extends Model
{
    protected $table = 'pagesdetails';
}
