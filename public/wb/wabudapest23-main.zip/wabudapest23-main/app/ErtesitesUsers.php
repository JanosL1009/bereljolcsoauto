<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Ertesitesek;

class ErtesitesUsers extends Model
{
    protected $table = "ertesites_users";


     /**
     * Get the phone record associated with the user.
     */
    public function ertesites()
    {
        return $this->hasOne('App\Ertesitesek','id','ertesites_id');
    }

}
