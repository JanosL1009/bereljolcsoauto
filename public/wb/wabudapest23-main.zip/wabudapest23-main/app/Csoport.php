<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Terulet;
use App\AlHelyszin;

class Csoport extends Model
{
    //
    protected $table = 'csoport';

    public function Terulet()
    {
        return $this->hasOne('App\Terulet','id','terulet_id');
    }

    public function Esemeny()
    {
        $terulet = $this->Terulet;
        $KeresettEsemeny = Terulet::find($terulet->id)->Esemeny;
        return $KeresettEsemeny;

    }

    public function Helyszin()
    {
        return $this->hasOne('App\AlHelyszin','id','helyszin_id');
    }
}
