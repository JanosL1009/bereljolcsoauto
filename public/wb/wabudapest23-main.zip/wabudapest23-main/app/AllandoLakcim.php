<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AllandoLakcim extends Model
{
    protected $table = 'allandolakcim';

    protected $primaryKey = 'felhasznaloid';


    public function megye_datas()
    {
        return $this->hasOne('App\Megyek','megye_id','megyeID');
    }
}
