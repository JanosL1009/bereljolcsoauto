<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Felhasznalo extends Model
{
    protected $table = 'felhasznalok';


    public function felhasznalo()
    {
        return $this->belongsTo('App\User','id');
    }

    public function FelhasznaloFeladat()
    {
        return $this->hasOne('App\FelhasznaloFeladat', 'felhasznalo_id','id');
    }

}
