<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OnkentesSzabadidopontok extends Model
{
     protected $table = "onkentes_szabadidopontok";

     protected $primaryKey = 'felhasznalo_id';


}
