<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TeruletVezetokTerulet extends Model
{
    protected $table = 'teruletvezetok_terulet';
}
