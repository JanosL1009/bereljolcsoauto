<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CivilSzervezetTagja extends Model
{
    protected $table = "civil_szervezet";
    protected $primaryKey = "c_id";
    
}
