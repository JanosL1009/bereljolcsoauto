<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AkkreditacioController extends Controller
{
    public function kereso(Request $request)
    {

    }

    
    public function profil(Request $request,int $UserID)
    {
       
        $user = DB::table('felhasznalok')->join('users','users.id','=','felhasznalok.id')->leftJoin('akkred_osszevont',function($join){
            $join->on('akkred_osszevont.nev', '=', 'felhasznalok.vezeteknev')
            ->on('akkred_osszevont.szul_ido', '=', 'felhasznalok.szulIdo');
        })->where( 'felhasznalok.id','=' ,$UserID)->first(['users.id','users.name','felhasznalok.vezeteknev','felhasznalok.szulIdo','felhasznalok.profilkep',
        'akkred_osszevont.qr','akkred_osszevont.qrlink','akkred_osszevont.card_number','akkred_osszevont.status','akkred_osszevont.atvette'  ]);
        
        return view('onkentes/akkreditacio/profil')->with('user',$user);
        
    }

    public function update_akkred_osszevont(Request $request)
    {
        $validate = $request->validate([
            'qr' => 'required',
            'qrlink' => 'required',
            'uid' => 'required|integer'
        ]);

        $uid = $request->input('uid');
        $qrlink = $request->input('qrlink');
        $qr = $request->input('qr');
        $status = (int)$request->input('status');
        $cardnumber = $request->input('cardnumber');
        $atvette = $request->input('atvette');
        $user = DB::table('felhasznalok')->join('users','users.id','=','felhasznalok.id')->leftJoin('akkred_osszevont',function($join){
            $join->on('akkred_osszevont.nev', '=', 'felhasznalok.vezeteknev')
            ->on('akkred_osszevont.szul_ido', '=', 'felhasznalok.szulIdo');
        })->where( 'felhasznalok.id','=' ,$uid)->first(['felhasznalok.vezeteknev','users.name','felhasznalok.szulIdo','felhasznalok.profilkep',
        'akkred_osszevont.qr','akkred_osszevont.qrlink','akkred_osszevont.card_number','akkred_osszevont.status' ]);

        try{
            DB::table('akkred_osszevont')->updateOrInsert(
           
                ['akkred_osszevont.szul_ido' => $user->szulIdo,
                    'akkred_osszevont.nev' => $user->vezeteknev
             ],
                ['akkred_osszevont.qrlink' =>  $qrlink,'akkred_osszevont.qr' =>  $qr,'akkred_osszevont.card_number' =>  $cardnumber,
                'akkred_osszevont.status' =>  $status,'akkred_osszevont.atvette' =>  $atvette
                    ]
            );
        }
        catch(Exception $e)
        {
            return back()->withErrors('Hiba a mentéskor!','failed');
        }
        

        return back()->withErrors('A módosítás sikerült!','success');
    }
}
