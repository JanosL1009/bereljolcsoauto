<?php

namespace App\Http\Controllers;

use App\AlHelyszin;
use App\Http\Controllers\DB_OMR_Operations;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Carbon;
use Exception;
use DateTime;
use App\Hir;
use App\HirSEO;
use App\User;
use App\Model\Felhasznalo;
use App\FelhasznaloInfo;
use App\Ruha;
use App\RuhaEsemeny;
use App\EsemenySzervezok;
use App\FelhasznaloFeladat;
use App\RuhaAtadoAtvetel;
use App\Jeligek;
use App\JeligeCsoportTagok;
use App\BeszeltNyelvek;
use App\Model\BeosztasKezeloRepo;
use App\Terulet;
use App\Csoport;
use App\Helyszin;
use App\YtpPlayed as AppYtpPlayed;
use lluminate\Support\Facades\Hash;
use App\Http\Controllers\Msg\OmrEmail;
use App\SystemEmails;
use App\OnkentesSzabadidopontok;
use App\LogTeruletBeosztas;
class AjaxController
{

    /**********************
     *  ALTALNOS FGV-EK
     * ***********************
     */

     public function getAllUser()
     {
        return json_encode(User::all());
     }

     /**
      * A felhasznalok DB tabla tartalma
      */
     public function getFelhasznalok()
     {

     }

    public function GetTelepulesLista()
    {
        $msg = DB_OMR_Operations::GetTelepulesGroupsBy_JSON();
        return response()->json($msg, 200); //a viewvab kell megjeleniteni
    }

    /**
     * Egy adott esemeny teruleteit keri le
     * @param int Esemeny id
     *
     * @return json Terulet lista
     */
    public function GetTeruletek(Request $request)
    {
        $teruletek = DB_OMR_Operations::GetTeruletek($request->input('es_id'));
        return response()->json($teruletek, 200);
    }

    /**
     * Egy terulet csoportjait keri le.
     * Ajax hivanal a valtozoneve legyen: tid
     * @param int Nev: tid
     * @return Csoport:Array
     */
    public function GetCsoportok(Request $request)
    {
        $teruletID = $request->input("tid");
        $csoportok = Csoport::where('terulet_id',$teruletID)->get(['id','nev']);
        return $csoportok;
    }

    public function TeruletTorles(Request $request)
    {
        $v = $request->input('_datas');
         $z = $v[0];
        $is_res = DB_OMR_Operations::DeleteTeruletForID($z['t_id']);
        return $is_res;
    }

    public function DelGroups(Request $request)
    {
        $csopID = intval($request->input('csid'));
        $return = DB::table('csoport')->where('id','=',$csopID)->delete();

        return $return;
    }

    public function EsemenyDelete(Request $request)
    {

        $esemenyID = $request->input('_esid');
        $res = DB_OMR_Operations::DeleteEsemeny($esemenyID);
        if($res > 0)
        {
            return response()->json('1', 200);
        }
        else
        {
            return response()->json('0', 200);
        }


    }

    /**
     * A helyszinek listajaval ter vissza a response
     *
     * @return Response(JSON)
     */
    public function GetHelyszin(Request $request)
    {
            $res = DB_OMR_Operations::GetHelyszin();
            return response()->json($res, 200);
    }

    public function GetEsemenyHelyszine(Request $request, int $EsemenyID)
    {
        $res = DB_OMR_Operations::GetHelyszinEsemenyID($EsemenyID);
        return response()->json($res, 200);
    }

    public function DocDeleteAdmin(Request $request)
    {
        //dd($request->input('_esid'));
        DB::table('alt_dokumentumok')->where('doc_id', 'like',$request->input('_esid'))->delete();

        return response()->json('valid', 200);
    }

    public function TeruletAktivInackitv(Request $request)
    {
        $allapot = intval($request->input('act'));
        $tid = intval($request->input('tid'));
        DB::table('terulet')->where('id','=',$tid)->update(['teruletAktiv' => $allapot]);
        $res = DB::table('terulet')->where('id','=',$tid)->pluck('teruletAktiv');
        return response()->json($res, 200);

    }

    /** Esemeny szervezok beosztasa */
    public function esemenySzervezokBeosztasa(Request $request)
    {
        $UserId = intval($request->input('uid'));
        $TeruletId = intval($request->input('tid'));
        $time = Carbon::now();
        $esemenyID = intval($request->input('eid'));
        $actuser = 0; //a modositofelhasznalo lesz
        $res = DB::table('esemeny_szervezok')->insert(['felhasznalo_id' => $UserId, "Esemeny_id" => $esemenyID, "szint_id" => 3, "modosito_id" => 0, "modositas_ideje" => $time]);

        if($res)
            return 1;
            else
            return 0;
    }

    public function esemenySzervezokBeosztasaTorles(Request $request)
    {
        $UserId = intval($request->input('uid'));
        $esemenyId = intval($request->input('eid'));
        $res = DB::table('esemeny_szervezok')->whereRaw('felhasznalo_id='.$UserId.' AND Esemeny_id='.$esemenyId.' AND szint_id=3')->delete();

        if($res)
            return 1;
            else
            return DB::table('esemeny_szervezok')->whereRaw('felhasznalo_id='.$UserId.' AND Esemeny_id='.$esemenyId.' AND szint_id=3')->toSql();
    }

    /**Terulet vezetok,  területi önkéntes koordinátorok beosztása*/
    public function TeruletVezetoBeosztasa(Request $request)
    {
        $UserId = intval($request->input('uid'));
        $TeruletId = intval($request->input('tid'));
        $time = Carbon::now();
        $esemenyID = DB::table('terulet')->where('id','=',$TeruletId)->pluck('esemeny_id');
        $actuser = 0; //a modositofelhasznalo lesz
        $res = DB::table('esemeny_szervezok')->insert(['felhasznalo_id' => $UserId, "Esemeny_id" => $esemenyID[0],"terulet_id" => $TeruletId, "szint_id" => 4, "modosito_id" => 0, "modositas_ideje" => $time]);
        try{
            $res = DB::table('felhasznalo_feladat')->update(["csoport_id" => 0])->where('felhasznalo_id', '=',$UserId);

        }
            catch(\Throwable $e){
                $now = new \DateTime();
                $res = DB::table('felhasznalo_feladat')->insert(["felhasznalo_id" => $UserId,'feladat_id' => 0,'csoport_id' => 0,'terulet_id' =>$TeruletId,'esemeny_id' => $esemenyID[0],'priority' => 0,'other' => 0,'jelentkezesIdeje' => $now]);
            }

        if($res)
            return 1;
            else
            return 0;


    }

    public function TeruletVezetoEltav(Request $request)
    {
        $teruletid = $request->input('tid');
        $UserID = $request->input('uid');
        $esemenyid = DB::table('terulet')->where('id','=',$teruletid)->get();

        $res = DB::table('esemeny_szervezok')->where('felhasznalo_id' ,'=',$UserID)->where('Esemeny_id','=',$esemenyid[0]->esemeny_id)->where('terulet_id' ,'=',$teruletid)->where('szint_id','=',4)->delete();
        if($res > 0)
            return 1;
            else
            return 0;
    }

    /**Csoportvezetok beosztasa */
    /**
     * @version v1.8.0
     * @since v1.8.0
     * @method
     * A felhasznalo feladatba nem kerul be innen, semmi mert valtozott az uzleti logika.
     * Kizarolag a csoortba beosztott emberek kozul lehet vezetőt kinevezni - egyenlőre
     */
    public function CsoportVezetoBeosztasa(Request $request)
    {
        $user = auth()->user();
        $ActUserID = $user["id"];

        $UserId = $request->input('uid');
        $csoportID = $request->input('csid');


        $TeruletId = DB::table('csoport')->where('id','=',$csoportID)->first()->terulet_id;

        $time = Carbon::now();
        $esemenyID = DB::table('terulet')->where('id','=',$TeruletId)->first()->esemeny_id;
        $actuser = 0; //a modositofelhasznalo lesz
       // $res1 = DB::table('esemeny_szervezok')->insert(['felhasznalo_id' => $UserId, "Esemeny_id" => $esemenyID, "szint_id" => 5, "modosito_id" => 0, "modositas_ideje" => $time]);

        $esemenySzervezok = new EsemenySzervezok;
        $esemenySzervezok->felhasznalo_id =   $UserId;
        $esemenySzervezok->Esemeny_id = $esemenyID ;
        $esemenySzervezok->terulet_id = $TeruletId;
        $esemenySzervezok->csoport_id =  $csoportID;
        $esemenySzervezok->szint_id = 5;
        $esemenySzervezok->modosito_id =$ActUserID;
        $esemenySzervezok->modositas_ideje = Carbon::now();

        $esemenySzervezok->save();



        if($esemenySzervezok)
            return 1;
        else
            return 0;

        //$res = DB::table('felhasznalo_feladat')->where('felhasznalo_id', '=', $UserId)->where('terulet_id', '=',$TeruletId[0]->terulet_id)->limit(1)->update(["csoport_id" => $csoportID]);


    }

    public function CsoportVezetoEltavloitasa(Request $request)
    {
        $FelhasznaloID = $request->input('uid');
        $csoport_id = $request->input('gid');

        $res1 = EsemenySzervezok::where('felhasznalo_id',$FelhasznaloID)->
        where('csoport_id',$csoport_id)->
        where('szint_id',5)->delete();

        return $res1;
    }

    public function CsoportUserBeosztasa(Request $request)
    {
        $UserId = $request->input('uid');
        $csoportID = $request->input('csid');
        $Terulet = DB::table('csoport')->where('id','=',$csoportID)->select('terulet_id')->get();
        $TeruletId = $Terulet[0]->terulet_id;
       // $time = Carbon::now();
       $esemenyID = Terulet::find($TeruletId)->esemeny_id;

        $ff = FelhasznaloFeladat::where('felhasznalo_id', '=', $UserId)->where('esemeny_id', '=',$esemenyID)->get();
        //le jon a jelentkezes : ez egy 3-as tomb

        $felhasznaloFeladat = null;
        $res = 0;
        $isOther = false; $isTerulet = false;

        foreach($ff as $jelentkezes) //bejarjuk a tombot
        {
            if($jelentkezes->terulet_id == $TeruletId) //ha egyezik a terulet id a jelentkezes teruletidjaval akkor
            {
                $felhasznaloFeladat = $jelentkezes; //az aktualis jelentkezest be rakjuk egy tagvaltozoba
                $isTerulet = true; //terulet egyezoseg be kapcsolva
            }
        }

        if($isTerulet)
        {
            $felhasznaloFeladat->csoport_id = $csoportID;
            $felhasznaloFeladat->save();$res = 1;
        }
        else
        {
            //$felhasznaloFeladat = $ff[2];
                unset($felhasznaloFeladat);
                $felhasznaloFeladat = new FelhasznaloFeladat();
                $felhasznaloFeladat->felhasznalo_id = $UserId;
                $felhasznaloFeladat->esemeny_id = $esemenyID;
                $felhasznaloFeladat->terulet_id = $TeruletId;
                $felhasznaloFeladat->csoport_id = $csoportID;
                $felhasznaloFeladat->priority = 4;
                $felhasznaloFeladat->other = 1;
                $felhasznaloFeladat->jelentkezesIdeje = Carbon::now();
                $felhasznaloFeladat->save(); $res = 1;
            
        }


//TB: $2y$10$qM.ejKTiyTjXLc1T9hytDujh0WxjLPO2JmJNEQU4PvBw7VWJwCjVm

        //$res = DB::table('felhasznalo_feladat')->where('felhasznalo_id', '=', $UserId)->where('terulet_id', '=',$TeruletId[0]->terulet_id)->limit(1)->update(["csoport_id" => $csoportID]);

        if($res == 1)
            return 1;
            else
            return 0;
    }


    public function EsemenySzervezoVezetoEltavolit(Request $request)
    {
        $UserId = intval($request->input('uid'));

    }

    public function CsoportUserEltavolitas(Request $request)
    {
        $FelhasznaloID = $request->input('uid');
        $CsoportID = $request->input('csid');

        $res = DB::table('felhasznalo_feladat')->where('felhasznalo_id','=',$FelhasznaloID)->where('csoport_id','=',$CsoportID)->update(['csoport_id' => 0]);

        if($res > 0)
        return 1;
        else
        return 0;

    }



    public function GetTeruletekJidAlapjan(Request $request)
    {
        $jelentkezesID = $request->input('jid');
        $result = DB::table('terulet')->join('felhasznalo_feladat','terulet.esemeny_id','=','felhasznalo_feladat.esemeny_id')->where('felhasznalo_feladat.jelentkezesID','=',$jelentkezesID)->where('terulet.teruletAktiv','=',1)->get();
        return response()->json($result, 200);
    }

    public function HelyszinekLekerdezese(Request $request)
    {
        $result = DB::table('helyszin')->get();
        return response()->json($result, 200);
    }

    public function TeruletBeosztasa(Request $request)
    {
        $teruletid = $request->input('tid');
        $UserID = $request->input('uid');
        $time = Carbon::now();
        $array = [
            ['felhasznalo_id' =>  $UserID ,'terulet_id' => $teruletid,'beosztasIdeje' => $time]
        ];
        $res = 0;
        if (DB::table('terulet_beosztas')->where('felhasznalo_id', $UserID)->where('terulet_id', $teruletid)->doesntExist()) {
             DB::table('terulet_beosztas')->insert($array);
            $res = 1;
        } else $res = 2;

        $loggedUser = auth()->user();
        $logTerbeoszt = new LogTeruletBeosztas();
        $logTerbeoszt->felhasznalo_id = $UserID;
        $logTerbeoszt->terulet_id = $teruletid;
        $logTerbeoszt->beosztasIdeje = Carbon::now();
        $logTerbeoszt->muvelet = 'Beosztás';
        $logTerbeoszt->modosito = $loggedUser['id'];
        $logTerbeoszt->save();
      
        return $res;
    }

    /**
     * @param int[] A beosztando azonositok tombje
     * @return int 
     */
    public function TeruletBeosztasaTomeges(Request $request)
    {
        $ids = json_decode($request->input('arrayid'));
        $teruletid = $request->input('tid');
        foreach($ids as $UserID )
        {
            if (DB::table('terulet_beosztas')->where('felhasznalo_id', $UserID)->where('terulet_id', $teruletid)->doesntExist()) {
               
                DB::table('terulet_beosztas')->insert(
                    ['felhasznalo_id' => $UserID, 'terulet_id' => $teruletid, 'beosztasIdeje' => Carbon::now()]
                    
                );
               $res = $ids;
           } else $res = 2;
        }
        return $res;
    }

    public function TeruletBeosztasEltavolitas(Request $request)
    {
        $teruletid = (int)$request->input('tid');
        $UserID = $request->input('uid');
        $res = DB::table('terulet_beosztas')->where('felhasznalo_id' ,'=', $UserID)->where('terulet_id','=', $teruletid)->delete();
        
        try 
        {
            
            
            DB::table('felhasznalo_feladat')->where('felhasznalo_id' ,'=', $UserID)->where('terulet_id','=', $teruletid)->update(
                [
                    'csoport_id' => 0
                ]
            );

            $loggedUser = auth()->user();
            $logTerbeoszt = new LogTeruletBeosztas();
            $logTerbeoszt->felhasznalo_id = $UserID;
            $logTerbeoszt->terulet_id = $teruletid;
            $logTerbeoszt->beosztasIdeje = 'NULL';
            $logTerbeoszt->muvelet = 'Törlés, eltávolítás';
            $logTerbeoszt->modosito = $loggedUser['id'];
            $logTerbeoszt->save();
        
        }
        catch(Exception $e)
        {

        }

        if($res > 0)
        return 1;
        else
        return 0;

    }

    public function TeruletIdoMegszoritasai(Request $request)
    {
        $teruletid = $request->input('tid');
        $res = DB::table('terulet')->where('id','=',$teruletid)->select('kezdesIdopont','befejezesIdopont')->get();

        if(isset($res))
        {
            return  response()->json($res, 200);
        }
        else return 0;

    }

    public function ProgramLocationDelete(Request $request)
    {

        $hid = $request->input('hid');

        $res = DB::table('esemeny_telepules')->where('es_id','=',$hid)->delete();

        return $res;
    }

    /**
     * Egy hir torlese
     */
    public function HirTorles(Request $request)
    {
        $id = $request->input('_esid');
        HirSEO::where('hir_id',$id)->delete();
        $res = Hir::where('h_id',$id)->delete();

        if(isset($res))
        {
            return  response()->json($res, 200);
        }
        else return 0;
    }

    /** **********************
     *  RUHA ÁTADÓ
     * ***********************
     */

    public function AddDressController(Request $request)
    {
        $id = $request->input('uid');
        $res = DB::table('jogosultsag')->insert([
            'felhasznalo_id' => $id,
            'felhasznaloszint_id' => 7,
            'utolsomodositas_ideje' => Carbon::now(),
            'elozo_felh_szint' => 2,
            'modosito_felh_id' => 0
        ]);

        if($res)
            return 1;
        else
            return 0;

    }

    public function RemoveDressController(Request $request)
    {
        $id = $request->input('uid');
        $res = DB::table('jogosultsag')->where('felhasznalo_id','=',$id)->where('felhasznaloszint_id','=',7)->delete();
        if($res > 0)
            return 1;
            else
            return 0;
    }

    public function DressDelete(Request $request)
    {
        $dressID = $request->input('did');
        $res = Ruha::find($dressID)->delete();
        if($res)
            return 1;
            else
            return 0;

    }

    public function AddDressToPrograms(Request $request)
    {
        $user = auth()->user();
        $UserId = $user["id"];

        $EventID = $request->input('e_id');
        $DressID =  $request->input('d_id');

        $DressEvents = new RuhaEsemeny;
        $DressEvents->esemeny_id = $EventID;
        $DressEvents->ruha_id = $DressID;
        $DressEvents->modosito = $UserId;
        $DressEvents->save();

        if($DressEvents)
            return 1;
            else
            return 0;
    }

    public function DressRemovePrograms(Request $request)
    {
        $user = auth()->user();
        $UserId = $user["id"];

        $EventID = $request->input('e_id');
        $DressID =  $request->input('d_id');

        RuhaEsemeny::where('esemeny_id',$EventID)->where('ruha_id',$DressID)->delete();


    }

    public function UserAddToDress(Request $request)
    {
        $user = auth()->user();

        $volunteer = $request->input('uid');
        $dressID = $request->input('did');

        $ruhaAtadaoAtvetel = new RuhaAtadoAtvetel;
        $ruhaAtadaoAtvetel->felhasznalo_id = $volunteer;
        $ruhaAtadaoAtvetel->atadasIdeje= Carbon::now();
        $ruhaAtadaoAtvetel->modosito= $user["id"];
        $ruhaAtadaoAtvetel->ruha_id =  $dressID;
        $ruhaAtadaoAtvetel->save();

        $dress = Ruha::find($dressID);
        $dress->keszlet = $dress->keszlet - 1;
        $dress->kiosztva = $dress->kiosztva + 1;
        $dress->modosito = $user['id'];
        $dress->save();

        if($ruhaAtadaoAtvetel)
            return 1;
        else
            return 0;
    }

    public function UserRemoveToDress(Request $request)
    {
        $user = auth()->user();

        $volunteer = $request->input('uid');
        $dressID = $request->input('did');

        $ruhaAtadaoAtvetel = RuhaAtadoAtvetel::where('ruha_id','=',$dressID)
        ->where('felhasznalo_id','=',$volunteer)->update([
            'visszaVetelezesIdeje' => Carbon::now(),
            'modosito'=> $user["id"],
        ]);

        $dress = Ruha::find($dressID);
        $dress->keszlet = $dress->keszlet + 1;
        $dress->kiosztva = $dress->kiosztva - 1;
        $dress->modosito = $user['id'];
        $dress->save();

        if($ruhaAtadaoAtvetel)
            return 1;
        else
            return 0;

    }



    /**
     * @version 2.0
     * A jelige csoportkezelés miatt tortent valtozas: csak a csoportba osztások jelennek meg, nem sz összes jelige
     */
    public function getJeligek()
    {
        $user = auth()->user(); $UserID = $user['id'];
        $jeligeCsoportjaim = JeligeCsoportTagok::where('felhasznalo_id',$UserID)->get('jelige_id')->toArray();
        $jeligek = Jeligek::whereIn('id',$jeligeCsoportjaim)->get();

        return response()->json($jeligek,200);
    }

     /**
     * @version 3.0
     * Admin oldali jelentkezteteshez es modositashoz
     * @date 21.08.26
     */
    public function getJeligekAdmin(Request $request)
    {
        $UserID = (int)$request->input('uid');
        $jeligeCsoportjaim = JeligeCsoportTagok::where('felhasznalo_id',$UserID)->get('jelige_id')->toArray();
        $jeligek = Jeligek::whereIn('id',$jeligeCsoportjaim)->get();

        return response()->json($jeligek,200);
    }

    public function JeligeLetrehozas(Request $request)
    {
        $user = auth()->user();
        $ujJelige = new Jeligek;
        try {
            $ujJelige->jeligeNeve = $request->input('ujelige');
            $ujJelige->letrehozo = $user["id"];
            $ujJelige->save();
        }
        catch(Exception $e)
        {
            return 0;
        }
        

        $csoport = new JeligeCsoportTagok();
        $csoport->felhasznalo_id = $user["id"];
        $csoport->letrehozo = $user["id"];$csoport->modosito = $user["id"];
        $csoport->aktiv = 1;
        $csoport->jelige_id = $ujJelige->id;
        $csoport->save();

        unset($user,$csoport);
        if($ujJelige)
        { return 1;}
        else
        {return 0;}
    }

    public function KeszletInformacio(Request $request)
    {
        $dressID = $request->input('did');
        $dress = Ruha::where('id',$dressID)->get(['kiosztva','keszlet']);
        return $dress;
    }

    public function EgyNyelvTorlese(Request $request)
    {
        $nyelvID = $request->input('nyid');
        if(!is_int(intval($nyelvID)))
        {
            return 0; ///Ez nem integer tipus
        }

        $res = BeszeltNyelvek::find($nyelvID)->delete();
        if($res > 0)
        {
            return 1;
        }
        else
        {
            return $res;
        }


    }

    public function ProfilAdatokBeosztashoz(Request $request)
    {
        $id = $request->input('uid');
        $tid = $request->input('tid');
        $actUser = User::find($id);

        $terulet = Terulet::find($tid);

        $beosztasrepo = new BeosztasKezeloRepo($actUser,$terulet->esemeny_id,$tid );

        return $beosztasrepo->ProfilAdatokBeosztashoz();

    }

    public function Calendar(Request $request)
    {
        $id = $request->input('uid');
        $tid = $request->input('tid');
        $actUser = User::find($id);

        $terulet = Terulet::find($tid);

        $beosztasrepo = new BeosztasKezeloRepo($actUser,$terulet->esemeny_id,$tid );

        return $beosztasrepo->Calendar();
    }

    public function GetTeruletHelyszine(int $TeruletID)
    {
        $tid = Terulet::where('id',$TeruletID)->get('teruletHelyszineID');
        $res = Helyszin::find($tid);
        return $res; 
    }

    public function GetAlHelyszinek(Request $request)
    {
        $alHelyszinek = null;

        try{
            $HelyszinID = Terulet::where('id',$request->input('TeruletID'))->first()->teruletHelyszineID;
            $alHelyszinek = \App\AlHelyszin::where('helyszinID',$HelyszinID)->get();
        }
        catch(Exception $e)
        {
            $alHelyszinek = 'Error';
        }
        finally{
            return $alHelyszinek;
        }

    }


    public function testusercreator()
    {

      /*  for($i = 1;$i < 4;$i++)
        {
            $nev = 'Programkoordinator Koordinator'.$i;
            $mail = 'programkoordinator'.$i.'@iec2020.hu';
            DB_OMR_Operations::InsertTesztUsers($nev,$mail);
        }*/

        DB_OMR_Operations::InsertTesztUsers('Somogyi Eszter','schweszty@hotmail.com');

        DB_OMR_Operations::InsertTesztUsers('Soós Árpád','soosarpad88@gmail.com');

        DB_OMR_Operations::InsertTesztUsers('Olajos Edith','99ditti@gmail.com');

        DB_OMR_Operations::InsertTesztUsers('Bozsó Barbara','bella.bozso@gmail.com');

        DB_OMR_Operations::InsertTesztUsers('Zára Villő','zaravillo@gmail.com ');

        DB_OMR_Operations::InsertTesztUsers('Barta Boglárka','barta.bogi15@gmail.com');

            DB_OMR_Operations::InsertTesztUsers('Marxer Sára Boróka','marxersara2002@gmail.com');

         

            DB_OMR_Operations::InsertTesztUsers('Vékás Johanna','vekasjoja@gmail.com');
            DB_OMR_Operations::InsertTesztUsers('Rafai Vanda','rvanda0928@gmail.com');
            DB_OMR_Operations::InsertTesztUsers('Gerő Réka Katinka','gkatinka.04@gmail.com');
            DB_OMR_Operations::InsertTesztUsers('Kapolcsi-SZabó Botond','kapolcsiboti@gmail.com');
         
           DB_OMR_Operations::InsertTesztUsers('Szabó Róza','szabo.rozafranciska@gmail.com');
            DB_OMR_Operations::InsertTesztUsers('Imre Mátyás','imrematyko@gmail.com');
            DB_OMR_Operations::InsertTesztUsers('Nyisztor Zselyke','nyisztorzselyke19@gmail.com');
            DB_OMR_Operations::InsertTesztUsers('Szemán Áron','sz.aron2016@gmail.com');
            DB_OMR_Operations::InsertTesztUsers('Putz Máté','putzmate04@gamil.com');
            DB_OMR_Operations::InsertTesztUsers('Zsmeberi Sebestyén','zsembery.sebi@gmail.com');

            DB_OMR_Operations::InsertTesztUsers('Szemán Áron','sz.aron2016@gmail.com');
            DB_OMR_Operations::InsertTesztUsers('Szemán Ákos','szemanakos1@gmail.com');
            DB_OMR_Operations::InsertTesztUsers('Bucskó Bálint','bucskob@gmail.com');
            DB_OMR_Operations::InsertTesztUsers('Bakter Borbála','borka.bakter@gmail.com');
            DB_OMR_Operations::InsertTesztUsers('Karvázy Csenge','karvazy.csenge@cserkesz.hu');
            DB_OMR_Operations::InsertTesztUsers('Gőtze Dóra','gotzedori@gmail.com');
            DB_OMR_Operations::InsertTesztUsers('Nagy-Benczeyné Pál Edith','mixolid.e@gmail.com');
            DB_OMR_Operations::InsertTesztUsers('Balázs Gábor','gabor.balazs.sc@gmail.com');
            DB_OMR_Operations::InsertTesztUsers('Sárosi Géza Mikál','gezasarosi100@gmail.com');
            DB_OMR_Operations::InsertTesztUsers('Márkus Jakab','markus.jakab04@gmail.com');

            

            DB_OMR_Operations::InsertTesztUsers('Borka Janó','borka.jano@gmail.com');

            DB_OMR_Operations::InsertTesztUsers('Jakab Kristóf','kristofjakab25@gmail.com');

            DB_OMR_Operations::InsertTesztUsers('Bederna Luca Panna','bederna.luca@gmail.com');

            DB_OMR_Operations::InsertTesztUsers('Dankovics Márton','marton.dankovics@gmail.com');

            DB_OMR_Operations::InsertTesztUsers('Ragó Sára','rago.sara@ezernegyes.hu');

            DB_OMR_Operations::InsertTesztUsers('Nagy-Benczey Viktor Krisztián','simontornya001@gmail.com');
            DB_OMR_Operations::InsertTesztUsers('Tárkányi Botond','kobra@cserkesz.hu');

            echo 'Kész';
    }


    /**
     * Visszater a felhasznalok alap adataival. Elsosorban a Program koordinátor miatt lett kialakitva
     * Post paramterbe, requestbe a jogszint kell!
     *
     * @return JSON
     */
    public function getUsers(Request $request)
    {
        $jogszint = $request->input('jszint');
        $search = $request->input('item');
        if($jogszint > 1 && $jogszint < 7)
        {
            $res = DB::table('users')->join('jogosultsag','users.id','=','jogosultsag.felhasznalo_id','inner')->
            where('jogosultsag.felhasznaloszint_id',$jogszint)->
            where('users.name','LIKE','%'.$search.'%')->get(['users.id','users.name','users.email']);
        }
        else
        {
            return json_encode('Nem létező jogszint');
        }

        return json_encode($res);
    }


    public function YtpState(Request $request)
    {
        $actplaytime = $request->input('start');
        if($actplaytime)
        {
            $user = auth()->user();
            $id = $user['id'];
    
            $ytp = new AppYtpPlayed();
            $ytp->felhasznalo_id = $id;
            $ytp->startTime = Carbon::now();
            $ytp->save();
        }
       
    }

    public function YtpListener(Request $request)
    {
        $user = auth()->user();
        $id = $user['id'];
        $actplaytime = $request->input('playtime');

        $ytp = AppYtpPlayed::where("felhasznalo_id", $id)->orderBy('created_at', 'desc')->first();
        $ytp->actplayTime = $actplaytime;
        $ytp->save();

    }


    public function AccountVerified(Request $request)
    {
        $user = auth()->user();
        $UserId  = (int)$request->input("id");
        $User = User::find($UserId);
        $User->AccountActicvate();
        $User->modifier = $user['id'];
        if($User->save())
        {
            return 1;
        }
        else 
        {
            return 0;
        }
    }

    public function AccountPwdChange(Request $request)
    {
        $user = auth()->user();
        $newpwd = $request->input('pwd');
        $userid = (int)$request->input('id');
        $newpwsdhash = \Hash::make($newpwd);

        $User = User::find($userid);
        $User->password = $newpwsdhash;

        if($User->save())
        {
            return 1;
        }
        else 
        {
            return 0;
        }
    }

    public function moderateProfilPic(Request $request)
    {
        $userid = (int)$request->input("id");
        $User = User::find($userid);
        $validstatus = (int)$request->input("vstatus");
        $systemMsg = null;
        $t = null;
        switch((int)$validstatus)
        {
            case 1: 
                $t = "valid";
                $systemMsg = SystemEmails::find(10);$t = $systemMsg.';;'.$validstatus ;
                OmrEmail::SendMailAnUser($User->email ,$systemMsg->tartalom);
                break;
            case 2: 
                
                $systemMsg = SystemEmails::find(9);$t = $systemMsg.';;'.$validstatus ;
                OmrEmail::SendMailAnUser($User->email ,$systemMsg->tartalom);
                break;

            default:
                return abort(503);
            break;

        }

        $info = Felhasznalo::find($userid);
        $user = auth()->user();

        $info->kepvalidalas = (int)$validstatus;

        if($info->save())
        {
            return 1;
        }
        else{
            return 0;
        }


    }

   

}
