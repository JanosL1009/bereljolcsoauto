<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use App\Http\Controllers\DB_OMR_Operations;
use App\Http\Models\RuhaAtado\Altalanos;
use App\User;
use App\Ruha;
use App\RuhaAtadoAtvetel;

use App\Ajandekok;
use App\AjandekokAtadoAtvetel;
use App\RuhaEsemeny;
use App\Terulet;
use App\TeruletBeosztas;
use App\Esemeny;
use Illuminate\Support\Facades\Input;
use App\Model\Felhasznalo;
use App\FelhasznaloInfo;
use App\UserEgyhazmegye;
use App\SzemlyesAdatok;
use App\Http\Models\CustomProfileValidator;
use App\Support\Collection;
use App\Jogosultsag;
use App\FelhasznloSzintek;
use Exception;

class OnentesRuhaAtadoController extends Controller
{
    public function DressControl(Request $request)
    {
        $dress = Ruha::orderBy('created_at','desc')->paginate(15);

        $user = auth()->user();
        $id = $user['id'];

        $model = new Altalanos($id);
        $model->profilpic = DB_OMR_Operations::GetProfilkep($id);

        return view('onkentes/ruhaatado/index')->with('submenuitem',2)->with('dresses',$dress)->with('model',$model);
    }

 /**
     * creatingnewdress.blade
     */
    public function AddNewDress(Request $request)
    {
        $user = auth()->user();
        //dd($user->jogosultsag_data);

        $model = new Altalanos($user["id"]);
        $model->profilpic = DB_OMR_Operations::GetProfilkep($user["id"]);
        /**
         * submenuitem = 0 :: minden gomb/link secondary lesz
         */
        return view('onkentes/ruhaatado/creatingnewdress')->with('model',$model)->with('submenuitem',0);
    }


    /**
     * POST method: creatingnewdress.blade
     */
    public function DressAdd(Request $request)
    {

        $user = auth()->user();
        $UserId = $user["id"];

        

        $dressName = $request->input('DressName');
        $dressStock = $request->input('DressStock');
        $dresStockOut = $request->input('DressStockOut');

        try 
        {
            $dress = new Ruha;
            $dress->ruhaNeve = $dressName;
            $dress->keszlet = $dressStock;
            $dress->kiosztva = $dresStockOut;
            $dress->letrehozo = $UserId;
            $dress->save();

            return redirect()->action(
                [OnentesRuhaAtadoController::class, 'DressControl'], ['success' => 1]
            );

        }
        catch(Exception $e)
        {
            return redirect()->action(
                [OnentesRuhaAtadoController::class, 'DressControl'], ['success' => 0]
            );
        }
        

        
       // return redirect()->route('onkentes_dresscontrol',['success' => true]);
    }

    public function DressAllInfo(Request $request,$id)
    {
        $user = auth()->user();
        $dress = Ruha::where('id',$id)->first();
        //dd($dress);
        $esemenyek = Esemeny::select('id','nev')->get();


        $dressProgram = RuhaEsemeny::where('ruha_id',$dress->id)->get();

        $selectedPrograms = array();

        foreach($dressProgram as $dp)
        {
            $prog = array();
            $prog['programID'] = $dp->programs->id;
            $prog['programName'] = $dp->programs->nev;
            array_push($selectedPrograms,$prog);
        }



        /**
         * @var array[array] azokat a terulet azonositokat tartalmazza, melyeknek le kell kérni a beosztottjait
         */
        $teruletJelentkezok = array();
        $jelentkezoAzonositok = [];
        if(isset($dressProgram->esemeny_id))
        {
            if(isset($selectedPrograms))
            {
                foreach($selectedPrograms as $program)
                {
                    $result = $this->getTeruletJelentkezok($program['programID']);

                    array_push($teruletJelentkezok,$result);
                }
            }


            foreach($teruletJelentkezok[0] as $user)
            {
                array_push($jelentkezoAzonositok,$user->id);
            }
        }
        else
        {
            $teruletJelentkezok[0] = null;
        }


        $model = new Altalanos($user["id"]);
        $model->profilpic = DB_OMR_Operations::GetProfilkep($user["id"]);

        $atadva = RuhaAtadoAtvetel::select('felhasznalo_id')->where('ruha_id','=',$id)->whereNull('visszaVetelezesIdeje')->get();
        ///dd($atadva);
        return view('onkentes/ruhaatado/fulldresssetting')->with('dress',$dress)->with('submenuitem',0)
        ->with('esemenyek',$esemenyek)->with('selectedPrograms',$selectedPrograms)->
        with('jelentkezok',$teruletJelentkezok[0])->with('jelentkezoAzonositok',$jelentkezoAzonositok)
        ->with('atadva',$atadva)->with('model',$model);

    }

 /**
     * POST feldolgozo metudosok
     */

    public function UpdateNameModify(Request $request)
    {
        $user = auth()->user();
        $UserId = $user["id"];

        $newName = $request->input('NewDressName');
        $DressID = $request->input('dressCode');

        $dress = Ruha::where('id',$DressID)->first();
        $dress->ruhaNeve = $newName;
        $dress->modosito = $UserId;
        $dress->updated_at = Carbon::now();
        $dress->save();

        return redirect()->route('ruha.onkentes.reszletek',['id' => $dress->id]);
    }

    public function UpdateDressStock(Request $request)
    {
        $user = auth()->user();
        $UserId = $user["id"];

        $stock = $request->input('NewDressStock');
        $DressID = $request->input('dressCode');

        $dress = Ruha::where('id',$DressID)->first();
        $dress->keszlet = $stock;
        $dress->modosito = $UserId;
        $dress->updated_at = Carbon::now();
        $dress->save();

        return redirect()->route('ruha.onkentes.reszletek',['id' => $dress->id]);
    }

    public function UpdateDressOutStock(Request $request)
    {
        $user = auth()->user();
        $UserId = $user["id"];

        $stockout = $request->input('NewDressStockOut');
        $DressID = $request->input('dressCode');

        $dress = Ruha::where('id',$DressID)->first();
        $dress->kiosztva = $stockout;
        $dress->modosito = $UserId;
        $dress->updated_at = Carbon::now();
        $dress->save();

        return redirect()->route('ruha.onkentes.reszletek',['id' => $dress->id]);
    }

     /**
     * visszater egy program jelentkezőivel, akik már be vannak osztva teruletre
     */
    private function getTeruletJelentkezok($programID)
    {
        $teruletID_List = Terulet::select('id')->where('esemeny_id',$programID)->get()->toArray();

        $teruletBeosztas = TeruletBeosztas::select('felhasznalo_id')->whereIn('terulet_id',$teruletID_List)->get()->toArray();
        unset($teruletID_List);

        $Users = User::whereIn('id',$teruletBeosztas)->orderBy('name')->get();
        unset($teruletBeosztas);

        return $Users;
    }


    /**   ONKENTES KERESO ES PROFIL MEGJELENITO */
/**
 * Eq: RuhaAtadoController::DressSearching
 */
    public function UserSearching(Request $request)
    {
        $name = $request->input('onkentes_neve');
        $email = $request->input('volemail');
        $logged = auth()->user();
        $id = (int)$logged["id"];
        $model = new Altalanos($id);
        $model->profilpic = DB_OMR_Operations::GetProfilkep($id);

        $talalat = null;

        if(isset($email))
        {
            $talalat = \App\User::where('email',$email)->get();
            $talalat = $this->getNewKeresoCollection($talalat)->paginate(20);
        }
 
        if(isset($name))
        {
             
             $talalat = User::where('name', 'like', '%'.$name.'%')->get();
 
             $talalat = $this->getNewKeresoCollection($talalat)->paginate(20);
        }

        if(isset($talalat))
        {
            return view('onkentes/ruhaatado/dresssearching', ['talalat' => $talalat->appends(Input::except('page')) ])->with('talalat',$talalat)->with('submenuitem',3)
            ->with('model',$model);
        }
        else{
            return view('onkentes/ruhaatado/dresssearching')
            ->with('talalat',$talalat)->with('submenuitem',3)->with('model',$model);
           
        }
    }

    public function ProfilNezo(Request $request,$UserId)
    {
        $logged = auth()->user();
        $id = (int)$logged["id"];

        $user = User::find($UserId);
        $osszesRuha = Ruha::all();
        $ruhaLista = RuhaAtadoAtvetel::where('felhasznalo_id',$UserId)->get();
        $jsonRuhaLista = array();
       foreach($ruhaLista as $ruha)
       {
           if(!isset($ruha->visszaVetelezesIdeje) )
           {
               try{
                $item["ruhaid"] = $ruha->Ruha->id??0;
                array_push($jsonRuhaLista,$item);
               }
               catch(Exception $e)
               {
                $item["ruhaid"] = 0;
               }
            
           }
           
       }

       $model = new Altalanos($id);
        $model->profilpic = DB_OMR_Operations::GetProfilkep($id);

        
        return view('onkentes/ruhaatado/userinfo')->with('user',$user)->with('ruhaLista',$ruhaLista)
        ->with('osszesRuha',$osszesRuha)->with('jsonRuhaLista',json_encode($jsonRuhaLista))->with('model',$model);
    }


    /**
     * visszavetelezes
     */

    public function visszavetelezes(int $RuhaAtadoID)
    {

        /**nem számolja ruhát */

        $user = auth()->user();
        //dd($user->jogosultsag_data);
        $UserId = $user["id"];

        $atvettRuhaAdatok = RuhaAtadoAtvetel::find($RuhaAtadoID);
        $atvettRuhaAdatok->modosito = $UserId;
        $atvettRuhaAdatok->visszaVetelezesIdeje = Carbon::now();

        $ruha = Ruha::find($atvettRuhaAdatok->ruha_id);
        $ujKeszlet = $ruha->kiosztva - $atvettRuhaAdatok->darabszam;
        $ruha->kiosztva = $ujKeszlet;
        $ruha->modosito = (int)$user["id"];
        try 
        {
            $ruha->save();
        }
        catch(Exception $e)
        {
            return back()->withErrors('Hiba a készlet kivonás során!','failed');
        }

        if($atvettRuhaAdatok->save())
        {
            return back()->withErrors('A visszavételezés sikeresen megtörtént!','success');
        }
        else  return back()->withErrors('A visszavételezés sikertelen!','failed');

    }

    /******************************************************************* */

     /**
     * Visszater egy collection-el, ami tartalmazza a kereso reszletes adatait. Tobb collectionbol keszit egy sajatot
     * collection tartalmat: id,nev,szuletesi ido, cim, profilkep, jogosultsag, vezetoi szintek
     *
     * @return Collection Kereso adatlapok eredmenyei
     */
    protected function getNewKeresoCollection($UserCollection, $FelhasznaloFeladatCollection = null)
    {
        $NewCollection = array();
        if(isset($FelhasznaloFeladatCollection)) //program szerinti keresesnel NEM null
        {

        }
        else //ha nem program szerint keres (kor,nev)
        {
            //dd($UserCollection[0]);
            foreach($UserCollection as $User)
            {


                $NewUser = null;
                $NewUser['id'] = $User->id;
                $NewUser['nev'] = $User->name;
                    
                $NewUser['email'] = $User->email;


try{
if($User->felhasznalo_data->kepvalidalas == 3 || $User->felhasznalo_data->kepvalidalas == 2)
{
    $NewUser['profilkepvalid'] = false;
}
else{
    $NewUser['profilkepvalid'] = true;
} 
}
catch(Exception $e)
{
$NewUser['profilkepvalid'] = false;
}

                   

                   // dd($cpv->getMessage());
                   $NewUser['atadva'] = false;
                   $ruhak = $User->Ruha;
                   foreach($ruhak as $ruha)
                   {
                        if($ruha->ruha_id == 1)
                        {
                            $NewUser['atadva'] = true;
                        }
                        
                   }
                

                if(isset($User->felhasznalo_data))
                {
                    $NewUser['profilkep'] = $User->felhasznalo_data->profilkep;
                }
                $NewUser['jogosultsag'] = null;
                /**
                 * Lehet: Önkéntes, Önkéntes és Ruha átadó, Adminisztrátor
                 */
                $jogok = Jogosultsag::where('felhasznalo_id',$User->id)->get();
                if(isset($jogok))
                {
                        foreach($jogok as $jog)
                        {
                                    $NewUser['jogosultsag'] = $NewUser['jogosultsag'].' '.FelhasznloSzintek::find($jog->felhasznaloszint_id)->SzintNeve;

                        }

                }


                array_push($NewCollection,$NewUser);

            }
        }
        //dd($NewCollection);
        return new Collection($NewCollection);
    }


    /**
     * Ajandek
     */

    public function ajandek_index() 
    {
       $dress = Ajandekok::orderBy('created_at','desc')->paginate(15);



       return view('adminisztratorok/ruha_atado/ajandekok')->with('submenuitem',4)->with('dresses',$dress);
    }

    public function UjAjandek()
    {
       

       return view('adminisztratorok/ruha_atado/ajandekletrehozasa')->with('submenuitem',4);
    }

    public function AjandekLetrehozasa(Request $request)
    {
       $validate = $request->validate([
           "DressName" => 'required'
       ]);

       $user = auth()->user();
       $UserId = $user["id"];

       $uj =  new Ajandekok();
       $uj->ajandekNeve = $request->input('DressName');
       $uj->keszlet = $request->input('DressStock');
       $uj->kiosztva = $request->input('DressStockOut');
       $uj->letrehozo =  $UserId;
       $uj->modosito = 0;
       $uj->save();
      
       return redirect()->route('ajandek.info',['id' => $uj->id]);
    }

    public function AjandekInfo($id)
    {
       $dress = Ajandekok::where('id',$id)->first();
       //dd($dress);
       

      // dd($teruletJelentkezok[0]);

       $atadva = AjandekokAtadoAtvetel::select('felhasznalo_id')->where('ruha_id','=',$id)->whereNull('visszaVetelezesIdeje')->get();
       ///dd($atadva);
       return view('adminisztratorok/ruha_atado/ajandekmodositas')->with('dress',$dress)->with('submenuitem',0);
    }

    public function AjandekNevenekModositasa(Request $request)
    {
       $ujnev = $request->input('NewDressName');
       $ajiCode = (int)$request->input('dressCode');

       $ajandek = Ajandekok::find($ajiCode);
       $ajandek->ajandekNeve = $ujnev;

       $ajandek->save();

       return back();
    }

    public function AjandekKeszletModositasa(Request $request)
    {
       $ujertek = (int)$request->input('NewDressStock');
       $ajiCode = (int)$request->input('dressCode');

       $ajandek = Ajandekok::find($ajiCode);
       $ajandek->keszlet = $ujertek;

       $ajandek->save();

       return back();
    }

    public function AjandekKiosztModositasa(Request $request)
    {
       $ujertek = (int)$request->input('NewDressStockOut');
       $ajiCode = (int)$request->input('dressCode');

       $ajandek = Ajandekok::find($ajiCode);
       $ajandek->kiosztva = $ujertek;

       $ajandek->save();

       return back();
    }

    public function AjandekProfilNezo($UserId)
    {
       $user = User::find($UserId);
       $osszesRuha = Ajandekok::all();
       $ruhaLista = AjandekokAtadoAtvetel::where('felhasznalo_id',$UserId)->get();
      
       $jsonRuhaLista = array();
       try{
           if(count($ruhaLista) > 0)
           {
               foreach($ruhaLista as $ruha)
               {
                   if(!isset($ruha->visszaVetelezesIdeje) )
                   {
                    $item["ruhaid"] = $ruha->ruha_id;
                    array_push($jsonRuhaLista,$item);
                   }
                   
               }
           }
           else $ruhaLista = null;
       }
       catch(Exception $e)
       {
           $ruhaLista = null;
       }
       
      
       return view('onkentes/ruhaatado/ajandekuserinfo')->with('user',$user)->with('ruhaLista',$ruhaLista)
       ->with('osszesRuha',$osszesRuha)->with('jsonRuhaLista',json_encode($jsonRuhaLista));
    }



    public function postAjandekAtadas(Request $request)
    {
        
        $loggeduser = auth()->user(); //atado
        $LoggedUserId = $loggeduser["id"]; 

        $UserID = $request->input('auid');
        $darabszam = $request->input('db');
        $ruhaID = $request->input('did'); //dressID
        $actTime = date('Y-m-d H:i:s');//Carbon::now();

        $ruha = Ajandekok::find($ruhaID);
        $kiosztva = (int)$ruha->kiosztva;
        $keszlet = (int)$ruha->keszlet;

        $ujKiosztottKeszlet = $kiosztva + $darabszam;
       
      try{
        if( (int)$ujKiosztottKeszlet <= $keszlet)
        {
            
            $ruha->kiosztva = $ujKiosztottKeszlet;
            
        }
        else throw new Exception();
      }
      catch(Exception $e)
      {
          return 0;
        //return 'Hiba a készletezés során. A készlet elfogyott!';
      }
      
      $ruhaKeszletMenteve = false;
      try{
        if($ruha->save())
        {
           
            $ruhaKeszletMenteve = true;
        }
    }
    catch(Exception $e)
    {
        return 1;
        //return back()->withErrors('Hiba a ruha készlet mentésekor!','failed');
    }


        $new = new AjandekokAtadoAtvetel();
        $new->ruha_id = $ruhaID;
        $new->darabszam = $darabszam;
        
        $new->atadasIdeje = $actTime;
        $new->felhasznalo_id = $UserID;
        $new->modosito = $LoggedUserId; //modosito/letrehozo
        $AtadoAtvetelMentve = false;

        try{
            if($new->save())
            {
                
                $AtadoAtvetelMentve = true;
            }
        }
        catch(Exception $e)
        {
            $error = new MyErrorLog();
            $error->controller = 'RuhaAtadoController';
            $error->methodname = 'postAjandekAtadas';
            $error->otherDescribe = 'Mentés hiba: 2';
            $error->exceptionMsg = $e;
            $error->save();
            return 2;
            //return back()->withErrors('Nem sikerült a darabszámok mentése!','failed');
        }

        if($AtadoAtvetelMentve &&  $ruhaKeszletMenteve)
        {
            $NewRecord = array();
             $dress["ruha_id"] = $ruhaID;
             $dress["ruha_atadoid"] = $new->id;
             $dress["ruha_neve"] = $ruha->ajandekNeve;
             $dress["atadasIdeje"] = $new->atadasIdeje;
             array_push($NewRecord,$dress);
            //return 3;
            return json_encode($NewRecord);
        }
        else 
        {
            return 4;
            //return back()->withErrors('Sikertelen átadás!','failed');
        }
    }


    /**
     * ajandekvisszavetelezes
     */
    public function ajandek_visszavetelezes(int $RuhaAtadoID)
    {

        /**nem számolja ruhát */

        $user = auth()->user();
        //dd($user->jogosultsag_data);
        $UserId = $user["id"];

        $atvettRuhaAdatok = AjandekokAtadoAtvetel::find($RuhaAtadoID);
        $atvettRuhaAdatok->modosito = $UserId;
        $atvettRuhaAdatok->visszaVetelezesIdeje = Carbon::now();

        $ruha = Ajandekok::find($atvettRuhaAdatok->ruha_id);
        $ujKeszlet = $ruha->kiosztva - $atvettRuhaAdatok->darabszam;
        $ruha->kiosztva = $ujKeszlet;
        $ruha->modosito = (int)$user["id"];
        try 
        {
            $ruha->save();
        }
        catch(Exception $e)
        {
            return back()->withErrors('Hiba a készlet kivonás során!','failed');
        }

        if($atvettRuhaAdatok->save())
        {
            return back()->withErrors('A visszavételezés sikeresen megtörtént!','success');
        }
        else  return back()->withErrors('A visszavételezés sikertelen!','failed');

    }


}
