<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use GuzzleHttp\Cookie;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\ClientException;
use GuzzleHttp\Psr7;
use GuzzleHttp\Exception\RequestException;
use Exception;
use Illuminate\Support\Carbon;
use Symfony\Component\HttpFoundation\Response;
use App\Edubase;
use App\User;
use App\TeruletBeosztas;
use App\Terulet;
use App\TeruletvezetokTerulet;
class EdubaseController extends Controller
{
    protected const APP_ID = '55NAImARReqNrmsS';
    protected const SECRET = 'ZHT2ZGAOlb4qxGZP6oBKnIAeXshk1GPU';

    public function Edubase(Request $request)
    {
        $id = auth()->id();
        
        if($id === null)
        {
            return abort(503); //nincs joga a metodus futtatasahoz
        }

        $elRes = Edubase::where('felhasznalo_id',$id)->first();
        
        if($elRes !== null)
        {
            //dd($elRes);
            if($elRes->valid_link > Carbon::now())
            {
               
                $elRes->educount =  (int)$elRes->educount + 1;
                $elRes->save();
                $this->ClassMembers($elRes->eduid,'C6VoH2ATtSF8SWav');
                $this->ClassMembers($elRes->eduid,'tlGug9mlb2aMHh8D');
                $this->ClassMembers($elRes->eduid,'U4ohK3ugkvvIqfb7'); //Baleset- és munkavédelem
                $this->ClassMembers($elRes->eduid,'OEIvngpgEHaIPhk4'); //Gyermek- és ifjúságvédelem
                $this->ClassMembers($elRes->eduid,'SXaaOw9un4IdNFE6'); //KATOLIKUS SZERVEZETEK / NEK TÁRSSZERVEZETEK
                $this->ClassMembers($elRes->eduid,'d8TWvelscDdE3MkH'); //NEK2020 - Második Önkéntes Online Tájékoztató - 2021. június 24
                $this->ClassMembers($elRes->eduid,'NoxyZzSxngqfYpU9'); //Nemzetközi és egyházi protokoll
                $this->ClassMembers($elRes->eduid,'j8SdWQxIz2j89QJt'); //TURISZTIKAI ISMERETEK
                if($this->HungexporaBeosztott($id))
                {
                    $this->ClassMembers($elRes->eduid,'nYUd9lFUzM3eNR3Q');
                }

                if($this->TeruletVezetok($id))
                {
                    $this->ClassMembers($elRes->eduid,'Iqw36WLXmmYPbBkz');
                }

                
                $this->redirectToEdubase($elRes->loginlink);
            }
            else
            {
                $this->ClassMembers($elRes->eduid,'C6VoH2ATtSF8SWav');
                $this->ClassMembers($elRes->eduid,'tlGug9mlb2aMHh8D');
                $this->ClassMembers($elRes->eduid,'U4ohK3ugkvvIqfb7'); //Baleset- és munkavédelem
                $this->ClassMembers($elRes->eduid,'OEIvngpgEHaIPhk4'); //Gyermek- és ifjúságvédelem
                $this->ClassMembers($elRes->eduid,'SXaaOw9un4IdNFE6'); //KATOLIKUS SZERVEZETEK / NEK TÁRSSZERVEZETEK
                $this->ClassMembers($elRes->eduid,'d8TWvelscDdE3MkH'); //NEK2020 - Második Önkéntes Online Tájékoztató - 2021. június 24
                $this->ClassMembers($elRes->eduid,'NoxyZzSxngqfYpU9'); //Nemzetközi és egyházi protokoll
                $this->ClassMembers($elRes->eduid,'j8SdWQxIz2j89QJt'); //TURISZTIKAI ISMERETEK
                if($this->HungexporaBeosztott($id))
                {
                    $this->ClassMembers($elRes->eduid,'nYUd9lFUzM3eNR3Q');
                }

                if($this->TeruletVezetok($id))
                {
                    $this->ClassMembers($elRes->eduid,'Iqw36WLXmmYPbBkz');
                }

                 $this->generateLoginLink($elRes->eduid);

            }
        }
        else 
        {
            
            //dd("jó ág");
                $user = User::find($id);
                $firstname = $user->felhasznalo_data->kozepsonev.' '.$user->felhasznalo_data->keresztnev;
                $lastname = $user->felhasznalo_data->vezeteknev;
                $email = 'onkentes'.$user->id.'@private.edubase.net';
                $szulido = $user->felhasznalo_data->szulIdo;

                $gender = null;
                if((int)$user->felhasznalo_data->neme == 0)
                {
                    $gender = 'male';
                }
                else
                {
                    $gender = 'female';
                }

                


            $url = 'https://nek.edubase.net/api/v1/user';
            

                $client = new Client( ["base_uri" => "https://nek.edubase.net/api/v1/user"],
                    [[
                        'Content-Type' => 'application/x-www-form-urlencoded; charset=utf-8',
                    // 'Content-Type' => 'application/json; charset=utf-8',
                        'debug'           => true
                    ]]
                
                );
                
                $response = null;
            try{
                $res = $client->request('POST', $url, [
                    'form_params' => [
                        'username' => 'onkentes'.$user->id,
                        'first_name' =>  $firstname,
                        'last_name' =>   $lastname,
                        
                        'email' =>  $email,
                        'gender' => $gender,
                        

                        'exam' => 'false',
                        'app' => self::APP_ID,
                        'secret' => self::SECRET
                ]]);
            
                if( $res->getStatusCode() == 200)
                {

                    $jsonresult = $res->getBody();
                    $j = json_decode($jsonresult,true);
                    // echo $j["user"];
                    
                    $newEdubaseRecord = new Edubase();
                    $newEdubaseRecord->felhasznalo_id = $user->id;
                    $newEdubaseRecord->eduusername = $j["username"];
                    $newEdubaseRecord->educount = 0;
                    $newEdubaseRecord->eduid = $j["user"];
                    $newEdubaseRecord->save();
                    
                    $this->ClassMembers($j["user"],'tlGug9mlb2aMHh8D');
                    $this->ClassMembers($j["user"],'C6VoH2ATtSF8SWav');
                    $this->ClassMembers($elRes->eduid,'U4ohK3ugkvvIqfb7'); //Baleset- és munkavédelem
                    $this->ClassMembers($elRes->eduid,'OEIvngpgEHaIPhk4'); //Gyermek- és ifjúságvédelem
                    $this->ClassMembers($elRes->eduid,'SXaaOw9un4IdNFE6'); //KATOLIKUS SZERVEZETEK / NEK TÁRSSZERVEZETEK
                    $this->ClassMembers($elRes->eduid,'d8TWvelscDdE3MkH'); //NEK2020 - Második Önkéntes Online Tájékoztató - 2021. június 24
                    $this->ClassMembers($elRes->eduid,'NoxyZzSxngqfYpU9'); //Nemzetközi és egyházi protokoll
                    $this->ClassMembers($elRes->eduid,'j8SdWQxIz2j89QJt'); //TURISZTIKAI ISMERETEK
                    if($this->HungexporaBeosztott($id))
                    {
                        $this->ClassMembers($elRes->eduid,'nYUd9lFUzM3eNR3Q');
                    }

                    if($this->TeruletVezetok($id))
                        {
                            $this->ClassMembers($elRes->eduid,'Iqw36WLXmmYPbBkz');
                        }

                    $this->generateLoginLink($j["user"]);
                }

            }
            catch(ClientException $ce)
            {
                echo "*******************************************";

                echo Psr7\Message::toString($ce->getRequest());
                echo "*******************************************  \r \n";
                if ($ce->hasResponse()) {
                    echo Psr7\Message::toString($ce->getResponse());
                }
            }
                                
                   
        }   

    }


    public function generateLoginLink(string $EduID)
    {
        $url = "https://nek.edubase.net/api/v1/user:login";
       $client = new Client( ["base_uri" => "https://nek.edubase.net/api/v1/user:login"],
                [[
                    'Content-Type' => 'application/x-www-form-urlencoded; charset=utf-8',
                // 'Content-Type' => 'application/json; charset=utf-8',
                    'debug'           => true
                ]]
       
        );

        $res = $client->request('POST', $url, [
            'form_params' => [
                'user' => $EduID,
                'expires' => 2,
                'logins' => 10,
                'app' => self::APP_ID,
                'secret' => self::SECRET
        ]]);

        $j = json_decode($res->getBody(),true);
      // echo $j["url"];
                $edubase = Edubase::where('eduid',$EduID)->first(); 
                
                $edubase->valid_link = $j["valid"];
                $edubase->loginlink = $j["url"];
                $counter = $edubase->educount;
                 $edubase->educount = $counter + 1;
                 $edubase->firstedulogin = Carbon::now();
                $edubase->save();

        $this->redirectToEdubase( $j["url"]);  
    }

    public function ClassMembers(string $EduID, string $ClassID)
    {
        $url = "https://nek.edubase.net/api/v1/classes:members";
        $client = new Client( ["base_uri" => "https://nek.edubase.net/api/v1/classes:members"],
                 [[
                     'Content-Type' => 'application/x-www-form-urlencoded; charset=utf-8',
                 // 'Content-Type' => 'application/json; charset=utf-8',
                     'debug'           => true
                 ]]
        
         );

         $res = $client->request('POST', $url, [
            'form_params' => [
                'classes' => $ClassID,
                'users' => $EduID,
                'expires' => '2021-12-30',
                'app' => self::APP_ID,
                'secret' => self::SECRET
        ]]);

        if( $res->getStatusCode() == 200)
        {}

    }

    public function HungexporaBeosztott(int $UserID)
    {
            $teruletek = Terulet::where('esemeny_id',38)->get('id');
            $whereArray = array();
            foreach($teruletek as $terulet)
            {
                array_push($whereArray,$terulet->id);
            }
            $beosztas = TeruletBeosztas::whereIn('terulet_id',$whereArray)->where('felhasznalo_id',$UserID)->get();
           //dd($whereArray ,$beosztas);
           $talalat = false;
            
           
            if(count($beosztas) > 0 )
            {
                $talalat = true;
                
            }

            return $talalat;
    }


    public function TeruletVezetok(int $UserID)
    {
            
            $beosztas = TeruletvezetokTerulet::where('felhasznalo_id',$UserID)->get();
           //dd($whereArray ,$beosztas);
           $talalat = false;
            
           
            if(count($beosztas) > 0 )
            {
                $talalat = true;
                
            }
            
            return $talalat;
    }


    public function redirectToEdubase(string $EdubaseLoginLink)
    {
        header('Location: '.$EdubaseLoginLink);
        exit;
    }

    public function EdubaseEloKozvetites()
    {
        $id = auth()->id();
        
        if($id === null)
        {
            return abort(503); //nincs joga a metodus futtatasahoz
        }

        $elRes = Edubase::where('felhasznalo_id',$id)->first();
       
        if($elRes !== null)
        {
            //dd($elRes);
            if($elRes->valid_link > Carbon::now())
            {
               
                $elRes->educount =  (int)$elRes->educount + 1;
                $elRes->save();
                $this->ClassMembers($elRes->eduid,'C6VoH2ATtSF8SWav');
                $this->ClassMembers($elRes->eduid,'tlGug9mlb2aMHh8D');
                $this->redirectToEdubase($elRes->loginlink);
            }
            else
            {
                $this->ClassMembers($elRes->eduid,'C6VoH2ATtSF8SWav');
                 $this->ClassMembers($elRes->eduid,'tlGug9mlb2aMHh8D');
                 $this->generateLoginLink($elRes->eduid);

            }
        }
        else 
        {
            //dd("jó ág");
                $user = User::find($id);
                $firstname = $user->felhasznalo_data->kozepsonev.' '.$user->felhasznalo_data->keresztnev;
                $lastname = $user->felhasznalo_data->vezeteknev;
                $email = 'onkentes'.$user->id.'@private.edubase.net';
                $szulido = $user->felhasznalo_data->szulIdo;

                $gender = null;
                if((int)$user->felhasznalo_data->neme == 0)
                {
                    $gender = 'male';
                }
                else
                {
                    $gender = 'female';
                }

                


            $url = 'https://nek.edubase.net/api/v1/user';
            

                $client = new Client( ["base_uri" => "https://nek.edubase.net/api/v1/user"],
                    [[
                        'Content-Type' => 'application/x-www-form-urlencoded; charset=utf-8',
                    // 'Content-Type' => 'application/json; charset=utf-8',
                        'debug'           => true
                    ]]
                
                );
                
                $response = null;
            try{
                $res = $client->request('POST', $url, [
                    'form_params' => [
                        'username' => 'onkentes'.$user->id,
                        'first_name' =>  $firstname,
                        'last_name' =>   $lastname,
                        
                        'email' =>  $email,
                        'gender' => $gender,
                        

                        'exam' => 'false',
                        'app' => self::APP_ID,
                        'secret' => self::SECRET
                ]]);
            
                if( $res->getStatusCode() == 200)
                {

                    $jsonresult = $res->getBody();
                    $j = json_decode($jsonresult,true);
                    // echo $j["user"];
                    
                    $newEdubaseRecord = new Edubase();
                    $newEdubaseRecord->felhasznalo_id = $user->id;
                    $newEdubaseRecord->eduusername = $j["username"];
                    $newEdubaseRecord->educount = 0;
                    $newEdubaseRecord->eduid = $j["user"];
                    $newEdubaseRecord->save();

                    $this->ClassMembers($j["user"],'C6VoH2ATtSF8SWav');
                    $this->ClassMembers($j["user"],'tlGug9mlb2aMHh8D');
                    
                    $this->generateLoginLink($j["user"]);
                }

            }
            catch(ClientException $ce)
            {
                echo "*******************************************";

                echo Psr7\Message::toString($ce->getRequest());
                echo "*******************************************  \r \n";
                if ($ce->hasResponse()) {
                    echo Psr7\Message::toString($ce->getResponse());
                }
            }
                                
                   
        }   
    }

}
