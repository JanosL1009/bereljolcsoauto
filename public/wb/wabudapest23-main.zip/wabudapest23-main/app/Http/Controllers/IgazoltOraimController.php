<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\FelhasznaloFeladat;
use App\Munkafelvetel;
use Auth;

use Illuminate\Support\Facades\DB;
use App\Http\Models\OnkentesBeosztasaimViewModel;
use App\User;

class IgazoltOraimController extends Controller
{
    public function index(Request $request)
    { 
        $UserId = Auth::id();
      
        $model = new OnkentesBeosztasaimViewModel($UserId);
        $model->profilpic = DB_OMR_Operations::GetProfilkep($UserId);
         
        $esemenyek = FelhasznaloFeladat::where('felhasznalo_id',$UserId)->where('csoport_id','>',1)->paginate(20);
        
        return view('onkentes.igazolt_orak')->with('esemenyek',$esemenyek)->with('model',$model);
    }


    public function orak(Request $request,int $CsoportID)
    {
        $UserId = Auth::id(); 
        $model = new OnkentesBeosztasaimViewModel($UserId);
        $model->profilpic = DB_OMR_Operations::GetProfilkep($UserId);

        $esemeny = FelhasznaloFeladat::where('felhasznalo_id',$UserId)->where('csoport_id','=',$CsoportID)->first();
        $orak = Munkafelvetel::where('felhasznalo_id',$UserId)->where('csoport_id','=',$CsoportID)->get();
        //dd($esemeny);
        return view('onkentes.oraszamok')->with('esemeny',$esemeny)->with('model',$model)->with('orak',$orak);
    }

    public function admin_index(Request $request,int $UserId)
    { 
        $AuthUserId = Auth::id();
      
        $model = new OnkentesBeosztasaimViewModel($AuthUserId);
        $model->profilpic = DB_OMR_Operations::GetProfilkep($AuthUserId);
         
        $esemenyek = FelhasznaloFeladat::where('felhasznalo_id',$UserId)->where('csoport_id','>',1)->paginate(20);
        $user = User::find($UserId);
        return view('adminisztratorok.igazoltorak.igazolt_orak')->with('esemenyek',$esemenyek)->with('model',$model)->with('user',$user);
    }

    public function admin_orak(Request $request,int $CsoportID, int $UserId)
    {
        $AuthUserId = Auth::id(); 
        $model = new OnkentesBeosztasaimViewModel($AuthUserId);
        $model->profilpic = DB_OMR_Operations::GetProfilkep($AuthUserId);

        $esemeny = FelhasznaloFeladat::where('felhasznalo_id',$UserId)->where('csoport_id','=',$CsoportID)->first();
        $orak = Munkafelvetel::where('felhasznalo_id',$UserId)->where('csoport_id','=',$CsoportID)->get();
        //dd($esemeny);
        $user = User::find($UserId);
        return view('adminisztratorok.igazoltorak.oraszamok')->with('esemeny',$esemeny)->with('model',$model)->with('orak',$orak)
        ->with('user',$user);
    }

}
