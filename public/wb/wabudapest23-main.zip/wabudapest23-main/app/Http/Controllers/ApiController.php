<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;

class ApiController extends Controller
{
    public function update(Request $request)
    {
        $token = Str::random(80);

        $request->user()->forceFill([
            'api_token' => hash('sha256', $token),
        ])->save();

        return ['token' => $token];
    }

    public function getOnkentesOrakSzama()
    {
        $oraszamok = DB::table('felhasznalok')->where('onkentesOrakSzama','>',0)->get('onkentesOrakSzama');

        $sum = 0;
        foreach($oraszamok as $ora)
        {
            $sum = $sum + (int)$ora->onkentesOrakSzama??0; 
        }

        unset($oraszamok);
        return json_encode($sum);
    }
}
