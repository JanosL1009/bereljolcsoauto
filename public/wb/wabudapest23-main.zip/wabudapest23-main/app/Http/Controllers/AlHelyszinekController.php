<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\AlHelyszin;
use App\Helyszin;
use Exception;

class AlHelyszinekController extends Controller
{
    public function letrehozas(Request $request)
    {
        return view('adminisztratorok.alhelyszinek.letrehozas');
    }

    public function onkentes_oldali_letrehozas(Request $request,int $HelyszinID)
    {
        $helyszin = null;
        try{
            $helyszin = Helyszin::find($HelyszinID);
        } 
        catch(Exception $e)
        {
            $helyszin = null;
        }

        return view('onkentes.alhelyszinek.letrehozas')->with('helyszin',$helyszin);
    }

    public function letrehozas_feldolgozo(Request $request)
    {
        $helyszin = Helyszin::where('Neve',$request->input('helyszin_neve'))->first(); //ami ID!!!
        $CsopHelyszinNeve = $request->input('csophelyszin_neve');

        try{
            $user = auth()->user();
            $alhelyszin = new AlHelyszin();
            $alhelyszin->helyszinID = $helyszin->id;
            $alhelyszin->nev = $CsopHelyszinNeve;
            $alhelyszin->letrehozo = $user['id'] ;
            $alhelyszin->save();
        }
        catch(Exception $e)
        {
            return redirect('alhelyszin.lista')->withErrors("Hiba a letrehozás során.",'letrehozoashiba');
        }
        
        

        return redirect(route('alhelyszin.lista'))->withErrors("Az új csoport helyszín létrehozása sikerült!",'sikerletrehozas');
    }

    public function onkentes_letrehozas_feldolgozo(Request $request)
    {
        //$helyszin = Helyszin::where('Neve',$request->input('helyszin_neve'))->first(); //ami ID!!!
        $CsopHelyszinNeve = $request->input('csophelyszin_neve');

        try{
            $user = auth()->user();
            $alhelyszin = new AlHelyszin();
            $alhelyszin->helyszinID = (int)$request->input('helyszin_id');
            $alhelyszin->nev = $CsopHelyszinNeve;
            $alhelyszin->letrehozo = $user['id'] ;
            $alhelyszin->save();
        }
        catch(Exception $e)
        {
            return back()->withErrors("Hiba a letrehozás során.",'failed');
        }
        
        

        return back()->withErrors("Az új csoport helyszín létrehozása sikerült!",'success');
    }

    public function modositas(int $id)
    {
        $alhelyszin = AlHelyszin::find($id);

        return view('adminisztratorok.alhelyszinek.modositas')->with('alhelyszin',$alhelyszin);
    }

    public function frissites_feldolgozo(Request $request)
    {
        $user = auth()->user();
        $helyszin = Helyszin::where('Neve',$request->input('helyszin_neve'))->first();
       
        try {
            $alhelyszin = AlHelyszin::find($request->input('id'));
            $alhelyszin->helyszinID = $helyszin->id;
            $alhelyszin->nev = $request->input('csophelyszin_neve');
            $alhelyszin->modosito =  $user['id'] ;
            $alhelyszin->save();
        }
        catch(Exception $e)
        {
            return redirect('alhelyszin.lista')->withErrors("Hiba a módosítás során.",'modositasihiba');
        }

        

        return redirect(route('alhelyszin.lista'))->withErrors("Az új csoport helyszín módosítása sikerült!",'sikermodositas');;
   
    }

    public function lista()
    {
        $helyszinek = AlHelyszin::paginate(15);

        return view('adminisztratorok.alhelyszinek.lista')->with('helyszinek',$helyszinek);
    }

}
