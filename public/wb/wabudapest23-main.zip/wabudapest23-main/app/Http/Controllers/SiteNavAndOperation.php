<?php
namespace App\Http\Controllers;
use App\Http\Controllers\I_SiteOperation;

class SiteNavAndOperation
{



    public static function getPagesForSearches($matchList,bool $prev_nev_btn = false, int $item = 15, int $ActPage = 0)
    {
        $MaxItem = count($matchList);
        $prevNum = 0;
        $nextNum = 0;

        if($prev_nev_btn)
        {
            if($ActPage > 1)
            {
                $prevNum = $ActPage - 1;
            }
            if($ActPage == $MaxItem )
            {
                $nextNum = $MaxItem;
            }
            else if($ActPage < $MaxItem)
            {
                $nextNum =  $ActPage + 1;
            }
        }

        $NumberOfPages = $MaxItem / $item;
        if(gettype($NumberOfPages) == 'double')
        {
            $NumberOfPages = intval($NumberOfPages) + intval(1);
        }

        return compact("MaxItem","prev_nev_btn","item","ActPage","prevNum", "nextNum","NumberOfPages");
    }

    /**Assoc array URL => Name  Output: exp. Rendezveny -> Passio2020 rendezveny neve -> terulet neve -> csoport neve
     *
    */
    public static function getBreadcrumb($urlParamList)
    {

    }


}
