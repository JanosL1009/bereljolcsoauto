<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Models\AdminBeallitasokViewModel;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use App\BeszeltNyelvek;
use App\SystemEmails;
use App\PagesDetails;
use Exception;
use App\Egyhazmegyek;
use App\UserEgyhazmegye;

class BeallitasokController extends Controller
{
    protected $UserID = null;
    public function __construct()
    {
        $user = auth()->user();
        $this->UserID = $user['id'];
    }


    public function AdminBeallitas()
    {
        $user = auth()->user();
        $model = new AdminBeallitasokViewModel($user['id']);
        $model->profilpic = DB_OMR_Operations::GetProfilkep($user['id']);
        $model->profilkepValtoztatasanaklehetosege = DB::table('systemsettings')->where('settingkey','=','profilpicmodify')->get()->first()->settingvalue;
       // dd($model->profilkepValtoztatasanaklehetosege);
        return view('adminisztratorok/AdminBeallitas')->with('model',$model);
    }

    /**
     * AJAX metodushoz :: post
     * Letiltja az onkenteseknek a profilkep valtoztatasanak ill feltoltesenek lehetoseget.
     */
    public function ProfilKepValtoztatasTiltasa(Request $request)
    {
        $mode = $request->input('profilpicmodifyval');

        if($mode == '0' || $mode == '1')
        {
            $user = auth()->user();
            $userid = $user['id'];
            $actdatetime = Carbon::now();
              //id->1=>profilepicmodify
            DB::table('systemsettings')->where('id','=',1)->update(['settingvalue' => $mode,'modosito' => $userid,'modositasideje' => $actdatetime]);
            return 1;
        }
        else return 0;




    }


    public function Nyelvek(Request $request,$field = null, $order = null)
    {
        $nyelvLista = null;
        $fieldName = null;

        try{
            if(isset($field) && isset($order))
            {
                if($order != 'asc' && $order != 'desc')
                {
                    throw new Exception();
                }


                switch($field)
                {
                    case 'nev':
                        $fieldName = 'nyelvNeve';

                    break;
                    case 'rovidnev':
                        $fieldName = 'nyelvRovidJelzese';

                    break;
                    default: $fieldName = 'nyelvNeve'; break;
                }
                $nyelvLista = BeszeltNyelvek::orderby($fieldName,$order)->paginate(15);
            }
            else
            {
                $nyelvLista = BeszeltNyelvek::paginate(15);
            }
        }
        catch(Exception $e)
        {
            $nyelvLista = BeszeltNyelvek::paginate(15);
        }

        //$nyelvLista = BeszeltNyelvek::all()->paginate(15);

        return view('adminisztratorok.beallitasok.beszeltnyelvek',['nyelvek' => $nyelvLista]);
    }


    /**
     * Form Method Type: POST
     *
     * @return void
     */
    public function UjBeszeltNyelvHozzaadasa(Request $request)
    {
        $NyelvElnevezese = $request->input('NewLangName');
        $NyelvRovidElnevezes = $request->input('NewShortLangName');
        $user = auth()->user();
        $ujNyelv = new BeszeltNyelvek;
        $ujNyelv->nyelvNeve =  $NyelvElnevezese;
        $ujNyelv->nyelvRovidJelzese = $NyelvRovidElnevezes;
        $ujNyelv->letrehozo = $user['id'];
        $ujNyelv->save();

        return back();
    }


    public function EgyhazMegyek(Request $request,$field = null,$order = null)
    {
        $Egyhazmegyek = null;
        $fieldName = null;

        try{
            if(isset($field) && isset($order))
            {
                if($order != 'asc' && $order != 'desc')
                {
                    throw new Exception();
                }


                switch($field)
                {
                    case 'nev':
                        $fieldName = 'nev';

                    break;
                    case 'felekezet':
                        $fieldName = 'felekezet';

                    break;
                    default: $fieldName = 'nev'; break;
                }
                $Egyhazmegyek = Egyhazmegyek::orderby($fieldName,$order)->paginate(15);
            }
            else
            {
                $Egyhazmegyek = Egyhazmegyek::paginate(15);
            }
        }
        catch(Exception $e)
        {
            $Egyhazmegyek = Egyhazmegyek::paginate(15);
        }



        $user = auth()->user();
        $model = new AdminBeallitasokViewModel($user['id']);
        $model->profilpic = DB_OMR_Operations::GetProfilkep($user['id']);

        return view('adminisztratorok.beallitasok.egyhazmegye',['egyhazmegyek' => $Egyhazmegyek])->with('model',$model);
    }

    public function UjEgyhazMegyeHozzaadasa(Request $request)
    {
        $user = auth()->user(); //akt user
        $elnevezes = $request->input('egyhazMegye');
        $felekezet = $request->input('felekezet');
        $megye = new Egyhazmegyek();
        $megye->nev = $elnevezes;
        $megye->felekezet = $felekezet;
        $megye->letrehozo = $user['id'];
        $megye->save();

        return back();
    }

    public function EgyhazmegyeModositas(Request $request)
    {
        $user = auth()->user(); //akt user
        $ujEgyhazMegyeNev = $request->input('modifyegyhazMegye');
        $egyhazMegyeID = $request->input('emid');
        $megye = Egyhazmegyek::find($egyhazMegyeID);
        $megye->nev = $ujEgyhazMegyeNev;
        $megye->modosito = $user['id'];
        $hibakod = null; $hiba = null;
        try{
            $megye->save();
            $hibakod = 1; //nincs hiba
        }
        catch(Exception $e)
        {
            $hibakod = 0; //hiba
            $hiba = $e;
        }


        return back()->withErrors(['mentes' =>  $hibakod, 'uzenet' => $hiba]);
    }

    public function DeleteEgyhazMegye(Request $request)
    {
        $id = $request->input('nyid');
        $megye = Egyhazmegyek::find($id);
        $megye->delete();

        if($megye)
            return 1;
            else
            return 0;
    }

    /**
     * A kiküldhető email üzeneteinek beallitasa
     */
    public function RendszerUzenetek($field = null,$order = null)
    {
        $systemMails = null;
        if(isset($field) && isset($order))
        {
            if($field == 'name' && ($order == 'asc' || $order == 'desc'))
            {
                if($order == 'asc')
                {
                    $systemMails = SystemEmails::orderBy('sm_name','asc')->paginate(15);
                }
                else
                {$systemMails = SystemEmails::orderBy('sm_name','desc')->paginate(15);}
            }
        }
        else
        {
            $systemMails = SystemEmails::all()->paginate(15);
        }


        return view('adminisztratorok.beallitasok.rendszeruzenetek',['systemMails' => $systemMails ]);
    }

    public function RendszerUzenetSzerkesztese(int $id)
    {
        $systemMsg = SystemEmails::find($id);

        return view('adminisztratorok.beallitasok.rendszermailmodositas',['systemMessage' => $systemMsg]);
    }

    public function profilkepErtesitoMail()
    {
        $systemMsg = SystemEmails::find(10); //profilkepre vonatkozo
        return view('adminisztratorok.beallitasok.profilkepmailszoveg')->with('msg',$systemMsg);
    }

    public function profilkepErtesitoMailUpdate(Request $request)
    {
        $user = auth()->user();
        try{
            $systemMsg = SystemEmails::find(10);
            $systemMsg->sm_name = $request->input('subject');
            $systemMsg->tartalom = $request->input('emailContent');
            $systemMsg->modosito = (int)$user["id"];
            $systemMsg->save();
        }
        catch(Exceptio $e)
        {
            return back()->withErrors('Sikertelen mentés!','sikertelenmentes');
        }
        

        return back()->withErrors('Sikeres mentés!','sikeresmentes');
    }

    public function invalidprofilkepErtesitoMail()
    {
        $systemMsg = SystemEmails::find(9); //profilkepre vonatkozo
        return view('adminisztratorok.beallitasok.profilkepmailszoveginv')->with('msg',$systemMsg);
    }

    public function invalidprofilkepErtesitoMailUpdate(Request $request)
    {
        $user = auth()->user();
        try{
            $systemMsg = SystemEmails::find(9);
           // $systemMsg->sm_name = $request->input('subject');
            $systemMsg->tartalom = $request->input('emailContent');
            $systemMsg->modosito = (int)$user["id"];
            $systemMsg->save();
        }
        catch(Exception $e)
        {
            return back()->withErrors('Sikertelen mentés!','sikertelenmentes');
        }
        

        return back()->withErrors('Sikeres mentés!','sikeresmentes');
    }

    /**
     * Method: post
     * Az elozo metodus form feldolgozo fgv-e
     */
    public function RendszerUzenetSzerkeszteseFeldolgozo(Request $request)
    {
        $id =  $request->input('MmID');
        $systemMsg = null;
        try{
            if(is_int(intval($id) ))
            {
                $systemMsg = SystemEmails::find($id);
            }
            else throw new Exception('nem megfelelő paraméter.');
        }
        catch(Exception $e)
        {
            return back();
        }

        $systemMsg->tartalom = $request->input('MailMsg');
        $systemMsg->modosito = $this->UserID;
        $systemMsg->save();

        return back();
    }


    /**
     * Ki listazza az onkentes oldal oldalainak a magyarazo szovegeit.
     *
     * @return View
     */
    public function MagyarazoSzovegekOldalankent()
    {
        $pageDetails = PagesDetails::all();

        return view('adminisztratorok.beallitasok.magyarazoszovegek_list',['pageDetails' => $pageDetails]);

    }



    /**
     * Betolit egy oldal leirasait
     * @param int pagesddetails ID DB-ből
     */
    public function MagyarazoSzovegSzerkesztese(Request $request,int $id)
    {
        $pageInfo =  PagesDetails::find($id);

        return view('adminisztratorok.beallitasok.magyarazoszoveg_szerkesztes' ,['pageInfo' => $pageInfo]);
    }

    /**
     * Method: POST
     * Urlap feldolgozo metodus
     * @return URL back()
     */
    public function MagyarazoSzovegFeldolgozo(Request $request)
    {
        $id = $request->input('MmID');

        if(is_int(intval($id)))
        {
            $user = auth()->user();
            $pageInfo =  PagesDetails::find($id);
            $pageInfo->leiras = $request->input('Msg');
            $pageInfo->modosito =   $user["id"];
            $pageInfo->save();

            return back();
        }
        else
         return back();

    }



}
