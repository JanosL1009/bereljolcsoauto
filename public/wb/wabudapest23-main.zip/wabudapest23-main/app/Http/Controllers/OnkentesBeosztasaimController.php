<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Mail;
use App\User;
use App\Esemeny;
use App\Terulet;
use App\TeruletBeosztas;
use App\Http\Models\Csoport;
use App\FelhasznaloFeladat;
use App\EsemenySzervezok;
use App\Http\Controllers\Auth;
use Illuminate\Support\Facades\DB;
use App\Http\Models\OnkentesBeosztasaimViewModel;
use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;
use App\Http\Models\Beosztas\OnkenteBeosztViewModel;
use App\Http\Controllers\DB_OMR_Operations;
use  App\Http\Models\CsoportokLekerdezese;
use App\Http\Controllers\CsoportMuveletek;
use  App\Http\Models\AdminCsopBeosztasViewModel;
use App\Model\BeosztasKezeloRepo;
use App\OnkentesViews;
use Exception;
use App\Csoport as ProgramCsoport;
use App\Http\Models\Koordinatorok\EsemenySzerkesztoViewModel;
use App\Http\Models\Koordinatorok\KoordinatorTeruletCsoportViewModel;
use App\AlHelyszin;
use App\UserAdminsViews;
use App\PagesDetails;
class OnkentesBeosztasaimController extends Controller
{


    public function __construct() {

    }

    public function beosztasaim(Request $request,$mode,$state)
    {
        $user = auth()->user();
        $today = Carbon::today()->toDateString();
        $model = new OnkentesBeosztasaimViewModel($user['id']);
        $model->profilpic = DB_OMR_Operations::GetProfilkep($user['id']);
        $model->mode = $mode;
        $model->state = $state;

        $userviews = new OnkentesViews();
        $userviews->slug = $_SERVER['REQUEST_URI'];
        $userviews->visitTimes = $today;
        $userviews->felhasznalo_id = $user['id'];
        $userviews->save();

        $pagesdetails = PagesDetails::find(11);

        if($mode == "aktiv")
        {

            $csoportBeosztasaim = null;
            if(isset($model->state))
            {
                if($model->state == "onkentes")//aktiv onkentes
                {
                    $queryString = 'SELECT felhasznalo_feladat.jelentkezesID,esemeny.id as esemeny_id, esemeny.nev as esemenynev, terulet_beosztas.terulet_id, terulet.nev as teruletnev, csoport.id as csoportid, csoport.nev as csoportnev, esemeny.kezdesDatum as kezdesDatum,  terulet.kezdesIdopont as teruletkezdes,terulet.befejezesIdopont as teruletvege FROM `terulet_beosztas` inner join felhasznalo_feladat on terulet_beosztas.felhasznalo_id = felhasznalo_feladat.felhasznalo_id and terulet_beosztas.terulet_id = felhasznalo_feladat.terulet_id join esemeny on esemeny.id = felhasznalo_feladat.esemeny_id join terulet on terulet.id = terulet_beosztas.terulet_id left join csoport on csoport.id = felhasznalo_feladat.csoport_id where terulet_beosztas.felhasznalo_id = '.$user["id"].' order by esemeny.kezdesDatum';
                    $csoportBeosztasaim = DB::select(DB::raw( $queryString));

                    $csereTomb = [];
                    $max = count($csoportBeosztasaim);
                    
                    for($i = 0; $i < $max;$i++)
                    {
                      $item = $csoportBeosztasaim[$i];
                      
                      if(count($csereTomb) == 0)
                      {
                        array_push($csereTomb,$csoportBeosztasaim[0]);
                      }
                      else 
                      {
                        if(!$this->isBeosztasKereso($csereTomb,$item))
                        {
                            array_push($csereTomb, $item);
                        }
                      }
                      
                    }


                   
                    //dd($csereTomb);
                  
                    $model->esemenyek = $csereTomb;
                    $model->AktivLink = '/onkentes/beosztasaim/aktiv/onkentes';
                    $model->ArchivLink = '/onkentes/beosztasaim/archiv/onkentes';
                    $model->OnkentesLink = '/onkentes/beosztasaim/aktiv/onkentes';
                    $model->VezetoLink = '/onkentes/beosztasaim/aktiv/vezeto';
                    //dd($csoportBeosztasaim);
                }
                if($model->state == "vezeto") //aktiv
                {

                    $csoportBeosztasaim = DB::table('esemeny_szervezok')->join('esemeny','esemeny_szervezok.Esemeny_id','=','esemeny.id')->
                    join('felhasznaloszintek','felhasznaloszintek.id','=','esemeny_szervezok.szint_id')
                    ->join('terulet','terulet.id','=','esemeny_szervezok.terulet_id','left')
                    ->join('csoport','esemeny_szervezok.csoport_id','=','csoport.id','left')
                    ->where('esemeny.befejezesDatum','>',$today)
                    ->where('esemeny_szervezok.felhasznalo_id','=',$user['id'])->whereBetween('esemeny_szervezok.szint_id',  [3,5])
                    ->select('esemeny_szervezok.esz_id','esemeny_szervezok.csoport_id','esemeny_szervezok.terulet_id as terulet_id','esemeny_szervezok.Esemeny_id',
                    'csoport.nev as csoportnev','terulet.nev as teruletnev','esemeny.nev as esemenynev','esemeny.kezdesDatum','felhasznaloszintek.SzintNeve'
                    )->paginate(15);

                    //dd($csoportBeosztasaim);

                    $model->state = 'vezeto';
                    $model->esemenyek = $csoportBeosztasaim;
                    $model->AktivLink = '/onkentes/beosztasaim/aktiv/onkentes';
                    $model->ArchivLink = '/onkentes/beosztasaim/archiv/vezeto';
                    $model->OnkentesLink = '/onkentes/beosztasaim/aktiv/onkentes';
                    $model->VezetoLink = '/onkentes/beosztasaim/aktiv/vezeto';
                }

            }
            //dd($model);
            return view('/onkentes/beosztasaim')->with('model',$model)->with('pagesdetails',$pagesdetails);
        }
        else if ($mode == "archiv")
        {
            $csoportBeosztasaim = null;
            if(isset($model->state))
            {
                if($model->state == "onkentes") //archiv
                {
                    $csoportBeosztasaim = DB::table('felhasznalo_feladat')->join('esemeny','felhasznalo_feladat.esemeny_id','=','esemeny.id')->
                    join('csoport','felhasznalo_feladat.csoport_id','=','csoport.id','inner')->
                    join('terulet','terulet.id','=','felhasznalo_feladat.terulet_id','inner')->
                    where('felhasznalo_feladat.csoport_id','>',0)->where('felhasznalo_feladat.felhasznalo_id','=',$user['id'])->where('csoport.befejezesDatuma','<',$today)
                    ->orderBy('esemeny.kezdesDatum','desc')->
                    select('felhasznalo_feladat.jelentkezesID','felhasznalo_feladat.csoport_id','felhasznalo_feladat.terulet_id','felhasznalo_feladat.esemeny_id',
                    'csoport.nev as csoportnev','terulet.nev as teruletnev','esemeny.nev as esemenynev','esemeny.kezdesDatum'
                    )->paginate(15);
                    $model->esemenyek = $csoportBeosztasaim;
                   // dd($model->esemenyek);
                    $model->AktivLink = '/onkentes/beosztasaim/aktiv/onkentes';
                    $model->ArchivLink = '/onkentes/beosztasaim/archiv/onkentes';
                    $model->OnkentesLink = '/onkentes/beosztasaim/archiv/onkentes';
                    $model->VezetoLink = '/onkentes/beosztasaim/archiv/vezeto';
                    //dd($model);
                }
                if($model->state == "vezeto") //archiv
                {
                    $csoportBeosztasaim = DB::table('esemeny_szervezok')->join('esemeny','esemeny_szervezok.Esemeny_id','=','esemeny.id')->
                    join('felhasznaloszintek','felhasznaloszintek.id','=','esemeny_szervezok.szint_id')
                    ->join('terulet','terulet.id','=','esemeny_szervezok.terulet_id','left')
                    ->join('csoport','esemeny_szervezok.csoport_id','=','csoport.id','left')
                    ->where('esemeny.befejezesDatum','<',$today)
                    ->where('esemeny_szervezok.felhasznalo_id','=',$user['id'])->whereBetween('esemeny_szervezok.szint_id',  [3,5])
                    ->select('esemeny_szervezok.esz_id','esemeny_szervezok.csoport_id','esemeny_szervezok.terulet_id','esemeny_szervezok.Esemeny_id',
                    'csoport.nev as csoportnev','terulet.nev as teruletnev','esemeny.nev as esemenynev','esemeny.kezdesDatum','felhasznaloszintek.SzintNeve'
                    )->paginate(15);

                    $model->esemenyek = $csoportBeosztasaim;
                   // dd($model->esemenyek);
                    $model->AktivLink = '/onkentes/beosztasaim/aktiv/vezeto';
                    $model->ArchivLink = '/onkentes/beosztasaim/archiv/onkentes';
                    $model->OnkentesLink = '/onkentes/beosztasaim/archiv/onkentes';
                    $model->VezetoLink = '/onkentes/beosztasaim/aktiv/vezeto';
                }

            }

            return view('/onkentes/beosztasaim')->with('model',$model)->with('pagesdetails',$pagesdetails);
        }
        else{

            $model->mode == "aktiv";
            return view('/onkentes/beosztasaim',['mode' => 'aktiv'])->with('model',$model)->with('pagesdetails',$pagesdetails);
        }



        return view('/onkentes/beosztasaim')->with('model',$model)->with('pagesdetails',$pagesdetails);
    }
    /** beosztasaim vege */



    public function beosztasom_reszletei_onkentes(Request $request,$jelentkezesID)
    {
        $user = auth()->user();


        $model = new OnkenteBeosztViewModel($user['id']);
        $model->profilpic = DB_OMR_Operations::GetProfilkep($user['id']);

        $userviews = new OnkentesViews();
        $userviews->slug = $_SERVER['REQUEST_URI'];
        $userviews->visitTimes = Carbon::now();
        $userviews->felhasznalo_id = $user['id'];
        $userviews->save();

        $felhasznalo_feladat = FelhasznaloFeladat::where('jelentkezesID',$jelentkezesID)->where('felhasznalo_id',$user['id'])->first();
        if(!isset($felhasznalo_feladat))
        {
            $EsemenySzervezo = EsemenySzervezok::where('esz_id',$jelentkezesID)->first();
            $felhasznalo_feladat = FelhasznaloFeladat::where('csoport_id',$EsemenySzervezo->csoport_id)->where('felhasznalo_id',$user['id'])->first();

        }
        if(isset($felhasznalo_feladat))
        {

            $model->esemeny = Esemeny::where('id','=',$felhasznalo_feladat->esemeny_id)->first();
            //dd($model->esemeny);
            $model->terulet = Terulet::where('id',$felhasznalo_feladat->terulet_id)->first();
            $model->csoport = ProgramCsoport::where('id',$felhasznalo_feladat->csoport_id)->first();

            $model->esemenyHelyszinek = DB::table('helyszin')->join('esemeny_telepules','helyszin.id','=','esemeny_telepules.telepules_id')
            ->where('esemeny_telepules.esemeny_id','=',$felhasznalo_feladat->esemeny_id)->get();


           $model->teruletHelyszinek = DB::table('helyszin')->join('terulet','helyszin.id','=','terulet.teruletHelyszineID')
           ->where('terulet.id','=',$felhasznalo_feladat->terulet_id)->get();

           $model->esemenyKoordinatorok = DB::table('users')->join('esemeny_szervezok','users.id','=','esemeny_szervezok.felhasznalo_id')
           ->where('Esemeny_id',$felhasznalo_feladat->esemeny_id)->where('esemeny_szervezok.szint_id','=',3)->get();

           $model->teruletVezetok = DB::table('users')->join('esemeny_szervezok','users.id','=','esemeny_szervezok.felhasznalo_id')
           ->where('terulet_id',$felhasznalo_feladat->terulet_id)
           ->where('esemeny_szervezok.szint_id','=',4)->get();

           $model->csoportVezetok = DB::table('users')->join('esemeny_szervezok','users.id','=','esemeny_szervezok.felhasznalo_id')
           ->where('csoport_id',$felhasznalo_feladat->csoport_id)
           ->where('esemeny_szervezok.szint_id','=',5)->get();

        }



       $model->breadcrumb ='<li class="breadcrumb-item"><a href="'.url('onkentes/beosztasaim/aktiv/onkentes').'">Beosztásaim</a></li>
       <li class="breadcrumb-item active" aria-current="page">Jelenlegi beosztásom</li>
       <li class="breadcrumb-item active" aria-current="page">'.$model->esemeny->nev.'</li>
       ';


        return view('onkentes/beosztas/onkentes_beosztasom')->with('model',$model);
    }


    /**
     * @deprecated v1.8.x
     * Valtoztak a kovetelemnyek. Mar nem az esemenyszervezok az elsodleges szempont, hanem a Teruletvezeto tabla es fuggosefei/kapcsolatai!
     *
     */
    public function beosztasom_reszletei_vezeto(Request $request,$szervezoid)
    {
        $user = auth()->user();

        $model = new OnkenteBeosztViewModel($user['id']);
        $model->profilpic = DB_OMR_Operations::GetProfilkep($user['id']);

        $userviews = new OnkentesViews();
        $userviews->slug = $_SERVER['REQUEST_URI'];
        $userviews->visitTimes = Carbon::now();
        $userviews->felhasznalo_id = $user['id'];
        $userviews->save();

        $EsemenySzervezok = EsemenySzervezok::where('esz_id',$szervezoid)->where('felhasznalo_id',$user['id'])->first();
        $model->jogszint = 0;
        try{
            $model->jogszint = $EsemenySzervezok->szint_id;
        }
        catch(Exception $e)
        {
            return abort(404);
        }

        if(isset($EsemenySzervezok))
        {
            $model->esemeny = Esemeny::where('id','=',$EsemenySzervezok->Esemeny_id)->first();
            if(isset($EsemenySzervezok->terulet_id))
            {

                $model->terulet = Terulet::where('id',$EsemenySzervezok->terulet_id)->first();
            }
            $model->esemenyHelyszinek = DB::table('helyszin')->join('esemeny_telepules','helyszin.id','=','esemeny_telepules.telepules_id')
            ->where('esemeny_telepules.esemeny_id','=',$EsemenySzervezok->Esemeny_id)->get();


           $model->teruletHelyszinek = DB::table('helyszin')->join('terulet','helyszin.id','=','terulet.teruletHelyszineID')
           ->where('terulet.id','=',$EsemenySzervezok->terulet_id)->get();

           $model->esemenyKoordinatorok = DB::table('users')->join('esemeny_szervezok','users.id','=','esemeny_szervezok.felhasznalo_id')
           ->where('Esemeny_id',$EsemenySzervezok->Esemeny_id)->where('esemeny_szervezok.szint_id','=',3)->get();

           $model->teruletVezetok = DB::table('users')->join('esemeny_szervezok','users.id','=','esemeny_szervezok.felhasznalo_id')
           ->where('terulet_id',$EsemenySzervezok->terulet_id)
           ->where('esemeny_szervezok.szint_id','=',4)->get();
        }

       $model->breadcrumb ='<li class="breadcrumb-item"><a href="'.url('onkentes/beosztasaim/aktiv/vezeto').'">Beosztásaim</a></li>
       <li class="breadcrumb-item active" aria-current="page">Jelenlegi vezetői beosztásom</li>
       <li class="breadcrumb-item active" aria-current="page"></li> ';

       $model->csoport = [];

        switch($model->jogszint)
        {
            case 4: //teruletvezeto
                //itt az osszes csoport kell, mert hozzaferhet mindenhez!
                $csoport = DB::table('csoport')->
                join('terulet','terulet.id','=','csoport.terulet_id')->
                where('terulet.id','=',$model->terulet->id)->
                select('csoport.id','csoport.nev','csoport.kezdesDatuma','csoport.befejezesDatuma','csoport.kezdesIdeje','csoport.befejezesIdeje','csoport.leiras')->
                get();

                foreach($csoport as $csop)
                {
                    $cs = [
                        "id" => $csop->id,
                        "nev" => $csop->nev,
                        "leiras" => $csop->leiras,
                        "kezdesDatuma" => $csop->kezdesDatuma,
                        "befejezesDatuma" => $csop->befejezesDatuma,
                        "kezdesIdeje" => $csop->kezdesIdeje,
                        "befejezesIdeje" => $csop->befejezesIdeje,
                        "csoportVezetok" => $this->getCsoportVezetokLekerdezese($EsemenySzervezok->csoport_id)
                    ];
                    array_push($model->csoport,$cs);
                }

                $model->breadcrumb ='<li class="breadcrumb-item"><a href="'.url('onkentes/beosztasaim/aktiv/vezeto').'">Beosztásaim</a></li>
                <li class="breadcrumb-item active" aria-current="page">Jelenlegi vezetői beosztásom</li>
                <li class="breadcrumb-item active" aria-current="page"><u> Terület (vezető) koordinátor</u></li> ';
                return view('onkentes/beosztas/teruletvezeto')->with('model',$model);
            break;
            case 5: //Csoportvezeto
                $csoport = DB::table('csoport')->
                where('id','=',$EsemenySzervezok->csoport_id)->
                select('csoport.id','csoport.nev','csoport.kezdesDatuma','csoport.befejezesDatuma','csoport.kezdesIdeje','csoport.befejezesIdeje','csoport.leiras')->
                get();

                foreach($csoport as $csop)
                {
                    $cs = [
                        "id" => $csop->id,
                        "nev" => $csop->nev,
                        "leiras" => $csop->leiras,
                        "kezdesDatuma" => $csop->kezdesDatuma,
                        "befejezesDatuma" => $csop->befejezesDatuma,
                        "kezdesIdeje" => $csop->kezdesIdeje,
                        "befejezesIdeje" => $csop->befejezesIdeje,
                        "csoportVezetok" => $this->getCsoportVezetokLekerdezese($EsemenySzervezok->csoport_id)
                    ];
                    array_push($model->csoport,$cs);
                }
               // dd($model->csoport);
                $model->breadcrumb ='<li class="breadcrumb-item"><a href="'.url('onkentes/beosztasaim/aktiv/vezeto').'">Beosztásaim</a></li>
                <li class="breadcrumb-item active" aria-current="page">Jelenlegi vezetői beosztásom</li>
                <li class="breadcrumb-item active" aria-current="page"><u> Csoportvezető</u></li> ';

                return view('onkentes/beosztas/csoportvezeto')->with('model',$model);
            break;
        }

       return view('onkentes/beosztas/vezetobeosztas')->with('model',$model);
    }

    /**
     * @since v1.8.0.
     * A beosztasom_reszletei_vezeto metodus helyett ezt kell hasznalni!
     */
    public function FizetettOnkentesTeruletvezeto(Request $request,$teruletid)
    {
        $user = auth()->user();

        $model = new OnkenteBeosztViewModel($user['id']);
        $model->profilpic = DB_OMR_Operations::GetProfilkep($user['id']);

        $terulet = Terulet::find($teruletid);
        $model->terulet = $terulet;
        $model->esemeny = Esemeny::find($terulet->esemeny_id);

        /**
         * Naplozas
         */
        $userviews = new OnkentesViews();
        $userviews->slug = $_SERVER['REQUEST_URI'];
        $userviews->visitTimes = Carbon::now();
        $userviews->felhasznalo_id = $user['id'];
        $userviews->save();

        $model->esemenyHelyszinek = DB::table('helyszin')->join('esemeny_telepules','helyszin.id','=','esemeny_telepules.telepules_id')
        ->where('esemeny_telepules.esemeny_id','=',$terulet->esemeny_id)->get();


       $model->teruletHelyszinek = DB::table('helyszin')->join('terulet','helyszin.id','=','terulet.teruletHelyszineID')
       ->where('terulet.id','=',$teruletid)->get();

       $model->esemenyKoordinatorok = DB::table('users')->join('esemeny_szervezok','users.id','=','esemeny_szervezok.felhasznalo_id')
       ->where('Esemeny_id',$terulet->esemeny_id)->where('esemeny_szervezok.szint_id','=',3)->get();

       $model->teruletVezetok = DB::table('users')->join('teruletvezetok_terulet','users.id','=','teruletvezetok_terulet.felhasznalo_id')
           ->where('terulet_id',$teruletid)->get();

       $model->csoport = [];
       $csoport = DB::table('csoport')->
       join('terulet','terulet.id','=','csoport.terulet_id')->
       where('terulet.id','=',$teruletid)->
       select('csoport.id','csoport.nev','csoport.kezdesDatuma','csoport.befejezesDatuma','csoport.kezdesIdeje','csoport.befejezesIdeje','csoport.leiras','csoport.helyszin_id')->
       get();

       foreach($csoport as $csop)
       {
           $cs = [
               "id" => $csop->id,
               "nev" => $csop->nev,
               "leiras" => $csop->leiras,
               "kezdesDatuma" => $csop->kezdesDatuma,
               "befejezesDatuma" => $csop->befejezesDatuma,
               "kezdesIdeje" => $csop->kezdesIdeje,
               "befejezesIdeje" => $csop->befejezesIdeje,
               "csoportVezetok" => $this->getCsoportVezetokLekerdezese($csop->id),
               "helyszin_id" => $csop->helyszin_id,
               "helyszin" => \App\AlHelyszin::find($csop->helyszin_id)->nev??''
           ];
           array_push($model->csoport,$cs);
       }
       $BeosztasKezelo = new BeosztasKezeloRepo($user,intval($terulet->esemeny_id),intval($teruletid),null);
            /**
          * @var Array
          */
          $model->jelentkezokLista =  $BeosztasKezelo->getIdTeruletJelentkezokListaja();
          $model->jokerJelentkezoLista = $BeosztasKezelo->getJokerJelentkezoIDk();

          $model->JokerJelentkezokSzama = $BeosztasKezelo->getTeruletJelentkezokJokerekSzama();


          $model->jelentkezokSzama = $BeosztasKezelo->getTeruletJelentkezokSzamaOsszesWithJokers();
          $model->BeosztottakSzama = $BeosztasKezelo->getTeruletAktualisBeosztottakSzama();
          $model->beosztottakListaja = $BeosztasKezelo->getTeruletreBeosztottakListajaID();

          $model->BeoszthatoOnkentesekSzama = $BeosztasKezelo->getBeoszthatoOnkentesekSzama();
       $usersArr = array();
       foreach($model->jelentkezokLista as $jelentkezo)
       {
          array_push($usersArr,$jelentkezo->felhasznalo_id);
       }
       foreach($model->beosztottakListaja as $jelentkezo)
       {
          array_push($usersArr,$jelentkezo->felhasznalo_id);
       }
       foreach($model->jokerJelentkezoLista as $jelentkezo)
       {
          array_push($usersArr,$jelentkezo->felhasznalo_id);
       }

       $model->UsersFreeTimes = $BeosztasKezelo->Calendar($usersArr);

       $csoportInfo = DB_OMR_Operations::CsoportLista($teruletid);

       $model->breadcrumb ='<li class="breadcrumb-item"><a href="'.url('onkentes/teruletvezeto/teruleteim').'">Területeim</a></li>
       <li class="breadcrumb-item active" aria-current="page">Jelenlegi vezetői beosztásom</li>
       <li class="breadcrumb-item active" aria-current="page"><u> Terület (vezető) koordinátor</u></li> ';
      //dd($model->csoport);
       return view('onkentes/beosztas/teruletvezeto')->with('model',$model)->with('csoportInfo',$csoportInfo);


    }

    /**
     * @deprecated v1.8.x
     */
    public function OnkentesTeruletBeosztas(Request $resquest,$teruletid)
    {
        $user = auth()->user();

        $userviews = new OnkentesViews();
        $userviews->slug = $_SERVER['REQUEST_URI'];
        $userviews->visitTimes = Carbon::now();
        $userviews->felhasznalo_id = $user['id'];
        $userviews->save();

        $csoportok = new CsoportokLekerdezese($user['id']);
        $csoportok->csoport = DB_OMR_Operations::CsoportLista($teruletid);
        $csoportok->profilpic = DB_OMR_Operations::GetProfilkep($user['id']);

        $terulet = DB::table('terulet')->where('id','=',$teruletid)->get();

        $csoportok->teruletKezdesIdopont = $terulet[0]->kezdesIdopont;
        $csoportok->teruletBefejezesIdopont = $terulet[0]->befejezesIdopont;
        $csoportok->teruletneve = $terulet[0]->nev;
        $rendezvenyNeve =  DB::table('esemeny')->where('id','=',$terulet[0]->esemeny_id)->pluck('nev');
        $csoportok->teruletid =  $terulet[0]->id;
        $csoportok->esemeny_id =  $terulet[0]->esemeny_id;
        $csoportok->rendezvenyNeve = $rendezvenyNeve[0];
        $BeosztasKezelo = new BeosztasKezeloRepo($user,intval($csoportok->esemeny_id),intval($teruletid),null);



         $csoportok->tervezettLetszam = $terulet[0]->tervezettLetszam;
         $csoportok->TeruletAktiv =  $terulet[0]->teruletAktiv;
         $csoportok->teruletLeiras = $terulet[0]->leiras;

         /**
          * @var Array
          */
         $csoportok->jelentkezokLista =  $BeosztasKezelo->getIdTeruletJelentkezokListaja();
         $csoportok->jokerJelentkezoLista = $BeosztasKezelo->getJokerJelentkezoIDk();

       // dd($csoportok->jelentkezokLista,$csoportok->jokerJelentkezoLista);

         //$csoportok->JokerJelentkezokSzama = $BeosztasKezelo->getTeruletJelentkezokJokerekSzama();
         $csoportok->JokerJelentkezokSzama = count($csoportok->jokerJelentkezoLista);

         $csoportok->jelentkezokSzama = count($csoportok->jelentkezokLista);
         $csoportok->BeosztottakSzama = $BeosztasKezelo->getTeruletAktualisBeosztottakSzama();
         $csoportok->beosztottakListaja = $BeosztasKezelo->getTeruletreBeosztottakListajaID();

         $usersArr = array();
         foreach($csoportok->jelentkezokLista as $jelentkezo)
         {
            array_push($usersArr,$jelentkezo->felhasznalo_id);
         }
         foreach($csoportok->beosztottakListaja as $jelentkezo)
         {
            array_push($usersArr,$jelentkezo->felhasznalo_id);
         }
         foreach($csoportok->jokerJelentkezoLista as $jelentkezo)
         {
            array_push($usersArr,$jelentkezo->felhasznalo_id);
         }

         $model = $csoportok;
         $users = User::whereIn('id',$usersArr)->get(['id','name']);

         $model->UsersFreeTimes = $BeosztasKezelo->Calendar($usersArr);

         $csoportok->breadcrumb ='<li class="breadcrumb-item"><a href="'.url('onkentes/beosztasaim/aktiv/vezeto').'">Beosztásaim</a></li>
         <li  class="breadcrumb-item">'.$rendezvenyNeve[0].'</li>
         <li class="breadcrumb-item" ><a href="'.url('teruletvezeto/beosztasom_reszletei/v1_8_0/'.$terulet[0]->id).'">'.$terulet[0]->nev.'</a></li>
         <li class="breadcrumb-item active" aria-current="page">A terület beosztása</li>';

         $model = $csoportok;

         $users = User::whereIn('id',$usersArr)->get(['id','name']);

         return view('/onkentes/beosztas/teruletekbeosztasa')->with('model',$model)->with('users',$users)->
         with('CsoportosJelentkezok',$BeosztasKezelo->GetCsoportosJelentkezok()??null)->
         with('JeligeLista', $BeosztasKezelo->getExistGroups());
    }

    /**
     * Felépíti a csoportszerkeszts bladet
     * @param int Csoport azonosito
     */
    public function CsoportSzerkesztesOnkentOldalrol(Request $request,int $id)
    {
        $user = auth()->user();
        $model = null;

        
        try{
            $model = new Csoport($user['id'],$id);
        }
        catch(Exception $e)
        {
            return back()->withErrors('Hiba a lekérdezésben: a ProgramCsoport létrehozása nem sikerült!','megjelenes_hiba');
        }


        try{
            $model->csoport = ProgramCsoport::find($id);
        }
        catch(Exception $e)
        {
            return back()->withErrors('Hiba a lekérdezésben: a ProgramCsoport létrehozása nem sikerült!','megjelenes_hiba');
        }
        
        $model->profilpic = DB_OMR_Operations::GetProfilkep($user['id']);
        $model->igenyeltOnkentesLetszam = $model->csoport->igenyelt_onkentes_letszam;
        $terulet = Terulet::where('id','=',$model->csoport->terulet_id)->first();
        $esemeny = Esemeny::where('id','=',$terulet->esemeny_id)->first();
       // $model->helyszin = DB::table('helyszin')->where('id',$model->csoport->helyszin_id)->first()->Neve;
        //dd($model->helyszin);

        $urlPrevious = url()->previous();
        //use Illuminate\Support\Str;
        $isCsopVez = \Illuminate\Support\Str::is('*csoportvezeto*',$urlPrevious);

        if($isCsopVez)
        {
            $model->breadcrumb = '
            <li  class="breadcrumb-item">'.$esemeny->nev.'</li>
            <li class="breadcrumb-item" ><a href="'.route('csopvezeto.teruletekcsoportok',['id' => $terulet->id]).'">'.$terulet->nev.'</a></li>
            <li class="breadcrumb-item active" aria-current="page">'.$model->csoport->nev.'</li>';
        }
        else
        {
            $model->breadcrumb = '<li class="breadcrumb-item"><a href="'.url('teruletvezeto/beosztasom_reszletei/v1_8_0/'.$terulet->id).'">Területeim</a></li>
            <li  class="breadcrumb-item">'.$esemeny->nev.'</li>
            <li class="breadcrumb-item" ><a href="'.url('onkentes/beosztas/teruletbeosztas/'.$terulet->id).'">'.$terulet->nev.'</a></li>
            <li class="breadcrumb-item active" aria-current="page">'.$model->csoport->nev.'</li>';
        }

        $kezdes = explode(" ",$terulet->kezdesIdopont);
        $vege = explode(" ",$terulet->befejezesIdopont);
        

        $TeruletData = [
            "id" => $terulet->id,
            "kezdesDatuma" => $kezdes[0],
            "kezdesOra" => $this->Ora($kezdes[1]),
            "kezdesPerc" => $this->Perc($kezdes[1]),
            "befejezesDatuma" => $vege[0],
            "befejezesOra" => $this->Ora($vege[1]),
            "befejezesPerc" => $this->Perc($vege[1]),
           
        ];

        return view('onkentes/szerkesztes/csoportszerkesztes')->with('model',$model)->with('terulet',$TeruletData);
        //return back()->with('model',$model)->with('terulet',$TeruletData);
    }


    /**
     * Feldogzza, frissiti a csoport a csoportszerkesztes bladeből
     * @param int CsoportAzonosito csoport->id
     * @param URL
     */
    public function Csoport_szerkesztese_feldolgozo(Request $request,$id)
    {

        $helyszinID = 0;
        $user = auth()->user();
        try{
            $helyszinID = AlHelyszin::where('nev',$request->cshelyszin1)->first()->id;
            
        }
        catch(Exception $e)
        {
            return back()->withErrors('Hiba a módosítás során: nem létező csoport helyszín.','alhelyszinhiba');
        }
        $d = Carbon::now();
        $user = auth()->user();
        try{
            DB::table('csoport')->where('id', $id)->update([

                "nev" => $request->csoportNeve,
                "leiras" => $request->csoportLeiras,
                "kezdesDatuma" => $request->cskezdIdejeDatum,
                "kezdesIdeje" => $request->cskezdIdejeOra.':'.$request->cskezdIdejePerc,
                "befejezesDatuma" => $request->csbefIdejeDatum,
                "befejezesIdeje" =>  $request->csbefIdejeOra.':'.$request->csbefIdejePerc,
                "igenyelt_onkentes_letszam" => $request->cstervLetszam,
                "helyszin_id" => $helyszinID,
                "modosito" => $user["id"],
                "updated_at" => $d
            ]);
        }
        catch(Exception $e)
        {
            return back()->withErrors("Sikertelen mentés! Hiba az update folyamatban.",'mentes_hiba');
        }
        

        return back()->withErrors("Sikeres mentés",'mentes');
    }


    public function CsoportBeosztas(Request $request,$teruletid,$csoportid)
    {
        $user = auth()->user();
        $model = new AdminCsopBeosztasViewModel($user["id"]);
        $model->profilpic = DB_OMR_Operations::GetProfilkep($user['id']);

        $userviews = new OnkentesViews();
        $userviews->slug = $_SERVER['REQUEST_URI'];
        $userviews->visitTimes = Carbon::now();
        $userviews->felhasznalo_id = $user['id'];
        $userviews->save();

        $model->csoportID = $csoportid;

        $model->teruletID = $teruletid;
        $esemenyID = Terulet::find($teruletid)->esemeny_id;
        $BeosztasKezelo = new BeosztasKezeloRepo($user,intval($esemenyID),intval($teruletid),$csoportid);
        $model->jelentkezokLista = $BeosztasKezelo->GetCsoportba_NEM_Beosztottak();


        //$model->EsemenySzervezok = DB::table('users')->join('esemeny_szervezok','users.id','=','esemeny_szervezok.felhasznalo_id')->select('users.*')->where('esemeny_szervezok.szint_id','=',3)->get();
        $csoportVezetok = DB::table('users')->join('felhasznalo_feladat','felhasznalo_feladat.felhasznalo_id','=','users.id')->join('esemeny_szervezok','users.id','=','esemeny_szervezok.felhasznalo_id')->where('esemeny_szervezok.szint_id','=',5)->get();
        //dd($csoportVezetok);
        if(isset($csoportVezetok))
        {
            $model->CsoportVezetok = $csoportVezetok;
        }


        $csoportTagok = DB::table('felhasznalo_feladat')->join('users','users.id','=','felhasznalo_feladat.felhasznalo_id')->where('csoport_id','=',$csoportid)->get();

        //dd($csoportTagok);
        if(isset($csoportTagok))
        {
            $model->CsoportTagok = $csoportTagok;
        }

        $model->BeosztottakSzama = $BeosztasKezelo->getCsoportAktualisBeosztottakSzama();
        $model->TervezettCsoportLetszam = $BeosztasKezelo->getCsoportLetszam();

        $usersArr = array();
        if(isset($model->jelentkezokLista))
        {
            foreach($model->jelentkezokLista as $jelentkezo)
            {
               array_push($usersArr,$jelentkezo);
            }
            foreach($BeosztasKezelo->GetCsoportBeosztas() as $jelentkezo)
            {
               array_push($usersArr,$jelentkezo->felhasznalo_id);
            }
            $users = User::whereIn('id',$usersArr)->get(['id','name']);
        }

         $terulet  = Terulet::where('id',$model->teruletID)->first();
         $esemeny = Esemeny::where('id','=',$terulet->esemeny_id)->first();
        $csoport = ProgramCsoport::where('id',$csoportid)->first();

        $csoportvezeto = false;
        $urlPrevious = url()->previous();
        //use Illuminate\Support\Str;
        $isCsopVez = \Illuminate\Support\Str::is('*csoportvezeto*',$urlPrevious);
        
        if($isCsopVez)
        {
            $model->breadcrumb ='
            <li  class="breadcrumb-item">'.$esemeny->nev.'</li>
            <li class="breadcrumb-item" ><a href="'.route("csopvezeto.teruletekcsoportok",['id' => $model->teruletID]).'">'.$terulet->nev.'</a></li>
            <li class="breadcrumb-item active" aria-current="page">A csoport beosztása: '.$csoport->nev.'</li>';
   
        }
        else
        {
            $model->breadcrumb ='
            <li  class="breadcrumb-item">'.$esemeny->nev.'</li>
            <li class="breadcrumb-item" ><a href="'.url('teruletvezeto/beosztasom_reszletei/v1_8_0/'.$model->teruletID).'">'.$terulet->nev.'</a></li>
            <li class="breadcrumb-item" ><a href="'.url('onkentes/CsoportBeosztas/'.$model->teruletID.'/'.$model->csoportID).'">'.$csoport->nev.'</a></li>
            <li class="breadcrumb-item active" aria-current="page">A csoport beosztása</li>';
   
        }


      
        return view('onkentes/beosztas/beosztasok_jogszerint/csoportbeosztas')->with('model',$model)->
        with('csoportBeosztottakID',$BeosztasKezelo->GetCsoportBeosztas())->with('users',$users)->
        with('CsoportosJelentkezok',$BeosztasKezelo->GetCsoportosJelentkezok()??null)->
        with('JeligeLista', $BeosztasKezelo->getExistGroups());
    }

    public function CsoportVezetokBeosztas(Request $request,$teruletid,$csoportid)
    {

        $user = auth()->user();
        $model = new AdminCsopBeosztasViewModel($user["id"]);
        $model->profilpic = DB_OMR_Operations::GetProfilkep($user['id']);
        $userviews = new OnkentesViews();
        $userviews->slug = $_SERVER['REQUEST_URI'];
        $userviews->visitTimes = Carbon::now();
        $userviews->felhasznalo_id = $user['id'];
        $userviews->save();

         $model->csoportID = $csoportid;

         $model->teruletID = $teruletid;
         //$model->adminLista = DB::table('users')->join('jogosultsag',"users.id",'=','jogosultsag.felhasznalo_id')->select('users.*')->where('jogosultsag.felhasznaloszint_id','=',1)->get();
         //mar nem kell, mert csak csoport beosztott lehet vezető. sok kavarodast okozott a felhasznaloknal a funkció kezelése....

         $esemenyID = DB::table('terulet')->where('id','=',$model->teruletID)->select('esemeny_id')->get()->first()->esemeny_id;
         $model->esemeny_id = $esemenyID;
         $BeosztasKezelo = new BeosztasKezeloRepo($user,intval($esemenyID),intval($teruletid),$model->csoportID);


         $model->jelentkezokLista =  $BeosztasKezelo->GetCsoportBeosztas();

         //dd( $csoportok->GetJelentkezokTeljes()[0]->name);
         $model->EsemenySzervezok = DB::table('users')->join('esemeny_szervezok','users.id','=','esemeny_szervezok.felhasznalo_id')->select('users.*')->where('esemeny_szervezok.szint_id','=',3)->get();
         $csoportVezetok = DB::table('users')->join('felhasznalo_feladat','felhasznalo_feladat.felhasznalo_id','=','users.id')->join('esemeny_szervezok','users.id','=','esemeny_szervezok.felhasznalo_id')->where('esemeny_szervezok.szint_id','=',5)->get();
         //dd($csoportVezetok);
         if(isset($csoportVezetok))
         {
             $model->CsoportVezetok = $csoportVezetok;
         }


         $csoportTagok = DB::table('felhasznalo_feladat')->join('users','users.id','=','felhasznalo_feladat.felhasznalo_id')->where('csoport_id','=',$model->csoportID)->get();


         if(isset($csoportTagok))
         {
             $model->CsoportTagok = $csoportTagok;
         }

         $terulet  = Terulet::where('id','=',$model->teruletID)->first();

         $esemeny = Esemeny::where('id',$terulet->esemeny_id)->first();
         $csoport = ProgramCsoport::where('id',$csoportid)->first();



         $model->breadcrumb ='
         <li  class="breadcrumb-item">'.$esemeny->nev.'</li>
         <li class="breadcrumb-item" ><a href="'.url(str_replace(url('/'), '', url()->previous())).'">'.$terulet->nev.'</a></li>
         <li class="breadcrumb-item" ><a href="'.url('onkentes/CsoportBeosztas/'.$model->teruletID.'/'.$model->csoportID).'">A "'.$csoport->nev.'" beosztása</a></li>
         <li class="breadcrumb-item active" aria-current="page">A csoportvezető(k) beosztása</li>';

        return view('/onkentes/beosztas/beosztasok_jogszerint/csoportvezetok_beosztasa')->with('model',$model);

    }

    private function getCsoportVezetokLekerdezese(int $cs_id)
    {
        return DB::table('users')->join('esemeny_szervezok','users.id','=','esemeny_szervezok.felhasznalo_id')->
                join('terulet','esemeny_szervezok.terulet_id','=','terulet.id')->
                join('csoport','esemeny_szervezok.csoport_id','=','csoport.id')
                ->where('esemeny_szervezok.szint_id','=',5)->
                where('esemeny_szervezok.csoport_id',$cs_id)->
                select('users.name')->get();
    }

    public function UjCsoportLetrehozasa(Request $request)
    {
        $user = auth()->user();

        $esemenyID = $request->input('esemenyi');
        
        $kezdesDatuma = $request->input('kezdIdoEvCs')."-".$request->input('kezdIdoHoCs')."-".$request->input('kezdIdoNapCs'); 
        $befejezesDatuma = $request->input('befIdoEvCs')."-".$request->input('befIdoHoCs')."-".$request->input('befIdoNapCs');

        $kezdesIdeje = $request->input('cskezdIdejeOra').":".$request->input('cskezdIdejePerc').":00";
        $befejezesIdeje = $request->input('csbefIdejeOra').":".$request->input('csbefIdejePerc').":00";
        $csNev = $request->input('csoportNeve');
        $csLeiras = $request->input('csoportLeiras');
        $csTerulet = $request->input('csTerulet');
        $cstervLetszam = $request->input('cstervLetszam');
        $helyszinNev = $request->input('cshelyszin1');
        
        $helyszinID = null;

        try
        {
            $helyszinID = DB::table('alhelyszin')->where('nev',$helyszinNev)->first()->id; //alhelyszin lett : version 2.0
        }
        catch(Exception $e)
        {
           return back()->withErrors('Sikertelen csoport létrehozás. Hiba: nem létező alhelyszín.','nemletezoelhelyszin');
        }
       
        $csoport = new ProgramCsoport;
        $csoport->nev =  $csNev;
        $csoport->kezdesDatuma =  $kezdesDatuma;
        $csoport->kezdesIdeje =  $kezdesIdeje;
        $csoport->befejezesDatuma =  $befejezesDatuma;
        $csoport->befejezesIdeje =  $befejezesIdeje;
        $csoport->igenyelt_onkentes_letszam =  $cstervLetszam;
        $csoport->helyszin_id = $helyszinID;
        $csoport->leiras =  $csLeiras;
        $csoport->terulet_id =  $csTerulet;
        $csoport->letrehozo =  $user['id'];
        $csoport->save();

        $Helyszinek = null; //???? nemeelég egy helyszin???
       // DB_OMR_Operations::InsertCsoport($csNev,$kezdesDatuma,$kezdesIdeje,$befejezesDatuma,$befejezesIdeje,1,$cstervLetszam,$csLeiras,$csTerulet);

        return back();
    }


    /**
     * csopivezeto
     */
    public function CsoportvezetokIndex(Request $request,int $esemenyid, int $csid)
    {
        $user = auth()->user();
        $model = new EsemenySzerkesztoViewModel($user['id']);
        $Esemeny = DB_OMR_Operations::GetEsemenyForId($esemenyid);
       

        $model->esemenyID = $esemenyid;
        $model->esemenyNeve = $Esemeny->nev;
        $model->kezdesDatuma = $Esemeny->kezdesDatum;
        $model->kezdesIdeje = $Esemeny->kezdesIdeje;
        $model->befejezesDatuma = $Esemeny->befejezesDatum;
        $model->befejezesIdeje = $Esemeny->befejezesIdeje;
        $model->Leiras = $Esemeny->Leiras;

        if ($Esemeny->toborzas == 1)
        {
            $model->Toborzas = 'checked';
        }
        else
        {
            $model->Toborzas = null;
        }

        $esemenyhelyszin = DB_OMR_Operations::GetEsemenyTelepules($esemenyid);
        $model->helyszin = array();

        foreach ($esemenyhelyszin as $helyszin)
        {
            //dd($helyszin);
            $Helyszinek = new \App\Http\Models\AdminEsemenyTelepulesViewModel();

            $telepules = DB::table('helyszin')->where('id','=',$helyszin->telepules_id)->get();

            $Helyszinek->Telepulesnev = isset($telepules[0]->Neve)?$telepules[0]->Neve:'-';
           // dd($telepules[0]->Cim);
            $Helyszinek->cim = $telepules&&isset($telepules[0]->Cim)?$telepules[0]->Cim:'-';;
            $Helyszinek->id = $helyszin->es_id;

            array_push($model->helyszin, $Helyszinek);
        }

        $model->Statusz = DB_OMR_Operations::EsemenyStatuszOptionsHTML($Esemeny->statusz_id);
        $model->adminLista = DB::table('users')->join('jogosultsag',"users.id",'=','jogosultsag.felhasznalo_id')->select('users.*')->where('jogosultsag.felhasznaloszint_id','=',1)->get();


        $model->EsemenySzervezok = DB::table('users')->join('esemeny_szervezok','users.id','=','esemeny_szervezok.felhasznalo_id')->select('users.*')->where('esemeny_szervezok.szint_id','=',3)->get();
        DB::table('users')->join('esemeny_szervezok','users.id','=','esemeny_szervezok.felhasznalo_id')->select('users.*')->where('esemeny_szervezok.szint_id','=',3)->count();

        $csoportvezetok = DB_OMR_Operations::getCsoportVezetokListajaEsemenySzerintOsszes($model->esemenyID);
        $teruletvezetok = DB_OMR_Operations::getTeruletVezetokListajaEsemenySzerintOsszes($model->esemenyID);
       
        $e_sz = EsemenySzervezok::where('felhasznalo_id',$user['id'])->where('csoport_id', $csid)->first();
       
        $model->teruletek = Terulet::where('id',$e_sz->terulet_id)->get();

        $beosztasKezelo = new BeosztasKezeloRepo(null,$esemenyid);
        $model->BeosztottakSzama = $beosztasKezelo->GetBeosztottakSzama(true);
        $model->NemBeosztottakSzama = $beosztasKezelo->getNemBeosztottak(true);


        
        /**
         * @version 1.1.0 Csak azok vannak a listaban akik adminok
         */

        return view("onkentes.csoportvezetok.esemenyindex")->with('model',$model)->
        with('csoportvezetok',$csoportvezetok)->with('teruletvezetok',$teruletvezetok);
    }


    /**Csopi vezeto */
    public function TeruletCsoportokCsopVezeto(int $teruletid,int $csid)
    {
        $user = auth()->user();
        /**
         * NAPLOZAS
         */
         $userviews = new UserAdminsViews;
         $userviews->slug = $_SERVER['REQUEST_URI'];
         $userviews->visitTimes = Carbon::now();
         $userviews->felhasznalo_id = $user['id'];
         $userviews->save();
 
        $csoportok = new KoordinatorTeruletCsoportViewModel($user['id']);
        $csoportok->csoport = ProgramCsoport::find($csid);
      
        $csoportok->profilpic = DB_OMR_Operations::GetProfilkep($user['id']);
 
         $terulet = Terulet::find($teruletid);
         $beosztaskezelo = new BeosztasKezeloRepo($user,$terulet->esemeny_id,$teruletid);
 
 
        $terulet = DB::table('terulet')->where('id','=',$teruletid)->get();
 
        $csoportok->teruletneve = $terulet[0]->nev;
         $csoportok->teruletKezdesIdopont = $terulet[0]->kezdesIdopont;
         $csoportok->teruletBefejezesIdopont = $terulet[0]->befejezesIdopont;
 
        $esemeny =   DB::table('esemeny')->where('id','=',$terulet[0]->esemeny_id)->get();
        $csoportok->rendezvenyNeve =  $esemeny[0]->nev;
        $csoportok->rendezvenyKezdesDatuma = $esemeny[0]->kezdesDatum;
        $csoportok->rendezvenyBefejezesDatuma = $esemeny[0]->befejezesDatum;
        $csoportok->teruletid =  $terulet[0]->id;
        $csoportok->esemeny_id =  $terulet[0]->esemeny_id;
 
         $jelentkezokSzama = $beosztaskezelo->getIdTeruletJelentkezokListaja();
         $jokerJelentkezokSzama = $beosztaskezelo->getJokerJelentkezoIDk();
         $csoportok->jelentkezokSzama = count($jelentkezokSzama) + count($jokerJelentkezokSzama);
 
         $csoportok->tervezettLetszam = $terulet[0]->tervezettLetszam;
         $csoportok->TeruletAktiv =  $terulet[0]->teruletAktiv;
         $csoportok->teruletLeiras = $terulet[0]->leiras;
         $TeruletHelyszineID  = DB::table('terulet')->where('id','=',$csoportok->teruletid )->select('teruletHelyszineID')->get();
 
         $helyszin = DB::table('helyszin')->where('id','=', $TeruletHelyszineID[0]->teruletHelyszineID )->get();
 
         $csoportok->helyszin = $helyszin[0]->Neve;
         $csoportok->cim = $helyszin[0]->Cim;
         
 
         $csoportok->jelentkezokLista =  DB::table('users')->join('felhasznalo_feladat',"users.id",'=','felhasznalo_feladat.felhasznalo_id')->select('users.*')->where('felhasznalo_feladat.terulet_id','=',$teruletid)->get();
 
 
         $csoportok->TeruletVezetok = $beosztaskezelo->getTeruletVezetokListaja();
 
         $csoportok->CsoportVezetok = $beosztaskezelo->getCsoportVezetokListaja();
 
 
         $model = $csoportok;
         return view("onkentes.csoportvezetok.csoportok")->with('model',$model);
    }

    /**
     * POST XHR method
     * A Jelentkezeseim pont alatt, ellenorzi, hogy hova lett beosztva es kijelzi sargaval
     */
    public function getXhrModosithatoJelentkezes()
    {

        $user = auth()->user();

        if($user['id'] > 1000)
        {
            try 
            {
                $today = Carbon::today()->toDateString();
                $jelentkezeseim = DB::table('felhasznalo_feladat')->join('esemeny','felhasznalo_feladat.esemeny_id','=','esemeny.id')->
                leftJoin('csoport',function($join){
                    $join->on('felhasznalo_feladat.csoport_id','=','csoport.id');
                })->
                join('terulet','terulet.id','=','felhasznalo_feladat.terulet_id','inner')->
                where('felhasznalo_feladat.terulet_id','>',0)->where('felhasznalo_feladat.felhasznalo_id','=',$user['id'])
                ->groupBy('terulet_id')->
                select('felhasznalo_feladat.jelentkezesID','felhasznalo_feladat.csoport_id','felhasznalo_feladat.terulet_id','felhasznalo_feladat.esemeny_id',
                'terulet.teruletAktiv as teruletAktiv','terulet.nev as teruletnev','esemeny.nev as esemenynev','esemeny.kezdesDatum','terulet.tervezettLetszam'
                )->get();

                
               
               $result = array();
              foreach($jelentkezeseim as $jelentkezes)
              {
                    $values = [];
                    //$beosztasSzam = $this->beosztottTeruletSzamok($jelentkezes->terulet_id);
                    $values['j_id'] = (int)$jelentkezes->jelentkezesID;
                    $values['terulet_id'] = (int)$jelentkezes->terulet_id;
                    $values['tervezettLetszam'] = (int)$jelentkezes->tervezettLetszam;
                    $values['beosztottakSzama'] = $this->beosztottTeruletSzamok($jelentkezes->terulet_id);
                    $values['teruletAktiv'] = (int)$jelentkezes->teruletAktiv;
                    $values['beosztva'] = $this->isBeosztva((int)$jelentkezes->terulet_id,$user['id']);
                    $values['user'] = $user['id'];
                    array_push($result,$values);
              }

                return json_encode($result);
            }
            catch(Exception $e)
            {
                return json_encode('hiba',200);
            }
            
        }
        else 
        {
            return 'Error: 503';
        }

        
    }

    protected function beosztottTeruletSzamok(int $TeruletID) : int
    {
        try{
            return TeruletBeosztas::where('terulet_id',$TeruletID)->get()->count('terulet_id');
        }
        catch(Exception $e)
        {
            return 0;
        }
        
    }

    /**Teruletre */
    protected function isBeosztva(int $TeruletID,int $FelhasznaloID) : bool
    {
        try{
            $res = TeruletBeosztas::where('terulet_id',$TeruletID)->
            where('felhasznalo_id',$FelhasznaloID)->
            get()->count('felhasznalo_id');

            if($res > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
                
        }
        catch(Exception $e)
        {
            return false;
        }
    }


    /**
     * Csoportba
     */
 protected function isBeosztvaCsoportba(int $TeruletID,int $FelhasznaloID) 
    {
        try{
            $res = FelhasznaloFeladat::where('terulet_id',$TeruletID)->
            where('felhasznalo_id',$FelhasznaloID)->where('csoport_id','>',1)->
            get();

            return $res;
                
        }
        catch(Exception $e)
        {
            return false;
        }
    }

    protected function Ora($ido)
    {
        $ora = null;

        if(isset($ido))
        {
                $pieces = explode(":", $ido);
                $ora = $pieces[0];
        }

        return $ora;
    }

    protected function Perc($ido)
    {
        $perc = null;

        if(isset($ido))
        {
                $pieces = explode(":", $ido);
                $perc = $pieces[1];
        }

        return $perc;
    }

   protected function isBeosztasKereso($array, $item) : bool
   {
       $result = false;
        foreach($array as $arrayItem)
        {
            if($arrayItem->terulet_id == $item->terulet_id
            && $arrayItem->csoportnev == null 
            && $item->csoportnev == null 
            )
            {
                $result = true;
            }

            if($arrayItem->terulet_id == $item->terulet_id
            && $arrayItem->csoportnev != null 
            && $item->csoportnev == null 
            )
            {
                $result = true;
            }

            
        }
        return $result;
   }

}

