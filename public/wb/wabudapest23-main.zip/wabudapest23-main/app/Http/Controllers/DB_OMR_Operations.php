<?php
namespace App\Http\Controllers;

use App\EsemenySzervezok;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Carbon;
use App\Http\Models\Vezeto;
use App\Http\Models\Csoport;
use  App\Http\Models\Terulet;
use  App\Http\Models\TeruletCsoportokkal;
use App\Http\Models\esemenyek_onkenteseknek_reszleteiViewModel;
use Exception;
use App\Munkahely;
use App\FelhasznaloInfo;
use App\Fosuli;
use App\Iskola;
use Illuminate\Support\Facades\Auth;
Use App\Model\Felhasznalo;
use App\OnkentesSzabadidopontok;
use App\Esemeny;
use App\FelhasznaloFeladat;
use App\EsemenyTelepules; use App\Helyszin;
use App\AllandoLakcim; use App\TartozkodasiLakcim;

class DB_OMR_Operations
{

    public static function InsertUjUsers($fullName, $email, $email_verified_at,$password, $created_at,$updated_at,$username, $parent_id)
    {
        $last_index_id = DB::table('users')->insertGetId(
            ['name' => $fullName, 'email' =>  $email, 'email_verified_at' => $email_verified_at, 'password' => $password,'created_at' => $created_at,
            'updated_at' => $updated_at, 'username' => $username,'parent_id' => $parent_id ]);
        return  $last_index_id;
    }

    /**
     * @return users Visszater egy user adataival a user táblából [asszoc. tömb]
     */
    public static function GetUser($id)
    {
        $select = "SELECT * from users where id = ".$id;
        $User = null;
        $eredmeny = DB::select($select);
        $User['id'] = $id;
        foreach($eredmeny as $user)
        {
            $User['name'] = $user->name;
            $User['email'] = $user->email;
            $User['email_verified_at'] = $user->email_verified_at;
            $User['password'] = $user->password;
            $User['created_at'] = $user->created_at;
            $User['updated_at'] = $user->updated_at;
            $User['username'] = $user->username;
            $User['parent_id'] = $user->parent_id;
        }
        unset($eredmeny);
        return $User;
    }

    public static function UpdateFelhasznalok($id,$vnev = null,$knev = null,$kozepsonev,$neme,$email = null,$szulIdo,$szulhely_ID,$orszag_id,$lakcim = null,$telszam,$kor)
    {
        $select = "select count(id) from felhasznalok where id =  ".$id;
        $eredmeny = collect(DB::select($select))->first(); $res = 0;
        foreach($eredmeny as $i)
        {
            $res = $i;
        }

        if($res == 0)
        {
            $insert = "INSERT into felhasznalok values(".$id.",'".$vnev."','".$knev."',".$neme.",'".$neme."','".$szulIdo."',".$szulhely_ID.",".$orszag_id.",'".$lakcim."',".$kor.");";
           // print($insert); die();
            DB::insert($insert);
        }
        else{

            $searchString   = '-';
            $pos = strpos($szulIdo, $searchString);
            //dd($pos);
            if($pos == false)
            {
                $pieces = explode("/", $szulIdo); $newdatetime = $pieces[0]."-".$pieces[1]."-".$pieces[2];

            }
            else $newdatetime = $szulIdo;



           $update = "UPDATE felhasznalok SET vezeteknev = '".$vnev."',keresztnev = '".$knev."',kozepsonev = '".$kozepsonev."' ,neme = ".$neme.",szulIdo = '".$newdatetime."', szulhely_ID = '".$szulhely_ID."',orszag_id = '".$orszag_id."', telefonszam = '".$telszam."', kor = ".$kor."  where id = ".$id;
            //dd($update);
            DB::update($update);

        }
    }

    public static function UpdateFelhasznaloInfok($felhasznalo_id,$tevekenyseg_id,$polomeret,$fogyatekossag,$fogyLeirasa)
    {

            $info = FelhasznaloInfo::where('felhasznalo_id',$felhasznalo_id)->first();

            $info->tevekenyseg_id = $tevekenyseg_id;
            $info->polomeret = $polomeret;
            $info->fogyatekossag = $fogyatekossag;
            $info->fogyLeirasa = $fogyLeirasa;
           // $info->polotipus = -1;
            //dd($info);
            $info->save();


    }

    public static function UpdateFelhasznaloInfokPolotipussal($felhasznalo_id,$tevekenyseg_id,$polomeret,$fogyatekossag,$fogyLeirasa,$polotipus)
    {

            $info = FelhasznaloInfo::where('felhasznalo_id',$felhasznalo_id)->first();

            $info->tevekenyseg_id = $tevekenyseg_id;
            $info->polomeret = $polomeret;
            $info->fogyatekossag = $fogyatekossag;
            $info->fogyLeirasa = $fogyLeirasa;
            $info->polotipus = $polotipus;
            //dd($info);
            $info->save();


    }

    public static function UpdateTartozkodasiLakcim($felhasznaloid,$irszam,$TelepulesID,$orszagID,$cim,$megyeID)
    {
        $select = "select count(felhasznaloid) from tartozkodasilakcim where felhasznaloid =  ".$felhasznaloid;
        $eredmeny = collect(DB::select($select))->first(); $res = 0;
        foreach($eredmeny as $i)
        {
            $res = $i;
        }
        if($res == 0)
        {
            $insert = "INSERT into tartozkodasilakcim values(".$felhasznaloid.",'".$irszam."','".$TelepulesID."',1,'".$cim."',".$megyeID.");";
           // print($insert); die();
            DB::insert($insert);
        }
        else{
            $tartlakcim = TartozkodasiLakcim::find($felhasznaloid);
            $tartlakcim->IranyitoSzam = $irszam;
            $tartlakcim->TelepulesID = $TelepulesID;
            $tartlakcim->OrszagID = $orszagID;
            $tartlakcim->Cim = $cim;
            $tartlakcim->megyeID = $megyeID;
            $tartlakcim->save();
            //$update = "UPDATE tartozkodasilakcim SET IranyitoSzam = '".$irszam."', TelepulesID = '".$TelepulesID."',OrszagID ='".$orszagID."',Cim = '".$cim."',megyeID = ".$megyeID."  where felhasznaloid = ".$felhasznaloid;
            //DB::update($update);
        }
    }

    public static function GetTartozkodasiLakcim($UserId)
    {
        $select = "SELECT * from tartozkodasilakcim where felhasznaloid = ".$UserId;
        $eredmeny = collect(DB::select($select))->first();
        return $eredmeny;
    }

    public static function UpdateAllandoLakcim($felhasznaloid,$irszam,$Telepules,$orszag,$cim,$megyeID)
    {
        $select = "select count(felhasznaloid) from allandolakcim where felhasznaloid =  ".$felhasznaloid;
        $eredmeny = collect(DB::select($select))->first(); $res = 0;
        foreach($eredmeny as $i)
        {
            $res = $i;
        }
        if($res == 0)
        {
            $insert = "INSERT into allandolakcim values(".$felhasznaloid.",'".$irszam."','".$Telepules."','".$orszag."','".$cim."',".$megyeID.");";
           // print($insert); die();
            DB::insert($insert);
        }
        else{
            $allandolakcim = AllandoLakcim::find($felhasznaloid);
            $allandolakcim->IranyitoSzam = $irszam;
            $allandolakcim->Telepules = $Telepules;
            $allandolakcim->Orszag = $orszag;
            $allandolakcim->Cim = $cim;
            $allandolakcim->megyeID = $megyeID;
            $allandolakcim->save();
            
        }
    }

    public static function GetAllandoLakcim($felhasznalo_id)
    {
        $eredmeny = collect(DB::select("SELECT * from allandolakcim where felhasznaloid = ".$felhasznalo_id))->first();
        return $eredmeny;
    }






    public static function InsertNyelv($felhasznaloID, $nyelv,$nyelvszint_id)
    {
        $insert = "INSERT into nyelvismeret values (".$felhasznaloID.",'".$nyelv."',".$nyelvszint_id.");";
        DB::insert($insert);
    }

    public static function UpdateNyelv($felhasznaloID, $nyelv,$nyelvszint_id,$sorrend)
    {
        if($nyelvszint_id != 1 || $nyelvszint_id != 2 || $nyelvszint_id != 3)
        {
            $nyelvszint_id = 1;
        }

        $update ="UPDATE nyelvismeret SET nyelv='".$nyelv."', nyelvszint_id = '".$nyelvszint_id."' WHERE felhasznalo_id = ".$felhasznaloID." AND  sorrend = ".$sorrend;
        DB::update($update);
    }

    public static function DeleteNyelv($felhasznaloID, $nyelv,$nyelvszint_id,$sorrend)
    {
        $delete = "DELETE FROM nyelvismeret where felhasznalo_id = ".$felhasznaloID." AND nyelv = '".$nyelv."' AND sorrend = ".$sorrend;
        DB::delete($delete);

    }




    public static function InsertDatable($id)
    {
        $insert = "";
        DB::insert("INSERT INTO `felhasznalok` (`id`, `vezeteknev`, `keresztnev`, `neme`, `email`, `szulIdo`, `szulhely_ID`, `orszag_id`, `lakcim`, `telefonszam`, `szulhely`,`profilkep`,`kor`) VALUES (".$id.", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '','blank-profile-pic-omr.png',1);");
/*
        $insert = "";
        DB::insert("INSERT INTO `felhasznaloinfo` (`felhasznaloinfoid`, `felhasznalo_id`, `tevekenyseg_id`, `polomeret`, `fogyatekossag`,`fogyLeirasa`,`polotipus`,`created_at`,`updated_at`) VALUES ('".$id."', '".$id."', NULL, NULL, NULL,NULL,-1,".Carbon::now().",".Carbon::now().");");*/
        $felhInfo = new FelhasznaloInfo;
        $felhInfo->felhasznalo_id = $id;
        $felhInfo->tevekenyseg_id = null;
        $felhInfo->polomeret = null;
        $felhInfo->fogyatekossag = null;
        $felhInfo->fogyLeirasa = null;
        $felhInfo->polotipus = -1;
        $felhInfo->etkezesIgenyEgyebLeiras = null;
        $felhInfo->etkezesIgenyID = null;
        $felhInfo->igazolasIgenyID = null;
        $felhInfo->igazolasEgyeb = null;
        $felhInfo->save();

        $insert = "INSERT INTO `nyelvismeret` (`nyelv_id`, `felhasznalo_id`, `nyelv`, `nyelvszint_id`, `sorrend`) VALUES (NULL, ".$id.", NULL, NULL, '1');";
        DB::insert($insert);

        $insert = "INSERT INTO `nyelvismeret` (`nyelv_id`, `felhasznalo_id`, `nyelv`, `nyelvszint_id`, `sorrend`) VALUES (NULL, ".$id.", NULL, NULL, '2');";
        DB::insert($insert);

        $insert = "INSERT INTO `nyelvismeret` (`nyelv_id`, `felhasznalo_id`, `nyelv`, `nyelvszint_id`, `sorrend`) VALUES (NULL, ".$id.", NULL, NULL, '3');";
        DB::insert($insert);

        $insert = "INSERT INTO `allandolakcim` (`felhasznaloid`, `IranyitoSzam`, `Telepules`, `Orszag`, `Cim`, `megyeID`) VALUES ('".$id."', NULL, NULL, NULL, NULL, 0)";
        DB::insert($insert);

        $insert = "INSERT INTO `tartozkodasilakcim` (`felhasznaloid`, `IranyitoSzam`, `TelepulesID`, `OrszagID`, `Cim`, `megyeID`) VALUES ('".$id."', NULL, NULL, NULL, NULL, ' ');";
        DB::insert($insert);

        $insert = "INSERT INTO `egyeb_szervezet` VALUES (NULL,NULL, ".$id.");";
        DB::insert($insert);

        $insert = "INSERT INTO `civil_szervezet` VALUES (NULL,NULL, ".$id.");";
        DB::insert($insert);

        $naptar = new OnkentesSzabadidopontok();
        $naptar->felhasznalo_id = $id;
        $naptar->foglalas_json = '{"y2020":{"Szeptember":{"szabad":["Empty","5-10to15-20","Empty","2-3to11-12","Empty","1-3to12-17","7-10to22-20","Empty","6-10to10-30","4-13to15-19","Empty","Empty","1-17to10-20","Empty","2-5to15-18","Empty","Empty","3-6to7-16","Empty","Empty","Empty","Empty","08-00to15-00","10-00to14-00","Empty","Empty","10-00to18-00","Empty","Empty","2-2to17-20"]},"Oktober":{"szabad":["Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty"]},"November":{"szabad":["Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty"]},"December":{"szabad":["Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty"]}}}';
        $naptar->save();
    }

    public static function InsertTesztUsers($fullname, $email)
    {

        $id = DB::table('users')->insertGetId([
            'name' => $fullname,
            'email' => $email,
            'email_verified_at' => Carbon::now(),
            'password' => '$2y$10$K/x//YEoOLnt3ObjTPBQVehQ0bgdHFV37pYz2Rx9AGmzZCUhQE5M2', //Teszt123
            'created_at' => Carbon::now(),
            'updated_at' => Carbon::now(),
            'blocked' => 0,
            'modifier' => -1
        ]);
        $insert = "";
        DB::insert("INSERT INTO `felhasznalok` (`id`, `vezeteknev`, `keresztnev`, `neme`, `email`, `szulIdo`, `szulhely_ID`, `orszag_id`, `lakcim`, `telefonszam`, `szulhely`,`profilkep`,`kor`) VALUES (".$id.", NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '','blank-profile-pic-omr.png',1);");

        $insert = "";
        DB::insert("INSERT INTO `felhasznaloinfo` (`felhasznaloinfoid`, `felhasznalo_id`, `tevekenyseg_id`, `polomeret`, `fogyatekossag`,`fogyLeirasa`) VALUES ('NULL', '".$id."', NULL, NULL, NULL,NULL);");



        $insert = "INSERT INTO `nyelvismeret` (`nyelv_id`, `felhasznalo_id`, `nyelv`, `nyelvszint_id`, `sorrend`) VALUES (NULL, ".$id.", NULL, NULL, '1');";
        DB::insert($insert);

        $insert = "INSERT INTO `nyelvismeret` (`nyelv_id`, `felhasznalo_id`, `nyelv`, `nyelvszint_id`, `sorrend`) VALUES (NULL, ".$id.", NULL, NULL, '2');";
        DB::insert($insert);

        $insert = "INSERT INTO `nyelvismeret` (`nyelv_id`, `felhasznalo_id`, `nyelv`, `nyelvszint_id`, `sorrend`) VALUES (NULL, ".$id.", NULL, NULL, '3');";
        DB::insert($insert);

        $insert = "INSERT INTO `allandolakcim` (`felhasznaloid`, `IranyitoSzam`, `Telepules`, `Orszag`, `Cim`, `megyeID`) VALUES ('".$id."', NULL, NULL, NULL, NULL, 0)";
        DB::insert($insert);

        $insert = "INSERT INTO `tartozkodasilakcim` (`felhasznaloid`, `IranyitoSzam`, `TelepulesID`, `OrszagID`, `Cim`, `megyeID`) VALUES ('".$id."', NULL, NULL, NULL, NULL, ' ');";
        DB::insert($insert);

        $insert = "INSERT INTO `egyeb_szervezet` VALUES (NULL,NULL, ".$id.");";
        DB::insert($insert);

        $insert = "INSERT INTO `civil_szervezet` VALUES (NULL,NULL, ".$id.");";
        DB::insert($insert);

        DB::table('ruhaatado_atvetel')->insert(['felhasznalo_id' => $id,'polotipus' => 2]);

        DB::table('jogosultsag')->insert([
            'felhasznalo_id' => $id,
            'felhasznaloszint_id' => 2,
            'utolsomodositas_ideje' => Carbon::now(),
            'elozo_felh_szint' => 2,
            'modosito_felh_id' => 0
        ]);

        $naptar = new OnkentesSzabadidopontok();
        $naptar->felhasznalo_id = $id;
        $naptar->foglalas_json = '{"y2020":{"Szeptember":{"szabad":["Empty","5-10to15-20","Empty","2-3to11-12","Empty","1-3to12-17","7-10to22-20","Empty","6-10to10-30","4-13to15-19","Empty","Empty","1-17to10-20","Empty","2-5to15-18","Empty","Empty","3-6to7-16","Empty","Empty","Empty","Empty","08-00to15-00","10-00to14-00","Empty","Empty","10-00to18-00","Empty","Empty","2-2to17-20"]},"Oktober":{"szabad":["Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty"]},"November":{"szabad":["Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty"]},"December":{"szabad":["Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty"]}}}';
        $naptar->save();
    }

    /**
     * 
     * 
     * @version 1.1
     *  A nyelveket bovitettem, hogy 5 legyen!
     */
    public static function InsertDatableEmail($id, $email)
    {
        //$insert = "";
        //DB::insert("INSERT INTO `felhasznalok` (`id`, `email`, `vezeteknev`, `keresztnev`, `neme`, `szulIdo`, `szulhely_ID`, `orszag_id`, `lakcim`, `telefonszam`, `szulhely`,`profilkep`,`kor`) VALUES (".$id.", '".$email."', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', '','blank-profile-pic-omr.png',1);");

        /*
        $insert = "";
        DB::insert("INSERT INTO `felhasznaloinfo` (`felhasznaloinfoid`, `felhasznalo_id`, `tevekenyseg_id`, `polomeret`, `fogyatekossag`,`fogyLeirasa`,`polotipus`,`created_at`,`updated_at`) VALUES ('".$id."', '".$id."', NULL, NULL, NULL,NULL,-1,".Carbon::now().",".Carbon::now().");");*/
        $felhInfo = new FelhasznaloInfo;
        $felhInfo->felhasznalo_id = $id;
        $felhInfo->tevekenyseg_id = null;
        $felhInfo->polomeret = null;
        $felhInfo->fogyatekossag = null;
        $felhInfo->fogyLeirasa = null;
        $felhInfo->polotipus = -1;
        $felhInfo->etkezesIgenyEgyebLeiras = null;
        $felhInfo->etkezesIgenyID = null;
        $felhInfo->igazolasIgenyID = null;
        $felhInfo->igazolasEgyeb = null;
        $felhInfo->save();

        $insert = "INSERT INTO `nyelvismeret` (`nyelv_id`, `felhasznalo_id`, `nyelv`, `nyelvszint_id`, `sorrend`) VALUES (NULL, ".$id.", NULL, NULL, '1');";
        DB::insert($insert);

        $insert = "INSERT INTO `nyelvismeret` (`nyelv_id`, `felhasznalo_id`, `nyelv`, `nyelvszint_id`, `sorrend`) VALUES (NULL, ".$id.", NULL, NULL, '2');";
        DB::insert($insert);

        $insert = "INSERT INTO `nyelvismeret` (`nyelv_id`, `felhasznalo_id`, `nyelv`, `nyelvszint_id`, `sorrend`) VALUES (NULL, ".$id.", NULL, NULL, '3');";
        DB::insert($insert);

        $insert = "INSERT INTO `nyelvismeret` (`nyelv_id`, `felhasznalo_id`, `nyelv`, `nyelvszint_id`, `sorrend`) VALUES (NULL, ".$id.", NULL, NULL, '4');";
        DB::insert($insert);

        $insert = "INSERT INTO `nyelvismeret` (`nyelv_id`, `felhasznalo_id`, `nyelv`, `nyelvszint_id`, `sorrend`) VALUES (NULL, ".$id.", NULL, NULL, '5');";
        DB::insert($insert);

        $insert = "INSERT INTO `allandolakcim` (`felhasznaloid`, `IranyitoSzam`, `Telepules`, `Orszag`, `Cim`, `megyeID`) VALUES ('".$id."', NULL, NULL, NULL, NULL, 0)";
        DB::insert($insert);

        $insert = "INSERT INTO `tartozkodasilakcim` (`felhasznaloid`, `IranyitoSzam`, `TelepulesID`, `OrszagID`, `Cim`, `megyeID`) VALUES ('".$id."', NULL, NULL, NULL, NULL, ' ');";
        DB::insert($insert);

        $insert = "INSERT INTO `egyeb_szervezet` VALUES (NULL,NULL, ".$id.");";
        DB::insert($insert);

        $insert = "INSERT INTO `civil_szervezet` VALUES (NULL,NULL, ".$id.");";
        DB::insert($insert);

        DB::table('ruhaatado_atvetel')->insert(['felhasznalo_id' => $id,'polotipus' => 2]);

        $naptar = new OnkentesSzabadidopontok();
        $naptar->felhasznalo_id = $id;
        $naptar->foglalas_json = '{"y2021": {"August": {"szabad": ["Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty"]}, "December ": {"szabad ": ["Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty"]}, "November ": {"szabad ": ["Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty"]}, "September": {"szabad": ["Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty", "Empty"]}}}';
        $naptar->save();
    }

    /**
     * Vissza adja egy felhasznalo profilkepet
     * @param int Felhasznalo azonosito
     * @return string Kép neve [név.formatum]
     */
    public static function GetProfilkep($UserId)
    {
        $profilkep = null;
        try{
            $select = "select profilkep from felhasznalok where id =  ".$UserId;
            $eredmeny = collect(DB::select($select))->first();
            $profilkep =  $eredmeny->profilkep;
            return $profilkep;
        }
        catch(Exception $e)
        {
            $profilkep = 'blank-profile-pic-omr.png';
        }
        finally{
            return $profilkep;
        }
       

       
    }

    public static function UpdateProfilkep($UserId,$ProfilkepNeve)
    {
        $update = "UPDATE felhasznalok set profilkep = '".$ProfilkepNeve."', kepvalidalas = 3 where id = ".$UserId;
        DB::update($update);
    }

    /**
     * Lekérdező függvények
     */

    public static function GetTelepules($telepulesID)
    {
        $select = "select nev from telepules where id =  ".$telepulesID;
        $eredmeny = collect(DB::select($select))->first();

        return $eredmeny->nev;
    }

    public static function GetOrszag($orszagID)
    {

        $select = "select huNev from orszag where id =  ".$orszagID;
        //dd($select);
        $eredmeny = collect(DB::select($select))->first();

        return $eredmeny->huNev;
    }

    public static function GetOrszagNoCollect($orszagID)
    {

        $select = "select huNev from orszag where id =  ".$orszagID;
        //dd($select);
        $eredmeny = DB::select($select);


        if(isset($eredmeny))
        {
                return "";
        }
        else
        {  return $eredmeny->huNev;}


    }


    public static function GetFelhasznalo($id)
    {
        $select = "SELECT * from felhasznalok where id =  ".$id;
        $eredmeny = DB::select($select);
        $data = null;
        foreach($eredmeny as $item)
        {
            $data["vezeteknev"] = $item->vezeteknev;
            $data["keresztnev"] = $item->keresztnev;
            $data["kozepsonev"] = $item->kozepsonev;
            $data["neme_id"] = $item->neme;
            $data["email"] = $item->email;
            $data["szulIdo"] = $item->szulIdo;
            $data["szulhely"] = $item->szulhely_ID;
            $data["orszag"] = $item->orszag_id;
           $data["telefonszam"] = $item->telefonszam;
           $data["kor"] = $item->kor;
        }
        unset($eredmeny);
        return $data;
    }

    public static function GetFelhasznaloByEmail($email)
    {
        $select = "SELECT * from felhasznalok where email =  ".$email;
        $eredmeny = DB::select($select);
        $data = null;
        foreach($eredmeny as $item)
        {
            $data["vezeteknev"] = $item->vezeteknev;
            $data["keresztnev"] = $item->keresztnev;
            $data["kozepsonev"] = $item->kozepsonev;
            $data["neme_id"] = $item->neme;
            $data["email"] = $item->email;
            $data["szulIdo"] = $item->szulIdo;
            $data["szulhely"] = $item->szulhely_ID;
            $data["orszag"] = $item->orszag_id;
           $data["telefonszam"] = $item->telefonszam;
           $data["kor"] = $item->kor;
        }
        unset($eredmeny);
        return $data;
    }


/** EXPORT */

    public static function GetFelhasznalo2($id)
    {
        $select = "SELECT * from felhasznalok where id = ".$id;
        $eredmeny = DB::select($select);

        $data = null;
        foreach($eredmeny as $item)
        {
            $data["id"] = $item->id;
            $data["vezeteknev"] = $item->vezeteknev;
            $data["keresztnev"] = $item->keresztnev;
            $data["kozepsonev"] = $item->kozepsonev;
            $data["neme_id"] = $item->neme;
            $data["email"] = $item->email;
            $data["szulIdo"] = $item->szulIdo;
            $data["szulhely"] = $item->szulhely_ID;
            $data["orszag"] = $item->orszag_id;
           $data["telefonszam"] = $item->telefonszam;
           $data["kor"] = $item->kor;
        }

        return $data;
    }

    public static function GetUsers()
    {
        $select = "SELECT * from users";
        $eredmeny = DB::select($select);

        return $eredmeny;
    }



/**EXPORT */


    public static function GetFelhasznaloinfo($id)
    {
        $eredmeny = FelhasznaloInfo::where('felhasznalo_id',$id)->get();
        $data = null;
        foreach($eredmeny as $item)
        {
            $data["felhasznalo_id"] = $id;
            $data["tevekenyseg_id"] = $item->tevekenyseg_id;
            $data["tevekenyseg"] = self::GetTevekenyseg($item->tevekenyseg_id);
            $data["polomeret"] = $item->polomeret;
            $data["fogyatekossag_id"] = $item->fogyatekossag;
            $data["fogyLeirasa"] = $item->fogyLeirasa;
            $data["etkezesIgenyID"] = $item->etkezesIgenyID;
            $data["etkezesIgenyEgyebLeiras"] = $item->etkezesIgenyEgyebLeiras;
            $data["igazolasIgenyID"] = $item->igazolasIgenyID;
            $data["igazolasEgyeb"] = $item->igazolasEgyeb;

            if($data["fogyatekossag_id"] == 0)
            {
                $data["fogyatekossag"] = "Nem";
            }
            else
            {
                $data["fogyatekossag"] = "Igen";
            }

            $data["polotipus"] = $item->polotipus;
        }
        unset($eredmeny);
       // dd($data);
        return $data;
    }

    public static function GetTevekenyseg($tevekenysegID)
    {

        if($tevekenysegID != 0)
        {
            $select = "select tevekenyseg from tevekenyseg where id =  ".$tevekenysegID;
            $eredmeny = collect(DB::select($select))->first();

            return $eredmeny->tevekenyseg;
        }
        else return 0;





    }

    public static function GetKor($UserID)
    {

        $select = "SELECT * from felhasznalok where felhasznalo_id = ".$UserID;
        $eredmeny = collect(DB::select($select))->first();

        return $eredmeny->kor;
    }

    /**
     * Egy listaval ter vissza
     * @return Collect Nyelvek
     */
    public static function GetNyelvek($felhasznalo_id)
    {
        $select = "SELECT * from nyelvismeret where felhasznalo_id = ".$felhasznalo_id;
        $eredmeny = collect(DB::select($select));

        return $eredmeny;
    }

    //telepules

    public static function GetTelepulesID($TelepulesNev)
    {
        $select = "SELECT id FROM telepules WHERE nev = '".$TelepulesNev."'";
        $eredmeny = collect(DB::select($select))->first();

        return $eredmeny->id;
    }

    public static function GetTelepulesID_ToIrszam($IrSzam)
    {
        $select = "SELECT id FROM telepules WHERE irszam = '".$IrSzam."'";
        $eredmeny = collect(DB::select($select))->first();

        return $eredmeny->id;
    }

    public static function GetTelepules_ToIrszamFull($IrSzam)
    {
        $select = "SELECT * FROM telepules WHERE irszam = '".$IrSzam."'";
        $eredmeny = collect(DB::select($select));

        return $eredmeny;
    }

    public static function GetTelepules_JSON()
    {
        $select = "SELECT * FROM telepules";
        $eredmeny = collect(DB::select($select));

        return json_encode($eredmeny);
    }

    public static function GetTelepulesGroupsBy_JSON()
    {
        $Select = "SELECT * FROM `telepules` group by `nev`;";
        $eredmeny = DB::table('telepules')->groupBy('nev')->orderBy('nev','asc')->get();

        return $eredmeny;
    }


    //telepules vege

    //orszag

    /**
     * Visszater a zosszes orszaggal
     */
    public static function GetOrszag_JSON()
    {
        $select = "SELECT * FROM orszag";
        $eredmeny = collect(DB::select($select));

        return json_encode($eredmeny);
    }


    /**
     * Visszater nyelv alapjan az orszagokkal. Pl: Magyar : 1, Angolul : 2
     */
    public static function GetOrszagID_TO_JSON($nyelvID)
    {

        $eredmeny = null;
        switch($nyelvID)
        {
            case 1:
                $select = "SELECT id,huNev FROM orszag";
                $eredmeny = collect(DB::select($select));
            break;
            case 2:
                $select = "SELECT id,enNev FROM orszag";
                $eredmeny = collect(DB::select($select));
            break;
        }

        return json_encode($eredmeny);

    }

    public static function GetOrszagForID($orszag_id)
    {
        $select = "SELECT huNev FROM orszag WHERE id = ".$orszag_id;
        $eredmeny = DB::select($select);
        return $eredmeny;
    }

    public static function GetOrszagForIDAndLang($orszag_id,$nyelvID)
    {
        $eredmeny = null;
        switch($nyelvID)
        {
            case 1:
            $select = "SELECT id,huNev FROM orszag WHERE id = ".$orszag_id;
            $eredmeny = collect(DB::select($select))->first();
            break;
            case 2:
                $select = "SELECT id,enNev FROM orszag where id = ".$orszag_id;
                $eredmeny = collect(DB::select($select))->first();
            break;
        }
        $eredmeny;
    }

    public static function InsertHelyszin($HelyszinNeve,$Cim)
    {
        $insert = "INSERT into helyszin values (null,'".$HelyszinNeve."','".$Cim."');";
        DB::insert($insert);

    }

    public static function GetHelyszin()
    {
        $select = "SELECT * from helyszin";
        $eredmeny = collect(DB::select($select));
        return $eredmeny;
    }


    public static function GetHelyszinEsemenyID(int $EsemenyID)
    {
       $helyszinekID = EsemenyTelepules::where('esemeny_id',$EsemenyID)->get(['telepules_id'])->toArray(); 
       $helyszinek = Helyszin::whereIn('id',$helyszinekID)->get();
       return $helyszinek;
    }

    public static function GetHelyszinPages($page,$limit)
    {
        $offset = 0;$select = null;
        if($page > 1)
        {
            $offset = $offset * $page;
            $select = "SELECT * from helyszin LIMIT  ".$limit." OFFSET ".$offset;
        }
        else
        {
            $select = "SELECT * from helyszin LIMIT ".$limit;
        }

        $eredmeny = DB::select($select);
        return $eredmeny;
    }


    public static function GetHelyszinNev($HelyszinID)
    {
        $select = "SELECT *  from helyszin where id = ".$HelyszinID;
        $eredmeny = collect(DB::select($select));
        //dd($eredmeny);
        return $eredmeny;
    }

    public static function GetHelyszinToJSON()
    {
        $select = "SELECT * from helyszin";
        $eredmeny = collect(DB::select($select));
        return encode_json($eredmeny);
    }

    public static function GetHelyszinIDForName($helyszinNeve)
    {
        $select = "SELECT id from helyszin where Neve = '".$helyszinNeve."';";
        $eredmeny = collect(DB::select($select));
        return $eredmeny;
    }

    public static function GetSelectOnketesNevek($neve)
    {
        $select = "SELECT * from users WHERE name LIKE '%".$neve."%'";
        $eredmeny = DB::select($select);
        return $eredmeny;
    }

public static function GetOnkentesNevekPages($page,$limit, $neve)
    {
        $offset = 0;$select = null;
        if($page > 1)
        {
            $offset = $offset * $page;
            $select = "SELECT * from users WHERE name LIKE '%".$neve."%' LIMIT ".$limit." OFFSET ".$offset;
        }
        else
        {
            $select = "SELECT * from users WHERE name LIKE '%".$neve."%' LIMIT ".$limit;
        }

        $eredmeny = collect(DB::select($select));
        return $eredmeny;
    }


    //*********************           ESEMENYEK               */

    public static function GetEsemenyStatusz()
    {
        $select = "SELECT * from esemenystatusz;";
        $eredmeny = collect(DB::select($select));
        return $eredmeny;
    }

    public static function GetEsemenyStatuszForID($id)
    {
        $select = "SELECT * from esemenystatusz where id = ".$id;
        $eredmeny = collect(DB::select($select))->first();
        return $eredmeny->statusz;
    }


    public static function GetEsemenyStatuszToJSON()
    {
        $select = "SELECT * from esemenystatusz;";
        $eredmeny = collect(DB::select($select));
        return encode_json($eredmeny);
    }

    public static function InsertEsemeny($nev,$kezdesDatum,$kezdesIdeje,$befejezesDatum,$befejezesIdeje,$statusz_id,$toborzas_id,$Leiras,$Email = null,$EsemenyKep)
    {
       // $insert = "INSERT INTO esemeny VALUES (NULL, '".$nev."', '".$kezdesDatum."', '".$kezdesIdeje.":20', '".$befejezesDatum."', '".$befejezesIdeje.":00', '".$statusz_id."', '".$toborzas_id."', '".$Leiras."', '".$HelyszinID."', '".$EsemenyKep."', '".$Email."')";
       // dd($insert);
      //  $ccc = DB::insert($insert);

        $last_index_id = DB::table('esemeny')->insertGetId(
            ['nev' => $nev, 'kezdesDatum' => $kezdesDatum,'kezdesIdeje' => $kezdesIdeje ,'befejezesDatum' => $befejezesDatum ,'befejezesIdeje' => $befejezesIdeje,
            'statusz_id' => $statusz_id, 'toborzas' => $toborzas_id, 'Leiras' =>$Leiras, 'telepules_id' => '109', 'esemeny_profilkep' => $EsemenyKep, 'email' => $Email
            ]);
        return  $last_index_id;
    }

    /**
     * Visszater az Esemény nevével
     */
    public static function GetEsemenyek()
    {
        $select = "SELECT * from esemeny";
        $eredmeny = DB::select($select);
        return $eredmeny;
    }

    /**
     * Visszater az Esemény nevével
     */
    public static function GetEsemenyekFirst15()
    {
        $select = "SELECT * from esemeny limit 15 ";
        $eredmeny = DB::select($select);
        return $eredmeny;
    }

public static function GetEsemenyekPages($page,$limit)
    {
        $offset = 0;$select = null;
        if($page > 1)
        {
            $offset = $offset * $page;
            $select = "SELECT * from esemeny LIMIT  ".$limit." OFFSET ".$offset;
        }
        else
        {
            $select = "SELECT * from esemeny LIMIT ".$limit;
        }

        $eredmeny = collect(DB::select($select));
        return $eredmeny;
    }

    public static function GetEsemenyForId($esemeny_id)
    {
        $select = "SELECT * from esemeny where id = ".$esemeny_id;
        $eredmeny = collect(DB::select($select))->first();
        return $eredmeny;
    }


    /**
     * esemeny torles
     * 
     */
    public static function DeleteEsemeny($EsemenyID)
    {
        $Delete = "DELETE FROM `esemeny` WHERE id = ".$EsemenyID;
        $eredmeny = DB::delete($Delete);
        EsemenySzervezok::where('Esemeny_id',$EsemenyID)->delete();
        FelhasznaloFeladat::where('esemeny_id',$EsemenyID)->delete();
        /**
         * Itt ezt boviteni, a terulet beosztasokat is torolni
         * Az ertesiteskbol is torolni
         * 
         */
        return $eredmeny;
    }

    public static function GetEsemenyTelepules($esemeny_id)
    {
        $select = "SELECT * from esemeny_telepules where esemeny_id = ".$esemeny_id;
        $eredmeny = DB::select($select);
        return $eredmeny;
    }


    public static function InsertEsemenyDok($esemeny_id,$docname,$felhasznaloID, $active)
    {
        $hozzaadva = date("Y-m-d");
        $insert = "INSERT INTO esemeny_dokumentum values(null,".$esemeny_id.",'".$docname."','".$hozzaadva."',".$felhasznaloID.",".$active.");";
        DB::insert($insert);
    }

    public static function InsertEsemenySzervezo($esemenyID,$SzervezoVezetoID)
    {
        DB::insert("INSERT INTO esemeny_szervezok values(".$esemenyID.",".$SzervezoVezetoID.");");
    }

    public static function DeleteEsemenySzervezo($esemenyID,$SzervezoVezetoID)
    {
        DB::delete("DELETE esemeny_szervezok where Esemeny_id = ".$esemenyID." AND SzervezoVezeto_id = ".$SzervezoVezetoID);
    }

    public static function InsertFelhasznaloKepek($felhasznalo_id,$picname)
    {
        $hozzaadva = date("Y-m-d");
        DB::insert("INSERT into felhasznalo_kepek values (null,".$felhasznalo_id.",'".$picname."','".$hozzaadva."'); ");

    }

    public static function DeleteFelhasznaloKepek($felhasznalo_id,$picname)
    {
        DB::delete("DELETE felhasznalo_kepek where felhasznalo_id = ".$felhasznalo_id." AND picname = '".$picname."';");
    }

    public static function InsertTerulet($nev,$leiras,$esemeny_id,$kezdesIdopont = NULL,$befejezesIdopont = NULL,$tervezettLetszam = NULL,$jelentkezokSzama = 0,$teruletHelyszineID,$teruletAktiv = NULL)
    {
        DB::insert("INSERT into terulet values(null,'".$nev."','".$leiras."',".$esemeny_id.",'".$kezdesIdopont."','".$befejezesIdopont."','".$tervezettLetszam."','".$jelentkezokSzama."','".$teruletHelyszineID."','".$teruletAktiv."');");
    }

    public static function GetTeruletek($esemenyID)
    {
        $Select = "SELECT * from terulet where esemeny_id = ".$esemenyID;
        $eredmeny = DB::select($Select);

        return $eredmeny;
    }

    public static function GetTerulet($teruletID)
    {
        $Select = "SELECT * from terulet where id = ".$teruletID;
        $eredmeny = DB::select($Select);

        return $eredmeny;
    }

    public static function DeleteTerulet($nev)
    {
        $delete = "DELETE terulet where nev = '".$nev."'";
        DB::delete($delete);
    }

    public static function DeleteTeruletForID($terulet_id)
    {
        $delete = "DELETE FROM terulet where id = ".$terulet_id;
        $res = DB::delete($delete);
        return $res;
    }


    public static function InsertJogosultsag($felhasznaloID,$felhasznaloSzint)
    {
        $modositas = "Y-m_d H:m:s";
        $insert = "INSERT INTO jogosultsag values (null,".$felhasznaloID.",".$felhasznaloSzint.",'".$modositas."',0,0);";
        DB::insert($insert);

    }

    public static function UpdateJogosultsag($felhasznaloID,$felhasznaloSzint)
    {
        $modositas = "Y-m_d H:m:s";
        $update = "UPDATE jogosultsag SET felhasznaloszint_id = ".$felhasznaloSzint." where felhasznalo_id = ".$felhasznaloID;
        DB::update($update);
    }

    public static function Jogosultsag($felhasznaloID)
    {
        $select = "SELECT felhasznaloszint_id from jogosultsag where felhasznalo_id = ".$felhasznaloID;
        $eredmeny = collect(DB::select("$select"))->first();

        return $eredmeny;
    }

    /**
     * @return bool
     */
    public static function JogosultsagEll($felhasznaloID, $SzuksegesJogszint)
    {
        $select = "SELECT felhasznaloszint_id from jogosultsag where felhasznalo_id = ".$felhasznaloID;
        $eredmeny = collect(DB::select("$select"))->first();

        if($eredmeny == $SzuksegesJogszint)
            return true;
        else
            return false;

    }

    public static function ElerhetoJogosutsagok()
    {
        $select = "SELECT * from jogosultsag;";
        $eredmeny = collect(DB::select($select));
        return $eredmeny;
    }

    public static function FelhasznaloSzintMegnevezese($felhasznaloszint_id)
    {
        $select = "SELECT SzintNeve from felhasznaloszintek where id = ".$felhasznaloszint_id;
        $eredmeny = collect(DB::select($select))->first();
        return $eredmeny->SzintNeve;
    }
//************************************************************************ */
//************************************************************************ */
//************************************************************************ */

//********************Lekerdezesek a Viewokhoz**************************** */

//************************************************************************ */
//************************************************************************ */
//************************************************************************ */

/**
 * Visszaadja a egy Terulet Csoportjait egy tombben
 */
public static function CsoportLista($teruletID)
{
        $select = "SELECT * from csoport where terulet_id = ".$teruletID;
        $eredmeny = DB::select($select);
        $CsoportLista = array();

        foreach($eredmeny as $dbcsoport)
        {
            $csoport = new Csoport(0,$dbcsoport->id);
            $csoport->CsoportNeve = $dbcsoport->nev;
            $csoport->kezdesDatuma = $dbcsoport->kezdesDatuma;
            $csoport->kezdesIdeje = $dbcsoport->kezdesIdeje;
            $csoport->befejezesDatuma = $dbcsoport->befejezesDatuma;
            $csoport->befejezesIdeje = $dbcsoport->befejezesIdeje;

            $csoport->helyszin_id = $dbcsoport->helyszin_id;
          // $csoport->helyszin = self::GetHelyszinNev($csoport->helyszin_id);

            $csoport->igenyeltOnkentesLetszam = $dbcsoport->igenyelt_onkentes_letszam;
            $csoport->JelentkezokSzama = $dbcsoport->jelentkezok_onkentes_letszam;
            $csoport->BeosztottakSzama = count(DB::table('felhasznalo_feladat')->where('csoport_id','=',$dbcsoport->id)->get());
            //dd($csoport->BeosztottakSzama);
            $csoport->Leiras = $dbcsoport->leiras;
            $csoport->terulet_id = $dbcsoport->terulet_id;
            $csoport->teruletNeve = self::GetTerulet($csoport->terulet_id);

            $csoportVezetokSzama = EsemenySzervezok::where('szint_id',5)->where('csoport_id',$dbcsoport->id)->count();

            if($csoportVezetokSzama > 0)
            {
                $csoport->setCsoportVezeto(true); //beallitjuk, h van csoportvezeto, ha nulla, akkor automatikusan false lesz
            }

            array_push($CsoportLista,$csoport);
        }
        unset($eredmeny);
        return $CsoportLista;


        }

        public static function InsertCsoport($CsoportNev,$kezdesDatuma,$kezdesIdeje,$befejezesDatuma,$befejezesIdeje,$helyszin_id,$IgenyeltLetszam,$leiras,$teruletID)
        {
            $Insert = "INSERT INTO csoport values(NULL,'".$CsoportNev."','".$kezdesDatuma."','".$kezdesIdeje."','".$befejezesDatuma."','".$befejezesIdeje."','".$helyszin_id."',".$IgenyeltLetszam.",0,'".$leiras."',".$teruletID.");";
            DB::insert($Insert);
        }

        public static function GetCsoport($teruletID,$igaz)
        {
                if ($igaz)
                {
                    $select = "SELECT * from csoport where terulet_id = ".$teruletID;
                    $eredmeny = DB::select($select);
                    return $eredmeny;
                }
                else
                {
                    $select = "SELECT * from csoport where terulet_id = ".$teruletID;
                    $eredmeny = collect(DB::select($select))->first();
                    return $eredmeny;
                }
        }

    public static function GetFeladatokCsoportSzerint($csoportid)
    {

    }


    /**
     *
     * @return Array<Vezeto> visszater a vezetok listajaval
    */
    public static function VezetokListazasa()
    {
        $select = "SELECT * FROM `felhasznalok` inner join jogosultsag on felhasznalok.id = jogosultsag.felhasznalo_id;";
        $eredmeny = DB::select($select);

        $Vezetok = array();
        foreach($eredmeny as $user)
        {
            $vezeto = new Vezeto();
            $vezeto->id = $user->id;
            $vezeto->Nev = $user->Vezeteknev." ".$user->Keresztnev;
            $vezeto->FelhasznaloSzint = self::FelhasznaloSzintMegnevezese($user->felhasznaloszint_id);
            array_push($vezeto);
        }


        return $Vezetok;
    }



    /**
     * Felepiti az esemenyek_onkenteseknek_reszleteiViewModel-t az esemeny alapjan.
     * @var int Esemeny azonositja
     *
     * @return esemenyek_onkenteseknek_reszleteiModel
     */
    public static function Get_esemenyek_onkenteseknek_reszleteiModel($esemenyID)
    {
        $esemeny = self::GetEsemenyForId($esemenyID);

        //var_dump($esemeny);die();

        $select = "SELECT * from terulet where esemeny_id = ".$esemenyID;
        $eredmeny = DB::select($select);
        $teruletLista = array();

        $esemenyModel = new esemenyek_onkenteseknek_reszleteiViewModel();
        $esemenyModel->esemenyNeve = $esemeny[0]->nev;
        $esemenyModel->kezdesDatuma = $esemeny[0]->kezdesDatum;
        $esemenyModel->kezdesIdeje = $esemeny[0]->kezdesIdeje;
        $esemenyModel->befejezesDatuma = $esemeny[0]->befejezesDatum;
        $esemenyModel->befejezesIdeje = $esemeny[0]->befejezesIdeje;

        $esemenyModel->helyszin = self::GetTelepules($esemeny[0]->telepules_id);


        foreach($eredmeny as $dbterulet)
        {
            $terulet = new Terulet($dbterulet->id);
            $terulet->esemenyID = $dbterulet->esemeny_id;
            $terulet->nev = $dbterulet->nev;
            $terulet->leiras = $dbterulet->leiras;
            array_push($teruletLista,$terulet);

        }

        $esemenyModel->Teruletek = $teruletLista;

        return $esemenyModel;
    }

    /**
     * A terulet bladehez elkeszitjuk a modelt
     */
    public static function Teruletek($esemenyID)
    {
        $select = "SELECT * from terulet where esemeny_id = ".$esemenyID;
        $eredmeny = DB::select($select);
        $teruletLista = array();




    }

    public static function Jelentkezeseim($felhasznaloid)
    {
        $select = "SELECT * from felhasznalo_feladat where felhasznalo_id = ".$felhasznaloid;
        $eredmeny = DB::select($select);
        $esemenyLista = array();
        foreach($eredmeny as $jelentkezes)
        {
            $esemeny = self::GetEsemenyForId($jelentkezes->esemeny_id);
            array_push($esemenyLista,$esemeny);
        }

        //dd($esemenyLista);


        return $esemenyLista;

        //esemeny_neve, kezdes, telepules
    }

    /**
     * Beszurunk egy onkentes a felhasznalo_feladat tablaba. Ez a jelentkezes!
     * Azert kell kotelezoen megadni az esemeny,terulet,csoport adatait is, hogy ne kelljen kerezttáblás lekérdezéseket írni a későbbiekben a riportokhoz
     *
     *@param int,int,int,int Felhasznalo azonosito,Feladat azonositoja,Csoport azonositoja,Terulet azonositojaEsmeny azonositoja (Primary keys)
     *
     *
     */
    public static function  Jelentkezes($felhasznalo_id,$feladat_id,$csoport_id,$terulet_id,$esemeny_id,$date)
    {
        $insert = "INSERT into felhasznalo_feladat values (NULL,".$felhasznalo_id.",".$feladat_id.",".$csoport_id.",".$terulet_id.",".$esemeny_id.",'".$date."');";
        $insertJelentkezo = DB::insert($insert);

       // var_dump($insertJelentkezo);die();

        unset($insert);
    }

    public static function JelentkezesPassio20($felhasznaloID,$magassag,$konfekciomeret,$cipo,$fejkormeret,$szakallnovesztes,$neme,$vallas,$telefonszam)
    {

        $insert = "INSERT into passio2020kerdoiv values (null,".$felhasznaloID.",".$magassag.",'".$konfekciomeret."',".$cipo.",".$fejkormeret.",".$szakallnovesztes.",'".$vallas."',".$neme.",'".$telefonszam."');";
        //dd($insert);
        //"INSERT into passio2020kerdoiv values (1,150,'111',42,12,0,);"
        DB::insert($insert);

    }

    public static function GetJelentkezesPassio($UserId)
    {
        $Select = "SELECT * from passio2020kerdoiv where  felhasznalo_id = ".$UserId;
        $eredmeny = collect(DB::select($Select))->first();

        return $eredmeny;
    }

    public static function GetNyelv1($felhasznalo_id)
    {
        $eredmeny = DB::select('SELECT * from nyelvismeret where felhasznalo_id = '.$felhasznalo_id.' order by nyelv_id desc');

        return $eredmeny;
    }

    public static function KepMentese($UserId,$PicName,$NowDate)
    {
       DB::insert("INSERT INTO felhasznalo_kepek values (NULL,".$UserId.",'$PicName','".$NowDate."'); ");
    }

    public static function GetPolomeret($felhasznalo_id)
    {
        $eredmeny = collect(DB::select('SELECT * from felhasznaloinfo where felhasznalo_id = '.$felhasznalo_id))->first();

        return $eredmeny->polomeret;
    }


    /**
     * TEVEKENYSEGEK
     */

    /**
     *
     */
    public static function InsertTevekenysegEgyetemFosuli($UserId,$IntezmenyNeve,$Szak,$evfolyam)
    {
        Fosuli::updateOrCreate(['felhasznalo_id' => $UserId],
        ['intezmeny_neve' => $IntezmenyNeve, 'szak' => $Szak,
        'evfolyam' => $evfolyam,
        'modosito' => Auth::id()]);

        $info = FelhasznaloInfo::where('felhasznalo_id',$UserId)->first();
        $info->tevekenyseg_id = 1;
        $info->save();
    }

    /**
     *A tevekenyseg id 2 vagy 3 lehet: 2 = kozepiskola, 3 = alt.iskola
     * minden más ertekre hibat dob!
     */
    public static function InsertTevekenysegIskola($UserId,$IntezmenyNeve,$evfolyam,$tevekenysegID)
    {

        if(intval($tevekenysegID) > 3 || intval($tevekenysegID) == 1)
        {
            throw new Exception("A tevekenysegID kizarolag 2 vagy 3 lehet!");
        }

        Iskola::updateOrCreate(['felhasznalo_id' => $UserId],
        ['intezmenyneve' => $IntezmenyNeve,
            'evfolyam' => $evfolyam,
            'modosito' => Auth::id(),
            'tevekenysegID' => $tevekenysegID]);

        $info = FelhasznaloInfo::where('felhasznalo_id',$UserId)->first();
        $info->tevekenyseg_id = $tevekenysegID;
        $info->save();
    }

    public static function InsertTevekenysegMunkahely($UserId,$IntezmenyNeve = NULL,$beosztasa)
    {
        Munkahely::updateOrCreate(['felhasznalo_id' => $UserId],
            ['intezmenyneve' => $IntezmenyNeve, 'beosztasa' => $beosztasa,'datetime' => Carbon::now()]
        );

        $info = FelhasznaloInfo::where('felhasznalo_id',$UserId)->first();
        $info->tevekenyseg_id = 4;
        $info->save();
    }



    /**
     *
     */
    public static function GetEgyetemFosuli($UserId)
    {
        $select = "SELECT * from fosuli where felhasznalo_id = ".$UserId." order by modositas desc ";
        $eredmeny = DB::select($select);

        return $eredmeny;
    }

    /**
     * Visszatér egy user kozep vagy altalnos iskolajaval.
     *Az iskola tipusat az tevekenysegID határozza meg: 2-es középiskola, 3-as általános iskola
     */
    public static function GetAltIskola($UserId)
    {
        $select = "SELECT * from iskola where felhasznalo_id = ".$UserId." AND tevekenysegID = 3  order by modositas desc ";
        $eredmeny = DB::select($select);

        return $eredmeny;
    }

    public static function GetKozepIskola($UserId)
    {

        $select = "SELECT * from iskola where felhasznalo_id = ".$UserId." AND tevekenysegID = 2  order by modositas desc ";
        $eredmeny = DB::select($select);

        return $eredmeny;
    }

    public static function UpdateIskola($UserId, $intezmeny, $evfolyam, $tevekenysegID)
    {
        $datetime = date("Y-m-d H:m:s");
        $update = "UPDATE iskola SET intezmenyneve = '".$intezmeny."', beosztasa = ".$evfolyam.", tevekenysegID = ".$tevekenysegID.", datetime_i = '".$datetime."'  WHERE felhasznalo_id = ".$UserId;
        DB::update($update);
    }

    /**
     * Visszater egy user munkahelyével
     * ???? EZ MI EZ, miért nincs meg?????
     */
    public static function GetMunkahely($UserId)
    {
        $select = "SELECT * from munkahely where felhasznalo_id = ".$UserId; //" order by modositas desc ";
        $eredmeny = DB::select($select);

        return $eredmeny;
    }

    public static function  GetFotevekenysegId($UserId)
    {
        $select = "SELECT * from felhasznaloinfo where felhasznalo_id = ".$UserId;

        $eredmeny = DB::select($select);
        return $eredmeny;
    }
    public static function  GetFotevekenyseg($TevekenysegID)
    {
        $select = "SELECT * from tevekenyseg where id = ".$TevekenysegID;

        $eredmeny = collect(DB::select($select))->first();
        return $eredmeny->tevekenyseg;
    }


    public static function GetFoTevekenyseg_With_HTML_Output($UserId)
    {
        $select = "SELECT * from felhasznaloinfo where felhasznalo_id = ".$UserId;

        $tevID = collect(DB::select($select))->first();

        $output = null;  //dd($tevID);
        $null = "Nincs megadva";
        //dd($tevID->tevekenyseg_id);
        switch($tevID->tevekenyseg_id)
        {

            case "1":
                $Egyetem = collect(self::GetEgyetemFosuli($UserId))->first();
                $output = '<div class="tevBox"><label>Intézmény neve:</label><input class="form-control" type="text" id="foisk" name="foisk" data-validation="required" value="'.$Egyetem->intezmeny_neve.'"/>
                <label>Szakirány:</label><input class="form-control" type="text" id="szakneve" name="szakneve" data-validation="required" value="'.$Egyetem->szak.'"/>
                <label>Évfolyam:</label><input class="form-control" type="number" id="evfolyam" name="evfolyam" data-validation="required" value="'.$Egyetem->evfolyam.'"/></div>';

            break;

            case "2":
                $Iskola = collect(self::GetKozepIskola($UserId))->first();
                $output = '<p>Jelenlegi iskola: </p><input class="form-control" type="text"   id="kozepisk" name="kozepisk"  value="'.$Iskola->intezmenyneve.'"/>
                <p>Évfolyam: </p><input class="form-control" type="number"  id="kozepiskoszt" name="kozepiskoszt" value="'.$Iskola->evfolyam.'"/>';
            break;

            case "3":
            $Iskola2 = collect(self::GetAltIskola($UserId))->first();
            if(isset($Iskola2))
            {
                $output = '<p>Jelenlegi iskola: </p><input class="form-control" type="text"  id="altisk" name="altisk"  value="'.$Iskola2->intezmenyneve.'"/>
                <p>Évfolyam: </p><input class="form-control" type="number" id="altiskoszt" name="altiskoszt" value="'.$Iskola2->evfolyam.'"/>';

            }

            break;

            case 4:
                $Munka = collect(self::GetMunkahely($UserId))->first();
                if(isset($Munka->intezmenyneve))
                {
                    $output = ' <p>Munkaköre</p><input class="form-control" type="text" id="munkakor" name="munkakor" value="'.$Munka->beosztasa.'"/>';

                }

            break;
        }


        return $output;



    }


    /********************************************************** */


    /************************************************************ */

    /********************** megyek es orszagok  */

    public static function GetSelectmegyek()
    {
        $select = "SELECT * FROM megyek order by case when megye_neve like 'Budapest' then 0 else 1 end, TRIM(megye_neve)";

        $eredmeny = DB::select($select);
        return $eredmeny;
    }

    public static function GetSelectmegyek_id($megye_id)
    {
        if(isset($megye_id))
        {
            $select = "SELECT * FROM megyek WHERE megye_id = ".$megye_id;
            $eredmeny = DB::select($select);
            if(isset($eredmeny))
            { return $eredmeny;}
            else
            {
                return "";
            }
        }
        else
        {
            return "";
        }


    }



    public static function GetSelectorszag()
    {
        $select = "SELECT * FROM orszag order by case when huNev like 'Magyarország' then 0 else 1 end, TRIM(huNev)";
        $eredmeny = DB::select($select);
        return $eredmeny;
    }

    public static function GetSelectorszag_id($id)
    {
        $select = "SELECT * FROM orszag WHERE id = ".$id."";
        $eredmeny = DB::select($select);
        return $eredmeny;
    }

    /*public function dbteszt()
    {
        $value = self::GetOrszagOptionsId_HTML(1);
        dd($value);
        return view('db')->with('model',$value);
    }*/


    //---------------------------------helperek

    public static function GetMegyekOptions_HTML()
    {
        $output = '';
        $megyek = self::GetSelectmegyek();
        foreach($megyek as $megye)
        {
            $html = '<option value="'.$megye->megye_id.'">'.$megye->megye_neve.'</option>';
            $output = $output . $html;
        }
        return $output;
    }

    //megyeid szerint

    public static function GetMegyekOptionsId_HTML($megyeId)
    {
        $output = '';
        $megyek = self::GetSelectmegyek();
        foreach($megyek as $megye)
        {
            if($megye->megye_id == $megyeId)
            {
                $html = '<option value="'.$megye->megye_id.'" Selected="selected">'.$megye->megye_neve.'</option>';
                $output = $output . $html;
            }else
            {
                $html = '<option value="'.$megye->megye_id.'">'.$megye->megye_neve.'</option>';
                $output = $output . $html;
            }

        }
        return $output;
    }
    //országok
    public static function GetOrszagOptions_HTML()
    {
        $output = '';
        $orszagok = self::GetSelectorszag();
        //dd( $orszagok );
        foreach($orszagok as $orszag)
        {
            $html = '<option value="'.$orszag->id.'">'.$orszag->huNev.'</option>';
            $output = $output . $html;
        }
        return $output;
    }

    //országok id szerint
    public static function GetOrszagOptionsId_HTML($orszagId)
    {
        $output = '';
        $orszagok = self::GetSelectorszag();
        foreach($orszagok as $orszag)
        {
            if($orszag->id == $orszagId)
            {
                $html = '<option value="'.$orszag->id.'" Selected="selected">'.$orszag->huNev.'</option>';
                $output = $output . $html;
            }else
            {
                $html = '<option value="'.$orszag->id.'">'.$orszag->huNev.'</option>';
                $output = $output . $html;
            }

        }
        return $output;
    }

    public static function GetAllLakcim_MegyeIDForUser($userid)
    {
        $select = "SELECT * FROM allandolakcim where felhasznaloid = ".$userid;
        $eredmeny = collect(DB::select($select))->first();

        if(isset($eredmeny))
        {
            return $eredmeny->megyeID;
        }
        else
        {
            return "";
        }

    }

    public static function GetTartLakcim_MegyeIDForUser($userid)
    {
        $select = "SELECT * FROM tartozkodasilakcim where felhasznaloid = ".$userid;

        try{
                $eredmeny = collect(DB::select($select))->first();
                if(isset($eredmeny))
                {
                    return $eredmeny->megyeID;
                }
                else
                {
                    return "";
                }
        }
        catch(Exception $e)
        {
            return "";
        }


    }

    public static function GetAllLakcim_OrszagIDForUser($userid)
    {
        $select = "SELECT * FROM allandolakcim where felhasznaloid = ".$userid;
        $eredmeny = collect(DB::select($select))->first();
        return $eredmeny->OrszagID;
    }

    public static function GetTartLakcim_OrszagIDForUser($userid)
    {
        $select = "SELECT * FROM tartozkodasilakcim where felhasznaloid = ".$userid;
        $eredmeny = collect(DB::select($select))->first();
        return $eredmeny->OrszagID;
    }


    public static function UpdateOnkentesMashol($UserId,$SzervezetNeve)
    {
        $update = "UPDATE egyeb_szervezet SET szervezet_neve = '".$SzervezetNeve."'  WHERE felhasznalo_id = ".$UserId;
        DB::update($update);
    }

    public static function UpdateOnkentesCivilSzervezet($UserId,$SzervezetNeve)
    {
        $update = "UPDATE civil_szervezet SET szervezet_neve = '".$SzervezetNeve."'  WHERE felhasznalo_id = ".$UserId;
        DB::update($update);
    }

    public static function InsertEgyebSzervezet($szervezetNeve,$felhasznaloID)
    {
        $insert = "INSERT INTO egyeb_szervezet values (NULL,'".$szervezetNeve."',$felhasznaloID)";
        DB::insert($insert);
    }


    public static function InsertCivilSzervezet($szervezetNeve,$felhasznaloID)
    {
        $insert = "INSERT INTO civil_szervezet values (NULL,'".$szervezetNeve."',$felhasznaloID)";
        DB::insert($insert);
    }

    public static function GetEgyebSzervezet($felhasznaloID)
    {
        $select = "SELECT * from egyeb_szervezet where felhasznalo_id = ".$felhasznaloID;
        $eredmeny = collect(DB::select($select))->first();
        return $eredmeny;
    }

    public static function IsMasSzervezetTagja($felhasznaloID)
    {
        $exist = false;
        $select = "SELECT *,count(sz_id) as letezik  from egyeb_szervezet where felhasznalo_id = ".$felhasznaloID;
        $eredmeny = collect(DB::select($select))->first();

        if($eredmeny->letezik >= 1 && $eredmeny->szervezet_neve != NULL)
        {
            $exist = true;
            if($eredmeny->szervezet_neve == 'NULL'){$exist = null; }
            if($eredmeny->szervezet_neve == 'Nem'){$exist = false; }
        } else $exist = null;
        return $exist;
    }

    public static function IsCivilSzervezetTagja($felhasznaloID)
    {
        $exist = false;
        $select = "SELECT *,count(c_id) as letezik  from civil_szervezet where felhasznalo_id = ".$felhasznaloID;
        $eredmeny = collect(DB::select($select))->first();
        //dd($eredmeny->letezik);
        if($eredmeny->letezik >= 1 && $eredmeny->szervezet_neve != NULL)
        {
            $exist = true;
            if($eredmeny->szervezet_neve == 'NULL'){$exist = null; }
            if($eredmeny->szervezet_neve == 'Nem'){$exist = false; }
        }
        else $exist = null;
        return $exist;
    }

    public static function GetCivilSzervezet($felhasznaloID)
    {
        $select = "SELECT * from civil_szervezet where felhasznalo_id = ".$felhasznaloID;
        $eredmeny = collect(DB::select($select))->first();
        return $eredmeny;
    }

    public static function InsertEsemenyTelepules($esemeny_id,$telepules_id,$cim = null)
    {
        $Insert = "INSERT INTO esemeny_telepules values (NULL,".$esemeny_id.",".$telepules_id.",'".$cim."')";
        DB::insert("$Insert");
    }


    public static function UpdateMunkahely($UserId, $intezmeny, $beosztas)
    {
        $datetime = date("Y-m-d H:m:s");
        $update = "UPDATE munkahely SET intezmenyneve = '".$intezmeny."', beosztasa = '".$beosztas."', datetime = '".$datetime."'  WHERE felhasznalo_id = ".$UserId;
        DB::update($update);
    }

    public static function EsemenyStatuszOptionsHTML($id)
    {
        $statusz = self::GetEsemenyStatusz();

        $HTML = '<select class="custom-select" id="statusz" name="statusz">';

        foreach ($statusz as $stat)
        {
            if ($stat->id == $id)
            {
                $optiontHTML = '<option value="'.$stat->id.'" selected="selected">'.$stat->statusz.'</option>';
            }
            else
            {
                $optiontHTML = '<option value="'.$stat->id.'">'.$stat->statusz.'</option>';
            }
            $HTML = $HTML.''.$optiontHTML;
        }

        $HTML = $HTML.'</select>';

        return $HTML;
    }

    public static function UpdateEsemeny($id, $nev, $statusz, $toborzas, $leriras)
    {
        $update = "UPDATE esemeny SET nev = '".$nev."', statusz_id = ".$statusz.", toborzas = ".$toborzas.", Leiras = '".$leriras."'  WHERE id = ".$id;
        DB::update($update);
    }

    /**
     * egy esemeny csoportjainak vezetőit visszaadja.
     */
    public static function getCsoportVezetokListajaEsemenySzerintOsszes(int $esemenyID)
    {
        $esemenyek = EsemenySzervezok::where('Esemeny_id','=',$esemenyID)->whereNotNull('csoport_id')->
        where('szint_id',5)->groupby('csoport_id')->select('csoport_id')->get()->toArray();

        $result = DB::table('esemeny_szervezok')->join('users','esemeny_szervezok.felhasznalo_id','=','users.id','inner')
        ->join('csoport','csoport.id','=','esemeny_szervezok.csoport_id','inner')
        ->whereIn('esemeny_szervezok.csoport_id',$esemenyek)->
        where('esemeny_szervezok.szint_id','=',5)
        ->select('users.name','csoport.nev')
        ->get('users.name','csoport.nev');

        unset($esemenyek);

        return $result;


    }

    /**
     * csoportid alapjan vissza adja a vezett nevét és a csoportnevét
     */
    public static function getCsoportVezetokListaja(int $csoportID)
    {
        $result = DB::table('esemeny_szervezok')->join('users','esemeny_szervezok.felhasznalo_id','=','users.id','inner')
        ->join('csoport','csoport.id','=','esemeny_szervezok.csoport_id','inner')
        ->where('esemeny_szervezok.csoport_id','=',$csoportID)->
        where('esemeny_szervezok.szint_id','=',5)
        ->select('users.name','csoport.nev')
        ->get();

        return $result;
    }

    public static function getTeruletVezetokListajaEsemenySzerintOsszes(int $esemenyID)
    {
        $esemenyek = EsemenySzervezok::where('Esemeny_id','=',$esemenyID)->whereNotNull('terulet_id')->
        where('szint_id',4)->groupby('terulet_id')->select('terulet_id')->get()->toArray();

        $result = DB::table('esemeny_szervezok')->join('users','esemeny_szervezok.felhasznalo_id','=','users.id','inner')
        ->join('terulet','terulet.id','=','esemeny_szervezok.terulet_id','inner')
        ->whereIn('esemeny_szervezok.terulet_id',$esemenyek)->
        where('esemeny_szervezok.szint_id','=',4)
        ->select('users.name','terulet.nev')
        ->get('users.name','terulet.nev');

        unset($esemenyek);

        return $result;


    }

    public static function  getTeruletiKoordinatorok(int $TeruletId)
    {
        $result = DB::table('esemeny_szervezok')->join('users','esemeny_szervezok.felhasznalo_id','=','users.id','inner')
        ->join('terulet','terulet.id','=','esemeny_szervezok.terulet_id','inner')
        ->where('esemeny_szervezok.terulet','=',$TeruletId)->
        where('esemeny_szervezok.szint_id','=',4)
        ->select('users.name','terulet.nev')
        ->get();

        return $result;
    }

}
