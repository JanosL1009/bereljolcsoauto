<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Model\Felhasznalo;
use App\Users;
use Illuminate\Support\Facades\DB;

class ProfilKepValidalasController extends Controller
{
    public function validalasdashboard()
    {
        $users = DB::table('users')->join('felhasznalok','users.id','=','felhasznalok.id')->where('felhasznalok.profilkep','!=','blank-profile-pic-omr.png')->where('felhasznalok.kepvalidalas','3')->get();
        $count = $users->count();
        $users = DB::table('users')->join('felhasznalok','users.id','=','felhasznalok.id')->where('felhasznalok.profilkep','!=','blank-profile-pic-omr.png')->where('felhasznalok.kepvalidalas','3')->paginate(30);
        
        //$users->paginate(30);
        $ervenyes = Felhasznalo::where('kepvalidalas','1')->get()->count();
        

        return view("adminisztratorok.profilkepvalidalas.kepekvalidalasa")->with('users',$users)->
        with('count',$count)->with('ervenyes',$ervenyes);

    }
}
