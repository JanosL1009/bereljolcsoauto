<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use App\Jogosultsag;
class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function RuhaAtadoJog()
    {
        $user = auth()->user();
        $id = $user['id'];

        $szint = Jogosultsag::where('felhasznalo_id',$id)->where('felhasznaloszint_id',7)->exist();
        
        return $szint;
    }
}
