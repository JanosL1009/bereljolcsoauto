<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Models\ExportViewModel;
use App\Http\Controllers\ObjektumListakLekerdezese;
use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Facades\Excel;
use Maatwebsite\Excel\ExcelServiceProvider;
use Illuminate\Database\Eloquent\Collection;
use Maatwebsite\Excel\Writer;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\LaravelNovaExcel\Actions\DownloadExcel;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Events\BeforeExport;
use Maatwebsite\Excel\Events\AfterSheet;
use Maatwebsite\Excel\Sheet;
use App\Http\Controllers\DB_OMR_Operations;

/**
 * Az excel exporthoz szukseges objektum (Ha cellaegyesitest akarsz hasznalni, akkor implementalni kell a WithEvents interfacet...)
 */
class UserExport implements FromArray, WithHeadings
{
    protected $invoices;
    protected $sheet;

    /**
     *
     */
    protected $headingArray = array();

    public function __construct(array $invoices,array $myHeadings)
    {


        $this->invoices = $invoices;
        $this->headingArray = $myHeadings;
        //$sheet->mergeCells($range);
    }


/* Ha ellaegyestes kell akkor ig hasznald, nem tokeletes....
    public function registerEvents(): array
    {
        return [
            AfterSheet::class => function(AfterSheet $event) {
                // Merge Cells
                $event->sheet->getDelegate()->setMergeCells(['O1:R1']);
                // freeze the pane
               // $event->sheet->getDelegate()->freezePane('A4');
               /* / / Set the cell content centered
                $event->sheet->getDelegate()->getStyle('A1:A2')->getAlignment()->setHorizontal(\PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER);
                / / Define the column width
                $widths = ['A' => 10, 'B' => 15, 'C' => 25,...];
                foreach ($widths as $k => $v) {
                    / / Set the column width
                    $event->sheet->getDelegate()->getColumnDimension($k)->setWidth($v);
                }
                / / Other style requirements (set border, background color, etc.) handle the macro given in the extension, you can also customize the macro to achieve, see the official website for details

            },
        ];
    }
*/

    public function array(): array
    {
        return $this->invoices;
    }

    public function actions(Request $request)
    {
        return [
            new DownloadExcel(),
        ];
    }

    public function headings(): array
    {
        return $this->headingArray;
    }

       /**
        * @param "Fejlec elemit egy tombben kapja meg"
        *  */
    public function SetHeadings($headingArray)
    {

    }

}


/**
 * Az excel export szukseges fuggvenyek
 *
 * */
 class DB_Export
{

    /**
     * Visszater egy csoporthoz tartozo felhasznalok
     */
    public static function GetCsoport($csoportID)
    {

    }


    public static function GetFelhasznalok()
    {

    }


}
