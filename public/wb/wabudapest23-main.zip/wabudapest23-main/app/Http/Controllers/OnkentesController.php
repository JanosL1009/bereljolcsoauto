<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\DB_OMR_Operations;
use App\Http\Models\OnkentesEsemenyekViewModel;
use App\Http\Models\BeallitasokViewModel;
use App\Http\Models\profilszerkesztesViewModel;
use App\Http\Models\FelhasznaloHozzaadasaViewModel;
use App\Http\Models\esemenyek_onkenteseknek_reszleteiViewModel;
use App\Http\Models\OnkentesJelentkezeseimViewModel;
use Illuminate\Http\File;
use Illuminate\Support\Facades\Storage;
use Mail;
use Exception;
use App\User;
use App\Esemeny;
use App\EsemenySzervezok;
use App\FelhasznaloFeladat;
use App\Helyszin;
use App\Http\Controllers\Auth;
use Illuminate\Support\Facades\DB;
use App\Support\Collection;
use App\Http\Controllers\Msg\OmrEmail;
use Illuminate\Validation\Validator;
//use Illuminate\Support\Facades\Validator;
use App\Http\Models\UserDocuments;
use App\Http\Models\Documents;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Hash;
use App\PagesDetails;
use App\OnkentesViews;
use App\OnkentesSzabadidopontok;
use App\MyErrorLog;
use App\Jeligek;
use App\LogFelhasznaloFeladat;
use App\TeruletBeosztas;
use App\LogTeruletBeosztas;

class OnkentesController extends Controller
{
    //
    public function esemenyek_szuro($field=null,$order = null) {

      $documents = UserDocuments::all();
      $alt_documents = Documents::where('visibility_id', 0)->get();


              return view('onkentes/esemenyek', compact('$nev', '$kezdesido'/*, 'fromAdmin'*/));
    }

     public function esemenyek(Request $request,$mode,$field=null,$order = null)
    {
        $user = auth()->user();
        $UserId = $user["id"];
        $UserDatas = User::find($UserId);
        
        $exist = collect(DB::select("select count(id) as usercount from felhasznalok where id = ".$UserId))->first();

        $userviews = new OnkentesViews();
        $userviews->slug = $_SERVER['REQUEST_URI'];
        $userviews->visitTimes = Carbon::now();
        $userviews->felhasznalo_id = $user['id'];
        $userviews->save();

        if($exist->usercount == 0)
        {//ha nem letezik a user(first login, akkor a mezoit letrehozza)
            //$user = auth()->user();
            //$UserId = $user["id"];
           DB_OMR_Operations::InsertDatable($UserId);
        }

        $jelentkezeseim = DB::table('felhasznalo_feladat')->join('esemeny','felhasznalo_feladat.esemeny_id','=','esemeny.id')->join('terulet','felhasznalo_feladat.terulet_id','=','terulet.id')->where('felhasznalo_feladat.felhasznalo_id','=',$UserId )->select('jelentkezesID','esemeny.id','esemeny.nev as esemenyneve','esemeny.kezdesDatum','terulet.nev','terulet.teruletAktiv')->get();
       // dd( $jelentkezeseim );
        $fieldValid = false; $orderValid = false;
         if(isset($field) && isset($order) )
         {
            switch($field)
            {
                 case 'nev':
                     $field = "nev";
                     $fieldValid = true;
                 break;
                 case 'kezdesDatum':
                     $field = "kezdesDatum";  $fieldValid = true;
                 break;

                 default:
                   $fieldValid = true;$field = "nev";
                 break;
             }

             switch($order)
             {
                 case 'asc':
                     $orderValid = true;
                 break;
                 case 'desc':
                     $orderValid = true;
                 break;
                default:
                     $orderValid = true; $order = "desc";
                 break;
            }
        }


        if($mode == 'elerheto')
        {
            $model = new OnkentesEsemenyekViewModel($UserId);
          //$ActUser = User::getJelentkezeseim($UserId);
         
            if($fieldValid && $orderValid)
            {
                $model->esemenyek = DB::table('esemeny')->where('statusz_id', 2)->orderBy($field,$order)->get();
                if(isset($jelentkezeseim))
                {
                    $model->esemenyek = $this->JelentkezesSzuro($model->esemenyek,$jelentkezeseim)->paginate(15);
                   // dd($model->esemenyek);
                }
                else
                {
                    $model->esemenyek = $model->esemenyek->paginate();
                }

            }
            else
            {
                $model->esemenyek = DB::table('esemeny')->where('statusz_id', 2)->get();//majd kesobb ->paginate(15)

                /**
                 * A jelentkezesek alapjan torlom azokat, amikre mar jelenetkezett az onkentes
                 * AKKOR ha van jelentkezese
                 */
                if(isset($jelentkezeseim))
                {
                    $model->esemenyek = $this->JelentkezesSzuro($model->esemenyek,$jelentkezeseim)->paginate(15);
                   // dd($model->esemenyek);
                }
               else
                {
                    $model->esemenyek = DB::table('esemeny')->where('statusz_id', 2)->paginate(15);
                }



            }

            $model->mode = 'elerheto';
            $model->profilpic = DB_OMR_Operations::GetProfilkep($UserId);
           // $jog = DB_OMR_Operations::Jogosultsag($UserId);;
            //$model->jogszint = $jog->falhasznaloszint_id;
           // dd($model->esemenyek);
           $model->api_token = $UserDatas->api_token??0;
            $esemenyek = $model->esemenyek;
            $i = 0;
            foreach($esemenyek as $esemeny)
            {
                $telepules_id = null;
                try{
                    $telepules_id = $esemeny->telepules_id;
                }
                catch(Exception $e)
                {
                    dd($esemenyek[$i],$esemeny,$e);
                }
                $telepules_id = $esemeny->telepules_id;
                $esemeny->telepules_id = DB_OMR_Operations::GetTelepules($telepules_id); //igy a $esemeny->telepules_id-t felulirtuk es a telepules nevet fogja tartalmazni ->
                $esemeny->telepuleslist = $this->getTelepulesek($esemeny->id);
                //a view-ban már igy hasznalhatjuk!
                $i++;
            }

            unset($user);
            $pagesdetails = PagesDetails::find(1);
            $model->setMagyarazoSzovegek("leiras",$pagesdetails->leiras);

           // dd($model->esemenyek);
            return view('onkentes/esemenyek')->with('model',$model);
        }

        if($mode == 'jelentkeztem')
        {
            $user = auth()->user();
            $UserId = $user["id"];
            $model = new OnkentesEsemenyekViewModel($UserId);
            $model->api_token = $UserDatas->api_token;
            //$model->esemenyek = DB_OMR_Operations::Jelentkezeseim($UserId); //print($model->esemenyek[0]->nev);die(); igy hasznald!
            $model->esemenyek = DB::table('felhasznalo_feladat')->join('esemeny','felhasznalo_feladat.esemeny_id','=','esemeny.id')->join('terulet','felhasznalo_feladat.terulet_id','=','terulet.id')->where('felhasznalo_feladat.felhasznalo_id','=',$UserId )->select('jelentkezesID','esemeny.id','esemeny.nev as esemenyneve','esemeny.kezdesDatum','esemeny.befejezesDatum','terulet.nev','terulet.teruletAktiv','terulet.id as terulet_id')->get();
            if($fieldValid && $orderValid)
            {
                $model->esemenyek = DB::table('felhasznalo_feladat')->join('esemeny','felhasznalo_feladat.esemeny_id','=','esemeny.id')->join('terulet','felhasznalo_feladat.terulet_id','=','terulet.id')->where('felhasznalo_feladat.felhasznalo_id','=',$UserId )->select('jelentkezesID','esemeny.id','esemeny.nev as esemenyneve','esemeny.kezdesDatum','esemeny.befejezesDatum','terulet.nev','terulet.teruletAktiv','terulet.id as terulet_id')->orderBy($field,$order)->paginate(15);
            }
            else
            {
                $model->esemenyek = DB::table('felhasznalo_feladat')->join('esemeny','felhasznalo_feladat.esemeny_id','=','esemeny.id')->join('terulet','felhasznalo_feladat.terulet_id','=','terulet.id')->where('felhasznalo_feladat.felhasznalo_id','=',$UserId )->select('jelentkezesID','esemeny.id','esemeny.nev as esemenyneve','esemeny.kezdesDatum','esemeny.befejezesDatum','terulet.nev','terulet.teruletAktiv','terulet.id as terulet_id')->paginate(15);

            }
            $model->mode = 'jelentkeztem';
            $model->profilpic = DB_OMR_Operations::GetProfilkep($UserId);
            $pagesdetails = PagesDetails::find(2);
            $model->setMagyarazoSzovegek("leiras",$pagesdetails->leiras);
           // dd($model->esemenyek);
           // dd(count($model->esemenyek));
            return view('onkentes/esemenyek')->with('model',$model);
        }


    }
    public function getTelepulesek($esemeny_id) {
        $query="select * from esemeny_telepules LEFT JOIN telepules ON (esemeny_telepules.telepules_id=telepules.id) WHERE esemeny_telepules.esemeny_id=".$esemeny_id;
        $data= DB::select(DB::raw($query,array()));
        return $data;
    }

    public function terulet_jelentkezes(Request $request)
    {
        $user = auth()->user();
            $UserId = $user["id"];
        $terulet_id = $request->input('elsoTerulet');
        $esemeny_id = $request->input('esid');

        $masodikTerulet = $request->input('masodikTerulet');
        $harmadikTerulet = $request->input('harmadikTerulet');
        $all = 0;
        if($request->input('other') == 'on')
        {
            $all = 1;
        }

        $jelige = $request->input('jelige');
        $jeligeID = null;
        if(isset($jelige))
        {
            try{
                $jeligeID = Jeligek::where('jeligeNeve',$jelige)->first()->id;
            }
            catch(Exception $e)
            {
                $TaroltJelige = null;
            }
        }

        $jelentkezesIdeje = Carbon::now();
        DB::table('felhasznalo_feladat')->insert(['felhasznalo_id' => $UserId,'feladat_id' => 0, 'csoport_id' => '0','terulet_id' => $terulet_id,'esemeny_id' => $esemeny_id,'priority' => 1,'other' => $all,'jelentkezesIdeje' => $jelentkezesIdeje,'jeligeID' => $jeligeID ]);
        DB::table('felhasznalo_feladat')->insert(['felhasznalo_id' => $UserId,'feladat_id' => 0, 'csoport_id' => '0','terulet_id' => $masodikTerulet,'esemeny_id' => $esemeny_id,'priority' => 2,'other' => $all,'jelentkezesIdeje' => $jelentkezesIdeje,'jeligeID' => $jeligeID ]);

        DB::table('felhasznalo_feladat')->insert(['felhasznalo_id' => $UserId,'feladat_id' => 0, 'csoport_id' => '0','terulet_id' => $harmadikTerulet,'esemeny_id' => $esemeny_id,'priority' => 3,'other' => $all,'jelentkezesIdeje' => $jelentkezesIdeje,'jeligeID' => $jeligeID ]);

        try{
            $esemeny = Esemeny::find($esemeny_id);
            OmrEmail::AlertSuccessProgramAppliedForUser($user["email"],$esemeny);
        } 
        catch(Exception $e)
        {
            return redirect('/esemenyek_onkenteseknek/jelentkeztem');
        }
        

        return redirect('/esemenyek_onkenteseknek/jelentkeztem');
    }

    /**
     * @version 1.1.0 Az idopontjaimat implementálni kellett a teruleti idopontok miatt a calendariumbol.
     *@version 1.0.0 Megjeleníti egy esemeny részleteit
     */
    public function esemenyek_reszletei(Request $request,$esemenyid)
    {
        $user = auth()->user();
        $UserId = $user["id"];
        $model = new esemenyek_onkenteseknek_reszleteiViewModel($UserId);
        $model->profilpic = DB_OMR_Operations::GetProfilkep($UserId);

        $userviews = new OnkentesViews();
        $userviews->slug = $_SERVER['REQUEST_URI'];
        $userviews->visitTimes = Carbon::now();
        $userviews->felhasznalo_id = $user['id'];
        $userviews->save();

        $_helyszinek = DB::table('esemeny_telepules')->where('esemeny_id',$esemenyid)->get();
        $_helyszinek = collect($_helyszinek)->map(function($x){ return (int)$x->telepules_id; })->toArray();
        
        $helyszinek = Helyszin::whereIn('id',$_helyszinek)->get();
        

        $esemeny = DB_OMR_Operations::GetEsemenyForId($esemenyid); //DB::table('esemeny')->where('id', '=' , 1);
        $model->id = $esemenyid;
        $model->esemenyNeve = $esemeny->nev;
        $model->kezdesDatuma = $esemeny->kezdesDatum;
        $model->kezdesIdeje = $esemeny->kezdesIdeje;
        $model->befejezesDatuma = $esemeny->befejezesDatum;
        $model->befejezesIdeje = $esemeny->befejezesIdeje;
        $model->Leiras = $esemeny->Leiras;
        $model->Teruletek = DB::table('terulet')
                                ->where('teruletAktiv', 1)
                                ->where('esemeny_id','=',$esemeny->id)
                                ->get();

        if($esemeny->statusz_id != 2){
            return back();
        }

        /** szint_id = 3 felhasznaloszint szerint */

        $programKoordinatorokArray = EsemenySzervezok::where('Esemeny_id',$esemeny->id)->
        where('szint_id',3)
        ->get(['felhasznalo_id'])->toArray();

        $model->programKoordinatorok = User::whereIn('id',$programKoordinatorokArray)->get();

        $pagesdetails = PagesDetails::find(6);
            $model->setMagyarazoSzovegek("leiras",$pagesdetails->leiras);

        $idopontjaim = null;

        try{
            $idopontjaim = OnkentesSzabadidopontok::where('felhasznalo_id',$UserId)->get('foglalas_json');
        }
        catch(Exception $e)
        {
            $idopontjaim = null;
        }

        //dd($idopontjaim);

        return view('onkentes/esemenyek_reszletei',['idopontjaim' => $idopontjaim])->with('model',$model)->with('helyszinek',$helyszinek);
    }

    public function Jelentkezeseim_reszletei(Request $request,$jelentkezesid=null)
    {
        $user = auth()->user();
        $UserId = $user["id"];
        $model = new OnkentesJelentkezeseimViewModel($UserId);
        $model->profilpic = DB_OMR_Operations::GetProfilkep($UserId);

        $userviews = new OnkentesViews();
        $userviews->slug = $_SERVER['REQUEST_URI'];
        $userviews->visitTimes = Carbon::now();
        $userviews->felhasznalo_id = $user['id'];
        $userviews->save();

        $esemeny = DB_OMR_Operations::GetEsemenyForId($jelentkezesid); //DB::table('esemeny')->where('id', '=' , 1);
        $model->id = $jelentkezesid;
        $model->esemenyNeve = $esemeny->nev;
        $model->kezdesDatuma = $esemeny->kezdesDatum;
        $model->kezdesIdeje = $esemeny->kezdesIdeje;
        $model->befejezesDatuma = $esemeny->befejezesDatum;
        $model->befejezesIdeje = $esemeny->befejezesIdeje;
        $model->Leiras = $esemeny->Leiras;
        $model->Teruletek = DB::table('terulet')->where('esemeny_id','=',$esemeny->id)->get();

        $model->teruletekJelentkezve = DB::table('terulet')->join('felhasznalo_feladat','terulet.id','=','felhasznalo_feladat.terulet_id')->where('felhasznalo_feladat.felhasznalo_id','=',  $UserId)->where('felhasznalo_feladat.esemeny_id','=',$jelentkezesid)->select('terulet.nev')->get();

        $model->rendezvenySzervezo = DB::table('users')->join('esemeny_szervezok','users.id','=','esemeny_szervezok.felhasznalo_id')->where('esemeny_szervezok.Esemeny_id','=',$jelentkezesid)
        ->where('esemeny_szervezok.szint_id','=',3)
        ->get(['users.name','users.email']);

        return view('onkentes/jelentkeztem')->with('model',$model);
    }

    public function kerdoiv_passio_2020()
    {


        return view('onkentes/kerdoiv');
    }


	public function profilomszerkesztese()
    {
        //self::getExport();
        //return view('profil_szerkesztes');
    }

    public function terulet(Request $request,$teruletid)
    {


        return view('onkentes/terulet');
    }

    public static function beallitasok()
    {
        $user = auth()->user();
        $UserId = $user["id"];
        $model = new BeallitasokViewModel($UserId);
        $model->profilpic = DB_OMR_Operations::GetProfilkep($UserId);
        return view('onkentes/beallitasok')->with('model',$model);
    }

    public static function fiok_felfuggesztve()
    {
        $user = auth()->user();
        $UserId = $user["id"];
        DB::update("UPDATE users SET email_verified_at = NULL WHERE id = ".$UserId);

        return view('onkentes/fiok_felfuggesztve');
    }



    public function PassioJelentkezes(Request $request)
    {
        $user = auth()->user();
            $UserId = $user["id"];

        $ferfi = $request->input('ferfi');
        $woman = $request->input('woman');

        $email = $request->input('email');
        $sex = $request->input('userneme');;


        $magassag = $request->input('testmagassag');

        $konfekcio = $request->input('konfekcio');

        $cipomeret = $request->input('cipomeret');
        $fejkormeret = $request->input('fejkormeret');
        $szakallnov = 0;
        if($request->input('szakallnov') == 1 || $request->input('szakallnov') == 'yes')
        {
            $szakallnov = 1;
        }
        $telefonszam = $request->input('telefonszam');

        $vallas = $request->input('vallas');
        //dd($request);
        $user = auth()->user();
        $UserId = $user["id"];
      //  DB_OMR_Operations::JelentkezesPassio20($UserId,$magassag,$konfekcio,$cipomeret,$fejkormeret,$szakallnov,$sex,$vallas,$telefonszam);
       // $request->validatedCustomFile1->storeAs('local');

        $onarckepek = $request->file('file-6');

        $i = 0;
        foreach($onarckepek as $kep)
        {
            $ujFileNev = $UserId."_".date('Y_m_d')."_".$kep->getClientOriginalName();
            $kep->storeAs('images', $ujFileNev);
            DB_OMR_Operations::KepMentese($UserId,$ujFileNev,date('Y_m_d'));
            $i++;
        }
        $i=0;


        $onarckepek = $request->file('file-6');
        foreach($onarckepek as $kep)
        {
            $ujFileNev = $UserId."_0_".date('Y_m_d')."_".$kep->getClientOriginalName();
            $kep->storeAs('images', $ujFileNev);
            DB_OMR_Operations::KepMentese($UserId,$ujFileNev,date('Y_m_d'));
            $i++;
        }

        unset($i);
        //$file->move($destinationPath,$UserId."_".$file->getClientOriginalName());

       /* $request->file('validatedCustomFile1')->storeAs(
            'images', $request->user()->id."_".$file->getClientOriginalName()
        );*/

        DB_OMR_Operations::Jelentkezes($UserId,1,1,1,1,date('Y-m-d H:m:s'));

        Mail::send("onkentes/sikeres_regisztracio",["email" => $email],
                function($message) use ($email) {
                     $message->to($email)
                            ->subject('ÖMR regisztráció')
                           ->bcc(env('MAIL_KOZOS'),'ÖMR')
                            ->from(env('MAIL_FROM_NAME') );

                }
        );
        


        return  view('/onkentes/sikeres_jelentkezes');

    }

    public function felhasznalo_hozzaadasa(Request $request)
    {
        $user = auth()->user();
        $parent_id = $user['id'];
        $parent_email = $user['email'];

        /*$Felhasznalo = DB_OMR_Operations::GetFelhasznalo($id);
        $FelhasznaloInfo = DB_OMR_Operations::GetFelhasznaloinfo($id);*/
        $model = new FelhasznaloHozzaadasaViewModel();
        $model->email =  $parent_email;
       // $model->foteveknyseg_id = $FelhasznaloInfo['tevekenyseg_id'];
        $model->foteveknyseg = self::GetHTMLTevekenysegMaker(0);
        //dd( $model->foteveknyseg );
        $model->polomeret = self::getPolomeret('0');
        $model->fogyatekossag =  0;
        $model->FogyLeirasa = "";
        $nyelvek = DB_OMR_Operations::GetNyelv1(0);

        for($i = 0;$i < count($nyelvek);$i++)
        {
            if($i == 0)
            {
                $model->nyelv1 = $nyelvek[0]->nyelv;
                $model->nyelv1szint = $nyelvek[0]->nyelvszint_id;
            }
            if($i == 1)
            {
                $model->nyelv2 = $nyelvek[1]->nyelv;
                $model->nyelv2szint = $nyelvek[1]->nyelvszint_id;
            }
            if($i == 2)
            {
                $model->nyelv3 = $nyelvek[2]->nyelv;
                $model->nyelv3szint = $nyelvek[2]->nyelvszint_id;
            }

            if($i == 2)
            {
                break;
            }
        }

        $model->nyelv1szint = self::GetNyelvSzintHTML($model->nyelv1szint);
        $model->nyelv2szint = self::GetNyelvSzintHTML($model->nyelv2szint);
        $model->nyelv3szint = self::GetNyelvSzintHTML($model->nyelv3szint);
        $model->all_lakcim_orszag =  DB_OMR_Operations::GetOrszagOptions_HTML();
        $model->tart_lakcim_orszag =  DB_OMR_Operations::GetOrszagOptions_HTML();
        $model->Megye_AllLakcim = DB_OMR_Operations::GetMegyekOptions_HTML();
        $model->Megye_TartLakcim = DB_OMR_Operations::GetMegyekOptions_HTML();

        return view('onkentes/felhasznalo_hozzaadasa')->with('model',$model);
    }
    public function felhasznaloim(Request $request)
    {
        return view('onkentes/csoportom');
    }

    /**
     * Uj felhaszhnalo felvetele egy meglevo fiokbol
     *
     */
    public function egyeb_uj_felhasznalo_hozzaadasa(Request $request)
    {
        /**
         * @var user  A bejelenkezett felhasznalo! Ő hozza letre az uj usert, igy aza adatbazisba a parent_id-b a kerul
         * a $parent_id valtozo erteke!
         */
        $user = auth()->user();
        $parent_id = $user['id'];
        $parent_email = $user['email'];
       // var_dump($request);


        $vezeteknev = $request->input('vezeteknev');
        $kozepsonev = $request->input('kozepsonev');
        $keresztnev = $request->input('keresztnev');
        $usernemeValue = $request->input('userneme');
        $telszam = $request->input('telszam');
        $szulido = $request->input('szulido');
        $nev = $vezeteknev." ".$kozepsonev." ".$keresztnev;
        $ActUser = DB_OMR_Operations::GetUser($parent_id);
        $NewUserID = DB_OMR_Operations::InsertUjUsers($nev,$parent_email,$ActUser['email_verified_at'],$ActUser['password'],$ActUser['email_verified_at'],
        $ActUser['created_at'],$ActUser['updated_at'],$ActUser['username'],$ActUser['parent_id']);




        /**
         * @var int szuletesi idot szamitja ki a PHP/Carbon segitsegevel
         */
        $years = Carbon::parse($szulido)->age;

        $isLakcim = $request->input('isTartLakcim');

        $al_lakcim_orszag = $request->input('al_lakcim_orszag');
            $al_lakcim_telepules = $request->input('al_lakcim_telepules');
            $al_lakcim_irszam = $request->input('al_lakcim_irszam');
            $al_lakcim_utca = $request->input('al_lakcim_utca');
            $al_lakcim_megye = $request->input('al_lakcim_megye');
           // dd($al_lakcim_megye);

            $tart_lakcim_orszag = null;
            $tart_lakcim_telepules = null;
            $tart_lakcim_irszam = null;
            $tart_lakcim_utca = null;
            $tart_lakcim_megye = null;
        //dd($isLakcim);
        if($isLakcim == "TartAzonos")
        {


            $tart_lakcim_orszag = $request->input('al_lakcim_orszag');
            $tart_lakcim_telepules = $request->input('al_lakcim_telepules');
            $tart_lakcim_irszam = $request->input('al_lakcim_irszam');
            $tart_lakcim_utca = $request->input('al_lakcim_utca');
            $tart_lakcim_megye = $request->input('al_lakcim_megye');
           // dd($tart_lakcim_utca);
        }
        else if(!isset($isLakcim))
        {


            $tart_lakcim_orszag = $request->input('tart_lakcim_orszag');
            $tart_lakcim_telepules = $request->input('tart_lakcim_telepules');
            $tart_lakcim_irszam = $request->input('tart_lakcim_irszam');
            $tart_lakcim_utca = $request->input('tart_lakcim_utca');
            $tart_lakcim_megye = $request->input('tart_lakcim_megye');

        }
        else
        {
            //error
        }

       // dd($al_lakcim_orszag);
        $szulhely = $request->input('szulhely');
       // $email = $request->input('');


       // dd($tart_lakcim_telepules);

        $tevekenyseg = $request->input('tevekenyseg');
        $fogyatekossag = $request->input('fogyatekossag');
        $userpolomeret = $request->input('userpolomeret');

        $szakneve = $request->input('szakneve');
        $foiskneve = $request->input('foisk');
        $foiskEvfolyam =  $request->input('evfolyam');
        if(isset($szakneve ) && isset($foiskneve) && isset($foiskEvfolyam))
        {
            DB_OMR_Operations::InsertTevekenysegEgyetemFosuli($NewUserID,$foiskneve,$szakneve,$foiskEvfolyam);
        }


        $munkahelyNeve = $request->input('munkahely');
        $munkakor = $request->input('munkakor');

        if(isset($munkahelyNeve) && isset($munkakor))
        {
            DB_OMR_Operations::InsertTevekenysegMunkahely($NewUserID,$munkahelyNeve,$munkakor);
        }

        $kozepsuliNeve =  $request->input('kozepisk');
        $kozepsuliOsztaly =  $request->input('kozepiskoszt');

        if(isset($kozepsuliNeve) && isset($kozepsuliOsztaly))
        {
            DB_OMR_Operations::InsertTevekenysegIskola($NewUserID,$kozepsuliNeve,$kozepsuliOsztaly,2);
        }

        $altiskNeve =  $request->input('altisk');
        $altiskOsztaly =  $request->input('altiskoszt');

        if(isset($altiskNeve) && isset($altiskOsztaly))
        {
            DB_OMR_Operations::InsertTevekenysegIskola($NewUserID,$altiskNeve,$altiskOsztaly,3);
        }



        $nyelv1 = $request->input('nyelv1');
        $nyelv2 = $request->input('nyelv2');
        $nyelv3 = $request->input('nyelv3');

        if(isset($nyelv1))
        {
            DB_OMR_Operations::UpdateNyelv($NewUserID,$nyelv1,$request->input('nyelv1szint'),1);
        }
        else{
            DB_OMR_Operations::UpdateNyelv($NewUserID,' ',1,1);
        }

        if(isset($nyelv2))
        {
            DB_OMR_Operations::UpdateNyelv($NewUserID,$nyelv2,$request->input('nyelv2szint'),2);
        }
        else{
            DB_OMR_Operations::UpdateNyelv($NewUserID,' ',1,2);
        }

        if(isset($nyelv2))
        {
            DB_OMR_Operations::UpdateNyelv($NewUserID,$nyelv3,$request->input('nyelv3szint'),3);
        }
        else{
            DB_OMR_Operations::UpdateNyelv($NewUserID,' ',1,3);
        }


        $masSzervezetTagja = $request->input('masSzervezetTagja');
        //dd($masSzervezetTagja);
        if($masSzervezetTagja == "1")
        {
            $szervezetNeve = $request->input('egyebSzervezet');
            //dd($szervezetNeve);
            DB_OMR_Operations::UpdateOnkentesMashol($NewUserID,$szervezetNeve);
        }


        $fogyLeirasa = $request->input('fogyLeirasa');


       // print(DB_OMR_Operations::GetTelepulesID("Budapest"));
       // print(DB_OMR_Operations::GetTelepules_JSON());
        //die();
        DB_OMR_Operations::UpdateAllandoLakcim($NewUserID,$al_lakcim_irszam,$al_lakcim_telepules,$al_lakcim_orszag,$al_lakcim_utca,$al_lakcim_megye);
        DB_OMR_Operations::UpdateFelhasznalok($NewUserID,$vezeteknev,$keresztnev,$kozepsonev,$usernemeValue,'null',$szulido,$szulhely,1,'null',$telszam, $years);
        //dd($tevekenyseg);
        DB_OMR_Operations::UpdateFelhasznaloInfok($NewUserID,$tevekenyseg,$userpolomeret,$fogyatekossag,$fogyLeirasa );
        DB_OMR_Operations::UpdateTartozkodasiLakcim($NewUserID,$tart_lakcim_irszam,$tart_lakcim_telepules,$tart_lakcim_orszag,$tart_lakcim_utca,$tart_lakcim_megye);


        return redirect()->route('/onkentes/csoport');
    }

    /**
     * A felhasznaloi fiok vegeleges torlese!!!
     */
    public function fiok_torlese()
    {
        $user = auth()->user();
        $UserId = $user["id"];
        Auth::logout();
        $users = User::findOrFail($UserId);

        $users->delete();

        return view('onkentes/fiok_torlese');
    }




    public function jelentkezes_terulet_leadasa(Request $request)
    {
        $user = auth()->user();


        $jelentkezesID = $request->input('jid');

        $felhasznaloFeladat = FelhasznaloFeladat::find($jelentkezesID);
        $esemeny = null;
        try{
            $esemeny = Esemeny::find($felhasznaloFeladat->esemeny_id);
        }
        catch(Exception $e)
        {
            $error = new MyErrorLog();
            $error->controller = 'OnkentesController';
            $error->methodname = 'jelentkezes_terulet_leadasa';
            $error->otherDescribe = 'esemenyid lekerdezes';
            $error->exceptionMsg = $e->getMessage();
            $error->felhasznalo_id = $user['id'];
            $error->allAvialbleData = $request;
            $error->save();
            return back();
        }
        $ff = $felhasznaloFeladat;
        $result = DB::table('felhasznalo_feladat')->where('jelentkezesID',$jelentkezesID)->delete();

        $date = Carbon::now();

        try{
            $fll = new LogFelhasznaloFeladat();
            $fll->felhasznalo_id = $ff->felhasznalo_id;
            $fll->esemeny_id = $ff->esemeny_id;
            $fll->terulet_id = $ff->terulet_id;
            $fll->csoport_id = $ff->csoport_id;
            $fll->created_at = $date;
            $fll->muvelet = 'Onkentes altal lemondas.';
            $fll->save();

            $tb = TeruletBeosztas::where('terulet_id',$ff->terulet_id)->where('felhasznalo_id',$ff->felhasznalo_id)->first();

            if(isset($tb))
            {
                $tb->delete();
                
            }

            $logTerbeoszt = new LogTeruletBeosztas();
                $logTerbeoszt->jelentkezesID = $jelentkezesID;
                $logTerbeoszt->felhasznalo_id = $ff->felhasznalo_id;
                $logTerbeoszt->terulet_id = $ff->terulet_id;
                $logTerbeoszt->beosztasIdeje = $date;
                $logTerbeoszt->muvelet = 'Önkéntes által lemondva.';
                $logTerbeoszt->modosito = $ff->felhasznalo_id;
                $logTerbeoszt->save();

            $t = Terulet::find($felhasznaloFeladat->terulet_id)??'null';
            OmrEmail::AlertDisclaimProgramAppliedForUser($user["email"], $esemeny);
            OmrEmail::AlertDisclaimProgramAppliedForAdmin('onkentes@iec2020.hu', $esemeny,$t->nev);
        }
        catch(Exception $e)
        {
            return back();
        } 
        

        if($result > 0)
            return back();


    }

    public function teruletModositasa(Request $request)
    {
        $newArea = $request->input('newarea');
        $jid = $request->input('jidt');
        $user = auth()->user();
        $felhasznaloFeladat = FelhasznaloFeladat::find($jid);
        $esemeny = Esemeny::find($felhasznaloFeladat->esemeny_id);

        DB::table('felhasznalo_feladat')->where('jelentkezesID','=',$jid )->update(['terulet_id' => $newArea,'csoport_id' => 0]);
        $tb = TeruletBeosztas::where('terulet_id',$felhasznaloFeladat->terulet_id)->where('felhasznalo_id',$felhasznaloFeladat->felhasznalo_id)->first();

        $date = Carbon::now();
        try{

            if(isset($tb))
            {
                $tb->delete();
            }

            $logTerbeoszt = new LogTeruletBeosztas();
                $logTerbeoszt->jelentkezesID = $jelentkezesID;
                $logTerbeoszt->felhasznalo_id = $felhasznaloFeladat->felhasznalo_id;
                $logTerbeoszt->terulet_id = $felhasznaloFeladat->terulet_id;
                $logTerbeoszt->beosztasIdeje = $date;
                $logTerbeoszt->muvelet = 'Önkéntes által módosítva.';
                $logTerbeoszt->modosito = $felhasznaloFeladat->felhasznalo_id;
                $logTerbeoszt->save();
            $t = Terulet::find($felhasznaloFeladat->terulet_id)??'null';
            OmrEmail::AlertChangeAppliedAreaForUser($user["email"], $esemeny);
            OmrEmail::AlertChangeAppliedAreaForAdmin('onkentes@iec2020.com', $esemeny,$t->nev);
            OmrEmail::AlertChangeAppliedAreaForAdmin('janos.lakatos89@gmail.com', $esemeny,$t->nev);
        }
        catch(Exception $e)
        {return back();} 
        return back();
    }

    /**
     * POST method
     * Route: onkentes/jelszovaltoztatas
     */
    public function PasswdChange(Request $request)
    {
        $user = auth()->user();
        $currentPsswd = $request->input('oldPwd');

        if(Hash::check($currentPsswd, $user->password))
        {
            $validator =  [
                'newPwd' => 'required|min:5|max:20',
                'renewPwd' => 'required|min:5|max:20',
            ];
            $customMessages = [
                'required' => 'A(z) :attribute mező kötelező.',
                'min' => 'Az új jelszónak legalább 5 karakter hosszúnak kell lennie. ',
                'max' => 'A jelszó maximum 20 karakter hosszú lehet. Tipp: használjon nagy betűket és speciális karaktereket. '
            ];

            $this->validate($request, $validator, $customMessages);

            if($request->input('newPwd') != $request->input('renewPwd'))
            {
                $message = 'A be írt új jelszavak nem egyeznek! Kérjük probálja újra!';
                return back()->withErrors([$message, 'The Message']);
            }
            else
            {


                $user->fill([ 'password' => Hash::make($request->input('newPwd'))])->save();
                $message = 'A jelszavát sikeresen megváltoztatta! A következő belépésnél, kérjük figyeljen, hogy a most megadott jelszavát írja be!';
                return back()->withErrors([$message, 'The Message']);
            }


        }
        else
        {
            $message = 'A megadott, jelenlegi jelszava nem hiteles! Kérem adja meg újra jelszavát!';
            return back()->withErrors([$message, 'The Message']);
        }




    }

/**
 * **************************************************************************
 *
 * ********************************************************************************************************* *
 */
 /**
     * Seged fgv. a fotevekenyseg html kimenetenek eloallitasahoz
     * @param int
     */
    public function GetHTMLTevekenysegMaker($JelenlegiTevkensegID)
    {
        $get = "def";
        switch($JelenlegiTevkensegID)
        {
            case 1:
                $get = '<option value="1" selected="selected">Felsőoktatásban tanulok</option>
                <option value="2">Középiskolában tanulok</option>
                <option value="3">Általános iskolában tanulok</option>
                <option value="4">Dolgozom</option>
                <option value="5">Munkanélküli vagyok</option>
                <option value="6">Kisgyermeket nevelek otthon</option>
                <option value="7">Háztartásbeli vagyok otthon</option>
                <option value="8">Nyugdíjas vagyok</option>';
                return $get;
            break;

            case 2:
                $get = '<option value="1" >Felsőoktatásban tanulok</option>
                <option value="2" selected="selected">Középiskolában tanulok</option>
                <option value="3">Általános iskolában tanulok</option>
                <option value="4">Dolgozom</option>
                <option value="5">Munkanélküli vagyok</option>
                <option value="6">Kisgyermeket nevelek otthon</option>
                <option value="7">Háztartásbeli vagyok otthon</option>
                <option value="8">Nyugdíjas vagyok</option>';
                return $get;
            break;

            case 3:
                $get = '<option value="1" >Felsőoktatásban tanulok</option>
                <option value="2" >Középiskolában tanulok</option>
                <option value="3" selected="selected">Általános iskolában tanulok</option>
                <option value="4">Dolgozom</option>
                <option value="5">Munkanélküli vagyok</option>
                <option value="6">Kisgyermeket nevelek otthon</option>
                <option value="7">Háztartásbeli vagyok otthon</option>
                <option value="8">Nyugdíjas vagyok</option>';
                return $get;
            break;

            case 4:
                $get = '<option value="1" >Felsőoktatásban tanulok</option>
                <option value="2" >Középiskolában tanulok</option>
                <option value="3" >Általános iskolában tanulok</option>
                <option value="4" selected="selected">Dolgozom</option>
                <option value="5">Munkanélküli vagyok</option>
                <option value="6">Kisgyermeket nevelek otthon</option>
                <option value="7">Háztartásbeli vagyok otthon</option>
                <option value="8">Nyugdíjas vagyok</option>';
                return $get;
            break;

            case 5:
                $get = '<option value="1" >Felsőoktatásban tanulok</option>
                <option value="2" >Középiskolában tanulok</option>
                <option value="3" >Általános iskolában tanulok</option>
                <option value="4">Dolgozom</option>
                <option value="5" selected="selected">Munkanélküli vagyok</option>
                <option value="6">Kisgyermeket nevelek otthon</option>
                <option value="7">Háztartásbeli vagyok otthon</option>
                <option value="8">Nyugdíjas vagyok</option>';
                return $get;
            break;

            case 6:
                $get = '<option value="1" >Felsőoktatásban tanulok</option>
                <option value="2" >Középiskolában tanulok</option>
                <option value="3" >Általános iskolában tanulok</option>
                <option value="4" >Dolgozom</option>
                <option value="5" >Munkanélküli vagyok</option>
                <option value="6" selected="selected">Kisgyermeket nevelek otthon</option>
                /<option value="7">Háztartásbeli vagyok otthon</option>
                \/<option value="8">Nyugdíjas vagyok\\</option\>';
                return $get;
            break;

            case 7:
                $get = '<option value="1" >Felsőoktatásban tanulok</option>
                <option value="2" >Középiskolában tanulok</option>
                <option value="3" >Általános iskolában tanulok</option>
                <option value="4" >Dolgozom</option>
                <option value="5" >Munkanélküli vagyok</option>
                <option value="6" >Kisgyermeket nevelek otthon</option>
                <option value="7" selected="selected">Háztartásbeli vagyok otthon</option>
                <option value="8">Nyugdíjas vagyok</option>';
                return $get;
            break;

            case 8:
                $get = '<option value="1" >Felsőoktatásban tanulok</option>
                <option value="2" >Középiskolában tanulok</option>
                <option value="3" >Általános iskolában tanulok</option>
                <option value="4" >Dolgozom</option>
                <option value="5" >Munkanélküli vagyok</option>
                <option value="6" >Kisgyermeket nevelek otthon</option>
                <option value="7" >Háztartásbeli vagyok otthon</option>
                <option value="8" selected="selected">Nyugdíjas vagyok</option>';
                return $get;
            break;
            default:
                $get = '<option value="1" >Felsőoktatásban tanulok</option>
                <option value="2" >Középiskolában tanulok</option>
                <option value="3" >Általános iskolában tanulok</option>
                <option value="4" >Dolgozom</option>
                <option value="5" >Munkanélküli vagyok</option>
                <option value="6" >Kisgyermeket nevelek otthon</option>
                <option value="7" >Háztartásbeli vagyok otthon</option>
                <option value="8">Nyugdíjas vagyok</option>';
                return $get;
            break;
        }
    }

    public function getPolomeret($polomeret)
    {
        $get = null;
        switch($polomeret)
        {
            case 'XS':
                    $get = '<option value="XS" selected="selected">XS</option>
                    <option value="S">S</option>
                    <option value="M">M</option>
                    <option value="L">L</option>
                    <option value="XL">XL</option>
                    <option value="XXL">XXL</option> <option value="XXXL">XXXL</option> <option value="XXXXL+">XXXXL vagy nagyobb</option>';
                    return $get;
            break;
            case 'S':
                    $get = '<option value="XS" >XS</option>
                    <option value="S" selected="selected">S</option>
                    <option value="M">M</option>
                    <option value="L">L</option>
                    <option value="XL">XL</option>
                    <option value="XXL">XXL</option><option value="XXXL">XXXL</option> <option value="XXXXL+">XXXXL vagy nagyobb</option>';
                    return $get;
            break;
            case 'M':
                $get = '<option value="XS" >XS</option>
                <option value="S" >S</option>
                <option value="M" selected="selected">M</option>
                <option value="L">L</option>
                <option value="XL">XL</option>
                <option value="XXL">XXL</option><option value="XXXL">XXXL</option> <option value="XXXXL+">XXXXL vagy nagyobb</option>';
                    return $get;
            break;
            case 'L':
                $get = '<option value="XS" >XS</option>
                <option value="S" >S</option>
                <option value="M" >M</option>
                <option value="L" selected="selected">L</option>
                <option value="XL">XL</option>
                <option value="XXL">XXL</option><option value="XXXL">XXXL</option> <option value="XXXXL+">XXXXL vagy nagyobb</option>';
                    return $get;
            break;
            case 'XL':
            $get = '<option value="XS" >XS</option>
            <option value="S" >S</option>
            <option value="M" >M</option>
            <option value="L" >L</option>
            <option value="XL" selected="selected">XL</option>
            <option value="XXL">XXL</option><option value="XXXL">XXXL</option> <option value="XXXXL+">XXXXL vagy nagyobb</option>';
                    return $get;
            break;
            case 'XXL':
            $get = '<option value="XS" >XS</option>
            <option value="S" >S</option>
            <option value="M" >M</option>
            <option value="L" >L</option>
            <option value="XL">XL</option>
            <option value="XXL"  selected="selected">XXL</option><option value="XXXL">XXXL</option> <option value="XXXXL+">XXXXL vagy nagyobb</option>';
                    return $get;
            break;
            case 'XXXL':
            $get = '<option value="XS" >XS</option>
                    <option value="S" >S</option>
                    <option value="M" >M</option>
                    <option value="L" >L</option>
                    <option value="XL">XL</option>
                    <option value="XXL"  >XXL</option><option value="XXXL" selected="selected">XXXL</option> <option value="XXXXL+">XXXXL vagy nagyobb</option>';
                    return $get;
            break;
            case 'XXXXL+':
            $get = '<option value="XS" >XS</option>
                    <option value="S" >S</option>
                    <option value="M" >M</option>
                    <option value="L" >L</option>
                    <option value="XL">XL</option>
                    <option value="XXL"  >XXL</option><option value="XXXL" >XXXL</option> <option value="XXXXL+" selected="selected">XXXXL vagy nagyobb</option>';
                    return $get;
            break;
            default:
                $get = '<option value="XS" >XS</option>
                <option value="S" >S</option>
                <option value="M" >M</option>
                <option value="L" >L</option>
                <option value="XL">XL</option>
                <option value="XXL">XXL</option><option value="XXXL">XXXL</option> <option value="XXXXL+">XXXXL vagy nagyobb</option>';
                        return $get;
            break;
        }


    }

    public function GetNyelvSzintHTML($nyelvszintid)
    {
        $get = null;
        switch($nyelvszintid)
        {
            case '1':
                $get = '<option value="1" selected="selected">Alapfok</option>
                <option value="2">Középfok</option>
                <option value="3">Felsőfok</option>';
                return $get;
            break;

            case '2':
            $get = '<option value="1">Alapfok</option>
            <option value="2"  selected="selected">Középfok</option>
            <option value="3">Felsőfok</option>';
            return $get;
            break;

            case '3':
                $get = '<option value="1">Alapfok</option>
                <option value="2">Középfok</option>
                <option value="3"  selected="selected">Felsőfok</option>';
                return $get;
            break;

            default:
                $get = '<option value="1">Alapfok</option>
                <option value="2">Középfok</option>
                <option value="3">Felsőfok</option>';
                return $get;
            break;

        }
    }

    /**
     * Visszater egy collectionel, ami nem tartalmazza a jeletnkezeseket
     * @param Collection A modositando lekeres
     * @param Collection Ami alapjan torlunk az elso collection-bol
     *
     * @return Collection A szurt collection
     */
    private function JelentkezesSzuro($collection1, $collection2)
    {
       /**
        * A tomb elemeit torolni fogjuk
        */
       $deleteItems = array();

                    $matchcount = 0;

                    for($i = 0;$i < count($collection1);$i++)
                    {
                        foreach($collection2 as $jelentkezes)
                        {
                             if($collection1[$i]->id == $jelentkezes->id)
                                {
                                    if(count($deleteItems) == 0)
                                    {
                                        array_push($deleteItems,$i);
                                    }
                                    else
                                    {
                                        $match = false;
                                        foreach($deleteItems as $program)
                                        {
                                            if($program == $i)
                                            {
                                                $match = true;
                                            }
                                        }
                                        if(!$match)
                                        {
                                            array_push($deleteItems,$i);
                                        }
                                    }

                                }
                        }

                    }
                    foreach($deleteItems as $program)
                    {
                        $collection1->forget($program);
                    }

                    return new Collection($collection1);
    }


}
