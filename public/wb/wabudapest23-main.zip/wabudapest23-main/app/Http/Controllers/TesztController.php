<?php

namespace App\Http\Controllers;

use App\OnkentesSzabadidopontok;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use App\Terulet;
use App\Csoport;
use App\FelhasznaloFeladat;
use Illuminate\Support\Facades\DB;
use Exception;

class TesztController extends Controller
{
    public function tisztito()
    {
        $ff = FelhasznaloFeladat::all();

        foreach($ff as $f)
        {
            if(!$this->isTerulet($f->csoport_id,$f->terulet_id))
            {
                echo $f->jelentkezesID;
                echo 'Rossz: '.$f->terulet_id;
                $ujTid = $this->TeruletIDForCsoport($f->csoport_id);
                echo 'Jó: '.$ujTid;
                $f->terulet_id = $ujTid;
                $f->save();
                echo '----';
            }
        }

    }

    protected function isTerulet(int $csoportid, $ff_teruletid) : bool
    {
        $tid = 0;

        try 
        {
            $tid = Csoport::find($csoportid)->terulet_id;
        }
        catch(Exception $e)
        {
           return true;
        }
        

        if($tid == $ff_teruletid)
        {
            return true;
        }
        else 
            return false;

            //SELECT * FROM `terulet_beosztas` left join users on terulet_beosztas.felhasznalo_id = users.id WHERE `terulet_beosztas`.`terulet_id` = 153 and users.id is null
    }

    protected function TeruletIDForCsoport($csoportID) : int
    {
        $tid = Csoport::find($csoportID)->terulet_id;
        return $tid;
    }

    /**
     * datediff teszt
     */
    public function datediffteszt()
    {
        $date = new Carbon('2020-05-28');
        $dayDiff = $date->diffInDays('2020-06-11');
        dd( $dayDiff);
    }


    public function naptardefaultba()
    {
        $this->naptarupload(1884,1889);
       /* $this->naptarupload(1911,1946);
        $this->naptarupload(1949,1985);
        $this->naptarupload(1988,2001);
        $this->naptarupload(2004,2020);
        $this->naptarupload(2041,2120);*/
    }

    protected function naptarupload(int $min,int $max)
    {

        while($min < $max + 1)
        {
            $naptar = new OnkentesSzabadidopontok();
            $naptar->felhasznalo_id = $min;
            $naptar->foglalas_json = '{"y2020":{"Szeptember":{"szabad":["Empty","5-10to15-20","Empty","2-3to11-12","Empty","1-3to12-17","7-10to22-20","Empty","6-10to10-30","4-13to15-19","Empty","Empty","1-17to10-20","Empty","2-5to15-18","Empty","Empty","3-6to7-16","Empty","Empty","Empty","Empty","08-00to15-00","10-00to14-00","Empty","Empty","10-00to18-00","Empty","Empty","2-2to17-20"]},"Oktober":{"szabad":["Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty"]},"November":{"szabad":["Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty"]},"December":{"szabad":["Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty"]}}}';
            $naptar->save();
            $min++;
        }
    }


    public function import1()
    {
        $result = DB::table('euch_csod_forditas_import')->join('users','euch_csod_forditas_import.email','=','users.email')->get('users.id as id');

        foreach($result as $user)
        {
            $ff = new FelhasznaloFeladat();
            $ff->felhasznalo_id = $user->id;
            $ff->terulet_id = 251;
            $ff->esemeny_id = 18;
            $ff->priority = 1;
            $ff->other = 0;
            $ff->jelentkezesIdeje = Carbon::now();
            $ff->feladat_id = 0;
            $ff->csoport_id = 0;

            $ff->save();
        }

    }

    public function import2()
    {
        $result = DB::table('elokeszito_onk_import')->join('users','elokeszito_onk_import.email','=','users.email')->get('users.id as id');

        foreach($result as $user)
        {
            $ff = new FelhasznaloFeladat();
            $ff->felhasznalo_id = $user->id;
            $ff->terulet_id = 250;
            $ff->esemeny_id = 18;
            $ff->priority = 1;
            $ff->other = 0;
            $ff->jelentkezesIdeje = Carbon::now();
            $ff->feladat_id = 0;
            $ff->csoport_id = 0;

            $ff->save();
        }

    }

}
