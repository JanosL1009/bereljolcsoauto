<?php

namespace App\Http\Controllers\Auth;

use App\User;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;
use Mail;
use App\Http\Controllers\DB_OMR_Operations;
use Illuminate\Support\Facades\DB;
use App\Model\Felhasznalo;
use Illuminate\Support\Str;
class RegisterController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */

    use RegistersUsers;

    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
    protected $redirectTo = '/profil_szerkesztes';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {

        return Validator::make($data, [
            'vezeteknev' => ['required', 'string', 'max:255'],
            'kozepsonev' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'password' => ['required', 'string', 'min:8', 'confirmed'],
            'gdpr' => ['required'],
        ]);


    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return \App\User
     */
    protected function create(array $data)
    {
        $user = new \App\User();

        $user->name = $data['vezeteknev'].' '.$data['kozepsonev'];
        if(isset($data['keresztnev']))
        {
            $user->name =  $user->name.' '.$data['keresztnev'];
        }

        $masodikkeresztnev = null;
        if(isset($data['masodikkeresztnev']))
        {
            $masodikkeresztnev = $data['masodikkeresztnev'];
            $user->name =  $user->name.' '.$data['masodikkeresztnev'];
        }


        $user->email = $data['email'];
        $user->password = Hash::make($data['password']);

        if($data['nevelotag'] != 'none')
        {
            $user->elotag =  $data['nevelotag'];
            $user->name =  $user->elotag.' '.$user->name;
        }
        $user->api_token = Str::random(80);
        $user->save();
        
        $f = new Felhasznalo();
        $f->id = $user->id;
        
        
         $f->vezeteknev = $data['vezeteknev'];
       
        $f->kozepsonev = $data['kozepsonev'];
        if(isset($masodikkeresztnev))
        {
            $f->keresztnev = $masodikkeresztnev;
        }
        $f->email = $user->email;
        $f->profilkep = 'blank-profile-pic-omr.png';
        $f->save();

        DB::table('jogosultsag')->insert(["felhasznalo_id" => $user->id, "felhasznaloszint_id" => 2]);
        DB_OMR_Operations::InsertDatableEmail($user->id,$user->email);
        return $user;



    }
}
