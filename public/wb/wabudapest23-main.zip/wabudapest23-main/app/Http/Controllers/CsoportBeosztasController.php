<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use  App\Http\Models\AdminCsopBeosztasViewModel;
use  App\Http\Models\CsoportokLekerdezese;
use  App\Http\Models\CsopBeosztasViewModel;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\FrontEndMaker;
use Illuminate\Support\Facades\App;
use App\Model\BeosztasKezeloRepo;
use App\Support\Collection;
use App\Terulet;
use App\User;
use App\UserAdminsViews;
use Illuminate\Support\Carbon;

class CsoportBeosztasController extends Controller
{

    public function CsoportBeosztas(Request $request,$teruletid,$csoportid)
    {
        $user = auth()->user();
        $model = new AdminCsopBeosztasViewModel($user["id"]);
        $model->profilpic = DB_OMR_Operations::GetProfilkep($user['id']);

        $userviews = new UserAdminsViews;
        $userviews->slug = $_SERVER['REQUEST_URI'];
        $userviews->visitTimes = Carbon::now();
        $userviews->felhasznalo_id = $user['id'];
        $userviews->save();

        $model->csoportID = $csoportid;

        $model->teruletID = $teruletid ;
        $esemenyID = Terulet::find($teruletid)->esemeny_id;
        $BeosztasKezelo = new BeosztasKezeloRepo($user,intval($esemenyID),intval($teruletid),$csoportid);
        $model->jelentkezokLista = $BeosztasKezelo->GetCsoportba_NEM_Beosztottak();

        $csoportVezetok = DB::table('users')->join('felhasznalo_feladat','felhasznalo_feladat.felhasznalo_id','=','users.id')->join('esemeny_szervezok','users.id','=','esemeny_szervezok.felhasznalo_id')->where('esemeny_szervezok.szint_id','=',5)->get();
        //dd($csoportVezetok);
        if(isset($csoportVezetok))
        {
            $model->CsoportVezetok = $csoportVezetok;
        }


        $csoportTagok = DB::table('felhasznalo_feladat')->join('users','users.id','=','felhasznalo_feladat.felhasznalo_id')->where('csoport_id','=',$csoportid)->get();

        //dd($csoportTagok,$model->jelentkezokLista);
        if(isset($csoportTagok))
        {
            $model->CsoportTagok = $csoportTagok;
        }

        $model->BeosztottakSzama = $BeosztasKezelo->getCsoportAktualisBeosztottakSzama();
        $model->TervezettCsoportLetszam = $BeosztasKezelo->getCsoportLetszam();

        $model->breadcrumblink = FrontEndMaker::GetBreadcrumbCsoportBeosztas($esemenyID,$model->teruletID ,$model->csoportID);


        $usersArr = array();
        if(isset($model->jelentkezokLista))
        {
            foreach($model->jelentkezokLista as $jelentkezo)
            {
               array_push($usersArr,$jelentkezo);
            }
            foreach($BeosztasKezelo->GetCsoportBeosztas() as $jelentkezo)
            {
               array_push($usersArr,$jelentkezo->felhasznalo_id);
            }
            $users = User::whereIn('id',$usersArr)->get(['id','name']);
        }


        $model->UsersFreeTimes = $BeosztasKezelo->Calendar($usersArr);


        return view('/adminisztratorok/csoportbeosztas')->with('model',$model)->
        with('csoportBeosztottakID',$BeosztasKezelo->GetCsoportBeosztas())->with('users',$users)->with('CsoportosJelentkezok',$BeosztasKezelo->GetCsoportosJelentkezok()??null)->
        with('JeligeLista', $BeosztasKezelo->getExistGroups());
    }

    public function CsoportVezetokBeosztas(Request $request,$teruletid,$csoportid)
    {

        $user = auth()->user();
        $model = new AdminCsopBeosztasViewModel($user["id"]);
        $model->profilpic = DB_OMR_Operations::GetProfilkep($user['id']);

        $userviews = new UserAdminsViews;
        $userviews->slug = $_SERVER['REQUEST_URI'];
        $userviews->visitTimes = Carbon::now();
        $userviews->felhasznalo_id = $user['id'];
        $userviews->save();

        $model->csoportID = $csoportid;
        $model->teruletID = $teruletid ;
        $esemenyID = DB::table('terulet')->where('id','=',$model->teruletID)->select('esemeny_id')->get()->first()->esemeny_id;
        $model->esemeny_id = $esemenyID;
        $BeosztasKezelo = new BeosztasKezeloRepo($user,intval($esemenyID),intval($teruletid),$model->csoportID);


         //$model->adminLista = DB::table('users')->join('jogosultsag',"users.id",'=','jogosultsag.felhasznalo_id')->select('users.*')->where('jogosultsag.felhasznaloszint_id','=',1)->get();

         $model->jelentkezokLista =  $BeosztasKezelo->GetCsoportBeosztas();
        //dd($model->jelentkezokLista);
         //dd( $csoportok->GetJelentkezokTeljes()[0]->name);
         $model->EsemenySzervezok = DB::table('users')->join('esemeny_szervezok','users.id','=','esemeny_szervezok.felhasznalo_id')->select('users.*')->where('esemeny_szervezok.szint_id','=',3)->get();
         $csoportVezetok = DB::table('users')->join('felhasznalo_feladat','felhasznalo_feladat.felhasznalo_id','=','users.id')->join('esemeny_szervezok','users.id','=','esemeny_szervezok.felhasznalo_id')->where('esemeny_szervezok.szint_id','=',5)->get();
         //dd($csoportVezetok);
         if(isset($csoportVezetok))
         {
             $model->CsoportVezetok = $csoportVezetok;
         }


         $csoportTagok = DB::table('felhasznalo_feladat')->join('users','users.id','=','felhasznalo_feladat.felhasznalo_id')->where('csoport_id','=',$csoportid)->get();

         //dd($csoportTagok);
         if(isset($csoportTagok))
         {
             $model->CsoportTagok = $csoportTagok;
         }

         $model->breadcrumblink = FrontEndMaker::GetBreadcrumbCsoportBeosztas($esemenyID,$model->teruletID ,$model->csoportID);

        return view('/adminisztratorok/csoportvezetok_beosztasa')->with('model',$model);

    }


}
