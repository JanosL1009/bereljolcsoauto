<?php
namespace App\Http\Controllers;

interface I_SiteOperation
{
    /**
     * @param array Talalati lista
     * @param bool If exist prev and next button, DEFAULT: FALSE
     * @param int Displayed item number; DEF: 15
     */
    public function getPagesForSearches($matchList,bool $prev_nev_btn = false,int $item = 15);

    /**Assoc array URL => Name  Output: exp. Rendezveny -> Passio2020 rendezveny neve -> terulet neve -> csoport neve
     *
    */
    public function getBreadcrumb($urlParamList);

}


