<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use GuzzleHttp\Cookie;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\ClientException;
use GuzzleHttp\Psr7;
use GuzzleHttp\Exception\RequestException;
use Exception;
use Illuminate\Support\Carbon;
use Symfony\Component\HttpFoundation\Response;
use App\User;
use App\SzemelyesAdatok;
use App\Model\Felhasznalo;
use App\AllandoLakcim;
use Illuminate\Support\Str;
use App\DataSync;
use Illuminate\Database\Eloquent\Builder;
use File;
use App\Akkreditacio;
class RentitController extends Controller
{

     /**
     * Class constructor.
     */
    public function __construct()
    {
        $this->middleware('checkpermission');
    }

    public function nem_jelentkezett_felhasznalok()
    {
        
    }

    public function jelentkezett_de_nincsatkuldve()
    {
       /* $Users = DB::table('users')->leftJoin('rentitsync','users.id','=','rentitsync.felhasznalo_id')->where('users.id','>',1800)
        ->whereNull('rentitsync.felhasznalo_id')->get('users.id');*/
        $Users = DB::table('users')->leftJoin('rentitsync','users.id','=','rentitsync.felhasznalo_id')
        ->join('felhasznalok','users.id','=','felhasznalok.id')->where('users.id','>',2999)->where('felhasznalok.kepvalidalas',1)
        ->whereNull('rentitsync.felhasznalo_id')
        ->get('users.id');
        $userarray = array();

        foreach($Users as $user)
        {
            array_push($userarray,$user->id);
        }

       /* $filteredUsers = User::whereIn('id',$userarray)->has('FelhasznaloFeladat')->
        whereHas('szemelyesadatok_data', function (Builder $query) {
            $query->where('allampolgarsag', '=', '0');
        })
        ->get();*/

        /* atkuldeni: 3034,4539,3743,4119
         */
        $filteredUsers = User::whereIn('id',$userarray)->
        whereHas('felhasznalo_data', function (Builder $query) {
            $query->where('kor', '>', '1');
        })
        ->get();
        //dd($filteredUsers);

/*
        foreach($filteredUsers as $user)
        {
            echo $user->id.'; ';
        }*/
        $datas = '{';
            $i = 0;
        foreach($filteredUsers as $user)
        {

            $random = Str::random(12);
            $email = $random.'_'.$user->id.'@iec2020.hu';
            $firstname = $user->felhasznalo_data->kozepsonev;
            $lastname = $user->felhasznalo_data->vezeteknev;
            $date_of_birth = $user->felhasznalo_data->szulIdo;
            $place_of_birth = $user->felhasznalo_data->szulhely_ID;
            $name_of_mother = $user->szemelyesadatok_data->anyjaneve;
            $id_number = $user->szemelyesadatok_data->szemigszam;

            //csak a magyarok
            $country; //itt kell majd munkalkodni ...
            $alampolgarsagom = (int)$user->szemelyesadatok_data->allampolgarsag;

           /* if($alampolgarsagom == 169)
            {
                dd($user,(int)$user->szemelyesadatok_data->allampolgarsag);
            }*/

            if($alampolgarsagom === 0){$country = "HU";}
            if($alampolgarsagom === 3){$country = "DZ"; }
            if($alampolgarsagom === 24){$country = "BRA"; }
            if($alampolgarsagom === 147){$country = "RO"; }
            if($alampolgarsagom === 55){$country = "PH"; }
            if($alampolgarsagom === 58){$country = "GH"; }
            if($alampolgarsagom === 68){$country = "HR"; }
            if($alampolgarsagom === 169){$country = "SVK"; }
            if($alampolgarsagom == 100){$country = "PL"; }
            if($alampolgarsagom == 139){$country = "PAK"; }
            if($alampolgarsagom == 166){$country = "RS"; }
            if($alampolgarsagom == 187){$country = "UA"; }
            if($alampolgarsagom == 200){$country = "AUT"; }


                $allandoLakcim = AllandoLakcim::where('felhasznaloid',$user->id)->first();
                $state = $allandoLakcim->megye_datas->megye_neve;//megye
                
                if($i == 0)
                {
                    
                    $datas = $datas.'"'.$email.'":{ "first_name":"'.$firstname.'", "last_name":"'.$lastname.'", "date_of_birth":"'.$date_of_birth.'","place_of_birth":"'.$place_of_birth.'", "name_of_mother":"'. $name_of_mother.'", "country":"'. $country.'", "state":"'.$state.'", "postcode":"'.$allandoLakcim->IranyitoSzam.'", "city":"'.$allandoLakcim->Telepules.'", "address":"'.$allandoLakcim->Cim.'", "id_number":"'.$id_number.'" } ';
        
                }
                else 
                {
                    $datas = $datas.',"'.$email.'":{ "first_name":"'.$firstname.'", "last_name":"'.$lastname.'", "date_of_birth":"'.$date_of_birth.'","place_of_birth":"'.$place_of_birth.'", "name_of_mother":"'. $name_of_mother.'", "country":"'. $country.'", "state":"'.$state.'", "postcode":"'.$allandoLakcim->IranyitoSzam.'", "city":"'.$allandoLakcim->Telepules.'", "address":"'.$allandoLakcim->Cim.'", "id_number":"'.$id_number.'" } ';

                }

            $sync = new DataSync();
            $sync->felhasznalo_id = $user->id;
            $sync->virtual_email = $email;
            $sync->save();
            $i++;
        }

        $datas = $datas.'}'; //end
        $count = count($filteredUsers);
        //dd($datas,$count);

        $url = 'https://nek2020api.eventcloud.hu/onkentes';
        $client = new Client( ["base_uri" => "https://nek2020api.eventcloud.hu/onkentes"],
        [[
            'Content-Type' => 'application/x-www-form-urlencoded; charset=utf-8',
            'User-Agent' => 'NEKAppClient',
            'debug'           => true
        ]]
    
            );

            $response = null;
            try{
                $res = $client->request('POST', $url, [
                    'headers' => [
                        'User-Agent' => 'NEKAppClient',
                        
                    ],
                    'form_params' => [
                        'auth' => 'df34zov.r456Oyb2r',
                        'data' =>  $datas,
                        
                ]]);
            
                if( $res->getStatusCode() == 200)
                {

                    $jsonresult = $res->getBody();
                    $j = json_decode($jsonresult,true);

                    DB::table('rentitsync')->whereIn('felhasznalo_id',$userarray)
                    ->update(
                        [
                            'sync_status' => 1,
                            'sync_result' => $jsonresult
                        ]
                    );
                    echo $jsonresult;
                }
                else 
                {
                    $jsonresult = $res->getBody();
                    $j = json_decode($jsonresult,true);

                    DB::table('rentitsync')->whereIn('felhasznalo_id',$userarray)
                    ->update(
                        [
                            'sync_status' => 0,
                            'sync_result' => $jsonresult
                        ]
                    );
                    echo $jsonresult;
                }
        }
        catch(ClientException $ce)
        {
            echo "*******************************************";

            echo Psr7\Message::toString($ce->getRequest());
            echo "*******************************************  \r \n";
            if ($ce->hasResponse()) {
                echo Psr7\Message::toString($ce->getResponse());
            }
        }

       
    }


/**
 * 
 * 07.21 reggel, legelso adatok atkuldese
 */
    public function adatszinronizacio()
    {
        $url = 'https://nek2020api.eventcloud.hu/onkentes';
        
        $min_id = 5151; //1.kör: 4532 ;; 2.kör: 4701;;3.kör: 4801;;4.kör: 3030;; 5. kör: 3701
        $max_id = 7093; //1.kör: 4700 ;; 2.kör: 4800;;3. kör: 5000;;4. kör: 3700;; 5.kör: 4100

        //6.kör: 4101;; 7.kör: 4532;; 8. kör: 5151
        //6.kör 4531;; 7. kör: 5150;; 8. kör: 7093

        $client = new Client( ["base_uri" => "https://nek2020api.eventcloud.hu/onkentes"],
            [[
                'Content-Type' => 'application/x-www-form-urlencoded; charset=utf-8',
                'User-Agent' => 'NEKAppClient',
                'debug'           => true
            ]]
        
        );

            $Users = User::where('id','>',$min_id)->where('id','<',$max_id)->has('FelhasznaloFeladat')->
            whereHas('szemelyesadatok_data', function (Builder $query) {
                $query->where('allampolgarsag', '=', '0');
            })
            ->get();

           // dd($Users);

            //json builder 
            $datas = '{';
                $i = 0;
            foreach($Users as $user)
            {

                $random = Str::random(12);
                $email = $random.'_'.$user->id.'@iec2020.hu';
                $firstname = $user->felhasznalo_data->kozepsonev;
                $lastname = $user->felhasznalo_data->vezeteknev;
                $date_of_birth = $user->felhasznalo_data->szulIdo;
                $place_of_birth = $user->felhasznalo_data->szulhely_ID;
                $name_of_mother = $user->szemelyesadatok_data->anyjaneve;
                $id_number = $user->szemelyesadatok_data->szemigszam;

                //csak a magyarok
                $country = "HU"; //itt kell majd munkalkodni ...
                if((int)$user->szemelyesadatok_data->allampolgarsag == 0)
                {
                    $country = "HU";

                    $allandoLakcim = AllandoLakcim::where('felhasznaloid',$user->id)->first();
                    $state = $allandoLakcim->megye_datas->megye_neve;//megye
                    
                    if($i == 0)
                    {
                        
                        $datas = $datas.'"'.$email.'":{ "first_name":"'.$firstname.'", "last_name":"'.$lastname.'", "date_of_birth":"'.$date_of_birth.'","'.$place_of_birth.'":"Budapest", "name_of_mother":"'. $name_of_mother.'", "country":"HU", "state":"'.$state.'", "postcode":"'.$allandoLakcim->IranyitoSzam.'", "city":"'.$allandoLakcim->Telepules.'", "address":"'.$allandoLakcim->Cim.'", "id_number":"'.$id_number.'" } ';
            
                    }
                    else 
                    {
                        $datas = $datas.',"'.$email.'":{ "first_name":"'.$firstname.'", "last_name":"'.$lastname.'", "date_of_birth":"'.$date_of_birth.'","place_of_birth":"'.$place_of_birth.'", "name_of_mother":"'. $name_of_mother.'", "country":"HU", "state":"'.$state.'", "postcode":"'.$allandoLakcim->IranyitoSzam.'", "city":"'.$allandoLakcim->Telepules.'", "address":"'.$allandoLakcim->Cim.'", "id_number":"'.$id_number.'" } ';
    
                    }

                }

               /* $sync = new DataSync();
                $sync->felhasznalo_id = $user->id;
                $sync->virtual_email = $email;
                $sync->save();*/
                $i++;
            }

            $datas = $datas.'}'; //end
            dd($datas);
            $response = null;
            try{
                $res = $client->request('POST', $url, [
                    'headers' => [
                        'User-Agent' => 'NEKAppClient',
                        
                    ],
                    'form_params' => [
                        'auth' => 'df34zov.r456Oyb2r',
                        'data' =>  $datas,
                        
                ]]);
            
                if( $res->getStatusCode() == 200)
                {

                    $jsonresult = $res->getBody();
                    $j = json_decode($jsonresult,true);

                    DB::table('rentitsync')->where('felhasznalo_id','>',$min_id)->where('felhasznalo_id','<',$max_id)
                    ->update(
                        [
                            'sync_status' => 1,
                            'sync_result' => $jsonresult
                        ]
                    );
                echo $jsonresult;
                }
                else 
                {
                    $jsonresult = $res->getBody();
                    $j = json_decode($jsonresult,true);

                    DB::table('rentitsync')->where('felhasznalo_id','>',$min_id)->where('felhasznalo_id','<',$max_id)
                    ->update(
                        [
                            'sync_status' => 0,
                            'sync_result' => $jsonresult
                        ]
                    );
                echo $jsonresult;
                }
        }
        catch(ClientException $ce)
        {
            echo "*******************************************";

            echo Psr7\Message::toString($ce->getRequest());
            echo "*******************************************  \r \n";
            if ($ce->hasResponse()) {
                echo Psr7\Message::toString($ce->getResponse());
            }
        }
    }

    /**
     * tesztelve mukodik
     */
    public function teszt_api()
    {
     /*   $url = 'https://nek2020api.eventcloud.hu/onkentes';
            

        $client = new Client( ["base_uri" => "https://nek2020api.eventcloud.hu/onkentes"],
            [[
                'Content-Type' => 'application/x-www-form-urlencoded; charset=utf-8',
                'User-Agent' => 'NEKAppClient',
                'debug'           => true
            ]]
        
        );

        $Users = User::where('id','>','2358')->where('id','<','2364')->get();

        //json builder 
        $datas = '{';
            $i = 0;
        foreach($Users as $user)
        {
            $random = Str::random(12);
            $email = $random.'_'.$user->id.'@iec2020.hu';
            $firstname = $user->felhasznalo_data->kozepsonev;
            $lastname = $user->felhasznalo_data->vezeteknev;
            $date_of_birth = $user->felhasznalo_data->szulIdo;
            $place_of_birth = $user->felhasznalo_data->szulhely_ID;
            $name_of_mother = $user->szemelyesadatok_data->anyjaneve;
            $id_number = $user->szemelyesadatok_data->szemigszam;

            $country = "HU"; //itt kell majd munkalkodni ...

            $allandoLakcim = AllandoLakcim::where('felhasznaloid',$user->id)->first();
            $state = $allandoLakcim->megye_datas->megye_neve;//megye
            
            if($i == 0)
            {
                
                $datas = $datas.'"'.$email.'":{ "first_name":"'.$firstname.'", "last_name":"'.$lastname.'", "date_of_birth":"'.$date_of_birth.'","'.$place_of_birth.'":"Budapest", "name_of_mother":"'. $name_of_mother.'", "country":"HU", "state":"'.$state.'", "postcode":"'.$allandoLakcim->IranyitoSzam.'", "city":"'.$allandoLakcim->Telepules.'", "address":"'.$allandoLakcim->Cim.'", "id_number":"'.$id_number.'" } ';
      
            }
            else 
            {
                $datas = $datas.',"'.$email.'":{ "first_name":"'.$firstname.'", "last_name":"'.$lastname.'", "date_of_birth":"'.$date_of_birth.'","place_of_birth":"'.$place_of_birth.'", "name_of_mother":"'. $name_of_mother.'", "country":"HU", "state":"'.$state.'", "postcode":"'.$allandoLakcim->IranyitoSzam.'", "city":"'.$allandoLakcim->Telepules.'", "address":"'.$allandoLakcim->Cim.'", "id_number":"'.$id_number.'" } ';

            }
            $i++;
        }

        $datas = $datas.'}'; //end

        $response = null;
        try{
            $res = $client->request('POST', $url, [
                'headers' => [
                    'User-Agent' => 'NEKAppClient',
                    
                ],
                'form_params' => [
                    'auth' => 'df34zov.r456Oyb2r',
                    'data' =>  $datas,
                    
            ]]);
        
            if( $res->getStatusCode() == 200)
            {

                $jsonresult = $res->getBody();
                $j = json_decode($jsonresult,true);
                
               echo $jsonresult;
            }
            else 
            {
                $jsonresult = $res->getBody();
                $j = json_decode($jsonresult,true);
                
               echo $jsonresult;
            }
    }
    catch(ClientException $ce)
    {
        echo "*******************************************";

        echo Psr7\Message::toString($ce->getRequest());
        echo "*******************************************  \r \n";
        if ($ce->hasResponse()) {
            echo Psr7\Message::toString($ce->getResponse());
        }
    }*/
}


    public function profilkepakkreditaciora()
    {
       /* $users =  DB::select( DB::raw("SELECT users.id,users.name,felhasznalok.vezeteknev,felhasznalok.kozepsonev,felhasznalok.profilkep, akkred_osszevont.qr,akkred_osszevont.qrlink,akkred_osszevont.card_number FROM `users` join felhasznalok on users.id = felhasznalok.id join rentitsync on users.id = rentitsync.felhasznalo_id 
        join felhasznalo_feladat on felhasznalo_feladat.felhasznalo_id = users.id
        left join akkred_osszevont on felhasznalok.vezeteknev = akkred_osszevont.nev and felhasznalok.szulIdo = akkred_osszevont.szul_ido where akkred_osszevont.card_number = '' and felhasznalok.profilkep != 'blank-profile-pic-omr.png' and felhasznalok.kepvalidalas = 1 group by users.id") );
     */ // dd($users);

      $users =  DB::select( DB::raw("SELECT users.id,users.name,felhasznalok.vezeteknev,felhasznalok.kozepsonev,felhasznalok.profilkep FROM `users` join felhasznalok on users.id = felhasznalok.id join rentitsync on users.id = rentitsync.felhasznalo_id where felhasznalok.profilkep != 'blank-profile-pic-omr.png' and felhasznalok.kepvalidalas = 1  group by users.id") );
   
      /**
       * 
         
       */

        //$i = 0;
        foreach($users as $user)
        {
            //if($i == 10) {break;}
            $akkreditacio = new Akkreditacio();
            $akkreditacio->felhasznalo_id = $user->id;
            $newName = Str::slug($user->vezeteknev).'_'.Str::slug($user->kozepsonev).$user->profilkep;
            $akkreditacio->picslug = $newName;
            $akkreditacio->save();
            
            File::copy('userpic/'.$user->profilkep,public_path('copy/'.$newName));
            
            //$i++;
        }
        
        echo "Kész";
    }
}
