<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HirlevelController extends Controller
{
    public function index()
    {
        return view('adminisztratorok/hirlevel/index');
    }

    public function uj_hirlevel_letrehozasa(Request $request)
    {
        return view('adminisztratorok/hirlevel/ujhirlevel_letrehozasa');
    }
}
