<?php

namespace App\Http\Controllers;

use App\Esemeny;
use App\Http\Controllers\DB_OMR_Operations;
use Illuminate\Http\Request;
use App\Http\Models\Hirek\HirekMegjeleniteseViewModel;
use App\Http\Models\Hirek\HirSzerkeszteseViewModel;
use App\Http\Models\Hirek\UjHirViewModel;
use App\Http\Models\Hirek\HirMegjeleneseOnkentes;//viewmodel
use App\Http\Models\Hirek\HirekOnkentesViewModel;
use App\Hir;
use App\HirSEO;
use App\HirStats;
use App\HirKepek;
use App\HirKategoria;
use Illuminate\Support\Carbon;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Validator;
use Exception;

class HirekController extends Controller
{
    protected const HIR_DIR = 'hir/';
    /**
     * Admin oldalon az uj hirt fogja letrehozni
     */
    public function uj_hir_letrehozasa(Request $request)
    {
        $user = auth()->user();
        $model = new UjHirViewModel($user['id']);
        $model->profilpic = DB_OMR_Operations::GetProfilkep($user['id']);

        $programs = Esemeny::all();
            foreach($programs as $program)
            {
                $assocProgram = array(
                    'id' => $program->id,
                    'cim' => $program->nev
                );
                array_push($model->RelatedPrograms,$assocProgram);
            }

        return view('adminisztratorok/hirek/ujhirletrehozasa')->with('model',$model);
    }

    /**
     * POST metodus, a formhoz
     */
    public function ujhir_letrehozo(Request $request)
    {
       // dd($request->all());
      // $file = $request->file('imgInp'); dd($file);
    
     

        $user = auth()->user();
        $model = new UjHirViewModel($user['id']);
        $model->profilpic = DB_OMR_Operations::GetProfilkep($user['id']);

        /**
         * Az rtekek 0,1,2 lehet.
         * @var int
         */
         $hirMegjelenese = null;
         try{
            $megjelenes = $request->input('HirMegjelenese');
           // dd($megjlenes );
            if(is_int(intval($megjelenes)) == true)
            {
               // dd($hirMegjelenese, 222,$megjlenes);
                if(intval($request->input('HirMegjelenese')) > 0 && intval($request->input('HirMegjelenese')) < 3 )
                {
                    $hirMegjelenese = (int)$megjelenes;
                }
                else throw new Exception();
            }
            else throw new Exception();

         } catch(Exception $e)
        {
            $hirMegjelenese = 0; /// csak regisztrált tagok lathatjak
         }

        $hir = new Hir;
        $hir->hir_cime = $request->input('hirCime');
        $hir->hir_tartalma = $request->input('hirLeiras');
        $hir->megjelenes = $hirMegjelenese;
        $statusz = $request->input('HirStatusza');
        if($statusz == 1)
        {
            $hir->allpot = 0;
        }
        else
        {
            $hir->allpot = 1;
        }
        $hir->letrehozo = $user['id'];

        $hir->modosito = $user['id'];
       // dd($hir);
        $hir->save();
        $hirseo = new HirSEO;
        $hirseo->Hir()->associate($hir);
        $hirseo->description = $request->input('seoDescription');
        $hirseo->keywords = $request->input('seoKeywords');
        $hirseo->title = $request->input('seoTitle');
        $hirseo->og_title = $request->input('ogTitle');
        $hirseo->og_desc = $request->input('og_desc');
        $hirseo->og_url = $this->GetSeoUrlGenerate($hir->hir_cime);
        $hirseo->save();

      /*  $hirKepek = new HirKepek;
        $hirKepek->Hir()->associate($hir);

        //dd($request->all());
       
       
            
           
            $ogImage = $request->file('imgInp'); // az elso nagy kep
            $thumbnailImg = $request->file('file_name');
            
            $extensionOgImg = $ogImage->getClientOriginalExtension();
            $extensionTImg = $thumbnailImg->getClientOriginalExtension();
            
             $hirKepek->jumbotronImg = uniqid() . '_' . time() . 'A.' . $extensionOgImg;
             $ogImage->move(self::HIR_DIR, $hirKepek->jumbotronImg);
           
           
          
              $hirKepek->thumbnailImg = uniqid() . '_' . time() . 'B.' . $extensionTImg;
            $thumbnailImg->move(self::HIR_DIR, $hirKepek->thumbnailImg);
                 
              
           





            $hirKepek->letrehozo = $user['id'];
            $hirKepek->modosito = $user['id'];
            $hirKepek->save();
        
*/
        $relatedPrograms = explode(',',$request->input('relatedprograms'));
        foreach($relatedPrograms as $id)
        {
            $hirKategoria = new HirKategoria;
            $hirKategoria->Hir()->associate($hir);
            $hirKategoria->category_id = $id;
            $hirKategoria->save();
        }


        return redirect()->route('Admin.Hir.Uj.Kepfeltoltes',['hirid' => $hir->h_id]);
    }


    public function ujhir_kepekfeltoltese(int $hirid)
    {
        $hir = Hir::find($hirid);
        $hirKepek = HirKepek::where('hir_id',$hir->h_id)->first();
       
        return view('adminisztratorok.hirek.kepek_feltoltese')->with('HirCime',$hir->hir_cime)->with('hiID',$hir->h_id)
        ->with('hirKepek',$hirKepek);
    }

    /**
     * Admin oldalon a hirt fogja modositani
     */
    public function hir_szerkesztese(Request $request,int $hirdid)
    {
        if(is_null($hirdid))
        {
            abort(404);
        }
        $user = auth()->user();
        $model = new HirSzerkeszteseViewModel($user['id']);
        $model->profilpic = DB_OMR_Operations::GetProfilkep($user['id']);

        $hir = Hir::find($hirdid);
        //dd($hir);
        $model->HirCime = $hir->hir_cime;
        $model->Leiras = $hir->hir_tartalma;
        $model->title = $hir->title;
        $model->setStatusz($hir->allpot);
        $model->setHirMegjelenese($hir->megjelenes);
        $model->description = $hir->SEO->description;
        $model->keywords = $hir->SEO->keywords;
        $model->og_title = $hir->SEO->og_title;
        $model->od_desc = $hir->SEO->og_desc;

        $model->setRobots($hir->SEO->robots);
        $model->og_image = $hir->Images->jumbotronImg;

        $programs = Esemeny::all();
        foreach($programs as $program)
        {
            $assocProgram = array(
                'id' => $program->id,
                'cim' => $program->nev
            );
            array_push($model->RelatedPrograms,$assocProgram);
        }

        return view('adminisztratorok/hirek/hirszerkesztese')->with('model',$model)->with('h_id',$hir->h_id);
    }

    /**
     * Admin oldalon a hireket fogja megjeleniteni, tablazatosan ...
     */
    public function hirek_megjelenitese_admin(Request $request,$field = null,$order = null)
    {
        $user = auth()->user();
        $model = new HirekMegjeleniteseViewModel($user['id']);
        $model->profilpic = DB_OMR_Operations::GetProfilkep($user['id']);
        $model->hirek = Hir::paginate(15);
                $OrderBooelan = ["isResult" => false, "content" => null];
                if(isset($order))
                {
                    if($order == 'asc' || $order == 'desc')
                    {
                        $OrderBooelan["isResult"] = true;
                        $OrderBooelan["content"] = $order;
                    }
                } else redirect('404');

        if(isset($field))
        {
            if($OrderBooelan["isResult"])
            {
                if($field == 'cim' || $field = 'letrehozasideje' || $field = 'statusz') //maszkolas miatt eltero a field a db-tol
                {
                    switch($field)
                    {
                        case 'cim':
                            $model->hirek = Hir::orderBy('hir_cime',$OrderBooelan["content"])->paginate(15);
                        break;
                        case 'letrehozasideje':
                            $model->hirek = Hir::orderBy('created_at',$OrderBooelan["content"])->paginate(15);
                        break;
                        case 'statusz':
                            $model->hirek = Hir::orderBy('allpot',$OrderBooelan["content"])->paginate(15);
                        break;
                    }


                } else redirect('404');
            } else redirect('404');
        } else redirect('404');





        return view('adminisztratorok/hirek/hirek_crud')->with('model',$model);
    }

    /** a jumbotronbol carousel lett a front-enden. */
    /** A hireket jeleniti meg az onkentes oldalon csempe formaban*/
    public function hirek_megjelenitese_onkentes(Request $request)
    {

        $user =null;
        try
        {
            $user = auth()->user();
        }
        catch(Exception $e)
        {
            $user =null;
        }

        if(isset($user))
        {
            $JumbotronHir = Hir::take(2)->latest('created_at')->get();

            $model = new HirekOnkentesViewModel($user['id']);
            $model->profilpic = DB_OMR_Operations::GetProfilkep($user['id']);

            $model->setCarousel($JumbotronHir);


            unset( $JumbotronHir ); unset($JumbotronSeo);

              $NewsTileArray = array();
              $ForNewsTile = Hir::skip(2)->take(3)->latest('created_at')->get();
                foreach( $ForNewsTile as $News)
                {
                    $Seo = HirSEO::where('hir_id',$News->h_id)->first();
                    $kep = HirKepek::where('hir_id',$News->h_id)->first();
                    $AssocNew = array(
                        'Title' => $News->hir_cime,
                        'Description' => $Seo->description,
                        'SLUG' => $Seo->og_url,
                        'created_at' => $News->created_at,
                        'thumbnailImg' => $kep->thumbnailImg
                    );

                    array_push($NewsTileArray,$AssocNew);
                }
                //dd( $NewsTileArray);
                $model->SetNewsTiles( $NewsTileArray);

                unset($HirKepek);
            return view('onkentes/hirek/index')->with('model',$model);
        }
        else
        {
            $model = new HirekOnkentesViewModel(0);
            $model->profilpic = '';

            $JumbotronHir = Hir::take(4)->latest('created_at')->get();

            $JumbotronSeo = HirSEO::whereIn('hir_id',$JumbotronHir->pluck('h_id')->toArray())->get();

            $HirKepek = HirKepek::whereIn('hir_id',$JumbotronHir->pluck('h_id')->toArray())->get();
            $model->setCarousel($JumbotronHir, $JumbotronSeo,$HirKepek);

            unset( $JumbotronHir ); unset($JumbotronSeo);

              $NewsTileArray = array();
              $ForNewsTile = Hir::skip(1)->take(4)->latest('created_at')->get();
                foreach( $ForNewsTile as $News)
                {
                    $Seo = HirSEO::where('hir_id',$News->h_id)->first();
                    $kep = HirKepek::where('hir_id',$News->h_id)->first();
                    $AssocNew = array(
                        'Title' => $News->hir_cime,
                        'Description' => $Seo->description,
                        'SLUG' => $Seo->og_url,
                        'created_at' => $News->created_at,
                        'thumbnailImg' => $kep->thumbnailImg
                    );

                    array_push($NewsTileArray,$AssocNew);
                }
               // dd($NewsTileArray);
                $model->SetNewsTiles( $NewsTileArray);

                //dd($model);

            return view('onkentes/hirek/index')->with('model',$model);
        }


    }

    /**
     * Egy hir megjelnitese az onkentes oldalon
     * @param string SLUG
     */
    public function hir_megjelenitese_onkentes(Request $request,$hircim_slug = null)
    {
        $user = null;$model = null;
        try{
            $user = auth()->user();
            if(is_int($user['id']))
            {
                $model = new HirMegjeleneseOnkentes($user['id']);
            }
            else throw new Exception();
            
           
        }
        catch(Exception $e)
        {
            return redirect(route('login'));
        }
        
        if(isset($user))
        {
            $model->profilpic=DB_OMR_Operations::GetProfilkep($user['id']);
        }
        else
        {
            $model->profilpic = '';
        }

        if(isset($hircim_slug))
        {
            $HirSEO = HirSEO::where('og_url',$hircim_slug)->first();
            $Hir = Hir::where('h_id',$HirSEO->hir_id)->first();
            $model->HirID = $Hir->id;
            $model->HirCime = $Hir->hir_cime;
            $model->Leiras = $Hir->hir_tartalma;
            $model->Description = $HirSEO->description;
            $model->keywords = $HirSEO->keywords;

            $model->breadcrumb ='<li class="breadcrumb-item"><a href="'.url('onkentes/hirek').'">Hírek</a></li>
                <li class="breadcrumb-item active" aria-current="page">'.$model->HirCime.'</li>';
        }
        else
        {
            abort(404);
        }

        $FrissHir= Hir::take(4)->latest('created_at')->get();
        $FrissHirSeo = HirSEO::whereIn('hir_id',$FrissHir->pluck('h_id')->toArray())->get();
        $FrissHirKepek = HirKepek::whereIn('hir_id',$FrissHir->pluck('h_id')->toArray())->get();
        $frissek = new HirekOnkentesViewModel($user['id']);
        $frissek->setCarousel($FrissHir, $FrissHirSeo,$FrissHirKepek);
        $model->FrissHirek = $frissek->getCarouselModelItems();

        return view('onkentes/hirek/hir_megjelenitese')->with('model',$model);
    }

    /**
     * Kereses hirekben onkentes oldalrol
     */
    public function kereses_hirekben_onkentes(Request $request)
    {
        return back();
    }

    /**
     * Kereses hirekben admin oldalrol
     */
    public function kereses_hirekben_admin(Request $request)
    {
        return back();
    }




    private function GetSeoUrlGenerate($title)
    {
        $seoTitle =  Str::slug($title, '-');

        return $seoTitle;
    }

    /**
     * Method post
     */
    public function UploadJumbotronImage(Request $request)
    {
        $user = auth()->user();
        $UserId = $user["id"];

        if ($request->isMethod('get'))
            return "Invalid method call.";
        else {
            $validator = Validator::make($request->all(),
                [
                    //'file' => 'image',required|mimes:jpeg,png,jpg,gif,svg|max:2048
                    'file' => 'required|mimes:jpeg,png,jpg,gif,svg|max:2048'
                ],
                [
                    'file.image' => 'A fájl csak kép formátum lehet (jpeg, png, bmp, gif, or svg)'
                ]);
            if ($validator->fails())
                return array(
                    'fail' => true,
                    'errors' => $validator->errors()
                );
            $extension = $request->file('file')->getClientOriginalExtension();
            
            $filename = uniqid() . '_' . time() . 'A.' . $extension;
        
            
            $hirID = (int)$request->input('hirID');
            $hirKepek = HirKepek::firstOrCreate([
                'hir_id' => $hirID
            ]);
          
               
              
                $ogImage = $request->file('file'); // az elso nagy kep
               
                
                 $hirKepek->jumbotronImg = $filename;
                 $ogImage->move(self::HIR_DIR, $filename);
               
               
                $hirKepek->letrehozo = $user['id'];
                $hirKepek->modosito = $user['id'];
                $hirKepek->save();

            return $filename;
    }
}


    public function UploadThumbnailImage(Request $request)
    {
        $user = auth()->user();
        $UserId = $user["id"];

        if ($request->isMethod('get'))
            return "Invalid method call.";
        else {
            $validator = Validator::make($request->all(),
                [
                    //'file' => 'image',required|mimes:jpeg,png,jpg,gif,svg|max:2048
                    'file' => 'required|mimes:jpeg,png,jpg,gif,svg|max:2048'
                ],
                [
                    'file.image' => 'A fájl csak kép formátum lehet (jpeg, png, bmp, gif, or svg)'
                ]);
            if ($validator->fails())
                return array(
                    'fail' => true,
                    'errors' => $validator->errors()
                );
            $extension = $request->file('file')->getClientOriginalExtension();
            
            $filename = uniqid() . '_' . time() . 'B.' . $extension;
        
            
            $hirID = (int)$request->input('hirID');
            $hirKepek = HirKepek::firstOrCreate([
                'hir_id' => $hirID
            ]);
          
               
              
                $ogImage = $request->file('file'); // az elso nagy kep
               
                
                 $hirKepek->thumbnailImg = $filename;
                 $ogImage->move(self::HIR_DIR, $filename);
               
               
                $hirKepek->letrehozo = $user['id'];
                $hirKepek->modosito = $user['id'];
                $hirKepek->save();

                return $filename;
            }
    }


}
