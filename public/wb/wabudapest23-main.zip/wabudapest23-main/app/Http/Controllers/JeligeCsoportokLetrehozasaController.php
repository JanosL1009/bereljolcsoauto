<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Jeligek;
use App\JeligeCsoportTagok;
use App\Http\Models\JeligeCsoport\IndexViewModel;
use App\Http\Models\JeligeCsoport\CsoportkezelesViewModel;
use App\Http\Controllers\DB_OMR_Operations;
use App\Http\Controllers\Msg\OmrEmail as MsgOmrEmail;
use Illuminate\Database\QueryException;
use App\Support\Collection;
use Exception;
use Illuminate\Support\Carbon;
use App\User;
use ErrorException;
use App\Http\Controllers\Msg\OmrEmail;

class JeligeCsoportokLetrehozasaController extends Controller
{
    public function jelige_index(Request $request,$mode = null)
    {
        $user = auth()->user();
        $ActUserID = $user["id"];
        $model = new IndexViewModel($ActUserID);
        $model->profilpic = DB_OMR_Operations::GetProfilkep($ActUserID);

        if($mode == 'tagvagyok')
        {
            $jeligek = null;
            try
            {
                $csoportTagsagaim = JeligeCsoportTagok::where("felhasznalo_id",$ActUserID)->get("jelige_id")->toArray();
                $jeligek = Jeligek::whereIn('id',$csoportTagsagaim)->get();

            }
            catch(QueryException $qe)
            {
                $jeligek = null;$model->JeligeCsoportok=null;
            }

            if(isset($jeligek ))
            {
                foreach($jeligek as $jelige)
                {
                    $jcs = null;
                    $jcs["id"] = $jelige->id;
                    $jcs["jelige"] = mb_strtoupper($jelige->jeligeNeve);
                    $jcs["letrehozo"] = $jelige->csoportletrehozo->name;
                    $jcs["letrehozo_id"] = $jelige->letrehozo;
                    $jcs["isAdmin"] = false;
                    array_push($model->JeligeCsoportok, $jcs);
                }
            }

            $model->mode = 'tagvagyok';
        }
        else
        {
            $jeligek = null;
            try
            {
                $jeligek = Jeligek::where("letrehozo",$ActUserID)->get();
            }
            catch(QueryException $qe)
            {
                $jeligek = null;$model->JeligeCsoportok=null;
            }

            if(isset($jeligek ))
            {
                foreach($jeligek as $jelige)
                {
                    $jcs = null;
                    $jcs["id"] = $jelige->id;
                    $jcs["jelige"] = mb_strtoupper($jelige->jeligeNeve);
                    $jcs["letrehozo"] = $jelige->csoportletrehozo->name;
                    $jcs["letrehozo_id"] = $jelige->letrehozo;
                    $jcs["isAdmin"] = false;
                    array_push($model->JeligeCsoportok, $jcs);
                }
            }

            $model->JeligeCsoportok = new Collection($model->JeligeCsoportok);
            $model->mode = 'index';
        }
        /**
         * Nagybetusse alakitas...
         */

        //dd($model->JeligeCsoportok) ;



        return view('onkentes.jelige_csoportkezeles.jelige_index')->with('model',$model);
    }

    public function jeligecsoportkezeles(Request $request, int $JeligeCsoportID)
    {
        $user = auth()->user();
        $ActUserID = $user["id"];
        $model = new CsoportkezelesViewModel($ActUserID);
        $model->profilpic = DB_OMR_Operations::GetProfilkep($ActUserID);
        $model->ActUserID = $ActUserID;
        $jelige = Jeligek::find($JeligeCsoportID);
        $model->JeligeID = $jelige->id;
        $model->JeligeNeve = $jelige->jeligeNeve;
        $model->CsoportLetrehozoID = $jelige->letrehozo;
        $model->CsoportLetrehozoNeve = $jelige->csoportletrehozo->name;

        if($ActUserID == $jelige->letrehozo)
        {
            $model->isJeligeAdmin = true;
        }
        else $model->isJeligeAdmin = false;

        $csoporttagok = JeligeCsoportTagok::where('jelige_id',$JeligeCsoportID)->get();

        $_tag = false;
        foreach($csoporttagok as $tag)
        {
            if($tag->felhasznalo_id == $ActUserID)
            {
               
                $_tag = true; break;
            }
        }

        if(!$_tag)
           {  return redirect(route('jelige.index')); } 

        foreach($csoporttagok as $tag)
        {

            $jcs['jelige_id'] = $tag->jelige_id;
            $jcs['felhasznalo_id'] = $tag->felhasznalo_id;
            $jcs['nev'] = $tag->user->name;
            $jcs['aktiv'] = $tag->aktiv;
            if($jelige->letrehozo == $tag->felhasznalo_id)
            {
                $jcs['isAdmin'] = true;
            }
            else
            $jcs['isAdmin'] = false;

            $jcs['created_at'] = $tag->created_at; //a hozzadaas ideje is egyben

            array_push($model->CsoportTagok,$jcs);

        }

        //dd($model);

        return view('onkentes.jelige_csoportkezeles.csoportkezeles')->with('model',$model);
    }


    /**
     * Method: post
     * XHR kereshez
     */
    public function OnkentesEltavolitasaCsoportbol(int $felhasznalo_id, int $jelige_id ) : int
    {
        $jcsoport = JeligeCsoportTagok::where('felhasznalo_id',$felhasznalo_id)->where('jelige_id',$jelige_id)->delete();

        return $jcsoport;

    }

/**
 * Ha sajat magat tavoltija el, tehat nem jelige letrehozo user, csak tag
 */
    public function OnkentesEltavolitasa(Request $request)
    {
        $user = auth()->user();
        $ActUserID = $user["id"];
        $jeligeID = $request->input('esid');
        $eltavolitas = null;

        $csoportalapito = false;
        $tag = JeligeCsoportTagok::where('felhasznalo_id',$ActUserID)->where('jelige_id',$jeligeID)->first()->letrehozo;
        if($tag == $ActUserID)
        {
            $csoportalapito = true;
        }

        if($csoportalapito)
        {
           // $eltavolitas = $this->OnkentesEltavolitasaCsoportbol($ActUserID,$jeligeID);
            try {
                $eltavolitas = $this->OnkentesEltavolitasaCsoportbol($ActUserID,$jeligeID);
                $jcsoport = JeligeCsoportTagok::where('jelige_id',$jeligeID)->first();
                
                $csoport = Jeligek::find($jeligeID);
                $csoport->letrehozo = $jcsoport->felhaszalo_id;
                $csoport->save();
               
                $user = User::find((int)$jcsoport->felhaszalo_id);
                
                MsgOmrEmail::NewPosyBoss($user, $csoport);

            }
            catch(Exception $e)
            {
                return back();
            }
            
        }
        else
        {
            $eltavolitas = $this->OnkentesEltavolitasaCsoportbol($ActUserID,$jeligeID);
        }

        if($eltavolitas == 1)
        {
            return redirect('onkentes/jelige/index/');
        }
        else abort(403);

    }

    /**
     * Method: post
     * XHR
     * Torol egy csoportot es a csoportban levo tagokat eltavoltija a tablabol!
     * @param int Jelige csoport primary key
     */
    public function JeligeCsoportTorlese(Request $request) : int
    {
        $JeligeCsoportId = $request->input('jelige');

        $result = null;

        try{
            Jeligek::find($JeligeCsoportId)->delete();

            JeligeCsoportTagok::where('jelige_id',$JeligeCsoportId)->where('aktiv',1)->update([
                "aktiv" => 0
            ]);
            $result = 1;
        }
        catch(Exception $e)
        {
            $result = 0;
        }



        return $result;
    }

    /**
     * Method: POST
     * XHR kereshez
     * csoporkezeles.blade
     * @param string Email cím, akit keresünk
     * @return JSON
     */
    public function OnkentesKereseseEmailAlapjan(Request $request)
    {
        $Email = $request->input('email');
        $user = null;
        try{
            $user = User::where('email',$Email)->get(['id','name','email']);
        }
        catch(Exception $e)
        {
            $user = 'Hiba az SQL lekérdezésben: '.$e;
        }
        return json_encode($user);
    }

    /**
     * Visszater egy boolean ertekkel, hogy a csoportnak a user-e a letrehozoja.
     * A csoport letrehozo tud csak hozzaadni Onkentest a csoporthoz.
     * @param int Csoport id
     * @param int UserID
     * @return bool True: letrehozo; False: Nem letrehozo
     */
    protected function isJeligeCsoportLetrehozo(int $JeligeCsoportID, int $UserID) : bool
    {
        $result = Jeligek::where('id',$JeligeCsoportID)->where('letrehozo',$UserID)->exists();
        if($result == 1)
            return true;
            else
            return false;
    }

    /**
     * Method: POST
     * XHR
     * csoportkezeles.blade
     * Blade method:  CsoportbaFelvetel
     * Type: JavaScript
     */
    public function OnkentesHozzaadasaCsoporthoz(Request $request)
    {
        $user = auth()->user();
        $Letrehozo = $user["id"]; //actUser

        $felhasznalo_id = $request->input('adduserid');
        $jeligeCsoportID = $request->input('jid');

        $isTag = null;

        try{
            $isTag = JeligeCsoportTagok::where("felhasznalo_id",$felhasznalo_id)->where("jelige_id",$jeligeCsoportID)->first();
            if($isTag->jelige_id == $jeligeCsoportID)
            {
                return 0;
            }
        }
        catch(ErrorException $e)
        {
            $tagokSzama = JeligeCsoportTagok::where("jelige_id",$jeligeCsoportID)->get()->count();
            if($tagokSzama < 3 )
            {
                $jeligeCsoportTag = new JeligeCsoportTagok();
                $jeligeCsoportTag->jelige_id = $jeligeCsoportID;
                $jeligeCsoportTag->felhasznalo_id = $felhasznalo_id;
                $jeligeCsoportTag->aktiv = 1;
                $jeligeCsoportTag->letrehozo = $Letrehozo;
                $jeligeCsoportTag->modosito = null;
                $jeligeCsoportTag->save(); 
                return 1;
            }
            else
            {
                return 3;
            }
           
        }
      
     

        

        

    }

    /**
     * A letrehozo eltavolitja az onkentest..
     */    public function OnkentesEltavolitoLetrehozotol(Request $request)
    {
        $userid = $request->input('userid');$jeligeid = $request->input('jid');
       
       
        $eltavolitas = null;

        $csoportalapito = false;
        $tag = JeligeCsoportTagok::where('felhasznalo_id',$userid)->where('jelige_id',$jeligeid)->first()->letrehozo;
        if($tag ==  $userid )
        {
            $csoportalapito = true;
        }

        if($csoportalapito)
        {
           // $eltavolitas = $this->OnkentesEltavolitasaCsoportbol($ActUserID,$jeligeID);
            try {
                $eltavolitas = $this->OnkentesEltavolitasaCsoportbol( $userid ,$jeligeid);
                $jcsoport = JeligeCsoportTagok::where('jelige_id',$jeligeid)->first();
                
                $csoport = Jeligek::find($jeligeid);
                $csoport->letrehozo = $jcsoport->felhasznalo_id;
                $csoport->save();
                $User = User::find($jcsoport->felhasznalo_id);

                OmrEmail::NewPosyBoss($User,$csoport);
              
            }
            catch(Exception $e)
            {
                return abort(500);
            }
            
        }
        else
        {
           
            $eltavolitas = $this->OnkentesEltavolitasaCsoportbol($userid,$jeligeid);
        }

        if($eltavolitas == 1)
        {
            return  $eltavolitas;
        }
        else abort(403);
    }




}
