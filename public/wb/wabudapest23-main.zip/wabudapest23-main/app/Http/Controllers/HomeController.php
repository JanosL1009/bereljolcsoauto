<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\Msg\OmrEmail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\DB_OMR_Operations;
use App\Http\Models\OnkentesEsemenyekViewModel;
use App\Http\Controllers\Auth;
use App\Http\Models\profilszerkesztesViewModel;
use Illuminate\Support\Carbon;
use \Exception;
use App\User;
use App\Allampolgarsag;
Use App\Model\Felhasznalo;
Use App\FelhasznaloInfo;
use App\BeszeltNyelvek;
use App\PagesDetails;
use App\OnkentesViews;
use App\Egyhazmegyek;
use App\UserEgyhazmegye;
use Throwable;
use App\MyErrorLog;
use App\Http\Models\CustomProfileValidator;
use App\Nyelvismeret;
use App\Http\Models\Traits\TraitAllampolgManipulation;

class HomeController extends Controller
{
    use TraitAllampolgManipulation;
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(Request $request)
    {


        $user = auth()->user();
        $UserId = $user["id"];

        $exist = collect(DB::select("select  count(id) as usercount from felhasznalok where id = ".$UserId))->first();

        if($exist->usercount == 0)
        {
            $user = auth()->user();
            $UserId = $user["id"];

           DB_OMR_Operations::InsertDatable($UserId);
        }

        //
        $model = new OnkentesEsemenyekViewModel($UserId);
        $model->esemenyek = DB_OMR_Operations::GetEsemenyek(); //print($model->esemenyek[0]->nev);die(); igy hasznald!
        $model->api_token = User::find($UserId)->api_token??0;
        $esemenyek = $model->esemenyek;
        foreach($esemenyek as $esemeny)
        {
            $telepules_id = $esemeny->telepules_id;
            $esemeny->telepules_id = DB_OMR_Operations::GetTelepules($telepules_id); //igy a $esemeny->telepules_id-t felulirtuk es a telepules nevet fogja tartalmazni ->
            //a view-ban már igy hasznalhatjuk!
        }

        unset($user);

        $userviews = new OnkentesViews();
        $userviews->slug = $_SERVER['REQUEST_URI'];
        $userviews->visitTimes = Carbon::now();
        $userviews->felhasznalo_id = $user['id'];
        $userviews->save();


        return view('onkentes/esemenyek')->with('model',$model);

        //return view('home');
    }


    public function profilszerkesztes($cpv = null)
    {
       
        $user = auth()->user();
        $id = $user['id'];
        $UserDatas = User::find($id);
        $model = new profilszerkesztesViewModel($id);

        $Felhasznalo = Felhasznalo::find($id);// DB_OMR_Operations::GetFelhasznalo($id);
        $userviews = new OnkentesViews();
        $userviews->slug = $_SERVER['REQUEST_URI'];
        $userviews->visitTimes = Carbon::now();
        $userviews->felhasznalo_id = $user['id'];
        $userviews->save();
        //$FelhasznaloInfo = DB_OMR_Operations::GetFelhasznaloinfo($id);
        $FelhasznaloInfo = FelhasznaloInfo::where('felhasznalo_id',$id)->first();
        $szallastIgenyel = $FelhasznaloInfo->szallastIgenyel;
        //$model->Vezeteknev = $Felhasznalo->vezeteknev??'';//['vezeteknev'];
       //['kozepsonev'];

       if(isset($UserDatas->elotag))
       {
            $model->nevelotag = $UserDatas->elotag;
       }

        if(isset($Felhasznalo->vezeteknev))
        {
            $model->Vezeteknev = $Felhasznalo->vezeteknev;
        }
        else
        {
           
            $nevdarabolva = explode(' ',$UserDatas->name);
            $Insert = new Felhasznalo();
            $Insert->vezeteknev = $nevdarabolva[0];
            $Insert->keresztnev = $nevdarabolva[1];
            $Insert->kozepsonev = "";
        }


        $model->Keresztnev = $Felhasznalo->keresztnev??''; //['keresztnev'];
        $model->Kozepsonev =$Felhasznalo->kozepsonev??'';

        if(!isset($model->Vezeteknev))
        {
           $_userFullName = $UserDatas->name;
            
            $names = explode(" ", $_userFullName);
            $model->Vezeteknev = $names[0];
            $model->Kozepsonev = $names[1];
        }

        try {
            $model->Neme_id = $Felhasznalo->neme;//['neme_id'];

            $model->Nem =  "";
    
            if($model->Neme_id == 0)
            {
                $model->Nem = "Férfi";
            }
            else
            {
                $model->Nem = "Nő";
            }
        }
        catch(Exception $e)
        {
            $model->Neme_id = null;
        }
      


        $model->email =  $user['email'];

        if(isset($Felhasznalo->szulIdo))
        {
           /* $pieces = explode("-", $Felhasznalo->szulIdo);
            $model->szulido = $pieces[0]."/".$pieces[1]."/".$pieces[2];*/
            $model->szulido = $Felhasznalo->szulIdo;
        }

        

        try{
            $model->EletKor = $Felhasznalo->kor;
        }
        catch(Exception $e)
        {
            $model->EletKor = 0;
        }

        try{
            $model->szulhely =  $Felhasznalo->szulhely_ID;
        }
        catch(Exception $e)
        {
            $model->szulhely = '';
        }

        try{
            $model->Telefonszam = $Felhasznalo->telefonszam;
        }
        catch(Exception $e)
        {
            $model->Telefonszam = '';
        }
        
        try{
            if(isset($Felhasznalo->onkentesOrakSzama))
            {
                $model->onkentesOrakSzama =  $Felhasznalo->onkentesOrakSzama;
            }
        }
        catch(Exception $e)
        {
            $model->onkentesOrakSzama = 0;
        }
      

        $model->foteveknyseg_id = $FelhasznaloInfo->tevekenyseg_id;
        $model->foteveknyseg = self::GetHTMLTevekenysegMaker($model->foteveknyseg_id);

        $tev = DB_OMR_Operations::GetFoTevekenyseg_With_HTML_Output($id);

        try{
            $tev = DB_OMR_Operations::GetFoTevekenyseg_With_HTML_Output($id);
        }
        catch(Exception $e)
        {
            $error = new MyErrorLog();
            $error->controller = 'HomeController';
            $error->methodname = 'profilszerk';
            $error->otherDescribe = 'egyhazmegye';
            $error->exceptionMsg = $e->getMessage();
            $error->felhasznalo_id = $id;
            $error->allAvialbleData = 'DB_OMR_Operations::GetFoTevekenyseg_With_HTML_Output($id)';
            $error->save();
            $tev = null;
        }

        $model->fotevekenysegHTML =  $tev;

        if(intval($model->foteveknyseg) == 4)
        {
            $model->munkakor = DB::table('munkahely')->where('felhasznalo_id',$id)->first()->beosztasa;
        }

        $model->polomeret = self::getPolomeret($FelhasznaloInfo->polomeret);
        $model->fogyatekossag =  $FelhasznaloInfo->fogyatekossag;
        //dd($model->fogyatekossag);
        $model->FogyLeirasa = $FelhasznaloInfo->fogyLeirasa;
        $nyelv1 = DB::table('nyelvismeret')->where('felhasznalo_id',$id)->where('sorrend',1)->get()->first();
        $model->nyelv1 = $nyelv1->nyelv??' ';
        $model->nyelv1szint =   self::GetNyelvSzintHTML($nyelv1->nyelvszint_id??0);
        $nyelv2 =  DB::table('nyelvismeret')->where('felhasznalo_id',$id)->where('sorrend',2)->get()->first();
        $model->nyelv2 = $nyelv2->nyelv??' ';
        $model->nyelv2szint =   self::GetNyelvSzintHTML($nyelv2->nyelvszint_id??0);
        $nyelv3 = DB::table('nyelvismeret')->where('felhasznalo_id',$id)->where('sorrend',3)->get()->first();
        $model->nyelv3 = $nyelv3->nyelv??' ';
        $model->nyelv3szint =   self::GetNyelvSzintHTML($nyelv3->nyelvszint_id??0);
        $nyelv4 = DB::table('nyelvismeret')->where('felhasznalo_id',$id)->where('sorrend',4)->get()->first();
        $model->nyelv4 =  $nyelv4->nyelv??' ';
        $model->nyelv4szint =   self::GetNyelvSzintHTML( $nyelv4->nyelvszint_id??0);

        $nyelv5 = DB::table('nyelvismeret')->where('felhasznalo_id',$id)->where('sorrend',5)->get()->first();
        $model->nyelv5 = $nyelv5->nyelv??' ';
        $model->nyelv5szint =   self::GetNyelvSzintHTML($nyelv5->nyelvszint_id??0);

        $allando = DB_OMR_Operations::GetAllandoLakcim($id);

                if(isset($allando->Orszag))
                {
                    $model->all_lakcim_orszag =  DB_OMR_Operations::GetOrszagOptionsId_HTML($allando->Orszag);
                }
                else
                {
                    $model->all_lakcim_orszag = DB_OMR_Operations::GetOrszagOptions_HTML();

                }

          
           
            $model->all_lakcim_telepules = $allando->Telepules??'';
                
               
            $model->all_lakcim_irszam = $allando->IranyitoSzam??'';
            $model->all_lakcim_utca = $allando->Cim??'';
            $All_megyeID = DB_OMR_Operations::GetAllLakcim_MegyeIDForUser($id);
            $model->Megye_AllLakcim = DB_OMR_Operations::GetMegyekOptionsId_HTML($All_megyeID);





        $tartozkodasi = DB_OMR_Operations::GetTartozkodasiLakcim($id);
        $model->tart_lakcim_orszag = $tartozkodasi->OrszagID??0;
        $model->tart_lakcim_telepules = $tartozkodasi->TelepulesID??0;
        
        $model->tart_lakcim_utca = $tartozkodasi->Cim??'';
        $model->tart_lakcim_irszam = $tartozkodasi->IranyitoSzam??'';
        $Tart_megyeID = DB_OMR_Operations::GetTartLakcim_MegyeIDForUser($id);

        $model->Megye_TartLakcim = DB_OMR_Operations::GetMegyekOptionsId_HTML($tartozkodasi->megyeID??0);

        $model->tart_lakcim_orszag = DB_OMR_Operations::GetOrszagOptionsId_HTML($tartozkodasi->OrszagID??0);


        $tev = DB_OMR_Operations::GetFoTevekenyseg_With_HTML_Output($id);
        $model->fotevekenysegHTML = $tev;
        unset($allando);

        $model->profilpic = DB_OMR_Operations::GetProfilkep($id);

        $model->masSzervezetTagja = DB_OMR_Operations::IsMasSzervezetTagja($id);
        //dd($model->masSzervezetTagja);

        $model->MasSzervezetNeve = "";

        if($model->masSzervezetTagja)
        {
            $model->MasSzervezetNeve = DB_OMR_Operations::GetEgyebSzervezet($id)->szervezet_neve;
        }

        $model->CivilSzervezetTagja = DB_OMR_Operations::IsCivilSzervezetTagja($id);

        $model->CivilSzervezetNeve = "";

        if($model->CivilSzervezetTagja)
        {
            $model->CivilSzervezetNeve = DB_OMR_Operations::GetCivilSzervezet($id)->szervezet_neve;
        }

        $kepmode = DB::table('systemsettings')->where('settingkey','=','profilpicmodify')->select('settingvalue')->get()->first();

        if($kepmode->settingvalue == '1')
        {
            $model->kepmodositas = true;
        }
        else
        {
            $model->kepmodositas = false;
        }

        $szemelyesadatok = DB::table('szemelyesadatok')->where('felhasznalo_id','=',$id)->whereNotNull('felhasznalo_id')->get()->first();
        if(isset($szemelyesadatok))
        {
            $model->szemigszam =  $szemelyesadatok->szemigszam;
            $model->anyjaneve =  $szemelyesadatok->anyjaneve;
            $model->allampolgarsag =  $szemelyesadatok->allampolgarsag;
        }
        else{
            $model->szemigszam =  "";
            $model->anyjaneve =  "";
            $model->allampolgarsag = "";
        }

        try
        {
            $model->polotipusa = DB::table('ruhaatado_atvetel')->where('felhasznalo_id','=',$id)->select('polotipus')->get()->first()->polotipus;
        }
        catch(Exception $exception)
        {
            $model->polotipusa = -1;
        }

        $model->BeszelhetoNyelvek = BeszeltNyelvek::orderBy('nyelvNeve','asc')->get('nyelvNeve');

        if(isset($FelhasznaloInfo->etkezesIgenyID))
       {
         $model->setEtkezesiIgenyekArray($FelhasznaloInfo->etkezesIgenyID);
       }

         /**
         * Eloallitja a kimeneti html tartalmat.
         */
        $model->setEtkezesiIgenyekHTML(false);

        $model->igazolasIgenyID = $FelhasznaloInfo->igazolasIgenyID;
        if($model->igazolasIgenyID == 4)
        {
            $model->igazolasIgenyLeiras = $FelhasznaloInfo->igazolasEgyeb;
        }

        $pagesdetails = PagesDetails::find(4);
        $model->setMagyarazoSzovegek("leiras",$pagesdetails->leiras);

        $egyhazmegyek = Egyhazmegyek::all();

        $egyhazmegyek_groups = $egyhazmegyek->groupBy(function($item){
            return $item->felekezet;
        });
        $felekezetek = $egyhazmegyek_groups->keys()->all();

        $egyhazmegyek = $egyhazmegyek->ToJson();

        $valasztottEgyhaz = null;

        try{
                $valasztottEgyhaz = UserEgyhazmegye::where('felhasznalo_id',$id)->select(
                "egyhazmegye_id",
                "egyebInputValue",
                "nemTag"
            )->first();
            $valasztottEgyhaz = json_encode($valasztottEgyhaz);
        }
        catch(Throwable $t)
        {
            $valasztottEgyhaz = null;
        }

        $nevelotag = $UserDatas->elotag??'none';

        $allampolgarsagLista = \App\Allampolgarsag::orderBy('allampolgarsag', 'ASC')->get();
       
        //dd($this->getManupulateListOrder($allampolgarsagLista));
        $allampolgarsagLista = $this->getManupulateListOrder($allampolgarsagLista);
        if(isset($cpv))
        {
            
            return view('profilszerkesztes',['egyhazmegyek' => $egyhazmegyek,
            'felekezetek' => $felekezetek,
             'valasztottEgyhazMegye' =>  $valasztottEgyhaz,
             'nevelotag' => $nevelotag,
             'szallastIgenyel' => $szallastIgenyel
            ])->with('model',$model)->with('allampolgarsagLista' ,$allampolgarsagLista)->with('cpv',$cpv);
        }
        else
        {
            return view('profilszerkesztes',['egyhazmegyek' => $egyhazmegyek,
            'felekezetek' => $felekezetek,
             'valasztottEgyhazMegye' =>  $valasztottEgyhaz,
             'nevelotag' => $nevelotag,
             'szallastIgenyel' => $szallastIgenyel
            ])->with('model',$model)->with('allampolgarsagLista' ,$allampolgarsagLista);
        }

        
    }


    public function profil()
    {
        $user = auth()->user();
        $id = $user['id'];
        $UserDatas = User::find($id);
        $userviews = new OnkentesViews();
        $userviews->slug = $_SERVER['REQUEST_URI'];
        $userviews->visitTimes = Carbon::now();
        $userviews->felhasznalo_id = $user['id'];
        $userviews->save();

        $model = new profilszerkesztesViewModel($id);
        $model->api_token = $UserDatas->api_token;
        $Felhasznalo = Felhasznalo::find($id);// DB_OMR_Operations::GetFelhasznalo($id);

        $FelhasznaloInfo = FelhasznaloInfo::where('felhasznalo_id',$id)->first();
        $szallastIgenyel = $FelhasznaloInfo->szallastIgenyel;
        try{
            $model->Vezeteknev = $Felhasznalo->vezeteknev??'';//['vezeteknev'];
        
        }
        catch(Exception $e)
        {
            $model->Vezeteknev = '';//['vezeteknev'];
        }

        try{
            $model->Keresztnev = $Felhasznalo->keresztnev??''; 
        }
        catch(Exception $e)
        {
            $model->Keresztnev = '';
        }
       
        try{
            $model->Kozepsonev =$Felhasznalo->kozepsonev??''; 
        }
        catch(Exception $e)
        {
            $model->Kozepsonev = '';
        }


        if(!isset($model->Vezeteknev))
        {
            $_userFullName = User::where('id',$id)->first()->name;
            $names = explode(" ", $_userFullName);
            $model->Vezeteknev = $names[0];
            $model->Kozepsonev = $names[1];
        }

        try {
            $model->Neme_id = $Felhasznalo->neme;//['neme_id'];

            $model->Nem =  "";
    
            if($model->Neme_id == 0)
            {
                $model->Nem = "Férfi";
            }
            else
            {
                $model->Nem = "Nő";
            }
        }
        catch(Exception $e)
        {
            $model->Neme_id = null;
        }


        $model->email =  $user['email'];

        if(isset($Felhasznalo->szulIdo))
        {
            $pieces = explode("-", $Felhasznalo->szulIdo);
            $model->szulido = $pieces[0]."/".$pieces[1]."/".$pieces[2];
        }

        try{
            $model->EletKor = $Felhasznalo->kor;
        }
        catch(Exception $e)
        {
            $model->EletKor = 0;
        }

        try{
            $model->szulhely =  $Felhasznalo->szulhely_ID;
        }
        catch(Exception $e)
        {
            $model->szulhely = '';
        }

        try{
            $model->Telefonszam = $Felhasznalo->telefonszam;
        }
        catch(Exception $e)
        {
            $model->Telefonszam = '';
        }
        
        try{
            if(isset($Felhasznalo->onkentesOrakSzama))
            {
                $model->onkentesOrakSzama =  $Felhasznalo->onkentesOrakSzama;
            }
        }
        catch(Exception $e)
        {
            $model->onkentesOrakSzama = 0;
        }


        if(isset($Felhasznalo->onkentesOrakSzama))
        {
            $model->onkentesOrakSzama =  $Felhasznalo->onkentesOrakSzama;
        }


        try{
            $model->foteveknyseg_id = $FelhasznaloInfo->tevekenyseg_id;
        }
        catch(Exception $e)
        {
            $error = new MyErrorLog();
            $error->controller = 'HomeController';
            $error->methodname = 'profilszerk';
            $error->otherDescribe = 'egyhazmegye';
            $error->exceptionMsg = $e->getMessage();
            $error->felhasznalo_id = $id;
            $error->allAvilableData = 'DB_OMR_Operations::GetFoTevekenyseg_With_HTML_Output($id)';
            $error->save();
            $tev = null;

            $finfo = new FelhasznaloInfo();
            $finfo->felhasznaloinfoid = $id;
            $finfo->felhasznalo_id = $id;
            $finfo->save();
            $model->foteveknyseg_id =  $id;
        }
      
        $model->foteveknyseg = self::GetHTMLTevekenysegMaker($model->foteveknyseg_id);

        $tev = DB_OMR_Operations::GetFoTevekenyseg_With_HTML_Output($id);
        $model->fotevekenysegHTML =  $tev;

        if(intval($model->foteveknyseg) == 4)
        {
            $model->munkakor = DB::table('munkahely')->where('felhasznalo_id',$id)->first()->beosztasa;
        }

        $model->polomeret = $this->getPolomeret($FelhasznaloInfo->polomeret);
        $model->fogyatekossag =  $FelhasznaloInfo->fogyatekossag;
        $model->FogyLeirasa = $FelhasznaloInfo->fogyLeirasa;
        $nyelv1 = DB::table('nyelvismeret')->where('felhasznalo_id',$id)->where('sorrend',1)->get()->first();
        $model->nyelv1 = $nyelv1->nyelv??' ';
        $model->nyelv1szint =   self::GetNyelvSzintHTML($nyelv1->nyelvszint_id??0);

        $nyelv2 = DB::table('nyelvismeret')->where('felhasznalo_id',$id)->where('sorrend',2)->get()->first();
        $model->nyelv2 = $nyelv2->nyelv??' ';
        $model->nyelv2szint =   self::GetNyelvSzintHTML($nyelv2->nyelvszint_id??0);
        $nyelv3 = DB::table('nyelvismeret')->where('felhasznalo_id',$id)->where('sorrend',3)->get()->first();
        $model->nyelv3 = $nyelv3->nyelv??' ';
        $model->nyelv3szint =   self::GetNyelvSzintHTML($nyelv3->nyelvszint_id??0);

        $nyelv4 = DB::table('nyelvismeret')->where('felhasznalo_id',$id)->where('sorrend',4)->get()->first();
        $model->nyelv4 = $nyelv4->nyelv??' ';
        $model->nyelv4szint =   self::GetNyelvSzintHTML($nyelv4->nyelvszint_id??0);

        $nyelv5 = DB::table('nyelvismeret')->where('felhasznalo_id',$id)->where('sorrend',5)->get()->first();
        $model->nyelv5 = $nyelv5->nyelv??' ';
        $model->nyelv5szint =   self::GetNyelvSzintHTML($nyelv5->nyelvszint_id??0);

        $allando = DB_OMR_Operations::GetAllandoLakcim($id);

                if(isset($allando->Orszag))
                {
                    $model->all_lakcim_orszag =  DB_OMR_Operations::GetOrszagOptionsId_HTML($allando->Orszag);

                }
                else
                {
                    $model->all_lakcim_orszag = DB_OMR_Operations::GetOrszagOptions_HTML();

                }

            $model->all_lakcim_telepules = $allando->Telepules??'';
            $model->all_lakcim_irszam = $allando->IranyitoSzam??'';
            $model->all_lakcim_utca = $allando->Cim??'';
            $All_megyeID = DB_OMR_Operations::GetAllLakcim_MegyeIDForUser($id);
            $model->Megye_AllLakcim = DB_OMR_Operations::GetMegyekOptionsId_HTML($All_megyeID);





        $tartozkodasi = DB_OMR_Operations::GetTartozkodasiLakcim($id);
        $model->tart_lakcim_orszag = $tartozkodasi->OrszagID??0;
        $model->tart_lakcim_telepules = $tartozkodasi->TelepulesID??0;
        $model->tart_lakcim_utca = $tartozkodasi->Cim??'';
        $model->tart_lakcim_irszam = $tartozkodasi->IranyitoSzam??'';
        $Tart_megyeID = DB_OMR_Operations::GetTartLakcim_MegyeIDForUser($id);

        $model->Megye_TartLakcim = DB_OMR_Operations::GetMegyekOptionsId_HTML($tartozkodasi->megyeID??0);

        $model->tart_lakcim_orszag = DB_OMR_Operations::GetOrszagOptionsId_HTML($tartozkodasi->OrszagID??0);


        $tev = DB_OMR_Operations::GetFoTevekenyseg_With_HTML_Output($id);
        $model->fotevekenysegHTML = $tev;
        unset($allando);

        $model->profilpic = DB_OMR_Operations::GetProfilkep($id);

        $model->masSzervezetTagja = DB_OMR_Operations::IsMasSzervezetTagja($id);

        $model->MasSzervezetNeve = "";

        if($model->masSzervezetTagja)
        {
            $model->MasSzervezetNeve = DB_OMR_Operations::GetEgyebSzervezet($id)->szervezet_neve;
        }
       // dd($model->masSzervezetTagja ,$model->MasSzervezetNeve);
        $model->CivilSzervezetTagja = DB_OMR_Operations::IsCivilSzervezetTagja($id);

        $model->CivilSzervezetNeve = "";

        if($model->CivilSzervezetTagja)
        {
            $model->CivilSzervezetNeve = DB_OMR_Operations::GetCivilSzervezet($id)->szervezet_neve;
        }
      
        $kepmode = DB::table('systemsettings')->where('settingkey','=','profilpicmodify')->select('settingvalue')->get()->first();

        if($kepmode->settingvalue == '1')
        {
            $model->kepmodositas = true;
        }
        else
        {
            $model->kepmodositas = false;
        }

        $szemelyesadatok = DB::table('szemelyesadatok')->where('felhasznalo_id','=',$id)->whereNotNull('felhasznalo_id')->get()->first();
        if(isset($szemelyesadatok))
        {
            $model->szemigszam =  $szemelyesadatok->szemigszam;
            $model->anyjaneve =  $szemelyesadatok->anyjaneve;
            try
            {
                $model->allampolgarsag = Allampolgarsag::find( $szemelyesadatok->allampolgarsag)->allampolgarsag;
            }
            catch(Exception $e)
            {
                $model->allampolgarsag = 'Nincs kitöltve';
            }
            
        }
        else{
            $model->szemigszam =  "";
            $model->anyjaneve =  "";
            $model->allampolgarsag = "";
        }

        try
        {
            $model->polotipusa = DB::table('ruhaatado_atvetel')->where('felhasznalo_id','=',$id)->select('polotipus')->get()->first()->polotipus;
        }
        catch(Exception $exception)
        {
            $model->polotipusa = -1;
        }

       if(isset($FelhasznaloInfo->etkezesIgenyID))
       {
         $model->setEtkezesiIgenyekArray($FelhasznaloInfo->etkezesIgenyID);
       }


         /**
         * Eloallitja a kimeneti html tartalmat.
         */
        $model->setEtkezesiIgenyekHTML(true);

        $model->igazolasIgenyID = $FelhasznaloInfo->igazolasIgenyID;
        if($model->igazolasIgenyID == 4)
        {
            $model->igazolasIgenyLeiras = $FelhasznaloInfo->igazolasEgyeb;
        }

        $pagesdetails = PagesDetails::find(5);
        $model->setMagyarazoSzovegek("leiras",$pagesdetails->leiras);

        $titulus = $UserDatas->titulus??'none';
        $nevelotag = $UserDatas->elotag??'none';


        return view('profil_zarolt',['message' => '1', 'titulus' => $titulus,
        'nevelotag' => $nevelotag,
        'szallastIgenyel' => $szallastIgenyel
        ])->with('model',$model);
    }



    public function profilszerk(Request $request)
    {
        $user = auth()->user();
        $id = $user['id'];
        /**validacio sajat.. */
        $profilkepValid = false;
        $cpv = new CustomProfileValidator();
        $cpv->setGenerals($request->input('vezeteknev'),$request->input('kozepsonev'),$request->input('telszam'),
         $request->input('szuletesiIdoEv')
    ,$request->input('szuletesiIdoHo'),$request->input('szuletesiIdoNap'),$request->input('szulhely'),
    $request->input('userneme'),$request->input('mothername'),$request->input('nationality'),$request->input('szemigszam'));

        $cpv->setAllando($request->input('al_lakcim_orszag'), $request->input('al_lakcim_megye'),
        $request->input('al_lakcim_telepules'),$request->input('al_lakcim_irszam'),$request->input('al_lakcim_utca')
        );
       // dd($request->input('al_lakcim_irszam'));
            if($request->input('isTartLakcim') != 'TartAzonos')
            {
                $cpv->setTartozkodasi($request->input('tart_lakcim_orszag'),
                $request->input('tart_lakcim_telepules'),$request->input('tart_lakcim_irszam'),$request->input('tart_lakcim_utca'),
                $request->input('tart_lakcim_megye')
                );

            }
            if($request->input('masSzervezetTagja') == 1)
            {
               
                $cpv->setQuestions1($request->input("egyebSzervezet"));
            }
            
            if($request->input('masCivilSzervezetTagja')  == "1")
            {
                $cpv->setQuestions2($request->input("civilSzervezet"));
            }

            if($request->input('fogyatekossag')  == "1" || $request->input('fogyatekossag')  == "0")
            {
                $cpv->setFogy(true);
            } else {$cpv->setFogy(false);}

            $cpv->setRuha($request->input("userpolomeret"));
            
            $ruhatipusa = $request->input('userpolotipusa');
            if($ruhatipusa == "0" || $ruhatipusa == "1")
            {
                $cpv->setRuhaTipusa(true);
            } else  $cpv->setRuhaTipusa(false);
/*
            $felekezet = $request->input('Felekezetek');
            $egyhazmegye = $request->input('egyhazmegyek');
                 // dd($fel );
            if(isset($felekezet)){
                //dd($felekezet);
                  $cpv->setFelekezet(true); 

                  if($egyhazmegye == "none")
                  {
                    $cpv->setEgyhaz(false); 
                  }

                  if($felekezet == "Nem tartozom felekezethez")
                  {
                    $cpv->setFelekezet(true); 
                  }
                  if($felekezet == "Római Katolikus Egyházmegye")
                  {
                    $cpv->setFelekezet(true); 
                    $cpv->setEgyhaz(true);
                  }
                  if($felekezet == "Görög Katolikus Egyházmegye")
                  {
                    $cpv->setFelekezet(true); 
                    $cpv->setEgyhaz(true);
                  }
                  if($felekezet == "Egyéb")
                  {
                      $egyebinput = $request->input('egyhazinput');
                      if(isset($egyebinput))
                      {
                        $cpv->EgyhazEgyebInput(true);
                      }
                      else 
                      $cpv->EgyhazEgyebInput(false);
                    
                  }
                 
            }
            else{
                //dd($felekezet);
                $cpv->setFelekezet(false); 
            }
            //else $cpv->setEgyhazKozosseg(false);
            */
           
            $ft = $request->input('tevekenyseg');
            if($ft === NULL)
            {
                
                $cpv->setFoteveknyseg(false,(int)$ft);
            }
            else 
            {
                $cpv->setFoteveknyseg(true,(int)$ft);
                if(isset($ft))
                {
                    if($request->input("tevekenyseg") == 1)
                    {
                        $cpv->setFotevFelsoIskola($request->input('foisk')??'',$request->input('szakneve')??'',intval($request->input('evfolyam')));
                    }
                    if($request->input("tevekenyseg") == 2)
                    {
                        $cpv->setFotevKozepIskola($request->input('kozepisk')??'',intval($request->input('kozepiskoszt')));
                    }
                    if($request->input("tevekenyseg") == 3)
                    {
                        $cpv->setFotevAltIskola($request->input('altisk')??'',intval($request->input('altiskoszt')));
                    }
                    if($request->input("tevekenyseg") == 4)
                    {
                        $cpv->setFotevMunka($request->input('munkakor')??'');
                    }
                }
            }
            
            

                $egyebSzerv = $request->input("masSzervezetTagja");
            if(isset($egyebSzerv))
            {
                $cpv->setEgyebszervezet(true);
            }
            else{
                $cpv->setEgyebszervezet(false);
            }
            $civilSzerv = $request->input("masCivilSzervezetTagja");
            if(isset($civilSzerv))
            {
                $cpv->setCivilszervezet(true);
            }
            else
            {
                $cpv->setCivilszervezet(false);
            }

            $isgdpr = $request->input('isgdpr');
            if($isgdpr != 'on')
            {
                $cpv->setAdatkezelesi(false);
            }
            $cpv->setISFormValid();
    
        //dd($cpv);
        $cpv->ProfilPic($id);

        if(!$cpv->is_FormValid())
        {
            //dd($cpv->getMessage());
            $valid = true;
            $FelhasznaloTable = Felhasznalo::find($id);
            //dd( $UserTable);
            if(!isset($FelhasznaloTable->vezeteknev)) $valid = false;
            if(!isset($FelhasznaloTable->neme)) $valid = false;
            if(!isset($FelhasznaloTable->szulIdo)) $valid = false;
            if(!isset($FelhasznaloTable->szulhely_ID)) $valid = false;
            if(!isset($FelhasznaloTable->telefonszam)) $valid = false;
            
            if($FelhasznaloTable->profilkep != "blank-profile-pic-omr.png")
            {
                $profilkepValid = true;
            }

            if($valid)
            {
                $json = json_encode($cpv);
            
                return back()->withErrors($json, "cpv");
            }
            else
            {
               $inputs = array();
              
                foreach($request->request as $key => $value)
                {
                   // $inp[$key] = $value;
                   if($key == "nevelotag")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }

                    if($key == "telszam")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                    if($key == "vezeteknev")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                    if($key == "kozepsonev")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                    if($key == "keresztnev")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                    if($key == "sajatEmailCim")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                    if($key == "szuletesiIdoEv")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                    if($key == "szuletesiIdoHo")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                    if($key == "szuletesiIdoNap")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                    if($key == "szulhely")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                    if($key == "userneme")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                    if($key == "mothername")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }

                    if($key == "nationality")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }

                    if($key == "szemigszam")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }

                    if($key == "al_lakcim_orszag")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                    if($key == "al_lakcim_megye")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                    if($key == "al_lakcim_telepules")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                    if($key == "al_lakcim_irszam")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                    if($key == "al_lakcim_utca")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                    if($key == "tart_lakcim_orszag")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                    if($key == "tart_lakcim_megye")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                    if($key == "tart_lakcim_telepules")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                    if($key == "tart_lakcim_irszam")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                    if($key == "tart_lakcim_utca")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                    if($key == "isTartLakcim")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                    if($key == "masSzervezetTagja")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                    if($key == "egyebSzervezet")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                    if($key == "masCivilSzervezetTagja")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                    if($key == "civilSzervezet")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                    if($key == "Felekezetek")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                  /*  if($key == "egyhazmegyek")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }*/
                    if($key == "tevekenyseg")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                    if($key == "egyhazinput")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                    if($key == "fogyatekossag")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                    if($key == "fogyLeirasa")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                    if($key == "userpolomeret")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                    if($key == "userpolotipusa")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                    if($key == "foisk")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                    if($key == "szakneve")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                    if($key == "evfolyam")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                    if($key == "kozepiskoszt")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                    if($key == "kozepisk")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                    if($key == "altisk")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                    if($key == "altiskoszt")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                    if($key == "munkahely")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                    if($key == "munkakor")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                    if($key=="nyelv1")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                    if($key=="nyelv2")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                    if($key=="nyelv3")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                    if($key=="nyelv4")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                    if($key=="nyelv5")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                    if($key=="nyelv1szint")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                    if($key=="nyelv2szint")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                    if($key=="nyelv3szint")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                    if($key=="nyelv4szint")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                    if($key=="nyelv5szint")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                    if($key=="igazolas")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }
                    if($key=="etkezes")
                    {
                        $inp[$key] = $value;
                        array_push($inputs,$inp);
                    }




                    
                } //foreach vege
                //dd(json_encode($inputs));
                $json = json_encode($cpv);
                $inputJson = json_encode(end($inputs));
               // $inputJson =  array_merge(json_decode($inputJson, true), json_decode($json, true));
                return back()->withErrors($json, "cpv")->withErrors($inputJson,"oldInputs");
                

            }

            
           
        }

        //validacio vege
       

        $nev = $request->input('userfullname');
        $vezeteknev = ucfirst(mb_convert_case($request->input('vezeteknev'), MB_CASE_TITLE, "UTF-8"));

        $kozepsonev = ucfirst( mb_convert_case($request->input('kozepsonev'), MB_CASE_TITLE, "UTF-8"));
        $keresztnev = ucfirst(mb_convert_case($request->input('keresztnev'), MB_CASE_TITLE, "UTF-8"));

        $usernemeValue = $request->input('userneme');
       

        $mail = $request->input('sajatEmailCim');
        
        $telszam = null;
        try{
            $telszam = $request->input('telszam');
           
            for($i = 0; $i < strlen($telszam); $i++)
            {
                $character = $telszam[$i];
                if(is_int(intval($character)) == false)
                {
                    throw new Exception();
                }
            }
           
        }
        catch(Exception $e)
        {
            return back()->withErrors("A telefonszám kizárólag számokat tartalmazhat! Pl: 0036305556644","telszam")->withInput();
        }
        

        $szulido = $request->input('szuletesiIdoEv')."-".$request->input('szuletesiIdoHo')."-".$request->input('szuletesiIdoNap');
        /**
         * @var A szuletesi idot szamitja ki a PHP/Carbon segitsegevel
         */
        $years = null;
         try{
            $years = Carbon::parse($szulido)->age;
          
         }
         catch(Exception $e)
         {
           // dd('hiba: '.$years);
            $years = 'error';
         }

        

        $isLakcim = $request->input('isTartLakcim');

            $al_lakcim_orszag = $request->input('al_lakcim_orszag');
            $al_lakcim_telepules = $request->input('al_lakcim_telepules');

            try
            {
                if(isset($al_lakcim_telepules))
                {
                     if(is_numeric($al_lakcim_telepules))
                    {
                        throw new Exception();
                    }
                    
                }
                
            }
            catch(Exception $e)
            {
                return back()->withErrors("Kérjük érvényes település nevet adjon meg!","lakcim_telepules")->withInput();
            }

            $al_lakcim_irszam = $request->input('al_lakcim_irszam');
            $al_lakcim_utca = $request->input('al_lakcim_utca');
            $al_lakcim_megye = $request->input('al_lakcim_megye')??0;


            $tart_lakcim_orszag = null;
            $tart_lakcim_telepules = null;
            $tart_lakcim_irszam = null;
            $tart_lakcim_utca = null;
            $tart_lakcim_megye = null;

        if($isLakcim == "TartAzonos")
        {
            $tart_lakcim_orszag = $request->input('al_lakcim_orszag');
            $tart_lakcim_telepules = $request->input('al_lakcim_telepules');
            $tart_lakcim_irszam = $request->input('al_lakcim_irszam');
            $tart_lakcim_utca = $request->input('al_lakcim_utca');
            $tart_lakcim_megye = $request->input('al_lakcim_megye')??0;

        }
        else if(!isset($isLakcim))
        {
            $tart_lakcim_orszag = $request->input('tart_lakcim_orszag');
            $tart_lakcim_telepules = $request->input('tart_lakcim_telepules');
            $tart_lakcim_irszam = $request->input('tart_lakcim_irszam');
            $tart_lakcim_utca = $request->input('tart_lakcim_utca');
            $tart_lakcim_megye = $request->input('tart_lakcim_megye')??0;
        }
        else
        {
            //error
        }

        $szulhely = ucfirst(mb_convert_case($request->input('szulhely'), MB_CASE_TITLE, "UTF-8"));


        $tevekenyseg = $request->input('tevekenyseg');
        if(isset($tevekenyseg))
        {
            switch($tevekenyseg)
            {
                case 1:
                    $szakneve = $request->input('szakneve');
                    $foiskneve = $request->input('foisk');
                    $foiskEvfolyam =  $request->input('evfolyam');

                        if(isset($szakneve ) && isset($foiskneve) && isset($foiskEvfolyam))
                        {
                            DB_OMR_Operations::InsertTevekenysegEgyetemFosuli($id,$foiskneve,$szakneve,$foiskEvfolyam);
                        }
                break;

                case 2:
                    $kozepsuliNeve =  ucfirst(mb_strtolower(mb_convert_case($request->input('kozepisk'), MB_CASE_TITLE, "UTF-8")));
                   
                    $kozepsuliOsztaly =  $request->input('kozepiskoszt');

                    if(isset($kozepsuliNeve) && isset($kozepsuliOsztaly))
                    {
                        DB_OMR_Operations::InsertTevekenysegIskola($id,$kozepsuliNeve,$kozepsuliOsztaly,2);
                    }
                break;

                case 3:
                    $altiskNeve =  $request->input('altisk');
                    $altiskOsztaly =  $request->input('altiskoszt');

                    if(isset($altiskNeve) && isset($altiskOsztaly))
                    {
                        DB_OMR_Operations::InsertTevekenysegIskola($id,$altiskNeve,$altiskOsztaly,3);
                    }
                break;

                case 4:
                    $munkahelyNeve = '';//$request->input('munkahely'); keresre kiveve!
                    $munkakor = $request->input('munkakor');

                    if(isset($munkakor))
                    {
                        DB_OMR_Operations::InsertTevekenysegMunkahely($id,$munkahelyNeve,$munkakor);

                    }
                break;
            }
        }



        $fogyatekossag = $request->input('fogyatekossag');
        $userpolomeret = $request->input('userpolomeret');

       

        $masSzervezetTagja = $request->input('masSzervezetTagja');

        if($masSzervezetTagja == "1")
        {
            $szervezetNeve = ucfirst($request->input('egyebSzervezet'));
            DB::table('egyeb_szervezet')->updateOrInsert(['felhasznalo_id' => $id],['szervezet_neve' => $szervezetNeve]);

        }
        else if($masSzervezetTagja == "0")
        {
            
            DB::table('egyeb_szervezet')->updateOrInsert(['felhasznalo_id' => $id],['szervezet_neve' => "Nem"]);

        }
        else
        {
            DB::table('egyeb_szervezet')->where('felhasznalo_id',$id)->update(["szervezet_neve" => 'NULL']);
        }

        $masCivilSzervezetTagja = $request->input('masCivilSzervezetTagja');

        if($masCivilSzervezetTagja == '1')
        {
            $szervezetNeve = ucfirst($request->input('civilSzervezet'));
            DB::table('civil_szervezet')->updateOrInsert(['felhasznalo_id' => $id],['szervezet_neve' => $szervezetNeve]);

        }
        else if($masCivilSzervezetTagja == '0')
        {
           // $szervezetNeve = ucfirst($request->input('civilSzervezet'));
            DB::table('civil_szervezet')->updateOrInsert(['felhasznalo_id' => $id],['szervezet_neve' => "Nem"]);

        }
        else
        {
            DB::table('civil_szervezet')->where('felhasznalo_id',$id)->update(["szervezet_neve" => 'NULL']);
        }

        $fogyLeirasa = $request->input('fogyLeirasa');


        DB_OMR_Operations::UpdateAllandoLakcim($id,$al_lakcim_irszam,ucfirst($al_lakcim_telepules),$al_lakcim_orszag,ucfirst($al_lakcim_utca),$al_lakcim_megye);
        //DB_OMR_Operations::UpdateFelhasznalok($id,$vezeteknev,$keresztnev,$kozepsonev,$usernemeValue,'null',$szulido,$szulhely,1,'null',$telszam, $years);
        //uj kodresz = refaktor
        try {
            $felhasznalo = Felhasznalo::find( $id );
        $felhasznalo->vezeteknev = $vezeteknev;
        $felhasznalo->keresztnev = $keresztnev;
        $felhasznalo->kozepsonev = $kozepsonev;
        $felhasznalo->neme = $usernemeValue;
        $felhasznalo->email = $mail;
        $felhasznalo->szulIdo = $szulido;
        $felhasznalo->szulhely_ID = $szulhely;$felhasznalo->orszag_ID = null;
        $felhasznalo->lakcim = null;
        $felhasznalo->telefonszam = $telszam;

        if($years == 'error')
        {
            $felhasznalo->kor = 1;
        }
        else  $felhasznalo->kor = $years;
        

        }
        catch(Exception $e)
        {
            $felhasznalo = new Felhasznalo();
            $felhasznalo->id = $id;
        $felhasznalo->vezeteknev = $vezeteknev;
        $felhasznalo->keresztnev = $keresztnev;
        $felhasznalo->kozepsonev = $kozepsonev;
        $felhasznalo->neme = $usernemeValue;
        $felhasznalo->email = $mail;
        $felhasznalo->szulIdo = $szulido;
        $felhasznalo->szulhely_ID = $szulhely;$felhasznalo->orszag_ID = null;
        $felhasznalo->lakcim = null;
        $felhasznalo->telefonszam = $telszam;
        if($years == 'error')
        {
            $felhasznalo->kor = 1;
        }
        else  $felhasznalo->kor = $years;
        }
        finally{
            $felhasznalo->save();
        }
        
        


        DB_OMR_Operations::UpdateFelhasznaloInfok($id,$tevekenyseg,$userpolomeret,$fogyatekossag,$fogyLeirasa );
        DB_OMR_Operations::UpdateTartozkodasiLakcim($id,$tart_lakcim_irszam,ucfirst($tart_lakcim_telepules),$tart_lakcim_orszag,ucfirst($tart_lakcim_utca),$tart_lakcim_megye);

        $szemigszam = $request->input('szemigszam');
        $anyjaneve = ucfirst(mb_convert_case($request->input('mothername'), MB_CASE_TITLE, "UTF-8"));

        $allampolgarsag = $request->input('nationality');
        DB::table('szemelyesadatok')->updateOrInsert(["felhasznalo_id" => $id],["szemigszam" =>  strtoupper($szemigszam),
            "email" => "",
            "anyjaneve" => $anyjaneve ,
            "allampolgarsag" => ucfirst(mb_convert_case($allampolgarsag, MB_CASE_TITLE, "UTF-8"))
             ]);


        $polotipusa = $request->userpolotipusa;

        DB::table('ruhaatado_atvetel')->updateOrInsert(['felhasznalo_id' => $id],['polotipus' => $polotipusa]);

        $felhasznaloinfoModel = FelhasznaloInfo::where('felhasznalo_id',$id)->first();
        $felhasznaloinfoModel->polotipus = $polotipusa;




        $updatedUser = User::find($id);
        
        if($request->input('nevelotag') != "none")
        {
            $updatedUser->elotag = $request->input('nevelotag');
        }
        else
        {
            $updatedUser->elotag = null;
        }
        $updatedUser->name =  $updatedUser->elotag.' '.$vezeteknev.' '.$kozepsonev.' '.$keresztnev;
        $updatedUser->updated_at = Carbon::now();
        $updatedUser->modifier = $id;
        $updatedUser->save();
        DB::table('users')->where('id',$id)->update(['updated_at' => Carbon::now(),'modifier' => $id]);

        if(\DB::table('jogosultsag')->where('felhasznaloszint_id', 1)->where('felhasznalo_id', auth()->user()->id)->first()){
            return redirect('/admin/profilszerkesztes');
        }


        $felhasznaloinfoModel->etkezesIgenyID = $request->input('etkezes');
        
        $felhasznaloinfoModel->igazolasIgenyID = $request->input('igazolas');

        if($felhasznaloinfoModel->igazolasIgenyID == 4) //egyeb
        {
            $felhasznaloinfoModel->igazolasEgyeb = $request->input('egyedIgeny');
        }

        $szallas = $request->input('szallastIgenyel');
        if($szallas == "1")
        {
            $felhasznaloinfoModel->szallastIgenyel = 1;
        }
        if($szallas == "0")
        {
            $felhasznaloinfoModel->szallastIgenyel = 0;
        }
        

        $felhasznaloinfoModel->save();





        $felekezet = $request->input('Felekezetek');
        //dd($felekezet);
        $egyhazmegye = null; $egyebInput = null;
        switch((string)$felekezet)
        {


            case "Római Katolikus Egyház":
                    $egyhazmegye = $request->input('egyhazmegyek');//dd($egyhazmegye);
                    $EgyhazmegyeID = 1;
                    try{
                        $EgyhazmegyeID = Egyhazmegyek::where('nev',$egyhazmegye)->first()->id;
                    }
                    catch(Exception $e)
                    {
                        $error = new MyErrorLog();
                        $error->controller = 'HomeController';
                        $error->methodname = 'profilszerk';
                        $error->otherDescribe = 'egyhazmegye';
                        $error->exceptionMsg = $e->getMessage();
                        $error->felhasznalo_id = $id;
                        $error->allAvilableData = $request;
                        $error->save();
                        return back();
                    }
                   // dd($id);
                    $useregyhazmegye = UserEgyhazmegye::updateOrCreate(
                        ['felhasznalo_id' => $id],
                        ['egyhazmegye_id' => $EgyhazmegyeID,
                            "nemTag" => 0,
                         'modosito' => $id]
                    );
                    //dd($useregyhazmegye);
                    /*
                    $useregyhazmegye->felhasznalo_id = $user['id'];
                    $useregyhazmegye->egyhazmegye_id = $EgyhazmegyeID;
                    $useregyhazmegye->modosito = $user['id'];
                    $useregyhazmegye->egyebInputValue = null;
                    $useregyhazmegye->nemTag = null;
                    $useregyhazmegye->save();*/
            break;
            case "Görög Katolikus Egyház":
                $egyhazmegye = $request->input('egyhazmegyek');//dd($egyhazmegye);
                $EgyhazmegyeID = Egyhazmegyek::where('nev',$egyhazmegye)->first()->id;
                $useregyhazmegye = UserEgyhazmegye::updateOrCreate(
                    ['felhasznalo_id' => $id],
                    ['egyhazmegye_id' => $EgyhazmegyeID, 'modosito' => $id]
                );
        break;
            case 'Egyéb':
                $egyebInput = $request->input('egyhazinput');
                $EgyhazmegyeID = Egyhazmegyek::where('nev','Egyéb')->first()->id;
                
                    try{
                        if(!isset($egyebInput ))
                        {
                            throw new Exception();
                        }
                    }
                    catch(Exception $e)
                    {
                        return back()->withErrors("Kérjük írja be, melyik 'egyéb' egyházmegyéhez, felekezethez tartozik! A mező nem lehet üres!","egyebures")->withInput();
                    }
                
                UserEgyhazmegye::updateOrCreate(
                    ['felhasznalo_id' => $id],
                    ['egyhazmegye_id' => $EgyhazmegyeID, 'modosito' => $id,'egyebInputValue' => $egyebInput ]
                );
            break;
            case  'egyéb':
                $egyebInput = $request->input('egyhazinput');
                $EgyhazmegyeID = Egyhazmegyek::where('nev','Egyéb')->first()->id;
                
                    try{
                        if(!isset($egyebInput ))
                        {
                            throw new Exception();
                        }
                    }
                    catch(Exception $e)
                    {
                        return back()->withErrors("Kérjük írja be, melyik 'egyéb' egyházmegyéhez, felekezethez tartozik! A mező nem lehet üres!","egyebures")->withInput();
                    }
                
                UserEgyhazmegye::updateOrCreate(
                    ['felhasznalo_id' => $id],
                    ['egyhazmegye_id' => $EgyhazmegyeID, 'modosito' => $id,'egyebInputValue' => $egyebInput ]
                );
            break;
            case 'Nem tartozom felekezethez':
                UserEgyhazmegye::updateOrCreate(
                    ['felhasznalo_id' => $id],
                    ['egyhazmegye_id' => 10, 'modosito' => $id,'nemTag' => 1 ]
                );
            break;
            default:
            //$EgyhazmegyeID = Egyhazmegyek::where('nev',$egyebInput)->first()->id;
            UserEgyhazmegye::updateOrCreate(
                ['felhasznalo_id' => $id],
                ['egyhazmegye_id' => 10, 'modosito' => $id,'nemTag' => 1 ]
            );
           /* $useregyhazmegye->felhasznalo_id = $user['id'];
            $useregyhazmegye->egyhazmegye_id = 10;
            $useregyhazmegye->modosito = $user['id'];
            $useregyhazmegye->egyebInputValue = null;
            $useregyhazmegye->nemTag = 1;
            $useregyhazmegye->save();*/
        break;

        }
        unset($egyhazmegye);


        $nyelv1 = $request->input('nyelv1');
        $nyelv2 = $request->input('nyelv2');
        $nyelv3 = $request->input('nyelv3');
        $nyelv4 = $request->input('nyelv4');
        $nyelv5 = $request->input('nyelv5');

        /**
         * fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff
         * 
*
*
*ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff
*
*
*fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff
*
         *fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff
         */
       
        $this->UjNyelvFrissito($id,$request,$nyelv1,$nyelv2,$nyelv3,$nyelv4,$nyelv5);
        

        //dd($request->input('normal'),$request->input('laktozz'));

        try{
            OmrEmail::AlertUserDataChange($user['email']);
            /**
             * @note
             * lásd az admin controllerben leirtat!
             */
        }
        catch(Exception $e)
        {
            return back();
        }

        if($years == 'error')
        {
            
            return back()->withErrors("A születési idejét rosszul adta meg! Kérjük, adja meg mégegyszer! Profilja többi adata mentésre került!",'szulido');
      
        } else
        {/*
            if(!$profilkepValid)
            {
                return back()->withErrors("Profilja adatai mentésre kerültek! Kérjük, töltsön fel profilképet is különben, nem jelentkezhet rendezvényre!",'profilkep');
            }
            else */
             return redirect('/profil')->withErrors(['state' => '1']);
        }
       

    }

    /**
     * POST method
     */
    public function PasswdChange(Request $request)
    {


        return back();
    }

    public function logout(Request $request)
    {
        Auth::logout();
        \Cookie::forget('omr_session');
        return redirect('/login');
    }

    /**
     * Seged fgv. a fotevekenyseg html kimenetenek eloallitasahoz
     * @param int
     */
    public function GetHTMLTevekenysegMaker($JelenlegiTevkensegID)
    {
        $get = "def";
        switch($JelenlegiTevkensegID)
        {
            case 1:
                $get = '<option value="1" selected="selected">Felsőoktatásban tanulok</option>
                <option value="2">Középiskolában tanulok</option>
                <option value="3">Általános iskolában tanulok</option>
                <option value="4">Dolgozom</option>
                <option value="5">Munkanélküli vagyok</option>
                <option value="6">Kisgyermeket nevelek otthon</option>
                <option value="7">Háztartásbeli vagyok otthon</option>
                <option value="8">Nyugdíjas vagyok</option>';
                return $get;
            break;

            case 2:
                $get = '<option value="1" >Felsőoktatásban tanulok</option>
                <option value="2" selected="selected">Középiskolában tanulok</option>
                <option value="3">Általános iskolában tanulok</option>
                <option value="4">Dolgozom</option>
                <option value="5">Munkanélküli vagyok</option>
                <option value="6">Kisgyermeket nevelek otthon</option>
                <option value="7">Háztartásbeli vagyok otthon</option>
                <option value="8">Nyugdíjas vagyok</option>';
                return $get;
            break;

            case 3:
                $get = '<option value="1" >Felsőoktatásban tanulok</option>
                <option value="2" >Középiskolában tanulok</option>
                <option value="3" selected="selected">Általános iskolában tanulok</option>
                <option value="4">Dolgozom</option>
                <option value="5">Munkanélküli vagyok</option>
                <option value="6">Kisgyermeket nevelek otthon</option>
                <option value="7">Háztartásbeli vagyok otthon</option>
                <option value="8">Nyugdíjas vagyok</option>';
                return $get;
            break;

            case 4:
                $get = '<option value="1" >Felsőoktatásban tanulok</option>
                <option value="2" >Középiskolában tanulok</option>
                <option value="3" >Általános iskolában tanulok</option>
                <option value="4" selected="selected">Dolgozom</option>
                <option value="5">Munkanélküli vagyok</option>
                <option value="6">Kisgyermeket nevelek otthon</option>
                <option value="7">Háztartásbeli vagyok otthon</option>
                <option value="8">Nyugdíjas vagyok</option>';
                return $get;
            break;

            case 5:
                $get = '<option value="1" >Felsőoktatásban tanulok</option>
                <option value="2" >Középiskolában tanulok</option>
                <option value="3" >Általános iskolában tanulok</option>
                <option value="4">Dolgozom</option>
                <option value="5" selected="selected">Munkanélküli vagyok</option>
                <option value="6">Kisgyermeket nevelek otthon</option>
                <option value="7">Háztartásbeli vagyok otthon</option>
                <option value="8">Nyugdíjas vagyok</option>';
                return $get;
            break;

            case 6:
                $get = '<option value="1" >Felsőoktatásban tanulok</option>
                <option value="2" >Középiskolában tanulok</option>
                <option value="3" >Általános iskolában tanulok</option>
                <option value="4" >Dolgozom</option>
                <option value="5" >Munkanélküli vagyok</option>
                <option value="6" selected="selected">Kisgyermeket nevelek otthon</option>
                /<option value="7">Háztartásbeli vagyok otthon</option>
                \/<option value="8">Nyugdíjas vagyok\\</option\>';
                return $get;
            break;

            case 7:
                $get = '<option value="1" >Felsőoktatásban tanulok</option>
                <option value="2" >Középiskolában tanulok</option>
                <option value="3" >Általános iskolában tanulok</option>
                <option value="4" >Dolgozom</option>
                <option value="5" >Munkanélküli vagyok</option>
                <option value="6" >Kisgyermeket nevelek otthon</option>
                <option value="7" selected="selected">Háztartásbeli vagyok otthon</option>
                <option value="8">Nyugdíjas vagyok</option>';
                return $get;
            break;

            case 8:
                $get = '<option value="1" >Felsőoktatásban tanulok</option>
                <option value="2" >Középiskolában tanulok</option>
                <option value="3" >Általános iskolában tanulok</option>
                <option value="4" >Dolgozom</option>
                <option value="5" >Munkanélküli vagyok</option>
                <option value="6" >Kisgyermeket nevelek otthon</option>
                <option value="7" >Háztartásbeli vagyok otthon</option>
                <option value="8" selected="selected">Nyugdíjas vagyok</option>';
                return $get;
            break;
            default:
                $get = '<option value="1" >Felsőoktatásban tanulok</option>
                <option value="2" >Középiskolában tanulok</option>
                <option value="3" >Általános iskolában tanulok</option>
                <option value="4" >Dolgozom</option>
                <option value="5" >Munkanélküli vagyok</option>
                <option value="6" >Kisgyermeket nevelek otthon</option>
                <option value="7" >Háztartásbeli vagyok otthon</option>
                <option value="8">Nyugdíjas vagyok</option>';
                return $get;
            break;
        }
    }

    public function getPolomeret($polomeret)
    {
        $get = null;
        switch($polomeret)
        {
            case 'XS':
                    $get = '<option value="XS" selected="selected">XS</option>
                    <option value="S">S</option>
                    <option value="M">M</option>
                    <option value="L">L</option>
                    <option value="XL">XL</option>
                    <option value="XXL">XXL</option> <option value="XXXL">XXXL</option> <option value="XXXXL+">XXXXL vagy nagyobb</option>';
                    return $get;
            break;
            case 'S':
                    $get = '<option value="XS" >XS</option>
                    <option value="S" selected="selected">S</option>
                    <option value="M">M</option>
                    <option value="L">L</option>
                    <option value="XL">XL</option>
                    <option value="XXL">XXL</option><option value="XXXL">XXXL</option> <option value="XXXXL+">XXXXL vagy nagyobb</option>';
                    return $get;
            break;
            case 'M':
                $get = '<option value="XS" >XS</option>
                <option value="S" >S</option>
                <option value="M" selected="selected">M</option>
                <option value="L">L</option>
                <option value="XL">XL</option>
                <option value="XXL">XXL</option><option value="XXXL">XXXL</option> <option value="XXXXL+">XXXXL vagy nagyobb</option>';
                    return $get;
            break;
            case 'L':
                $get = '<option value="XS" >XS</option>
                <option value="S" >S</option>
                <option value="M" >M</option>
                <option value="L" selected="selected">L</option>
                <option value="XL">XL</option>
                <option value="XXL">XXL</option><option value="XXXL">XXXL</option> <option value="XXXXL+">XXXXL vagy nagyobb</option>';
                    return $get;
            break;
            case 'XL':
            $get = '<option value="XS" >XS</option>
            <option value="S" >S</option>
            <option value="M" >M</option>
            <option value="L" >L</option>
            <option value="XL" selected="selected">XL</option>
            <option value="XXL">XXL</option><option value="XXXL">XXXL</option> <option value="XXXXL+">XXXXL vagy nagyobb</option>';
                    return $get;
            break;
            case 'XXL':
            $get = '<option value="XS" >XS</option>
            <option value="S" >S</option>
            <option value="M" >M</option>
            <option value="L" >L</option>
            <option value="XL">XL</option>
            <option value="XXL"  selected="selected">XXL</option><option value="XXXL">XXXL</option> <option value="XXXXL+">XXXXL vagy nagyobb</option>';
                    return $get;
            break;
            case 'XXXL':
            $get = '<option value="XS" >XS</option>
                    <option value="S" >S</option>
                    <option value="M" >M</option>
                    <option value="L" >L</option>
                    <option value="XL">XL</option>
                    <option value="XXL"  >XXL</option><option value="XXXL" selected="selected">XXXL</option> <option value="XXXXL+">XXXXL vagy nagyobb</option>';
                    return $get;
            break;
            case 'XXXXL+':
            $get = '<option value="XS" >XS</option>
                    <option value="S" >S</option>
                    <option value="M" >M</option>
                    <option value="L" >L</option>
                    <option value="XL">XL</option>
                    <option value="XXL"  >XXL</option><option value="XXXL" >XXXL</option> <option value="XXXXL+" selected="selected">XXXXL vagy nagyobb</option>';
                    return $get;
            break;
            default:
                $get = '<option value="XS" >XS</option>
                <option value="S" >S</option>
                <option value="M" >M</option>
                <option value="L" >L</option>
                <option value="XL">XL</option>
                <option value="XXL">XXL</option><option value="XXXL">XXXL</option> <option value="XXXXL+">XXXXL vagy nagyobb</option>';
                        return $get;
            break;
        }


    }

    public function GetNyelvSzintHTML($nyelvszintid)
    {
        $get = null;
        switch($nyelvszintid)
        {
            case '1':
                $get = '<option value="1" selected="selected">Alapfok</option>
                <option value="2">Középfok</option>
                <option value="3">Felsőfok</option>';
                return $get;
            break;

            case '2':
            $get = '<option value="1">Alapfok</option>
            <option value="2"  selected="selected">Középfok</option>
            <option value="3">Felsőfok</option>';
            return $get;
            break;

            case '3':
                $get = '<option value="1">Alapfok</option>
                <option value="2">Középfok</option>
                <option value="3"  selected="selected">Felsőfok</option>';
                return $get;
            break;

            default:
                $get = '<option value="1">Alapfok</option>
                <option value="2">Középfok</option>
                <option value="3">Felsőfok</option>';
                return $get;
            break;

        }
    }



    public function ajaxImage(Request $request)
    {
        $user = auth()->user();
        $UserId = $user["id"];

        if ($request->isMethod('get'))
            return view('ajax_image_upload');
        else {
            $validator = Validator::make($request->all(),
                [
                    //'file' => 'image',required|mimes:jpeg,png,jpg,gif,svg|max:2048
                    'file' => 'required|mimes:jpeg,png,jpg,gif,svg|max:2048'
                ],
                [
                    'file.image' => 'A fájl csak kép formátum lehet (jpeg, png, bmp, gif, or svg)'
                ]);
            if ($validator->fails())
                return array(
                    'fail' => true,
                    'errors' => $validator->errors()
                );
            $extension = $request->file('file')->getClientOriginalExtension();
            $dir = 'userpic/';
            $filename = uniqid() . '_' . time() . '.' . $extension;
            $request->file('file')->move($dir, $filename);
            DB_OMR_Operations::UpdateProfilkep($UserId,$filename);
            $felh = Felhasznalo::find($UserId); 
            $felh->kepvalidalas = 3;
            $felh->save();
            
            return $filename;
        }
    }

    /**
     * Updated: 2021.04.14
     * @version 3.0.1 Elesites utan
     */
    protected function UjNyelvFrissito($id,Request $request,$nyelv1,$nyelv2,$nyelv3,$nyelv4,$nyelv5)
    {
        //$nyelvismeret = Nyelvismeret::where('felhasznalo_id',$UserID)->get();

        
        try {

            if(isset($nyelv1))
            {
               /* $def = true;
               if($nyelv1 == "def")
               {
                    $def = false;
               }*/
              // dd($valid);
               // if($def)
               // {
               //     dd($nyelv1);
                    $nyelvSzint1 = $request->input('nyelv1szint');
                    if(!isset($nyelvSzint1))
                    {
                        throw new Exception();
                    }
                    else
                    {
                        $r =  DB::table('nyelvismeret')->updateOrInsert(['felhasznalo_id' => $id, 'sorrend' => 1],['nyelv' => $nyelv1, 'nyelvszint_id' =>  $nyelvSzint1,'sorrend' => 1 ]);
            
                    }
              //  }
               /* else 
                { 
                    $nyelvismeret =  Nyelvismeret::where('felhasznalo_id',$id)->where('sorrend',1)->exist();
                    dd($nyelvismeret);
                    $this->NyelvTorlesEsUjraIndexeles($id,1);
                }*/
                
            }

            
        }
        catch(Exception $e)
        {
            return back()->withErrors("Validálási hiba! A 'Nyelv 1' mezőnél nem adta meg a nyeltudás szintjét! ",'nyelv1');
        }

        try
        {
            if(isset($nyelv2))
            {
                $nyelvSzint2 = $request->input('nyelv2szint');
                if(!isset($nyelvSzint2))
                {
                    throw new Exception();
                }
                else
                {
                    $r =  DB::table('nyelvismeret')->updateOrInsert(['felhasznalo_id' => $id, 'sorrend' => 2],['nyelv' => $nyelv2, 'nyelvszint_id' =>  $nyelvSzint2,'sorrend' => 2 ]);
        
                }
            }
            
        }
        catch(Exception $e)
        {
            return back()->withErrors("Validálási hiba! A 'Nyelv 2' mezőnél nem adta meg a nyeltudás szintjét! ",'nyelv2');
        }

        try
        {
            if(isset($nyelv3))
            {
                $nyelvSzint3 = $request->input('nyelv3szint');
                if(!isset($nyelvSzint3))
                {
                    throw new Exception();
                }
                else
                {
                    $r =  DB::table('nyelvismeret')->updateOrInsert(['felhasznalo_id' => $id, 'sorrend' => 3],['nyelv' => $nyelv3, 'nyelvszint_id' =>  $nyelvSzint3,'sorrend' => 3 ]);
        
                }
            }
            
        }
        catch(Exception $e)
        {
            return back()->withErrors("Validálási hiba! A 'Nyelv 3' mezőnél nem adta meg a nyeltudás szintjét! ",'nyelv3');
      
        }

        try{
            if(isset($nyelv4))
            {
                $nyelvSzint4 = $request->input('nyelv4szint');
                if(!isset($nyelvSzint4))
                {
                    throw new Exception();
                }
                else
                {
                    $r =  DB::table('nyelvismeret')->updateOrInsert(['felhasznalo_id' => $id, 'sorrend' => 4],['nyelv' => $nyelv4, 'nyelvszint_id' =>  $nyelvSzint4,'sorrend' => 4 ]);
        
                }
            }
           
        }
        catch(Exception $e)
        {
            return back()->withErrors("Validálási hiba! A 'Nyelv 4' mezőnél nem adta meg a nyeltudás szintjét! ",'nyelv4');

        }
       
        try{
            if(isset($nyelv5))
            {
                $nyelvSzint5 = $request->input('nyelv5szint');
                if(!isset($nyelvSzint5))
                {
                    throw new Exception();
                }
                else
                {
                    $r =  DB::table('nyelvismeret')->updateOrInsert(['felhasznalo_id' => $id, 'sorrend' => 5],['nyelv' => $nyelv5, 'nyelvszint_id' =>  $nyelvSzint5,'sorrend' => 5 ]);
        
                }
            }
            
        }
        catch(Exception $e)
        {
            return back()->withErrors("Validálási hiba! A 'Nyelv 5' mezőnél nem adta meg a nyeltudás szintjét! ",'nyelv5');

        }
    }

    protected function NyelvTorlesEsUjraIndexeles(int $UserID,int $ToroltNyelvIndex)
    {
        Nyelvismeret::where('felhasznalo_id',$UserID)->where('sorrend',$ToroltNyelvIndex)->delete();

    }

}
