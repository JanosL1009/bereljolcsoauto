<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use  App\Http\Models\MyCalendar\IndexViewModel;
use App\Http\Controllers\DB_OMR_Operations;
use App\OnkentesSzabadidopontok;
use App\PagesDetails;
use Carbon;
use Eexception;
use Exception;

class MyCalendarController extends Controller
{
    public function index(Request $request)
    {
        $user = auth()->user();
        $id = $user['id'];
        $model = new IndexViewModel($id);

        $model->profilpic = DB_OMR_Operations::GetProfilkep($id);

        $path = asset('json/defaultCalendar.json'); // ie: /var/www/laravel/app/storage/json/filename.json

        $model->Config = json_decode(file_get_contents($path), true);

        $pageDescription = PagesDetails::find(10)->leiras;

        $ReservedMessagePopUpBoxLbl = null;
        $DisclaimMessagePopUpBoxLbl = null;

        try{
          $ReservedMessagePopUpBoxLbl = PagesDetails::find(8)->leiras;
          $DisclaimMessagePopUpBoxLbl = PagesDetails::find(9)->leiras;
          $findme = 'Nincs leírás';
          if($ReservedMessagePopUpBoxLbl)
          {
              if(strpos($ReservedMessagePopUpBoxLbl, $findme) > 1)
              {
                throw new Exception();
              }

          }
          if($DisclaimMessagePopUpBoxLbl)
          {
              if(strpos($ReservedMessagePopUpBoxLbl, $findme) > 1)
              {
                throw new Exception();
              }
              
          }
        }
        catch(Exception $e)
        {
          
          $model->Idopontjaim = OnkentesSzabadidopontok::where('felhasznalo_id',$id)->get('foglalas_json');
        //dd(json_encode( $model->Idopontjaim,JSON_HEX_APOS));
        return view("onkentes.mycalendar.index")->with('model',$model)->with('ReservedMessagePopUpBoxLbl',$ReservedMessagePopUpBoxLbl)
        ->with('DisclaimMessagePopUpBoxLbl',$DisclaimMessagePopUpBoxLbl)->with('nondeclare','A felugró ablakok leírása nem található az adatbázisban vagy nincs módosítva a leírás!')
        ->with('pageDescription',$pageDescription);
          
      }


        try{
           // $this->setJsonToDatabase();
        }catch(Exception $e)
        {

        }
        $model->Idopontjaim = OnkentesSzabadidopontok::where('felhasznalo_id',$id)->get('foglalas_json');
        //dd(json_encode( $model->Idopontjaim,JSON_HEX_APOS));
        return view("onkentes.mycalendar.index")->with('model',$model)->with('ReservedMessagePopUpBoxLbl',$ReservedMessagePopUpBoxLbl)
        ->with('DisclaimMessagePopUpBoxLbl',$DisclaimMessagePopUpBoxLbl)->with('pageDescription',$pageDescription);
    }


    /**
     * @version 1.0.0.
     * POST method: xhr kereshez.
     * A fgv fogadja az Onkentes szabad idejet, majd menti a db-be.
     * @return int Visszater egy allapotkoddal 1:sikeres mentes,0: hiba
     */
    public function xhr_setFoglalas(Request $request)
    {
        $user = auth()->user();
        $id =  $user["id"];

       // $path = asset('json/defaultCalendar.json'); //publib/json
       // $Config = json_decode(file_get_contents($path));

        $ujJSON = $request->input("calendar");
        $foglaltsag = OnkentesSzabadidopontok::find($id); //$foglaltsag = json_decode($foglaltsag);
        $foglaltsag->foglalas_json = json_encode($ujJSON);
        $foglaltsag->save();


        return 1;

    }
    /**
     * Fejleszthetőség: version 1.1.0
     * a tomb ertekeket megvizsgalni hogy vannak-e illegalisa karakterek (sql injection...stb.)
     */


    /**
     * POST method: xhr kereshez.
     * Az elso oldalbetolteskor vagy sima frisseteskor fut le a metodus.
     * Elkuldi a klinsnek a meglévő foglaltságot egy adott userrol.
     *
     * @return JSON
     */
    public function xhr_meglevoFoglalasok()
    {

    }
    /**
     * Az eredmenyt a kliens oldalon parsoljuk a naptarba!
     */


     public function xhr_modositas()
     {

     }

     public function xhr_torles(Request $request)
     {
        $user = auth()->user();
        $id =  $user["id"];

       // $path = asset('json/defaultCalendar.json'); //publib/json
       // $Config = json_decode(file_get_contents($path));

        $ujJSON = $request->input("calendar");
        $foglaltsag = OnkentesSzabadidopontok::find($id); //$foglaltsag = json_decode($foglaltsag);
        $foglaltsag->foglalas_json = json_encode($ujJSON);
        $foglaltsag->save();


        return 1;
     }


     /*
      * Adatbazisba a json minta: ez alapajan tortenik a frontend megjelenies is a naptarban
      * {"y2020":
        {
          "Szeptember" :
          {
              "szabad" : ["Empty","Empty","DE","Empty","Empty","Empty","Empty","Empty","Empty","Empty"
              "Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty"
              "Empty","Empty","DE","DU","Empty","Empty","Egesznap","Empty","Empty","Empty","Empty"]
          },
          "Oktober" :
           {
                "szabad":["Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty",
                "Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty",
                "Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty"]
          },
           "November" :
          {
"szabad":["Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty",
                "Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty",
                "Empty","Empty","Empty","Empty","Empty","Empty","Empty"]
          },
          "December" :
          {
"szabad":["Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty",
                "Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty",
                "Empty","Empty","Empty","Empty","Empty","Empty","Empty","Empty"]
          }

      }
    }
      a 'szabad' tomb a honap napjai szerint vannak abrazolva.
      a tartalmat a defaultCalendar.json alapjan generaljuk, mert abban vannak a honapok napjainak ertekei
      pl: szeptember 30 napos
      valaki 11.dikén rá ér délután
      ezen indexhez értékként be kerül a 'DU' jelzés, az tobbi naphoz  pedig 'Empty'
      */

      private function setJsonToDatabase(/*string $year,int $month, int $day, string $value*/)
      {
        $user = auth()->user();
        $id =  $user["id"];

        $onkentesIdopontjai = OnkentesSzabadidopontok::where('felhasznalo_id',$id )->get(["foglalas_json"]);

        $son = $onkentesIdopontjai;
        $j = $son[0]["foglalas_json"]; $j = json_encode($j);
        //dd($j);

      }

      private function deleteJsonDatabase(string $year,int $month, int $day, string $value)
      {

      }

      public function getIdopontjaim(Request $request)
      {
        $userID = null;

        try{
          $userID = (int)$request->input('uid');
        }
        catch(Exception $e)
        {
            return 0;
        }

        $onkentesIdopontjai = null;
        try{
          $onkentesIdopontjai = OnkentesSzabadidopontok::where('felhasznalo_id',$userID )->get(["foglalas_json"]);

        }
        catch(Exception $e)
        {
            return 1;
        }

        return $onkentesIdopontjai;

      }



}
