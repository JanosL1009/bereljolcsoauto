<?php

namespace App\Http\Controllers;

use App\FelhasznaloFeladat;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\DB_OMR_Operations;
use Illuminate\Http\Request;
use  App\Http\Models\CsoportokLekerdezese;
use App\Model\BeosztasKezeloRepo;
use App\Support\Collection;
use App\Esemeny;
use App\Terulet;
use Exception;
use App\User;
use App\UserAdminsViews;
use Illuminate\Support\Carbon;
use App\TeruletVezetokTerulet;
use App\Jeligek;
use App\TeruletBeosztas;
class TeruletCsoportController extends Controller
{

    public function Csoportok_lekerdezese($teruletid)
    {
       $user = auth()->user();
        $userviews = new UserAdminsViews;
        $userviews->slug = $_SERVER['REQUEST_URI'];
        $userviews->visitTimes = Carbon::now();
        $userviews->felhasznalo_id = $user['id'];
        $userviews->save();
       $csoportok = new CsoportokLekerdezese($user['id']);
       $csoportok->csoport = DB_OMR_Operations::CsoportLista($teruletid);
       //dd($csoportok->csoport );
       $csoportok->profilpic = DB_OMR_Operations::GetProfilkep($user['id']);

        $terulet = Terulet::find($teruletid);
        $beosztaskezelo = new BeosztasKezeloRepo($user,$terulet->esemeny_id,$teruletid);
        //dd($beosztaskezelo->GetJokerJelentkezok());

       $terulet = DB::table('terulet')->where('id','=',$teruletid)->get();

       $csoportok->teruletneve = $terulet[0]->nev;
        $csoportok->teruletKezdesIdopont = $terulet[0]->kezdesIdopont;
        $csoportok->teruletBefejezesIdopont = $terulet[0]->befejezesIdopont;

       $esemeny =   DB::table('esemeny')->where('id','=',$terulet[0]->esemeny_id)->get();
       $csoportok->rendezvenyNeve =  $esemeny[0]->nev;
       $csoportok->rendezvenyKezdesDatuma = $esemeny[0]->kezdesDatum;
       $csoportok->rendezvenyBefejezesDatuma = $esemeny[0]->befejezesDatum;
       $csoportok->teruletid =  $terulet[0]->id;
       $csoportok->esemeny_id =  $terulet[0]->esemeny_id;

        $jelentkezokSzama = $beosztaskezelo->getIdTeruletJelentkezokListaja();
        $jokerJelentkezokSzama = $beosztaskezelo->getJokerJelentkezoIDk();
        $csoportok->jelentkezokSzama = count($jelentkezokSzama) + count($jokerJelentkezokSzama);

        $csoportok->tervezettLetszam = $terulet[0]->tervezettLetszam;
        $csoportok->TeruletAktiv =  $terulet[0]->teruletAktiv;
        $csoportok->teruletLeiras = $terulet[0]->leiras;
        $TeruletHelyszineID  = DB::table('terulet')->where('id','=',$csoportok->teruletid )->select('teruletHelyszineID')->get();

        $helyszin = DB::table('helyszin')->where('id','=', $TeruletHelyszineID[0]->teruletHelyszineID )->get();
        //dd($helyszin);
        $csoportok->helyszin = $helyszin[0]->Neve;
        $csoportok->cim = $helyszin[0]->Cim;

       //$csoportok->adminLista = TeruletVezetokTerulet::where('terulet_id',$teruletid)->get();
        $csoportok->jelentkezokLista =  DB::table('users')->join('felhasznalo_feladat',"users.id",'=','felhasznalo_feladat.felhasznalo_id')->select('users.*')->where('felhasznalo_feladat.terulet_id','=',$teruletid)->get();

       // $csoportok->EsemenySzervezok = DB::table('users')->join('esemeny_szervezok','users.id','=','esemeny_szervezok.felhasznalo_id')->select('users.*')->where('esemeny_szervezok.szint_id','=',3)->get();

        $csoportok->TeruletVezetok = $beosztaskezelo->getTeruletVezetokListaja();

        $csoportok->CsoportVezetok = $beosztaskezelo->getCsoportVezetokListaja();

        //$UjTeruletVezetok = DB::table('users')->join('jogosultsag','users.id','=','jogosultsag.felhasznalo_id')->
       // where('jogosultsag.felhasznaloszint_id','=',4)->select('users.*')->get();
        $model = $csoportok;
        return view('/adminisztratorok/csoportok')->with('model',$model);
    }

    public function TeruletLetszamValtoztatas(Request $request)
    {
        $teruletid = $request->input('tid');
        $ujLetszam = $request->input('ujletszam');

        DB::table('terulet')->where('id',"=",$teruletid)->update(['tervezettLetszam' => $ujLetszam]);

        return back();
    }


    public function TeruletNevenekModositasa(Request $request)
    {
        $TeruletID = $request->input('tid');
        $UjNev = $request->input('newareaname');

        $res = DB::table('terulet')->where('id','=',$TeruletID)->update(['nev' => $UjNev]);

        return back();

    }

    public function TeruletHelyszinValtoztatasa(Request $request)
    {
        $TeruletID = $request->input('tid');
        $UjHelyszinID = $request->input('hnev'); //helyszin neve

        DB::table('terulet')->where('id','=',$TeruletID )->update(['teruletHelyszineID' => $UjHelyszinID]);

        return back();
    }

    public function TeruletTorlese(Request $request)
    {
        $TeruletID = $request->input('teruletDelid');
        DB::table('terulet')->where('id','=', $TeruletID)->delete();
        return back();
    }

    public function CsoportTorlese(Request $request)
    {
        $csopID = intval($request->input('gid'));
        $return = DB::table('csoport')->where('id','=',$csopID)->delete();

        return $return;
    }

    public function TeruletLeirasanakModositasa(Request $request)
    {
        $user = auth()->user();
        $TeruletID = $request->input('areaid');
        $terulet = Terulet::find($TeruletID);
        $Leiras = $request->input('areaNewDescribeTT');
        if(!isset($Leiras))
        {
            $Leiras = " ";
        }
        $terulet->leiras = $Leiras;
        $terulet->modosito = $user['id'];
        $terulet->save();
        return back();
    }

    public function OnkentesTeruletBeosztas(Request $resquest,$teruletid)
    {
        $user = auth()->user();

        $csoportok = new CsoportokLekerdezese($user['id']);
        $csoportok->csoport = DB_OMR_Operations::CsoportLista($teruletid);
        $csoportok->profilpic = DB_OMR_Operations::GetProfilkep($user['id']);

        $userviews = new UserAdminsViews;
        $userviews->slug = $_SERVER['REQUEST_URI'];
        $userviews->visitTimes = Carbon::now();
        $userviews->felhasznalo_id = $user['id'];
        $userviews->save();

        $terulet = DB::table('terulet')->where('id','=',$teruletid)->get();

        $csoportok->teruletneve = $terulet[0]->nev;
        $rendezvenyNeve =  DB::table('esemeny')->where('id','=',$terulet[0]->esemeny_id)->pluck('nev');
        $csoportok->teruletid =  $terulet[0]->id;
        $csoportok->esemeny_id =  $terulet[0]->esemeny_id;
        $csoportok->rendezvenyNeve = $rendezvenyNeve[0];
        $BeosztasKezelo = new BeosztasKezeloRepo($user,intval($csoportok->esemeny_id),intval($teruletid),null);



         $csoportok->tervezettLetszam = $terulet[0]->tervezettLetszam;
         $csoportok->TeruletAktiv =  $terulet[0]->teruletAktiv;
         $csoportok->teruletLeiras = $terulet[0]->leiras;

         /**
          * @var Array
          */
         $csoportok->jelentkezokLista =  $BeosztasKezelo->getIdTeruletJelentkezokListaja();
         $csoportok->jokerJelentkezoLista = $BeosztasKezelo->getJokerJelentkezoIDk();

       // dd($csoportok->jelentkezokLista);

         //$csoportok->JokerJelentkezokSzama = $BeosztasKezelo->getTeruletJelentkezokJokerekSzama();
         $csoportok->JokerJelentkezokSzama = count($csoportok->jokerJelentkezoLista);

         $csoportok->jelentkezokSzama = count($csoportok->jelentkezokLista);
         $csoportok->BeosztottakSzama = $BeosztasKezelo->getTeruletAktualisBeosztottakSzama();
         $csoportok->beosztottakListaja = $BeosztasKezelo->getTeruletreBeosztottakListajaID();

        // $csoportok->BeoszthatoOnkentesekSzama = $BeosztasKezelo->getBeoszthatoOnkentesekSzama(); //ez a fgv nnem jo



         $usersArr = array();
         foreach($csoportok->jelentkezokLista as $jelentkezo)
         {
            array_push($usersArr,$jelentkezo->felhasznalo_id);
         }
         foreach($csoportok->beosztottakListaja as $jelentkezo)
         {
            array_push($usersArr,$jelentkezo->felhasznalo_id);
         }
         foreach($csoportok->jokerJelentkezoLista as $jelentkezo)
         {
            array_push($usersArr,$jelentkezo->felhasznalo_id);
         }

         $model = $csoportok;
         //$users = User::whereIn('id',$usersArr)->get(['id','name']);
         $tempStr = implode(',', $usersArr);
         $users = User::whereIn('id',$usersArr)->orderByRaw(DB::raw("FIELD(id, $tempStr)"))->get(['id','name']);
        
        // dd($usersArr,$users);
         $model->UsersFreeTimes = $BeosztasKezelo->Calendar($usersArr);
         //dd($model->jokerJelentkezoLista);

         return view('/adminisztratorok/teruletekbeosztasa')->with('model',$model)->with('users',$users)->
         with('CsoportosJelentkezok',$BeosztasKezelo->GetCsoportosJelentkezok())->
         with('JeligeLista', $BeosztasKezelo->getExistGroups())->with('terulet',$terulet);
    }

    public function getjokers(Request $request)
    {
        $esemenyid = $request->input('esID');
        $teruletid = $request->input('esID');
        $user = auth()->user();
        $BeosztasKezelo = new BeosztasKezeloRepo($user,intval($esemenyid ),intval($teruletid),null);
        return $BeosztasKezelo->GetJokerJelentkezok();
    }

    public function KezdesIdoModositasa(Request $request)
    {
        $dateFromFronEnd = $request->input('datepicker');//date 1900/00/00 to
        $formatedDate = str_replace("/","-",$dateFromFronEnd ); //date 1900-00-00

        $hour = 0; $minute = 0;

        $h = $request->input('kezdIdejeOra');

        if(is_int(intval($h)))
        {
            $hour = $h;
        }
        else throw new Exception("Integer formatum lehet! Hour");

        $m = $request->input('kezdIdejePerc');

        if(is_int(intval($m)))
        {
            $minute = $m;
        }
        else throw new Exception("Integer formatum lehet! Minute");

        $areaid = null;

        $aid = $request->input('areaid');

        if(is_int(intval($aid)))
        {
            $areaid = $aid;
        }
        else throw new Exception("Integer formatum lehet! Minute");

        $Terulet = Terulet::find($areaid);
        $Terulet->kezdesIdopont = $formatedDate." ".$hour.":".$minute.":00";
        $user = auth()->user();
        $Terulet->modosito = $user["id"];
        $Terulet->save();

        return back();

    }

    public function BefejezesIdoModositasa(Request $request)
    {

        $dateFromFronEnd = $request->input('datepicker2');//date 1900/00/00 to
        $formatedDate = str_replace("/","-",$dateFromFronEnd ); //date 1900-00-00

        $hour = 0; $minute = 0;

        $h = $request->input('befIdejeOra');

        if(is_int(intval($h)))
        {
            $hour = $h;
        }
        else throw new Exception("Integer formatum lehet! Hour");

        $m = $request->input('befIdejePerc');

        if(is_int(intval($m)))
        {
            $minute = $m;
        }
        else throw new Exception("Integer formatum lehet! Minute");

        $areaid = null;

        $aid = $request->input('areaid');

        if(is_int(intval($aid)))
        {
            $areaid = $aid;
        }
        else throw new Exception("Integer formatum lehet! Minute");

        $Terulet = Terulet::find($areaid);
        $Terulet->befejezesIdopont = $formatedDate." ".$hour.":".$minute.":00";
        $user = auth()->user();
        $Terulet->modosito = $user["id"];
        $Terulet->save();

        return back();

    }


    public function TeruletJelentkezesModositasa(Request $request, int $UserID)
    {
        $jelentkezesek = FelhasznaloFeladat::where('felhasznalo_id', $UserID)->get();
        $user = User::find($UserID);
        //$teruletBeosztas = TeruletBeosztas::where('felhasznalo_id', $UserID)->get();
        $datas = array();
        foreach($jelentkezesek as $jelentkezes)
        {
            $data['j_id'] = $jelentkezes->jelentkezesID;
            $data['esemeny_id'] = $jelentkezes->esemeny_id;
            $data['esemeny_nev'] = $jelentkezes->esemeny_data->nev??'';
            $data['terulet_id'] = $jelentkezes->terulet_id;
            $data['terulet_nev'] = $jelentkezes->terulet_data->nev??'';
            $data['csoport_id'] = $jelentkezes->csoport_id;
            $data['csoport_nev'] = $jelentkezes->csoport_data->nev??'';
            $data['priority'] = $jelentkezes->priority??'';
            
            if($jelentkezes->other == 1)
            {
                $data['joker'] = 'Igen';
            }
            else 
            {
                $data['joker'] = 'Nem'; 
            }
            if($data['csoport_id'] != 0)
            {
                $data['beosztott_csoport_id'] = $jelentkezes->csoport_id;
                $data['beosztott_csoport_nev'] = $jelentkezes->csoport_data->nev??'';
            }
            else 
            {
                $data['beosztott_csoport_id'] = '';
                $data['beosztott_csoport_nev'] = '';
            }

            $beosztottTerulet = TeruletBeosztas::where('felhasznalo_id', $UserID)->where('terulet_id',$jelentkezes->terulet_id)->get();

            if(isset($beosztottTerulet))
            {
                $data['beosztott_terulet_id'] = $jelentkezes->terulet_id;
                $data['beosztott_terulet_nev'] = $jelentkezes->terulet_data->nev??'';
            }
            else 
            {
                $data['beosztott_terulet_id'] = 0;
                $data['beosztott_terulet_nev'] = '';
            }
            $data['jelentkezesIdeje'] = $jelentkezes->created_at;
            array_push($datas,$data);
        }
        /**
         * adatszerkezet:
         * $data['esemeny_id']
         * $data['esemeny_nev']
         * $data['terulet_id']
         * $data['terulet_nev']
         * $data['terulet_id']
         * $data['csoport_nev']
         * $data['beosztott_terulet_id']
         * $data['beosztott_terulet_nev']
         * $data['beosztott_csoport_id']
         * $data['beosztott_csoport_nev']
         * $data['jelentkezesIdeje']
         */

         $esemenyek = Esemeny::all();

        return view('adminisztratorok/jelentkezesmodositasok/adatlap')->with('datas',$datas)->
        with('user',$user)->with('esemenyek',$esemenyek);
    }

    /**
     * POST
     * vissza adja egy rendezveny osszes teruletet
     */
    public function Teruletek(Request $request)
    {
        $esemenyID = $request->input('esid');
        
        return Terulet::where('esemeny_id',$esemenyID)->get();
    }

}
