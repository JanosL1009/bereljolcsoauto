<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Carbon;

use Illuminate\Support\Facades\Auth;
use Exception;
use App\Ertesitesek;
use App\ErtesitesUsers;
use App\User;
use GuzzleHttp;
use GuzzleHttp\Client;
class WSController extends Controller
{
    public function test()
    {
        return response()->json([
            "message" => "rendben van"
        ], 201);
       
    }

    public function getNotification()
    {
        return response()->json([
            "message" => "rendben van"
        ], 201);
    } 

    public function MessageNotification(Request $request)
    {
        //$token = '1FF62BCD9263449C5AD64A150A507229E25CA3E8D71D89B953651B0E318D563Faskdnfjbdsfbsdoj';

        if(empty($request->api_token))
        {
            abort(503);
        }
        
        $UserID = null;$userErtesitesei = null;
        try{
            $UserID = User::where('api_token',$request->api_token)->first()->id;
            $userErtesitesei = ErtesitesUsers::where('felhasznalo_id',$UserID)
            ->where('megtekintve',0)->orderby('created_at')->first();
        }
        catch(Exception $e)
        {
            $UserID = null;$userErtesitesei = null;
            $ertesites = json_encode("empty",200);
        }
       

        
        $ertesites = new Ertesitesek();
        try{
            $ertesites = Ertesitesek::find($userErtesitesei->ertesites_id);
        }
        catch(Exception $e)
        {
           
            $ertesites = json_encode("empty",200);
        }
        


        $name = $ertesites->nev??"";
        $id = $ertesites->id??0;



        $T = Carbon::now();
        return response()->json([
            "full" =>  $ertesites,
            "querydate" => $T,
            "notificationName" => $name,
            "id" => $id
        ], 201);
    }


}
