<?php
namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;

use App\Esemeny;
use App\Terulet;
use App\Csoport;

class FrontEndMaker
{

  public static function GetHelyszinek()
  {
    $eredmeny = DB::select("SELECT * from helyszin");

    //dd($eredmeny);
  }

  public static function GetBreadcrumbCsoportBeosztas($EsemenyID,$TeruletID = null,$CsoportID = null)
  {
      $EsemenyNeve = DB::table('esemeny')->where('id','=',$EsemenyID)->select('nev')->get()->first()->nev;
      $TeruletNeve = null; $CsoportNeve = null;
      if(isset($TeruletID))
      {
        $TeruletNeve = DB::table('terulet')->where('id','=',$TeruletID)->select('nev')->get()->first()->nev;
      }

      if(isset($CsoportID))
      {
        $CsoportNeve = DB::table('csoport')->where('id','=',$CsoportID)->select('nev')->get()->first()->nev;
      }
     // dd($EsemenyNeve);
      $breacrumblink = '<li class="breadcrumb-item"><a href="'.url('/admin/esemeny_szerkesztes/'.$EsemenyID).'">'.$EsemenyNeve.'</a></li>'; //DEFAULT

      if(isset($TeruletID))
      {
        $breacrumblink = $breacrumblink.'<li class="breadcrumb-item"><a href="'.url('/admin/csoportokterulet/'.$TeruletID).'">'.$TeruletNeve.'</a></li>';
      }

      if(isset($TeruletID))
      {
        $breacrumblink = $breacrumblink.'<li class="breadcrumb-item"><a href="'.url('/admin/CsoportBeosztas/'.$TeruletID.'/'.$CsoportID).'">'.$CsoportNeve.' csoport beosztás</a></li>';
      }



      return $breacrumblink;
  }

  public static function getBreadCrumLinkCsoportSzerkForAdmin($CsoportID)
  {
        $Csoport = Csoport::find($CsoportID);
        $terulet = $Csoport->Terulet;
        $esemeny = $Csoport->Esemeny();

       $esemenyLink = '<li class="breadcrumb-item"><a href="'.url('/admin/esemeny_szerkesztes/'.$esemeny->id).'">'.$esemeny->nev.'</a></li>';
        $teruletLink = '<li class="breadcrumb-item"><a href="'.url('/admin/csoportokterulet/'.$terulet->id).'">'.$terulet->nev.'</a></li>';
        $csoportLink = '<li class="breadcrumb-item"><a href="'.url('/admin/csoport_szerkesztes/'.$Csoport->id).'">'.$Csoport->nev.'</a></li>';

        return $esemenyLink.$teruletLink.$csoportLink;

    }

    public static function getMunkafelvetelBreadCrumbLinks($CsoportID)
    {
        $Csoport = Csoport::find($CsoportID);
        $terulet = $Csoport->Terulet;
        $esemeny = $Csoport->Esemeny();

       $esemenyLink = '<li class="breadcrumb-item active" aria-current="page">'.$esemeny->nev.'</li></li>';
        $csoportLink = '<li class="breadcrumb-item"><a href="'.url('/admin/CsoportBeosztas/'.$terulet->id.'/'.$Csoport->id).'">'.$Csoport->nev.'</a></li>
        <li class="breadcrumb-item active" aria-current="page">Műszakigazolás</li>
        ';

        return $esemenyLink.$csoportLink;
    }

    /**
     * Onkentes oldalra generalja a breadcrumblinket
     */
    public static function getMuszakigazolasOnekntesOldalrolBreadCrumbLinks($CsoportID)
    {
        $Csoport = Csoport::find($CsoportID);
        $terulet = $Csoport->Terulet;
        $esemeny = $Csoport->Esemeny();

       $esemenyLink = '<li class="breadcrumb-item active" aria-current="page">'.$esemeny->nev.'</li></li>';
        $csoportLink = '<li class="breadcrumb-item"><a href="'.url('onkentes/CsoportBeosztas/'.$terulet->id.'/'.$Csoport->id).'">'.$Csoport->nev.'</a></li>
        <li class="breadcrumb-item active" aria-current="page">Műszakigazolás</li>
        ';

        return $esemenyLink.$csoportLink;
    }

/*
  public static function GetBreadcrumbCsoportVezetőBeosztas($EsemenyID,$TeruletID = null,$CsoportID = null)
  {
      $EsemenyNeve = DB::table('esemeny')->where('id','=',$EsemenyID)->select('nev')->get()->first()->nev;
      $TeruletNeve = null; $CsoportNeve = null;
      if(isset($TeruletID))
      {
        $TeruletNeve = DB::table('terulet')->where('id','=',$TeruletID)->select('nev')->get()->first()->nev;
      }

      if(isset($CsoportID))
      {
        $CsoportNeve = DB::table('csoport')->where('id','=',$CsoportID)->select('nev')->get()->first()->nev;
      }
     // dd($EsemenyNeve);
      $breacrumblink = '<li class="breadcrumb-item"><a href="'.asset('/admin/esemeny_szerkesztes/'.$EsemenyID).'">'.$EsemenyNeve.'</a></li>'; //DEFAULT

      if(isset($TeruletID))
      {
        $breacrumblink = $breacrumblink.'<li class="breadcrumb-item"><a href="'.asset('/admin/csoportokterulet/'.$TeruletID).'">'.$TeruletNeve.'</a></li>';
      }

      if(isset($TeruletID))
      {
        $breacrumblink = $breacrumblink.'<li class="breadcrumb-item"><a href="'.asset('/admin/CsoportBeosztas/'.$TeruletID.'/'.$CsoportID).'">'.$CsoportNeve.' beosztás</a></li>';
      }



      return $breacrumblink;
  }
*/


}
