<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Ertesitesek;
use App\ErtesitesMegtekintese;
use App\ErtesitesProgram;
use App\ErtesitesUsers;
use App\Esemeny;
use App\Http\Models\ErtesitesekKezelese;

class OnkentesErtesitesek extends Controller
{

    protected $UserID = 0;
    protected $User = null;

    /**
     * Beallitja a $AdminUserID:int valtozot
     */
    private function setUserID() : void
    {
        if($this->UserID == 0)
        {
            $this->User = auth()->user();
            $this->UserID = intval($this->User["id"]);
        }
    }

    public function index()
    {
        $this->setUserID();
        $ertesitesek = new ErtesitesekKezelese();
        dd($ertesitesek->getErtesitesekOnkentesnek($this->UserID));

        return view('adminisztratorok.ertesites.index',['ertesitesek' => $ertesitekLista]);
    }
}
