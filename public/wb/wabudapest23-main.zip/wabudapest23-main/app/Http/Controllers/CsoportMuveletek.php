<?php

namespace App\Http\Controllers;
use App\Http\Models\Csoport;
use App\FelhasznaloFeladat;

use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\DB_OMR_Operations;
use Illuminate\Http\Request;
use App\Model\BeosztasKezeloRepo;
use App\Terulet;
class CsoportMuveletek
{
    private static $SzinKodok = ["#E5E5E5","#DBFD45","#00728B", "#004453","#16E1A7","#0B7053","#792E4E",
        "#F25D9C","#B2D4DC","#800080","#66AAB9","#FF3232","#7F7F7F","#514C48","#008000","#0C056D",
        "#B61AAE"
    ];

    private static $ActuallyColorCodeIndex = 0; //ez van a default tombben, deklaraskor
    //tomb[0] = $ActuallyColorCodeIndex; tomb[i] = $ActuallyColorCodeIndex++;

    /**
     * @param int Csoport azonositoja
     * @return Csoport Egy Csoport classt add vissza
     */
    public static function Csoport_szerkesztes(Request $request,$id)
    {
        $model = new Csoport($id);
        $csoport  = DB::table('csoport')->where('id', $id)->first();


       // dd($csoport);
       // dd(DB_OMR_Operations::GetHelyszinNev($csoport[0]->id));
        $helyszin = DB_OMR_Operations::GetHelyszinNev($csoport->helyszin_id)->first();

        $model->CsoportNeve = $csoport->nev;
        $model->igenyeltOnkentesLetszam = $csoport->igenyelt_onkentes_letszam;
        $model->Leiras = $csoport->leiras;
        $model->helyszin = $helyszin->Neve;
        $model->cim = $helyszin->Cim;
        $model->helyszin_id = $csoport->helyszin_id;
        $model->terulet_id = $csoport->terulet_id;
        $model->kezdesDatuma = $csoport->kezdesDatuma;
        $model->kezdesIdeje = $csoport->kezdesIdeje;
        $model->befejezesDatuma = $csoport->befejezesDatuma;
        $model->befejezesIdeje = $csoport->befejezesIdeje;

        return $model;
    }

    public static function CsoportSzerkeszteseFeldolgozo(Request $request,$id)
    {
        $csoport  = \DB::table('csoport')->where('id', $id)->update([

            "nev" => $request->csoportNeve,
            "leiras" => $request->csoportLeiras,
            "kezdesDatuma" => $request->cskezdIdejeDatum,
            "kezdesIdeje" => $request->cskezdIdejeOra.':'.$request->cskezdIdejePerc,
            "befejezesDatuma" => $request->csbefIdejeDatum,
            "befejezesIdeje" =>  $request->csbefIdejeOra.':'.$request->csbefIdejePerc,
            "igenyelt_onkentes_letszam" => $request->cstervLetszam

        ]);
    }

    /**
     * AJAX kereshez post metodus. A jeligeID-khoz rendel egy szinkodot. Ezek a szinkodok a csoportok.
     * @param Array Felhasznalo azonositok listaja a bladebol.
     * @param int terulet azonosito
     * @param int csoport azonosito
     *
     * @return Json[] Visszater egy asszociativ tombbel.
     */

    public static function JeligeSzerintiCsoport(Request $request/*,array $FelhasznaloAzonositok,$teruletID,$csoportID*/)
    {
        $FelhasznaloAzonositok = $request->input('applId');
        $teruletID = $request->input('tid');
        $csoportID = $request->input('csid');
        $user = auth()->user();
        $esemenyID = Terulet::find($teruletID)->esemeny_id;


        $BeosztasKezelo = new BeosztasKezeloRepo($user,intval($esemenyID),intval($teruletID),$csoportID);
        $jelentkezok = $BeosztasKezelo->getJelelentkezokWithUserDatas();
        $arraySelect = [];
        foreach($jelentkezok as $jelentkezo)
        {
            array_push($arraySelect,$jelentkezo->id);
        }

        $FelhasznaloFeladat = FelhasznaloFeladat::whereIn('felhasznalo_id',$arraySelect)
        ->where('terulet_id',$teruletID)->where('jeligeID','>',0)->groupby('felhasznalo_id')->get();

        // $jeligecsoport;
        $jeligeSzinAzonositok = [['jeligeID' => $FelhasznaloFeladat[0]->jeligeID,'uid' => $FelhasznaloFeladat[0]->felhasznalo_id,'colorcode' => self::$SzinKodok[0]]];
        $szinkodIndex = 1;
        foreach($FelhasznaloFeladat as $felhasznalo)
        {
            $exist = self::isExistItem($jeligeSzinAzonositok,$felhasznalo->felhasznalo_id);
            if(!$exist)
            {

                $ccode = $jeligeSzinAzonositok[self::$ActuallyColorCodeIndex]["colorcode"]; //TESZT: JO

                $colorExist = self::isExistColorCodeItem($jeligeSzinAzonositok,$ccode);
                //dd($colorExist );
                if($colorExist)
                {
                    //self::$ActuallyColorCodeIndex = self::$ActuallyColorCodeIndex + 1;
                    array_push($jeligeSzinAzonositok,
                    ['jeligeID' => $felhasznalo->jeligeID,
                    'uid' => $felhasznalo->felhasznalo_id,
                    'colorcode' => self::$SzinKodok[self::$ActuallyColorCodeIndex]]);

                }
                else
                {
                    self::$ActuallyColorCodeIndex = self::$ActuallyColorCodeIndex + 1;
                    array_push($jeligeSzinAzonositok,
                    ['jeligeID' => $felhasznalo->jeligeID,
                    'uid' => $felhasznalo->felhasznalo_id,
                    'colorcode' => self::$SzinKodok[self::$ActuallyColorCodeIndex]]);
                }

                //array_push($jeligeSzinAzonositok);
                // def.: ['jeligeID' => $FelhasznaloFeladat[0]->jeligeID,'colorcode' => self::$SzinKodok[0]]);
            }


        }
        //dd($jeligeSzinAzonositok);

        return json_encode($jeligeSzinAzonositok);
    }

    ///jeligeID szerint
    private static function isExistItem(array $Array,$item)
    {
        foreach($Array as $arrayItem)
        {
            if( $arrayItem['uid'] == $item)
            {
                return true;
            }
        }
        return false;
    }

    ///szinkod szerint
    private static function isExistColorCodeItem(array $Array,$item)
    {
        foreach($Array as $arrayItem)
        {
            if( $arrayItem['colorcode'] == $item)
            {
                return true;
            }
        }
        return false;
    }

    public static function getCsoportVezetok(Request $request,int $csoportID)
    {
       return  DB_OMR_Operations::getCsoportVezetokListaja($csoportID);
    }

}
