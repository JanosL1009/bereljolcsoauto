<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use App\Http\Controllers\DB_OMR_Operations;
use App\Exceptions\Handler;
use App\Http\Controllers\Riport; //DB queries
use App\Http\Controllers\SiteNavAndOperation;
use Illuminate\Http\Request;
use App\Support\Collection;
use App\Http\Controllers\FrontEndMaker;
use App\Http\Models\AdminEsemenyViewModel;
use App\Http\Models\UjhelyszinViewModel;
use App\Http\Models\AdminProfilViewModel;
use App\Http\Models\AdminEsemenyekViewModel;
use App\Http\Models\OnkentesKeresesViewModel;
use App\Http\Models\profilszerkesztesViewModel;
use App\Http\Models\AdminCsopBeosztasViewModel;
use App\Http\Models\FelhasznaloHozzaadasaViewModel;
use App\Http\Models\AdminTeruletModel;
use App\Http\Models\Csoport;
use Illuminate\Support\Carbon;
use App\Http\Models\AdminEsemenyTelepulesViewModel;
use \Exception;
use App\Esemeny;
use App\Allampolgarsag;
use App\Terulet;
use App\Jogosultsag;
use App\User;
use App\FelhasznloSzintek;
use Illuminate\Support\Facades\Input;
use App\Http\Controllers\Msg\OmrEmail;
Use App\Model\Felhasznalo;
use App\Csoport as ProgramCsoport;
use App\Model\BeosztasKezeloRepo;
use App\Teruletvezetok;
use App\Egyhazmegyek;
use App\UserEgyhazmegye;
use App\BeszeltNyelvek;
Use App\FelhasznaloInfo;
use Throwable;
use App\Http\Models\CustomProfileValidator;
use App\Http\Controllers\Logs;
use App\Http\Models\Traits\TraitAllampolgManipulation;
use App\FelhasznaloFeladat;
use App\LogFelhasznaloFeladat;

class AdminisztratorController extends Controller
{
    use TraitAllampolgManipulation;

    public function felhasznalok()
    {
        return view('adminisztratorok/felhasznalok');
    }

    /**
     * Esemenyek, rendezvények listázása
     */
    public function esemenyek(Request $request,$mode=null,$field=null,$order = null)
    {
        $user = auth()->user();
        $model = new AdminEsemenyekViewModel($user['id']);
        $model->profilpic = DB_OMR_Operations::GetProfilkep($user['id']);

        $model->rendezveny = null;
        $model->setMode($mode);



        if(isset($field) && isset($order) )
        {
            if($model->getModeCode() == 0)
                $model->rendezveny = DB::table('esemeny')->orderBy($field,$order)->paginate(15);
            else
            {
                $model->rendezveny = DB::table('esemeny')->where('statusz_id','=',$model->getModeCode())->
                orderBy($field,$order)->paginate(15);
                //dd($model->rendezveny);
            }


            foreach($model->rendezveny as $rend)
            {
                $statuszID = $rend->statusz_id;
                $rend->statusz_id = DB_OMR_Operations::GetEsemenyStatuszForID($statuszID);
                $telepules_id = $rend->telepules_id;
                $rend->telepules_id = DB_OMR_Operations::GetTelepules($telepules_id);
            }

        }
        else
        {

            if($model->getModeCode() == 0)
                {$model->rendezveny = DB::table('esemeny')->paginate(15);
                    //dd($model->rendezveny);
                }
            else
            {
                $model->rendezveny = DB::table('esemeny')->where('statusz_id','=',$model->getModeCode())
                ->paginate(15);
                //dd($model->rendezveny);
            }

            foreach($model->rendezveny as $rend)
            {
                $statuszID = $rend->statusz_id;
                $rend->statusz_id = DB_OMR_Operations::GetEsemenyStatuszForID($statuszID);
                $telepules_id = $rend->telepules_id;
                $rend->telepules_id = DB_OMR_Operations::GetTelepules($telepules_id);
            }
        }






       // dd($model->rendezveny);



        return view('adminisztratorok/esemenyek')->with('model',$model);

    }



    public function felhasznalo_letrehozasa()
    {

        return view('felhasznalo_letrehozasa');
    }

    /** ez valszeg nem kell */
    public function egyeb_uj_felhasznalo_hozzaadasa(Request $request)
    {
         /**
         * @var user  A bejelenkezett felhasznalo! Ő hozza letre az uj usert, igy aza adatbazisba a parent_id-b a kerul
         * a $parent_id valtozo erteke!
         */
        $user = auth()->user();
        $parent_id = $user['id'];
        //$parent_email = $user['email'];
       // var_dump($request);


        $vezeteknev = $request->input('vezeteknev');
        $kozepsonev = $request->input('kozepsonev');
        $keresztnev = $request->input('keresztnev');
        $usernemeValue = $request->input('userneme');
        $email = $request->input('sajatEmailCim');
        $telszam = $request->input('telszam');
        $jogosultsag = $request->input('AdminOnkentes');
        $szulido = $request->input('szulido');

        /*if(isset($szulido))
        {
            $pieces = explode("/", $szulido);
            dd($pieces);
            $szulido = $pieces[0]."-".$pieces[1]."-".$pieces[2];
        }*/

        //$szulido = $request->input('szulido');
        $nev = $vezeteknev." ".$kozepsonev." ".$keresztnev;
        $ActUser = DB_OMR_Operations::GetUser($parent_id);
        $NewUserID = DB_OMR_Operations::InsertUjUsers($nev,$email,$ActUser['email_verified_at'],$ActUser['password'],$ActUser['email_verified_at'],
        $ActUser['created_at'],$ActUser['updated_at'],$ActUser['username'],$ActUser['parent_id']);




        /**
         * @var int szuletesi idot szamitja ki a PHP/Carbon segitsegevel
         */
        $years = Carbon::parse($szulido)->age;

        $isLakcim = $request->input('isTartLakcim');

        $al_lakcim_orszag = $request->input('al_lakcim_orszag');
            $al_lakcim_telepules = $request->input('al_lakcim_telepules');
            $al_lakcim_irszam = $request->input('al_lakcim_irszam');
            $al_lakcim_utca = $request->input('al_lakcim_utca');
            $al_lakcim_megye = $request->input('al_lakcim_megye');
           // dd($al_lakcim_megye);

            $tart_lakcim_orszag = null;
            $tart_lakcim_telepules = null;
            $tart_lakcim_irszam = null;
            $tart_lakcim_utca = null;
            $tart_lakcim_megye = null;
        //dd($isLakcim);
        if($isLakcim == "TartAzonos")
        {


            $tart_lakcim_orszag = $request->input('al_lakcim_orszag');
            $tart_lakcim_telepules = $request->input('al_lakcim_telepules');
            $tart_lakcim_irszam = $request->input('al_lakcim_irszam');
            $tart_lakcim_utca = $request->input('al_lakcim_utca');
            $tart_lakcim_megye = $request->input('al_lakcim_megye');
           // dd($tart_lakcim_utca);
        }
        else if(!isset($isLakcim))
        {


            $tart_lakcim_orszag = $request->input('tart_lakcim_orszag');
            $tart_lakcim_telepules = $request->input('tart_lakcim_telepules');
            $tart_lakcim_irszam = $request->input('tart_lakcim_irszam');
            $tart_lakcim_utca = $request->input('tart_lakcim_utca');
            $tart_lakcim_megye = $request->input('tart_lakcim_megye');

        }
        else
        {
            //error
        }


        $szulhely = $request->input('szulhely');



        $tevekenyseg = $request->input('tevekenyseg');
        $fogyatekossag = $request->input('fogyatekossag');
        $userpolomeret = $request->input('userpolomeret');

        $szakneve = $request->input('szakneve');
        $foiskneve = $request->input('foisk');
        $foiskEvfolyam =  $request->input('evfolyam');
        if(isset($szakneve ) && isset($foiskneve) && isset($foiskEvfolyam))
        {
            DB_OMR_Operations::InsertTevekenysegEgyetemFosuli($NewUserID,$foiskneve,$szakneve,$foiskEvfolyam);
        }


        $munkahelyNeve = $request->input('munkahely');
        $munkakor = $request->input('munkakor');

        if(isset($munkahelyNeve) && isset($munkakor))
        {
            DB_OMR_Operations::InsertTevekenysegMunkahely($NewUserID,$munkahelyNeve,$munkakor);
        }

        $kozepsuliNeve =  $request->input('kozepisk');
        $kozepsuliOsztaly =  $request->input('kozepiskoszt');

        if(isset($kozepsuliNeve) && isset($kozepsuliOsztaly))
        {
            DB_OMR_Operations::InsertTevekenysegIskola($NewUserID,$kozepsuliNeve,$kozepsuliOsztaly,2);
        }

        $altiskNeve =  $request->input('altisk');
        $altiskOsztaly =  $request->input('altiskoszt');

        if(isset($altiskNeve) && isset($altiskOsztaly))
        {
            DB_OMR_Operations::InsertTevekenysegIskola($NewUserID,$altiskNeve,$altiskOsztaly,3);
        }



        $nyelv1 = $request->input('nyelv1');
        $nyelv2 = $request->input('nyelv2');
        $nyelv3 = $request->input('nyelv3');

        if(isset($nyelv1))
        {
            DB_OMR_Operations::UpdateNyelv($NewUserID,$nyelv1,$request->input('nyelv1szint'),1);
        }
        else{
            DB_OMR_Operations::UpdateNyelv($NewUserID,' ',1,1);
        }

        if(isset($nyelv2))
        {
            DB_OMR_Operations::UpdateNyelv($NewUserID,$nyelv2,$request->input('nyelv2szint'),2);
        }
        else{
            DB_OMR_Operations::UpdateNyelv($NewUserID,' ',1,2);
        }

        if(isset($nyelv2))
        {
            DB_OMR_Operations::UpdateNyelv($NewUserID,$nyelv3,$request->input('nyelv3szint'),3);
        }
        else{
            DB_OMR_Operations::UpdateNyelv($NewUserID,' ',1,3);
        }


        $masSzervezetTagja = $request->input('masSzervezetTagja');
        //dd($masSzervezetTagja);
        if($masSzervezetTagja == "1")
        {
            $szervezetNeve = $request->input('egyebSzervezet');
            //dd($szervezetNeve);
            DB_OMR_Operations::UpdateOnkentesMashol($NewUserID,$szervezetNeve);
        }


        $fogyLeirasa = $request->input('fogyLeirasa');


       // print(DB_OMR_Operations::GetTelepulesID("Budapest"));
       // print(DB_OMR_Operations::GetTelepules_JSON());
        //die();
        DB_OMR_Operations::UpdateAllandoLakcim($NewUserID,$al_lakcim_irszam,$al_lakcim_telepules,$al_lakcim_orszag,$al_lakcim_utca,$al_lakcim_megye);
        DB_OMR_Operations::UpdateFelhasznalok($NewUserID,$vezeteknev,$keresztnev,$kozepsonev,$usernemeValue,$email,$szulido,$szulhely,1,'null',$telszam, $years);
        //dd($tevekenyseg);
        DB_OMR_Operations::InsertJogosultsag($NewUserID, $jogosultsag);
        DB_OMR_Operations::UpdateFelhasznaloInfok($NewUserID,$tevekenyseg,$userpolomeret,$fogyatekossag,$fogyLeirasa );
        DB_OMR_Operations::UpdateTartozkodasiLakcim($NewUserID,$tart_lakcim_irszam,$tart_lakcim_telepules,$tart_lakcim_orszag,$tart_lakcim_utca,$tart_lakcim_megye);

        return redirect('admin/onkentes_keresese');
    }

    public function felhasznalo_hozzaadasa(Request $request)
    {
        $user = auth()->user();
        $parent_id = $user['id'];
        $parent_email = $user['email'];

        /*$Felhasznalo = DB_OMR_Operations::GetFelhasznalo($id);
        $FelhasznaloInfo = DB_OMR_Operations::GetFelhasznaloinfo($id);*/
        $model = new FelhasznaloHozzaadasaViewModel();
        $model->email =  $parent_email;
       // $model->foteveknyseg_id = $FelhasznaloInfo['tevekenyseg_id'];
        $model->foteveknyseg = self::GetHTMLTevekenysegMaker(0);
        //dd( $model->foteveknyseg );
        $model->polomeret = self::getPolomeret('0');
        $model->fogyatekossag =  0;
        $model->FogyLeirasa = "";
        $nyelvek = DB_OMR_Operations::GetNyelv1(0);

        for($i = 0;$i < count($nyelvek);$i++)
        {
            if($i == 0)
            {
                $model->nyelv1 = $nyelvek[0]->nyelv;
                $model->nyelv1szint = $nyelvek[0]->nyelvszint_id;
            }
            if($i == 1)
            {
                $model->nyelv2 = $nyelvek[1]->nyelv;
                $model->nyelv2szint = $nyelvek[1]->nyelvszint_id;
            }
            if($i == 2)
            {
                $model->nyelv3 = $nyelvek[2]->nyelv;
                $model->nyelv3szint = $nyelvek[2]->nyelvszint_id;
            }

            if($i == 2)
            {
                break;
            }
        }

        $model->nyelv1szint = self::GetNyelvSzintHTML($model->nyelv1szint);
        $model->nyelv2szint = self::GetNyelvSzintHTML($model->nyelv2szint);
        $model->nyelv3szint = self::GetNyelvSzintHTML($model->nyelv3szint);
        $model->all_lakcim_orszag =  DB_OMR_Operations::GetOrszagOptions_HTML();
        $model->tart_lakcim_orszag =  DB_OMR_Operations::GetOrszagOptions_HTML();
        $model->Megye_AllLakcim = DB_OMR_Operations::GetMegyekOptions_HTML();
        $model->Megye_TartLakcim = DB_OMR_Operations::GetMegyekOptions_HTML();

        return view('adminisztratorok/felhasznalo_hozzaadasa')->with('model',$model);
    }

    public function CreateNewUser(Request $request)
    {


        $validatedData = $request->validate([
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users']
        ]);

        $password = 'Alap123456';

        $name = $request->vezeteknev." ".$request->kozepsonev." ".$request->keresztnev;

         $user = \App\User::create([
            'name' => $name,
            'email' => $request->email,
            'password' => \Hash::make($password),
        ]);

        $user->sendEmailVerificationNotification();

        \DB::table('jogosultsag')->insert(["felhasznalo_id" => $user->id, "felhasznaloszint_id" => $request->jog]);

        DB_OMR_Operations::InsertDatableEmail($user->id, $user->email);

        \DB::table('felhasznalok')->where('email', $user->email)->update([
            "vezeteknev" => $request->vezeteknev,
            "kozepsonev" => $request->kozepsonev,
            "keresztnev" => $request->keresztnev,
            "telefonszam" => $request->telefonszam
        ]);


        return redirect('/admin/onkentes_keresese');
    }



    public function esemeny_szerkesztes(Request $request,int $esemenyid)
    {
        $user = auth()->user();
        $model = new AdminEsemenyViewModel($user['id']);
        $Esemeny = DB_OMR_Operations::GetEsemenyForId($esemenyid);
       // dd($Esemeny);

        $model->esemenyID = $esemenyid;
        $model->esemenyNeve = $Esemeny->nev;
        $model->kezdesDatuma = $Esemeny->kezdesDatum;
        $model->kezdesIdeje = $Esemeny->kezdesIdeje;
        $model->befejezesDatuma = $Esemeny->befejezesDatum;
        $model->befejezesIdeje = $Esemeny->befejezesIdeje;
        $model->Leiras = $Esemeny->Leiras;

        if ($Esemeny->toborzas == 1)
        {
            $model->Toborzas = 'checked';
        }
        else
        {
            $model->Toborzas = null;
        }

        $esemenyhelyszin = DB_OMR_Operations::GetEsemenyTelepules($esemenyid);
        $model->helyszin = array();

        foreach ($esemenyhelyszin as $helyszin)
        {
            //dd($helyszin);
            $Helyszinek = new AdminEsemenyTelepulesViewModel();

            $telepules = DB::table('helyszin')->where('id','=',$helyszin->telepules_id)->get();

            $Helyszinek->Telepulesnev = isset($telepules[0]->Neve)?$telepules[0]->Neve:'-';
           // dd($telepules[0]->Cim);
            $Helyszinek->cim = $telepules&&isset($telepules[0]->Cim)?$telepules[0]->Cim:'-';;
            $Helyszinek->id = $helyszin->es_id;

            array_push($model->helyszin, $Helyszinek);
        }

        $model->Statusz = DB_OMR_Operations::EsemenyStatuszOptionsHTML($Esemeny->statusz_id);
        $model->adminLista = DB::table('users')->join('jogosultsag',"users.id",'=','jogosultsag.felhasznalo_id')->select('users.*')->where('jogosultsag.felhasznaloszint_id','=',1)->get();



        $model->EsemenySzervezok = DB::table('users')->join('esemeny_szervezok','users.id','=','esemeny_szervezok.felhasznalo_id')->select('users.*')->where('esemeny_szervezok.szint_id','=',3)->get();

        $adminListaArray = $model->adminLista->pluck('id')->toArray();
        //dd($adminListaArray);
        $bovitettListaAznositok = DB::table('users')->join('esemeny_szervezok','users.id','=','esemeny_szervezok.felhasznalo_id')
        ->where('esemeny_szervezok.szint_id','=',3)->where('esemeny_szervezok.Esemeny_id','=',$model->esemenyID)->get('users.id');
        $azonositok = $bovitettListaAznositok->pluck('id')->toArray();
        $result = array_diff($azonositok, $adminListaArray);
        //dd($result);
        $bovitettLista = DB::table('users')->whereIN('id',$result)->get(['id','name','email']);

        unset($bovitettListaAznositok);
        $csoportvezetok = DB_OMR_Operations::getCsoportVezetokListajaEsemenySzerintOsszes($model->esemenyID);
        $teruletvezetok = DB_OMR_Operations::getTeruletVezetokListajaEsemenySzerintOsszes($model->esemenyID);

        $model->teruletek = DB_OMR_Operations::GetTeruletek($esemenyid);

        $beosztasKezelo = new BeosztasKezeloRepo(null,$esemenyid);
        $model->BeosztottakSzama = $beosztasKezelo->GetBeosztottakSzama(true);
        $model->NemBeosztottakSzama = $beosztasKezelo->getNemBeosztottak(true);


        /**
         * @version 1.1.0 Csak azok vannak a listaban akik adminok
         */

        return view('adminisztratorok/esemenyszerkesztese')->with('model',$model)->
        with('csoportvezetok',$csoportvezetok)->with('teruletvezetok',$teruletvezetok)->with('bovitettLista',$bovitettLista);
    }




    public function esemeny_szerkesztes_feldolgozo(Request $request, $esemenyid)
    {
        $esemenyNeve = $request->input('Esemenynev');
        $esemenykezdesDatum = $request->input('esemenykezdesDatum');
       //dd($request->all());
        $esemenyKezdesIdeje = $request->input('esemenyKezdesIdeje');
        $befejezesDatuma = $request->input('befejezesDatuma');
        $befejezesIdeje = $request->input('befejezesIdeje');
        $Leiras = $request->input('rendezvenyLeiras');
        $statusz = $request->input('statusz');
        DB::table('esemeny')->where('id','=',$esemenyid)->update( ['nev' => $esemenyNeve, 'kezdesDatum' => $esemenykezdesDatum,'kezdesDatum' => $esemenykezdesDatum ,
        'kezdesDatum' => $esemenykezdesDatum,'kezdesIdeje' => $esemenyKezdesIdeje,'befejezesDatum' => $befejezesDatuma,'befejezesIdeje' => $befejezesIdeje,
        'Leiras' => $Leiras,'statusz_id' => $statusz
        ]);


        $helyszin = 'szin'; $helyszincim = 'cim';
        $findme   = 'helyszin';

        $helyszinek = array();

        $reqArray = $request->all();
        //dd($reqArray);
        $v = $request->input('elsohelyszin'); //mert az indexelés itt kezdodik a HTML attibutumban helyszin1
        //dd($v);
        foreach ($reqArray as $key => $value)
        {

            $pos = strpos($key, $findme);
            //dd($key);
            if($pos == 0)
            {
                $_telepules = 'helyszin'.intval($v);
                //dd($_telepules);

                if(isset($_telepules))$telepules = $request->input($_telepules);
               // dd($telepules);
              // $rh = new RendezvenyHelyszin($v,$telepules,$value);

              if(isset($telepules))
                array_push($helyszinek,$telepules);

               $v++;
            }
            //if($v == 11)  dd($reqArray,$pos);


        }

        //dd($helyszinek);
        //sorba rendezett helyszin_id-k lekerdezve
        $telepulesek = DB::table('esemeny_telepules')->where('esemeny_id','=',$esemenyid)->select('telepules_id')->orderBy('telepules_id','asc')->get();
       // dd($telepulesek);
        $Is_UjTelepules = false;

        $i = 0;
        while($i < count($helyszinek))
        {

            $helyszinID = DB::table('helyszin')->where('Neve',$helyszinek[$i])->select('id')->get()->first()->id;
           // dd($helyszinID);
            $eredmeny = DB::table('esemeny_telepules')->where('esemeny_id',$esemenyid)->where('telepules_id','=',$helyszinID)->exists();

            if(!$eredmeny)
            {
                DB::table('esemeny_telepules')->insert(['esemeny_id' => $esemenyid,'telepules_id' =>  $helyszinID ]);
            }
            $i++;
        }

return back();
        //return redirect('/admin/esemeny_szerkesztes/'.$esemenyid);
    }


    /**
     * Új rendezvény létrehozása frontend
     */
    public function ujesemeny()
    {

        return view('/adminisztratorok/ujesemeny');
    }

     /**
     * Új rendezvény létrehozása, post feldolgozó
     */
    public function ujesemenyletrehozasa(Request $request)
    {
        $RendezvenyNeve = $request->input('rendezvenyNev');

        $KezdesDatum = $request->input('rendezvenyKezdDatuma');
        $kezdIdejeOra = $request->input('kezdIdejeOra');
        $kezdIdejePerc = $request->input('kezdIdejePerc');
        $KezdeIdeje = $kezdIdejeOra.":".$kezdIdejePerc;

        $BefDatum = $request->input('rendezvenyBefDatuma');

        $befIdejeOra = $request->input('befIdejeOra');
        $befIdejePerc = $request->input('befIdejePerc');
        $befIdeje = $befIdejeOra.":".$befIdejePerc;

        $Leiras = $request->input('rendezvenyLeiras');
        $Statusz = $request->input('RendezvenyStatusza');

        $request->validate(
           [ "helyszin1" => "required|string"  ]
        );
       

        $helyszin = 'szin'; $helyszincim = 'cim';
        $findme   = 'helyszin';

        $helyszinek = array();

        $reqArray = $request->all();

        $v = 1; //mert az indexelés 1nel kezdodik a HTML attibutumban helyszin1
        foreach ($reqArray as $key => $value)
        {

            $pos = strpos($key, $findme);

            if($pos == 0)
            {
                $_telepules = 'helyszin'.intval($v);
                $telepules = $request->input($_telepules);
               $rh = new RendezvenyHelyszin($v,$telepules,$value);
              // dd($rh);
               array_push($helyszinek,$rh);
               $v++;
            }
            //if($v == 11)  dd($reqArray,$pos);


        }




        /**
         * @var int A beszurt elem id-jat tartalmazza
         */
        $lastIndex = DB_OMR_Operations::InsertEsemeny($RendezvenyNeve,$KezdesDatum,$KezdeIdeje,$BefDatum,$befIdeje,$Statusz,0,$Leiras,'null','NULL',109);

        foreach($helyszinek as $helyszin)
        {
            $helyID = DB::table('helyszin')->where('Neve','=',$helyszin->telepules)->select('id')->get(); //DB_OMR_Operations::GetTelepulesID($helyszin->telepules);
          //dd($helyID[0]->id);
           // DB_OMR_Operations::InsertEsemenyTelepules($lastIndex,$helyID[0]->id,'null');
           if(isset($helyID[0]))
           {
            DB::table('esemeny_telepules')->insert(['esemeny_id' => $lastIndex ,'telepules_id' => $helyID[0]->id,'cim' => 'null']);
           }
        }


        //return redirect('admin/esemenyek');
            return redirect(route('admin.esemenyszerk',['esemenyid' => $lastIndex]));
    }

    //az esemeny_id hianyzik a linkhez
    public function UjTeruletLetrehozasa(Request $request)
    {
        $esemenyID = $request->input('teruletesemenyi');
        $kezdesDatuma = $request->input('kezdIdoEvT')."-".$request->input('kezdIdoHoT')."-".$request->input('kezdIdoNapT');
        $kezdesIdeje = $kezdesDatuma." ".$request->input('kezdIdejeOra').":".$request->input('kezdIdejePerc').":00";
        
        $befejezesDatuma = $request->input('befIdoEvT')."-".$request->input('befIdoHoT')."-".$request->input('befIdoNapT');
        $befejezesIdeje = $befejezesDatuma." ".$request->input('befIdejeOra').":".$request->input('befIdejePerc').":00";
        
        $thelyszin = $request->input('thelyszin1');

        $HelyszinID = null;
       
        $HelyszinID = DB::table('helyszin')->where('Neve','=',$thelyszin)->select('id')->first();
        
        $Leiras = $request->input('teruletLeiras');
     
        if(!isset($Leiras))
        {
            $Leiras = " ";
        }
      
        /**
         * Ez az azert kerult ide, hogy esetleg ha  a fronentrol rossz input erkezne, akkor is legyen egy helyszin tarsitva a terulethez
         */
        if(is_null($HelyszinID))
        {
            //a program helyszint kell majd fel venni
            $HelyszinID =  DB::table('helyszin')->select('id')->first();

        }

        DB::table('terulet')->insert(['nev' => $request->input('teruletNeve'),
                          'leiras' =>   $Leiras,
                          'esemeny_id' => $esemenyID,
                          'kezdesIdopont' =>$kezdesIdeje,
                          'befejezesIdopont' => $befejezesIdeje,
                          'tervezettLetszam' => $request->input('tervLetszam'),
                          'jelentkezokSzama' => 0,
                          'teruletHelyszineID' => $HelyszinID->id,
                          'teruletAktiv' => 0
        ]);

        return back()->withErrors(['teruletletrehozasa',1]);
       // return redirect('admin/esemeny_szerkesztes/'.$esemenyID);
    }

    //az esemeny_id hianyzik a linkhez
    public function UjCsoportLetrehozasa(Request $request)
    {
        $user = auth()->user();

       

        $esemenyID = $request->input('esemenyi');
        $kezdesDatuma = $request->input('kezdIdoEvCs')."-".$request->input('kezdIdoHoCs')."-".$request->input('kezdIdoNapCs'); 
        $befejezesDatuma = $request->input('befIdoEvCs')."-".$request->input('befIdoHoCs')."-".$request->input('befIdoNapCs');

        $kezdesIdeje = $request->input('cskezdIdejeOra').":".$request->input('cskezdIdejePerc').":00";
        $befejezesIdeje = $request->input('csbefIdejeOra').":".$request->input('csbefIdejePerc').":00";
        
        
        $csNev = $request->input('csoportNeve');
        $csLeiras = $request->input('csoportLeiras');
        $csTerulet = $request->input('csTerulet');
        $cstervLetszam = $request->input('cstervLetszam');
        $helyszin = $request->input('cshelyszin1');
        $helyszinID = null;

        try
        {
            $helyszinID = DB::table('alhelyszin')->where('nev',$helyszin)->first()->id; //alhelyszin lett : version 2.0
        }
        catch(Exception $e)
        {
           return back()->withErrors('Sikertelen csoport létrehozás. Hiba: nem létező alhelyszín.','nemletezoelhelyszin');
        }
        
        $csoport = new ProgramCsoport;
        $csoport->nev =  $csNev;
        $csoport->kezdesDatuma =  $kezdesDatuma;
        $csoport->kezdesIdeje =  $kezdesIdeje;
        $csoport->befejezesDatuma =  $befejezesDatuma;
        $csoport->befejezesIdeje =  $befejezesIdeje;
        $csoport->igenyelt_onkentes_letszam =  $cstervLetszam;
        $csoport->helyszin_id = $helyszinID; //mar alhelyszin tablabol dolgozik!!!
        $csoport->leiras =  $csLeiras;
        $csoport->terulet_id =  $csTerulet;
        $csoport->letrehozo =  $user['id'];
        $csoport->save();

        $Helyszinek = null; //???? nemeelég egy helyszin???
       // DB_OMR_Operations::InsertCsoport($csNev,$kezdesDatuma,$kezdesIdeje,$befejezesDatuma,$befejezesIdeje,1,$cstervLetszam,$csLeiras,$csTerulet);
        return back();
        //return redirect('admin/esemeny_szerkesztes/'.$esemenyID);
    }

    public function Csoport_szerkesztes(Request $request,$id)
    {
        $user = auth()->user();
        $model = new Csoport($user['id'],$id);
        $csoport  = \DB::table('csoport')->where('id', $id)->first();
        $model->profilpic = DB_OMR_Operations::GetProfilkep($user['id']);

       // dd($csoport);
       // dd(DB_OMR_Operations::GetHelyszinNev($csoport[0]->id));
       // $helyszin = DB_OMR_Operations::GetHelyszinNev($csoport->helyszin_id)->first();
        $helyszin = \App\AlHelyszin::where('id',$csoport->helyszin_id)->first();

        $model->CsoportNeve = $csoport->nev;
        $model->igenyeltOnkentesLetszam = $csoport->igenyelt_onkentes_letszam;
        $model->Leiras = $csoport->leiras;

        if(isset($helyszin))
        {
            $model->helyszin_id = $csoport->helyszin_id;
            $model->helyszin = $helyszin->nev;
           // $model->cim = $helyszin->Cim;
        }
        else
        {
            $model->helyszin_id = "";
            $model->helyszin = "";
            //$model->cim = "";
        }

        $model->terulet_id = $csoport->terulet_id;
        $model->kezdesDatuma = $csoport->kezdesDatuma;
        $model->kezdesIdeje = $csoport->kezdesIdeje;
        $model->befejezesDatuma = $csoport->befejezesDatuma;
        $model->befejezesIdeje = $csoport->befejezesIdeje;

        $model->breadcrumblink = FrontEndMaker::getBreadCrumLinkCsoportSzerkForAdmin($csoport->id);
        $Terulet = Terulet::find($model->terulet_id);
        $teruletKezdesIdeje = explode(' ',$Terulet->kezdesIdopont)[0];
        $teruletBefejezesIdeje = explode(' ',$Terulet->befejezesIdopont)[0];

        return view('/adminisztratorok/csoportszerkesztes')->with('model',$model)->with('teruletKezdesIdeje',$teruletKezdesIdeje)
        ->with('teruletBefejezesIdeje',$teruletBefejezesIdeje);
    }

    public function Csoport_szerkesztese_feldolgozo(Request $request,$id){

        $helyszinID =  \App\AlHelyszin::where('nev',$request->cshelyszin1)->first()->id;
        $d = Carbon::now();
        $user = auth()->user();
        try{
            $csoport  = \DB::table('csoport')->where('id', $id)->update([

                "nev" => $request->csoportNeve,
                "leiras" => $request->csoportLeiras,
                "kezdesDatuma" => $request->cskezdIdejeDatum,
                "kezdesIdeje" => $request->cskezdIdejeOra.':'.$request->cskezdIdejePerc,
                "befejezesDatuma" => $request->csbefIdejeDatum,
                "befejezesIdeje" =>  $request->csbefIdejeOra.':'.$request->csbefIdejePerc,
                "igenyelt_onkentes_letszam" => $request->cstervLetszam,
                "helyszin_id" => $helyszinID,
                "modosito" => $user["id"],
                "updated_at" => $d
            ]);
        }
        catch(Exception $e)
        {
            return back()->withErrors('Sikertelen mentés! Hiba a feldolgozásban.','hibamentes');
        } 
       

        return back()->withErrors('Sikeres mentés!','sikeresmentes');
    }




    public function Csoportok_lekerdezese($teruletid)
    {
        $model = DB_OMR_Operations::CsoportLista($teruletid);

        $pages = DB::table('csoport')->where('terulet_id', '=' , $teruletid)->paginate(15);

        return view('/adminisztratorok/csoportok',['pages' => $pages])->with('model',$model);
    }




    public function esemeny_lekerdezes(Request $request,$esemenyid)
    {
        $user = auth()->user();
        $model = new AdminEsemenyViewModel($user['id']);
        $model->profilpic = DB_OMR_Operations::GetProfilkep($user['id']);
        return view('/adminisztratorok/esemeny')->with('model',$model);
    }

    /**Egy felhasznalo hozzaadasa */
    public function ujfelhasznalo_hozzaadasa()
    {

        return view('adminisztratorok/ujfelhasznalo_hozzaadasa');
    }

    public function felhasznaloszerkesztese(Request $request,$felhasznaloid)
    {

        return view('adminisztratorok/felhasznaloszerkesztese');
    }

/**
 * **********************       **********************      **********************      **********************      **********************      **********************
 *
 *                                          ONKENTESEK ADMINISZTRACIOJA
 *
 * **********************       **********************      **********************      **********************      **********************      **********************
 */

    /**
     * Kersest biztosit az onkentesek kozott
     */
    public function onkentes_kereses(Request $request)
    {
        $user = auth()->user();
        $model = new OnkentesKeresesViewModel($user['id']);
        $model->profilpic = DB_OMR_Operations::GetProfilkep($user['id']);

        $user = new User;
        $szemelyek = null;

        $email = $request->input('volemail');

        if(isset($email))
        {
            $szemelyek = \App\User::where('email',$email)->get();
            $szemelyek = $this->getNewKeresoCollection($szemelyek)->paginate(15);
        }
        else
        {
            $name = $request->input('onkentes_neve');

            $kor = $request->input('onkentes_kora');
            $esemeny = $request->input('rendezveny');
    
    
    
            if(isset($esemeny))
            {
                $terulet = $request->input('terulet');
                if(!isset($terulet ) || $terulet > 1)
                {
                    $szemelyek = \App\User::all();
    
                    $esemenyJelentkezok = \App\TeruletBeosztas::where('terulet_id','=',$terulet)->get();
                    $queryArray = [];
                    foreach($esemenyJelentkezok as $jelentkezo)
                    {
                        array_push($queryArray,$jelentkezo->felhasznalo_id);
                    }
                    $szemelyek = $szemelyek->intersect(User::whereIn('id', $queryArray)
                    ->where('name', 'like', '%'.$name.'%')->get());
                   // dd($szemelyek);
                }
                else
                {
                    $szemelyek = \App\User::all();
    
                    $esemenyJelentkezok = \App\FelhasznaloFeladat::where('esemeny_id',$esemeny)->get();
                    $queryArray = [];
                    foreach($esemenyJelentkezok as $jelentkezo)
                    {
                        array_push($queryArray,$jelentkezo->felhasznalo_id);
                    }
                    $szemelyek = $szemelyek->intersect(User::whereIn('id', $queryArray)
                    ->where('name', 'like', '%'.$name.'%')->get());
                   // dd($szemelyek);
                }
    /*
                if(isset($name))
                {$szemelyek = $szemelyek->where('name', 'like', '%'.$name.'%');}
    */
                if(isset($kor) )
                {
                    $szemelyek = $szemelyek->where('felhasznalo_data.kor','=',$kor);
                }
    
                $szemelyek = $this->getNewKeresoCollection($szemelyek)->paginate(15);
    
            }
            else
            {
    
                if(isset($name) || isset($kor) )
                {
    
                    if($kor > 12)
                    {
                        $szemelyek = \App\User::where('name', 'like', '%'.$name.'%')->whereHas('felhasznalo_data',function($query)
                        use ($kor) {
                            $query->where('kor',$kor);
                        });
                        $szemelyek = $szemelyek->orderBy('name')->get();
    
                        $szemelyek = $this->getNewKeresoCollection($szemelyek)->paginate(15);
                    }
                    else
                    {
                        $szemelyek = \App\User::where('name','like','%'.$name.'%')->orderBy('name')->get();
                       // dd($name,$szemelyek);
                        $szemelyek = $this->getNewKeresoCollection($szemelyek)->paginate(15);
                      //  dd($szemelyek);
                    }
                }
    
            }
        }

       


        $model->programok = Esemeny::orderBy('nev')->get();

        if(isset($szemelyek))
        {

            return view('adminisztratorok/onkentes_keresese',['szemelyek' => $szemelyek->appends(Input::except('page')) ])
            ->with('model',$model)->with('szemelyek',$szemelyek);
        }
        else
        {
            return view('adminisztratorok/onkentes_keresese')->with('model',$model);
        }

    }
    /**
     * Visszater egy collection-el, ami tartalmazza a kereso reszletes adatait. Tobb collectionbol keszit egy sajatot
     * collection tartalma: id,nev,szuletesi ido, cim, profilkep, jogosultsag, vezetoi szintek
     *
     * @return Collection Kereso adatlapok eredmenyei
     */
    protected function getNewKeresoCollection($UserCollection, $FelhasznaloFeladatCollection = null)
    {
            $NewCollection = array();
            if(isset($FelhasznaloFeladatCollection)) //program szerinti keresesnel NEM null
            {

            }
            else //ha nem program szerint keres (kor,nev)
            {
                //dd($UserCollection[0]);
                foreach($UserCollection as $User)
                {
                    $NewUser = null;
                    $NewUser['id'] = $User->id;
                    $NewUser['nev'] = $User->name;
                    if(isset($User->felhasznalo_data))
                    {
                        $NewUser['szulIdo'] = $User->felhasznalo_data->szulIdo;
                        $NewUser['lakcim'] = $User->felhasznalo_data->lakcim;
                        $NewUser['profilkep'] = $User->felhasznalo_data->profilkep;
                    }
                    $NewUser['jogosultsag'] = null;
                    /**
                     * Lehet: Önkéntes, Önkéntes és Ruha átadó, Adminisztrátor
                     */
                    $jogok = Jogosultsag::where('felhasznalo_id',$User->id)->get();
                    if(isset($jogok))
                    {
                            foreach($jogok as $jog)
                            {
                                        $NewUser['jogosultsag'] = $NewUser['jogosultsag'].' '.FelhasznloSzintek::find($jog->felhasznaloszint_id)->SzintNeve;

                            }

                    }


                    array_push($NewCollection,$NewUser);

                }
            }
            //dd($NewCollection);
            return new Collection($NewCollection);
    }


    /**
     * Az onkentes_keressese pont alatt a linkek (a talalt felhasznalok profilja ) ide vezetnek
     *
     * @param int A talalt felhasznalo azonositoja
    */
    public function onkentesSzerkesztese(Request $request,$felhasznaloid)
    {
        $authuser = auth()->user();
        $AdminID = $authuser['id'];
        $model = new AdminProfilViewModel($AdminID );

        $adminkep = DB::table('users')->join('felhasznalok','users.id','=','felhasznalok.id')->where('users.id','=',$AdminID)->select('felhasznalok.profilkep')->first();
       
        $userM = \App\User::where('id', $felhasznaloid)->first();

        if(!$userM)
            return back();


        $felhT = \DB::table('felhasznalok')
                    ->where('id', $felhasznaloid)
                    ->first();

        if(!$felhT)
            return back();

        $id = $felhT->id;

        
        $Felhasznalo = Felhasznalo::find($id);
        $profilkepvalidstatus = (int)$Felhasznalo->kepvalidalas;
        $FelhasznaloInfo = FelhasznaloInfo::where('felhasznalo_id',$id)->first();
        $szallastIgenyel = $FelhasznaloInfo->szallastIgenyel;
        

        $model->Vezeteknev = $Felhasznalo->vezeteknev;
        $model->Keresztnev = $Felhasznalo->keresztnev;
        $model->Kozepsonev =$Felhasznalo->kozepsonev;

        $model->Neme_id = $Felhasznalo->neme;
        $model->Nem =  "";
        if($model->Neme_id == 0)
        {
            $model->Nem = "Férfi";
        }
        else
        {
            $model->Nem = "Nő";
        }

        $model->email =  $userM->email;
        

        if(isset($Felhasznalo->szulIdo))
        {/*
            $pieces = explode("-", $Felhasznalo['szulIdo']);
            $model->szulido = $pieces[0]."/".$pieces[1]."/".$pieces[2];*/
            $model->szulido = $Felhasznalo->szulIdo;
        }
        $model->EletKor = $Felhasznalo->kor;

        $model->szulhely =  $Felhasznalo->szulhely_ID;

        $model->Telefonszam = $Felhasznalo->telefonszam;


        if(isset($Felhasznalo->onkentesOrakSzama))
        {
            $model->onkentesOrakSzama =  $Felhasznalo->onkentesOrakSzama;
        }


        $model->foteveknyseg_id = $FelhasznaloInfo->tevekenyseg_id;
        //dd($model->foteveknyseg_id);
        $model->foteveknyseg = self::GetHTMLTevekenysegMaker($model->foteveknyseg_id);
        //dd( $model->foteveknyseg );
        $model->polomeret = self::getPolomeret($FelhasznaloInfo['polomeret']);
        $model->fogyatekossag =  $FelhasznaloInfo['fogyatekossag'];
        $model->FogyLeirasa = $FelhasznaloInfo['fogyLeirasa'];
        
        $nyelv1 = DB::table('nyelvismeret')->where('felhasznalo_id',$id)->where('sorrend',1)->get()->first();
        $model->nyelv1 = $nyelv1->nyelv??' ';
        $model->nyelv1szint =   self::GetNyelvSzintHTML($nyelv1->nyelvszint_id??0);
        $nyelv2 =  DB::table('nyelvismeret')->where('felhasznalo_id',$id)->where('sorrend',2)->get()->first();
        $model->nyelv2 = $nyelv2->nyelv??' ';
        $model->nyelv2szint =   self::GetNyelvSzintHTML($nyelv2->nyelvszint_id??0);
        $nyelv3 = DB::table('nyelvismeret')->where('felhasznalo_id',$id)->where('sorrend',3)->get()->first();
        $model->nyelv3 = $nyelv3->nyelv??' ';
        $model->nyelv3szint =   self::GetNyelvSzintHTML($nyelv3->nyelvszint_id??0);
        $nyelv4 = DB::table('nyelvismeret')->where('felhasznalo_id',$id)->where('sorrend',4)->get()->first();
        $model->nyelv4 =  $nyelv4->nyelv??' ';
        $model->nyelv4szint =   self::GetNyelvSzintHTML( $nyelv4->nyelvszint_id??0);

        $nyelv5 = DB::table('nyelvismeret')->where('felhasznalo_id',$id)->where('sorrend',5)->get()->first();
        $model->nyelv5 = $nyelv5->nyelv??' ';
        $model->nyelv5szint =   self::GetNyelvSzintHTML($nyelv5->nyelvszint_id??0);

        $model->BeszelhetoNyelvek = BeszeltNyelvek::orderBy('nyelvNeve','asc')->get('nyelvNeve');

        if(isset($FelhasznaloInfo->etkezesIgenyID))
       {
         $model->setEtkezesiIgenyekArray($FelhasznaloInfo["etkezesIgenyID"]);
       }

         /**
         * Eloallitja a kimeneti html tartalmat.
         */
        $model->setEtkezesiIgenyekHTML(false);

        $model->igazolasIgenyID = $FelhasznaloInfo->igazolasIgenyID;
        if($model->igazolasIgenyID == 4)
        {
            $model->igazolasIgenyLeiras = $FelhasznaloInfo->igazolasEgyeb;
        }

        $allando = DB_OMR_Operations::GetAllandoLakcim($id);

        if(isset($allando))
        {
            $model->all_lakcim_orszag =  DB_OMR_Operations::GetOrszagOptionsId_HTML($allando->Orszag);
            $model->all_lakcim_telepules = $allando->Telepules;
            $model->all_lakcim_irszam = $allando->IranyitoSzam;
            $model->all_lakcim_utca = $allando->Cim;
            $All_megyeID = DB_OMR_Operations::GetAllLakcim_MegyeIDForUser($id);
            $model->Megye_AllLakcim = DB_OMR_Operations::GetMegyekOptionsId_HTML($All_megyeID);
            //dd($model->Megye_AllLakcim);
        }




        $tartozkodasi = DB_OMR_Operations::GetTartozkodasiLakcim($id);
        if(isset($tartozkodasi))
        {
            $model->tart_lakcim_orszag = $tartozkodasi->OrszagID;
            $model->tart_lakcim_telepules = $tartozkodasi->TelepulesID;
            $model->tart_lakcim_utca = $tartozkodasi->Cim;
            $model->tart_lakcim_irszam = $tartozkodasi->IranyitoSzam;
            $Tart_megyeID = DB_OMR_Operations::GetTartLakcim_MegyeIDForUser($id);
            $model->Megye_TartLakcim = DB_OMR_Operations::GetMegyekOptionsId_HTML($tartozkodasi->megyeID);

            $model->tart_lakcim_orszag = DB_OMR_Operations::GetOrszagOptionsId_HTML($tartozkodasi->OrszagID);

        }


        $tev = DB_OMR_Operations::GetFoTevekenyseg_With_HTML_Output($id);
        $model->fotevekenysegHTML = $tev;
        unset($allando);

        $model->OnkentesProfilPic = DB_OMR_Operations::GetProfilkep($id);
        //dd($model);
        $model->masSzervezetTagja = DB_OMR_Operations::IsMasSzervezetTagja($id);

        $model->MasSzervezetNeve = "";

        if($model->masSzervezetTagja)
        {
            $model->MasSzervezetNeve = DB_OMR_Operations::GetEgyebSzervezet($id)->szervezet_neve;
        }

        $model->CivilSzervezetTagja = DB_OMR_Operations::IsCivilSzervezetTagja($id);

        $model->CivilSzervezetNeve = "";

        if($model->CivilSzervezetTagja)
        {
            $model->CivilSzervezetNeve = DB_OMR_Operations::GetCivilSzervezet($id)->szervezet_neve;
        }

        //uj adatok
        $szemelyesadatok = DB::table('szemelyesadatok')->where('felhasznalo_id','=',$id)->whereNotNull('felhasznalo_id')->get()->first();
        if(isset($szemelyesadatok))
        {
            $model->szemigszam =  $szemelyesadatok->szemigszam;
            $model->anyjaneve =  $szemelyesadatok->anyjaneve;
            try
            {
                $model->allampolgarsag = Allampolgarsag::find( $szemelyesadatok->allampolgarsag)->allampolgarsag;
            }
            catch(Exception $e)
            {
                $model->allampolgarsag = -1;
            }
        }
        else{
            $model->szemigszam =  "";
            $model->anyjaneve =  "";
            $model->allampolgarsag = "";
        }

        try
        {
            $model->polotipusa = DB::table('ruhaatado_atvetel')->where('felhasznalo_id','=',$id)->select('polotipus')->get()->first()->polotipus;
        }
        catch(Exception $exception)
        {
            $model->polotipusa = -1;
        }

        $egyhazmegyek = Egyhazmegyek::all();

        $egyhazmegyek_groups = $egyhazmegyek->groupBy(function($item){
            return $item->felekezet;
        });
        $felekezetek = $egyhazmegyek_groups->keys()->all();

        $egyhazmegyek = $egyhazmegyek->ToJson();

        $valasztottEgyhaz = null;

        try{
                $valasztottEgyhaz = UserEgyhazmegye::where('felhasznalo_id',$id)->select(
                "egyhazmegye_id",
                "egyebInputValue",
                "nemTag"
            )->first();
            $valasztottEgyhaz = json_encode($valasztottEgyhaz);
        }
        catch(Throwable $t)
        {
            $valasztottEgyhaz = null;
        }


        $model->jogszint = DB::table('jogosultsag')->where('felhasznalo_id','=',$id)->select('felhasznaloszint_id')->get()->first()->felhasznaloszint_id;

        //dd($userM );
        $model->blocked = $userM->blocked;
        if($model->blocked == 1)
        {
            $model->blocked_at = $userM->blocked_at;
            $modifier = $userM->modifier;
            $model->WhoBannedForName = DB::table('users')->where('id',$modifier)->select('name')->first()->name;
        }

        $tevnaplo = Logs::getUsersTable((int)$id);
        $logins = Logs::getLogins($id);
        $accverified = null;
        if(isset($userM->email_verified_at))
        {
            $accverified = true;
        } else $accverified = false;

       // dd($userM->email_verified_at,$accverified);

        return view('adminisztratorok/felhasznaloszerkesztese',
        ['egyhazmegyek' => $egyhazmegyek,
        'felekezetek' => $felekezetek,
         'valasztottEgyhazMegye' =>  $valasztottEgyhaz,
         'szallastIgenyel' => $szallastIgenyel
        ]
        )->with('model',$model)->with('id',$id)->with('tevnaplo',$tevnaplo)->with('logins',$logins)
        ->with('profilkepvalidstatus',$profilkepvalidstatus)
        ->with('accverified',$accverified);
    }

    public function onkentesTorlese(Request $request)
    {
        $email = $request->input('email');
        $res = DB::table('users')->where('email', '=', $email )->first();
        DB::table('users')->where('email', '=', $email )->delete();
        DB::table('felhasznalok')->where('email', '=', $email )->delete();
      /*  $lff = new LogFelhasznaloFeladat();
        $lff->*/
        
        unset($res); unset($lff);
        return  redirect('admin/onkentes_keresese');
    }

    /**
     * @version 3.0
     * Az adminisztrator kepes feljelentkeztetni onnkenteseket a rendszeren belul!
     */
    public function terulet_jelentkezes(Request $request)
    {
        
        $UserId = (int)$request->input('uid');
        $user = User::find($UserId);
        $felhasznalo_id = $UserId;
        
        $terulet_id = $request->input('terulet');
        $esemeny_id = $request->input('rendezveny');
        $priority = $request->input('priority');
        
        $all = 0;
        if($request->input('other') == 'on')
        {
            $all = 1;
        }

        $jelige = $request->input('jelige');
        $jeligeID = null;
        if(isset($jelige))
        {
            try{
                $jeligeID = Jeligek::where('jeligeNeve',$jelige)->first()->id;
            }
            catch(Exception $e)
            {
                $TaroltJelige = null;
            }
        }

        $jelentkezesIdeje = Carbon::now();

        $ff = FelhasznaloFeladat::where('felhasznalo_id',$UserId,)->where('esemeny_id',$esemeny_id)->first();

        if(isset($ff))
        {
            if($ff->priority == $priority)
            {
                return back()->withErrors('Ezen a jelentkezési helyen létezik már terület jelentkezés! Változtasd meg a priorotást vagy módosítsd a jelentkezést!','failed');
            }

            if($ff->other == 1 &&  $all == 0)
            {
                return back()->withErrors('Erre az eseményre már adtak le terület jelentkezést, ahol Joker jelentkezés volt beállítva. Állítsd be Joker jelentkezést itt is!','failed');
            }

            $jelentkezes = new FelhasznaloFeladat();
            $jelentkezes->felhasznalo_id = $felhasznalo_id;
            $jelentkezes->esemeny_id = $esemeny_id;
            $jelentkezes->terulet_id = $terulet_id;
            $jelentkezes->csoport_id = 0;
            $jelentkezes->feladat_id = 0;
            $jelentkezes->priority = $priority;
            $jelentkezes->other = $all;
            $jelentkezes->jelentkezesIdeje = $jelentkezesIdeje;
            $jelentkezes->jeligeID = $jeligeID;

            $jelentkezes->save();
           
            //DB::table('felhasznalo_feladat')->insert(['felhasznalo_id' => $UserId,'feladat_id' => 0, 'csoport_id' => '0','terulet_id' => $terulet_id,'esemeny_id' => $esemeny_id,'priority' => $priority,'other' => $all,'jelentkezesIdeje' => $jelentkezesIdeje,'jeligeID' => $jeligeID ]);
            return back()->withErrors('A jelentkezés sikerült!','success');

        }
        else
        {
            $jelentkezes = new FelhasznaloFeladat();
            $jelentkezes->felhasznalo_id = $felhasznalo_id;
            $jelentkezes->esemeny_id = $esemeny_id;
            $jelentkezes->terulet_id = $terulet_id;
            $jelentkezes->csoport_id = 0;
            $jelentkezes->feladat_id = 0;
            $jelentkezes->priority = $priority;
            $jelentkezes->other = $all;
            $jelentkezes->jelentkezesIdeje = $jelentkezesIdeje;
            $jelentkezes->jeligeID = $jeligeID;

            $jelentkezes->save();
           
            //DB::table('felhasznalo_feladat')->insert(['felhasznalo_id' => $UserId,'feladat_id' => 0, 'csoport_id' => '0','terulet_id' => $terulet_id,'esemeny_id' => $esemeny_id,'priority' => $priority,'other' => $all,'jelentkezesIdeje' => $jelentkezesIdeje,'jeligeID' => $jeligeID ]);
            return back()->withErrors('A jelentkezés sikerült!','success');
        } 

        
        try{
            $esemeny = Esemeny::find($esemeny_id);
           // OmrEmail::AlertSuccessProgramAppliedForUser($user->email,$esemeny);
        }
        catch(Exception $e)
        {
            return back()->withErrors('Az email küldés nem sikerült!', 'failed');
        }
        

         return back()->withErrors('A jelentkezés sikerült!','success');   
    }


    /**
     * A onkentesSzerkesztese-hoz tartozo feldolgozo form
     *
     */
    public function onkentesSzerkesztes_hozzaadas_feldolgozo(Request $request )
    {
        $id = $request->input('felhasznaloid');
        $currentData = DB::table('users')->where('id',$id)->first();


        $nev = $request->input('userfullname');
        $vezeteknev = $request->input('vezeteknev');
        $kozepsonev = $request->input('kozepsonev');
        $keresztnev = $request->input('keresztnev');
        $usernemeValue = $request->input('userneme');
        
        $telszam = null;
        try{
            $telszam = $request->input('telszam');
           
            for($i = 0; $i < strlen($telszam); $i++)
            {
                $character = $telszam[$i];
                if(is_int(intval($character)) == false)
                {
                    throw new Exception();
                }
            }
           
        }
        catch(Exception $e)
        {
            return back()->withErrors("A telefonszám kizárólag számokat tartalmazhat! Pl: 0036305556644","telszam")->withInput();
        }

        $szulido = $request->input('szuletesiIdoEv')."-".$request->input('szuletesiIdoHo')."-".$request->input('szuletesiIdoNap');
        /**
         * @var A szuletesi idot szamitja ki a PHP/Carbon segitsegevel
         */
        $years = Carbon::parse($szulido)->age;


        $isLakcim = $request->input('isTartLakcim');

        $al_lakcim_orszag = $request->input('al_lakcim_orszag');
        $al_lakcim_telepules = $request->input('al_lakcim_telepules');

        try
        {
            if(isset($al_lakcim_telepules))
            {
                 if(is_numeric($al_lakcim_telepules))
                {
                    throw new Exception();
                }
                
            }
            
        }
        catch(Exception $e)
        {
            return back()->withErrors("Kérjük érvényes település nevet adjon meg!","lakcim_telepules")->withInput();
        }

        $al_lakcim_irszam = $request->input('al_lakcim_irszam');
        $al_lakcim_utca = $request->input('al_lakcim_utca');
        $al_lakcim_megye = $request->input('al_lakcim_megye')??0;


        $tart_lakcim_orszag = null;
        $tart_lakcim_telepules = null;
        $tart_lakcim_irszam = null;
        $tart_lakcim_utca = null;
        $tart_lakcim_megye = null;

    if($isLakcim == "TartAzonos")
    {
        $tart_lakcim_orszag = $request->input('al_lakcim_orszag');
        $tart_lakcim_telepules = $request->input('al_lakcim_telepules');
        $tart_lakcim_irszam = $request->input('al_lakcim_irszam');
        $tart_lakcim_utca = $request->input('al_lakcim_utca');
        $tart_lakcim_megye = $request->input('al_lakcim_megye')??0;

    }
    else if(!isset($isLakcim))
    {
        $tart_lakcim_orszag = $request->input('tart_lakcim_orszag');
        $tart_lakcim_telepules = $request->input('tart_lakcim_telepules');
        $tart_lakcim_irszam = $request->input('tart_lakcim_irszam');
        $tart_lakcim_utca = $request->input('tart_lakcim_utca');
        $tart_lakcim_megye = $request->input('tart_lakcim_megye')??0;
    }
    else
    {
        //error
    }

    $szulhely = ucfirst(mb_convert_case($request->input('szulhely'), MB_CASE_TITLE, "UTF-8"));

    $tevekenyseg = $request->input('tevekenyseg');
    if(isset($tevekenyseg))
    {
        switch($tevekenyseg)
        {
            case 1:
                $szakneve = $request->input('szakneve');
                $foiskneve = $request->input('foisk');
                $foiskEvfolyam =  $request->input('evfolyam');

                    if(isset($szakneve ) && isset($foiskneve) && isset($foiskEvfolyam))
                    {
                        DB_OMR_Operations::InsertTevekenysegEgyetemFosuli($id,$foiskneve,$szakneve,$foiskEvfolyam);
                    }
            break;

            case 2:
                $kozepsuliNeve =  ucfirst(strtolower(mb_convert_case($request->input('kozepisk'), MB_CASE_TITLE, "UTF-8")));

                $kozepsuliOsztaly =  $request->input('kozepiskoszt');

                if(isset($kozepsuliNeve) && isset($kozepsuliOsztaly))
                {
                    DB_OMR_Operations::InsertTevekenysegIskola($id,$kozepsuliNeve,$kozepsuliOsztaly,2);
                }
            break;

            case 3:
                $altiskNeve =  $request->input('altisk');
                $altiskOsztaly =  $request->input('altiskoszt');

                if(isset($altiskNeve) && isset($altiskOsztaly))
                {
                    DB_OMR_Operations::InsertTevekenysegIskola($id,$altiskNeve,$altiskOsztaly,3);
                }
            break;

            case 4:
                $munkahelyNeve = '';//$request->input('munkahely'); keresre kiveve!
                $munkakor = $request->input('munkakor');

                if(isset($munkakor))
                {
                    DB_OMR_Operations::InsertTevekenysegMunkahely($id,$munkahelyNeve,$munkakor);

                }
            break;
        }
    }

        $fogyatekossag = $request->input('fogyatekossag');
        $userpolomeret = $request->input('userpolomeret');

        $masSzervezetTagja = $request->input('masSzervezetTagja');

        if($masSzervezetTagja == "1")
        {
            $szervezetNeve = ucfirst($request->input('egyebSzervezet'));
            DB::table('egyeb_szervezet')->updateOrInsert(['felhasznalo_id' => $id],['szervezet_neve' => $szervezetNeve]);

        }
        else if($masSzervezetTagja == "0")
        {
            
            DB::table('egyeb_szervezet')->updateOrInsert(['felhasznalo_id' => $id],['szervezet_neve' => "Nem"]);

        }
        else
        {
            DB::table('egyeb_szervezet')->where('felhasznalo_id',$id)->update(["szervezet_neve" => 'NULL']);
        }

        $masCivilSzervezetTagja = $request->input('masCivilSzervezetTagja');

        if($masCivilSzervezetTagja == '1')
        {
            $szervezetNeve = ucfirst($request->input('civilSzervezet'));
            DB::table('civil_szervezet')->updateOrInsert(['felhasznalo_id' => $id],['szervezet_neve' => $szervezetNeve]);

        }
        else if($masCivilSzervezetTagja == '0')
        {
           // $szervezetNeve = ucfirst($request->input('civilSzervezet'));
            DB::table('civil_szervezet')->updateOrInsert(['felhasznalo_id' => $id],['szervezet_neve' => "Nem"]);

        }
        else
        {
            DB::table('civil_szervezet')->where('felhasznalo_id',$id)->update(["szervezet_neve" => 'NULL']);
        }

        $fogyLeirasa = $request->input('fogyLeirasa');
        $sajatEmailCim = $request->input('sajatEmailCim');
        DB_OMR_Operations::UpdateAllandoLakcim($id,$al_lakcim_irszam,ucfirst($al_lakcim_telepules),$al_lakcim_orszag,ucfirst($al_lakcim_utca),$al_lakcim_megye);
       
        $felhasznalo = Felhasznalo::find( $id );
        $felhasznalo->vezeteknev = $vezeteknev;
        $felhasznalo->keresztnev = $keresztnev;
        $felhasznalo->kozepsonev = $kozepsonev;
        $felhasznalo->neme = $usernemeValue;
        $felhasznalo->email = $sajatEmailCim;
        $felhasznalo->szulIdo = $szulido;
        $felhasznalo->szulhely_ID = $szulhely;$felhasznalo->orszag_ID = null;
        $felhasznalo->lakcim = null;
        $felhasznalo->telefonszam = $telszam;
        $felhasznalo->kor = $years;
        $felhasznalo->save();

        DB_OMR_Operations::UpdateFelhasznaloInfok($id,$tevekenyseg,$userpolomeret,$fogyatekossag,$fogyLeirasa );
        DB_OMR_Operations::UpdateTartozkodasiLakcim($id,$tart_lakcim_irszam,ucfirst($tart_lakcim_telepules),$tart_lakcim_orszag,ucfirst($tart_lakcim_utca),$tart_lakcim_megye);


        $szakneve = $request->input('szakneve');
        $foiskneve = $request->input('foisk');
        $foiskEvfolyam =  $request->input('evfolyam');
        if(isset($szakneve ) && isset($foiskneve) && isset($foiskEvfolyam))
        {
            DB_OMR_Operations::InsertTevekenysegEgyetemFosuli($id,$foiskneve,$szakneve,$foiskEvfolyam);
        }


        $munkahelyNeve = $request->input('munkahely');
        $munkakor = $request->input('munkakor');

        if(isset($munkahelyNeve) && isset($munkakor))
        {
            DB_OMR_Operations::InsertTevekenysegMunkahely($id,$munkahelyNeve,$munkakor);
        }

        $kozepsuliNeve =  $request->input('kozepisk');
        $kozepsuliOsztaly =  $request->input('kozepiskoszt');

        if(isset($kozepsuliNeve) && isset($kozepsuliOsztaly))
        {
            DB_OMR_Operations::InsertTevekenysegIskola($id,$kozepsuliNeve,$kozepsuliOsztaly,2);
        }

        $altiskNeve =  $request->input('altisk');
        $altiskOsztaly =  $request->input('altiskoszt');

        if(isset($altiskNeve) && isset($altiskOsztaly))
        {
            DB_OMR_Operations::InsertTevekenysegIskola($id,$altiskNeve,$altiskOsztaly,3);
        }

        $felekezet = $request->input('Felekezetek');
       
        $egyhazmegye = null; $egyebInput = null;
        switch((string)$felekezet)
        {


            case "Római katolikus":
                    $egyhazmegye = $request->input('egyhazmegyek');//dd($egyhazmegye);
                    $EgyhazmegyeID = Egyhazmegyek::where('nev',$egyhazmegye)->first()->id;
                    $useregyhazmegye = UserEgyhazmegye::updateOrCreate(
                        ['felhasznalo_id' => $id],
                        ['egyhazmegye_id' => $EgyhazmegyeID, 'modosito' => $id]
                    );
                    /*
                    $useregyhazmegye->felhasznalo_id = $user['id'];
                    $useregyhazmegye->egyhazmegye_id = $EgyhazmegyeID;
                    $useregyhazmegye->modosito = $user['id'];
                    $useregyhazmegye->egyebInputValue = null;
                    $useregyhazmegye->nemTag = null;
                    $useregyhazmegye->save();*/
            break;
            case "Görög katolikus":
                $egyhazmegye = $request->input('egyhazmegyek');//dd($egyhazmegye);
                $EgyhazmegyeID = Egyhazmegyek::where('nev',$egyhazmegye)->first()->id;
                $useregyhazmegye = UserEgyhazmegye::updateOrCreate(
                    ['felhasznalo_id' => $id],
                    ['egyhazmegye_id' => $EgyhazmegyeID, 'modosito' => $id]
                );
        break;
            case 'Egyéb':
                $egyebInput = $request->input('egyhazinput');
               /* $EgyhazmegyeID = Egyhazmegyek::where('nev',$egyebInput)->first()->id;
                UserEgyhazmegye::updateOrCreate(
                    ['felhasznalo_id' => $id],
                    ['egyhazmegye_id' => $EgyhazmegyeID, 'modosito' => $id,'egyebInputValue' => $egyebInput ]
                );*/
            break;
            case  'egyéb':
                $egyebInput = $request->input('egyhazinput');
                $EgyhazmegyeID = Egyhazmegyek::where('nev','Egyéb')->first()->id;
                
                    try{
                        if(!isset($egyebInput ))
                        {
                            throw new Exception();
                        }
                    }
                    catch(Exception $e)
                    {
                        return back()->withErrors("Kérjük írja be, melyik 'egyéb' egyházmegyéhez, felekezethez tartozik! A mező nem lehet üres!","egyebures")->withInput();
                    }
                
                UserEgyhazmegye::updateOrCreate(
                    ['felhasznalo_id' => $id],
                    ['egyhazmegye_id' => $EgyhazmegyeID, 'modosito' => $id,'egyebInputValue' => $egyebInput ]
                );
            break;
            default:
            //$EgyhazmegyeID = Egyhazmegyek::where('nev',$egyebInput)->first()->id;
            UserEgyhazmegye::updateOrCreate(
                ['felhasznalo_id' => $id],
                ['egyhazmegye_id' => 10, 'modosito' => $id,'nemTag' => 1 ]
            );
           /* $useregyhazmegye->felhasznalo_id = $user['id'];
            $useregyhazmegye->egyhazmegye_id = 10;
            $useregyhazmegye->modosito = $user['id'];
            $useregyhazmegye->egyebInputValue = null;
            $useregyhazmegye->nemTag = 1;
            $useregyhazmegye->save();*/
        break;

        }
        unset($egyhazmegye);


       


        $masSzervezetTagja = $request->input('masSzervezetTagja');
        //dd($masSzervezetTagja);
        if($masSzervezetTagja == "1")
        {
            $szervezetNeve = $request->input('egyebSzervezet');
            //dd($szervezetNeve);
            DB_OMR_Operations::UpdateOnkentesMashol($id,$szervezetNeve);
        }


        $fogyLeirasa = $request->input('fogyLeirasa');


        //DB_OMR_Operations::UpdateAllandoLakcim($id,$al_lakcim_irszam,$al_lakcim_telepules,$al_lakcim_orszag,$al_lakcim_utca,$al_lakcim_megye);
        //DB_OMR_Operations::UpdateFelhasznalok($id,$vezeteknev,$keresztnev,$kozepsonev,$usernemeValue,'null',$szulido,$szulhely,1,'null',$telszam, $years);
        Felhasznalo::where('id',$id)->update([
                "vezeteknev" => $vezeteknev,
                "keresztnev" => $keresztnev,
                "kozepsonev" => $kozepsonev,
                "neme" =>$usernemeValue,
                "szulIdo" => $szulido,
                "szulhely" => $szulhely,
                "telefonszam" => $telszam,
                "kor" => $years
             ]);

        DB_OMR_Operations::UpdateFelhasznaloInfok($id,$tevekenyseg,$userpolomeret,$fogyatekossag,$fogyLeirasa );



        DB_OMR_Operations::UpdateTartozkodasiLakcim($id,$tart_lakcim_irszam,$tart_lakcim_telepules,$tart_lakcim_orszag,$tart_lakcim_utca,$tart_lakcim_megye);

        $szemigszam = $request->input('szemigszam');
        $anyjaneve = $request->input('mothername');
        $allampolgarsag = $request->input('nationality');
        DB::table('szemelyesadatok')->updateOrInsert(["felhasznalo_id" => $id],["szemigszam" =>  strtoupper($szemigszam),
            "email" => "",
            "anyjaneve" => $anyjaneve ,
            "allampolgarsag" => ucfirst(strtolower($allampolgarsag))
             ]);



        $polotipusa = $request->userpolotipusa;

        DB::table('ruhaatado_atvetel')->updateOrInsert(['felhasznalo_id' => $id],['polotipus' => $polotipusa]);
        
        $felhasznaloinfoModel = FelhasznaloInfo::where('felhasznalo_id',$id)->first();
        $felhasznaloinfoModel->polotipus = $polotipusa;
        $EtkezesiIgenyLanc = '';


        $normalEtrend = $request->input('normal');
        if(isset($normalEtrend))
        {
            $EtkezesiIgenyLanc = $normalEtrend; unset($normalEtrend);
        }

        $laktozz = $request->input('laktozz');
        if(isset($laktozz))
        {

            if(isset($EtkezesiIgenyLanc))
            {
                $EtkezesiIgenyLanc = $EtkezesiIgenyLanc.",".$laktozz;
            }
            else $EtkezesiIgenyLanc = $EtkezesiIgenyLanc;
            unset($laktozz);
        }

        $gluten = $request->input('gluten');

        if(isset($gluten))
        {

            if(isset($EtkezesiIgenyLanc))
            {
                $EtkezesiIgenyLanc = $EtkezesiIgenyLanc.",".$gluten;
            }
            else $EtkezesiIgenyLanc = $EtkezesiIgenyLanc;

            unset($gluten);
        }

        $vega = $request->input('vega');
        if(isset($vega))
        {

            if(isset($EtkezesiIgenyLanc))
            {
                $EtkezesiIgenyLanc = $EtkezesiIgenyLanc.",".$vega;
            }
            else $EtkezesiIgenyLanc = $EtkezesiIgenyLanc;

            unset($vega);
        }

        $egyeb = $request->input('egyeb');

        if(isset($egyeb))
        {

            if(isset($EtkezesiIgenyLanc))
            {
                $EtkezesiIgenyLanc = $EtkezesiIgenyLanc.",".$egyeb;
            }
            else $EtkezesiIgenyLanc = $EtkezesiIgenyLanc;

            $felhasznaloinfoModel->etkezesIgenyEgyebLeiras = $request->input('egyebIgeny'); //felhasznaloinfo model
            unset($egyeb);
        }
        $felhasznaloinfoModel->etkezesIgenyID = $EtkezesiIgenyLanc;

        $felhasznaloinfoModel->igazolasIgenyID = $request->input('igazolas');

        if($felhasznaloinfoModel->igazolasIgenyID == 4) //egyeb
        {
            $felhasznaloinfoModel->igazolasEgyeb = $request->input('egyedIgIgeny');
        }

        $felhasznaloinfoModel->save();
        
        $authuser = auth()->user();

        $jogszint = $request->input('jogstatusz');
        $ElozoJogszint = Jogosultsag::where('felhasznalo_id',$id)->where('felhasznaloszint_id',4)->first();
           
        if(isset($ElozoJogszint))
        {
            if($ElozoJogszint->felhasznaloszint_id == 4 && $jogszint != 4)
            {
                Teruletvezetok::where('felhasznalo_id',$id)->delete();
            }
        }
        
        unset($ElozoJogszint);
        /**
         * @version 1.0.1
         */
        if($jogszint == 4)
        {
            $teruletjogszint = Teruletvezetok::firstOrNew(array('felhasznalo_id' => $id));
            $teruletjogszint->felhasznalo_id = $id;
            $teruletjogszint->letrehozo = $authuser['id'];
            $teruletjogszint->save();
            DB::table('jogosultsag')->where('felhasznalo_id','=',$id)->update(['felhasznaloszint_id' => $jogszint]);
        }
        else
        {
            DB::table('jogosultsag')->where('felhasznalo_id','=',$id)->update(['felhasznaloszint_id' => $jogszint]);

        }



        $accountstate = $request->input('accountstate');
       // dd($accountstate,$currentData->blocked);
        if(intval($accountstate) != $currentData->blocked)
        {
           // dd($accountstate,$currentData->blocked);
            DB::table('users')->where('id','=',$id)->update(['blocked' => intval($accountstate),'blocked_at' => Carbon::now()]);
        }



        DB::table('users')->where('id',$id)->update(['modifier' => $authuser['id'], 'updated_at' => Carbon::now()]);

        $nyelv1 = $request->input('nyelv1');
        $nyelv2 = $request->input('nyelv2');
        $nyelv3 = $request->input('nyelv3');
        $nyelv4 = $request->input('nyelv4');
        $nyelv5 = $request->input('nyelv5');

        try {

            if(isset($nyelv1))
            {
                $nyelvSzint1 = $request->input('nyelv1szint');
                if(!isset($nyelvSzint1))
                {
                    throw new Exception();
                }
                else
                {
                    $r =  DB::table('nyelvismeret')->updateOrInsert(['felhasznalo_id' => $id, 'sorrend' => 1],['nyelv' => $nyelv1, 'nyelvszint_id' =>  $nyelvSzint1,'sorrend' => 1 ]);
        
                }
            }

           
        }
        catch(Exception $e)
        {
            return back()->withErrors("Validálási hiba! A 'Nyelv 1' mezőnél nem adta meg a nyeltudás szintjét! ",'nyelv1');
        }

        try
        {
            if(isset($nyelv2))
            {
                $nyelvSzint2 = $request->input('nyelv2szint');
                if(!isset($nyelvSzint2))
                {
                    throw new Exception();
                }
                else
                {
                    $r =  DB::table('nyelvismeret')->updateOrInsert(['felhasznalo_id' => $id, 'sorrend' => 2],['nyelv' => $nyelv2, 'nyelvszint_id' =>  $nyelvSzint2,'sorrend' => 2 ]);
        
                }
            }
            
        }
        catch(Exception $e)
        {
            return back()->withErrors("Validálási hiba! A 'Nyelv 2' mezőnél nem adta meg a nyeltudás szintjét! ",'nyelv2');
        }

        try
        {
            if(isset($nyelv3))
            {
                $nyelvSzint3 = $request->input('nyelv3szint');
                if(!isset($nyelvSzint3))
                {
                    throw new Exception();
                }
                else
                {
                    $r =  DB::table('nyelvismeret')->updateOrInsert(['felhasznalo_id' => $id, 'sorrend' => 3],['nyelv' => $nyelv3, 'nyelvszint_id' =>  $nyelvSzint3,'sorrend' => 3 ]);
        
                }
            }
            
        }
        catch(Exception $e)
        {
            return back()->withErrors("Validálási hiba! A 'Nyelv 3' mezőnél nem adta meg a nyeltudás szintjét! ",'nyelv3');
      
        }

        try{
            if(isset($nyelv4))
            {
                $nyelvSzint4 = $request->input('nyelv4szint');
                if(!isset($nyelvSzint4))
                {
                    throw new Exception();
                }
                else
                {
                    $r =  DB::table('nyelvismeret')->updateOrInsert(['felhasznalo_id' => $id, 'sorrend' => 4],['nyelv' => $nyelv4, 'nyelvszint_id' =>  $nyelvSzint4,'sorrend' => 4 ]);
        
                }
            }
           
        }
        catch(Exception $e)
        {
            return back()->withErrors("Validálási hiba! A 'Nyelv 4' mezőnél nem adta meg a nyeltudás szintjét! ",'nyelv4');

        }
       
        try{
            if(isset($nyelv5))
            {
                $nyelvSzint5 = $request->input('nyelv5szint');
                if(!isset($nyelvSzint5))
                {
                    throw new Exception();
                }
                else
                {
                    $r =  DB::table('nyelvismeret')->updateOrInsert(['felhasznalo_id' => $id, 'sorrend' => 5],['nyelv' => $nyelv5, 'nyelvszint_id' =>  $nyelvSzint5,'sorrend' => 5 ]);
        
                }
            }
            
        }
        catch(Exception $e)
        {
            return back()->withErrors("Validálási hiba! A 'Nyelv 5' mezőnél nem adta meg a nyeltudás szintjét! ",'nyelv5');

        }

        

        try
        {
            /**
             * Itt akkor keletkezhet hiba, ha nem allitjuk be a levelezsest!
             */
            $Email = $request->input('sajatEmailCim');
            OmrEmail::AlertUserDataChangeForAdmin($Email);
            /**
             * @note 
             * 2021.02.05 Kivéve a levelezés, meg nincs beallitva
             *  */            
        }
        catch(Exception $e)
        {
            return back();
        }




        return back();


    }



    /**
 * **********************       **********************      **********************      **********************      **********************      **********************
 *
 *                                          ONKENTESEK ADMINISZTRACIOJA VEGE
 *
 * **********************       **********************      **********************      **********************      **********************      **********************
 */


    public function uj_helyszin_hozzaadas(Request $request )
    {
        //dd(FrontEndMaker::GetHelyszinek());
        $user = auth()->user();
        $model = new UjhelyszinViewModel($user['id']);

        $displayedItemForPage = 15;

        $model->profilpic = DB_OMR_Operations::GetProfilkep($user['id']);

        $helyszinek = \DB::table('helyszin')->orderBy('Neve')->paginate(10);

       // dd($model->helyszinek);
        return view('adminisztratorok/ujhelyszin_hozzaadas', compact('helyszinek', 'model'));
    }

    public function uj_helyszin_hozzaadas_feldolgozo(Request $request)
    {
        $helyszin = $request->input('helyszin_neve');
        $cim = $request->input('cim');
        DB_OMR_Operations::InsertHelyszin($helyszin, $cim);
        return redirect('/admin/ujhelyszin_hozzaadas'); //hook
    }

     public function helyszin_torles_feldolgozo($id){

        $kapcsolat = \DB::table('esemeny_telepules')->where('telepules_id', $id)->first();

        if($kapcsolat){
            return back();
        }

        \DB::table('helyszin')->where('id', $id)->delete();

        return back();

     }

     public function helyszin_modositas_feldolgozo(Request $request, $id){


        $helyszin = \DB::table('helyszin')->where('id', $id)
                            ->update([
                                'Neve' => $request->neve,
                                'Cim' => $request->cim
                            ]);;



        return back();

     }

    public function helyszin_torlese(Request $request,$id)
    {

    }

    public function ProfilSzerkesztes()
    {
        $user = auth()->user();
        $id = $user['id'];
        $model = new AdminProfilViewModel($id);
        $UserDatas = User::find($id);
        // dd($user['id']);
        $model->profilpic = DB_OMR_Operations::GetProfilkep($id);
        $Felhasznalo = DB_OMR_Operations::GetFelhasznalo($id);
         //$FelhasznaloInfo = DB_OMR_Operations::GetFelhasznaloinfo($id);
         $FelhasznaloInfo = FelhasznaloInfo::where('felhasznalo_id',$id)->first();
         $szallastIgenyel = $FelhasznaloInfo->szallastIgenyel;

        //dd( $FelhasznaloInfo );

        $model->Vezeteknev = $Felhasznalo['vezeteknev'];
        $model->Keresztnev = $Felhasznalo['keresztnev'];
        $model->Kozepsonev = $Felhasznalo['kozepsonev'];
        $model->Neme_id = $Felhasznalo['neme_id'];
        $model->Nem =  "";
        if($model->Neme_id == 0)
        {
            $model->Nem = "Férfi";
        }
        else
        {
            $model->Nem = "Nő";
        }

        $model->email =  $user['email'];

        if(isset($Felhasznalo['szulIdo']))
        {
               $model->szulido = $Felhasznalo['szulIdo'];
        }
       // dd($model->szulido);

        $model->EletKor = $Felhasznalo['kor'];

        $model->szulhely =  $Felhasznalo['szulhely'];

        $model->Telefonszam = $Felhasznalo['telefonszam'];

        $model->polomeret = self::getPolomeret($FelhasznaloInfo->polomeret);
        $model->fogyatekossag =  $FelhasznaloInfo->fogyatekossag;
        $model->FogyLeirasa = $FelhasznaloInfo->fogyLeirasa;
        $nyelvek = DB_OMR_Operations::GetNyelv1($id);

        $model->BeszelhetoNyelvek = BeszeltNyelvek::orderBy('nyelvNeve','asc')->get('nyelvNeve');

        $nyelv1 = DB::table('nyelvismeret')->where('felhasznalo_id',$id)->where('sorrend',1)->get()->first();
        $model->nyelv1 = $nyelv1->nyelv??' ';
        $model->nyelv1szint =   self::GetNyelvSzintHTML($nyelv1->nyelvszint_id??0);
        $nyelv2 =  DB::table('nyelvismeret')->where('felhasznalo_id',$id)->where('sorrend',2)->get()->first();
        $model->nyelv2 = $nyelv2->nyelv??' ';
        $model->nyelv2szint =   self::GetNyelvSzintHTML($nyelv2->nyelvszint_id??0);
        $nyelv3 = DB::table('nyelvismeret')->where('felhasznalo_id',$id)->where('sorrend',3)->get()->first();
        $model->nyelv3 = $nyelv3->nyelv??' ';
        $model->nyelv3szint =   self::GetNyelvSzintHTML($nyelv3->nyelvszint_id??0);
        $nyelv4 = DB::table('nyelvismeret')->where('felhasznalo_id',$id)->where('sorrend',4)->get()->first();
        $model->nyelv4 =  $nyelv4->nyelv??' ';
        $model->nyelv4szint =   self::GetNyelvSzintHTML( $nyelv4->nyelvszint_id??0);

        $nyelv5 = DB::table('nyelvismeret')->where('felhasznalo_id',$id)->where('sorrend',5)->get()->first();
        $model->nyelv5 = $nyelv5->nyelv??' ';
        $model->nyelv5szint =   self::GetNyelvSzintHTML($nyelv5->nyelvszint_id??0);


        $allando = DB_OMR_Operations::GetAllandoLakcim($id);

        if(isset($allando->Orszag))
        {
            $model->all_lakcim_orszag =  DB_OMR_Operations::GetOrszagOptionsId_HTML($allando->Orszag);
        }
        else
        {
            $model->all_lakcim_orszag = DB_OMR_Operations::GetOrszagOptions_HTML();

        }

  
        
            $model->all_lakcim_telepules = $allando->Telepules??'';
                
            
            $model->all_lakcim_irszam = $allando->IranyitoSzam??'';
            $model->all_lakcim_utca = $allando->Cim??'';
            $All_megyeID = DB_OMR_Operations::GetAllLakcim_MegyeIDForUser($id);
            $model->Megye_AllLakcim = DB_OMR_Operations::GetMegyekOptionsId_HTML($All_megyeID);





        $tartozkodasi = DB_OMR_Operations::GetTartozkodasiLakcim($id);
        $model->tart_lakcim_orszag = $tartozkodasi->OrszagID??0;
        $model->tart_lakcim_telepules = $tartozkodasi->TelepulesID??0;
        $model->tart_lakcim_utca = $tartozkodasi->Cim??'';
        $model->tart_lakcim_irszam = $tartozkodasi->IranyitoSzam??'';
        $Tart_megyeID = DB_OMR_Operations::GetTartLakcim_MegyeIDForUser($id);

        $model->Megye_TartLakcim = DB_OMR_Operations::GetMegyekOptionsId_HTML($tartozkodasi->megyeID??0);

        $model->tart_lakcim_orszag = DB_OMR_Operations::GetOrszagOptionsId_HTML($tartozkodasi->OrszagID??0);


        $model->foteveknyseg_id = $FelhasznaloInfo->tevekenyseg_id;
        $model->foteveknyseg = self::GetHTMLTevekenysegMaker($model->foteveknyseg_id);

        //dd($id,$model->foteveknyseg_id,$model->foteveknyseg);
        $tev = DB_OMR_Operations::GetFoTevekenyseg_With_HTML_Output($id);
        $model->fotevekenysegHTML = $tev;
        unset($allando);


        //dd($model);
        $model->masSzervezetTagja = DB_OMR_Operations::IsMasSzervezetTagja($id);

        $model->MasSzervezetNeve = "";

        if($model->masSzervezetTagja)
        {
            $model->MasSzervezetNeve = DB_OMR_Operations::GetEgyebSzervezet($id)->szervezet_neve;
        }

        $model->CivilSzervezetTagja = DB_OMR_Operations::IsCivilSzervezetTagja($id);

        $model->CivilSzervezetNeve = "";

        if($model->CivilSzervezetTagja)
        {
            $model->CivilSzervezetNeve = DB_OMR_Operations::GetCivilSzervezet($id)->szervezet_neve;
        }


        $szemelyesadatok = DB::table('szemelyesadatok')->where('felhasznalo_id','=',$id)->whereNotNull('felhasznalo_id')->get()->first();
        if(isset($szemelyesadatok))
        {
            $model->szemigszam =  $szemelyesadatok->szemigszam;
            $model->anyjaneve =  $szemelyesadatok->anyjaneve;

            try
            {
                $model->allampolgarsag = Allampolgarsag::find( $szemelyesadatok->allampolgarsag)->id;
            }
            catch(Exception $e)
            {
                $model->allampolgarsag = 'Nincs kitöltve';
            }
        }
        else{
            $model->szemigszam =  "";
            $model->anyjaneve =  "";
            $model->allampolgarsag = "";
        }

        try
        {
            $model->polotipusa = DB::table('ruhaatado_atvetel')->where('felhasznalo_id','=',$id)->select('polotipus')->get()->first()->polotipus;
        }
        catch(Exception $exception)
        {
            $model->polotipusa = -1;
        }

         /**
         * Eloallitja a kimeneti html tartalmat.
         */
        $model->setEtkezesiIgenyekHTML(false);

        $model->igazolasIgenyID = $FelhasznaloInfo->igazolasIgenyID;
        if($model->igazolasIgenyID == 4)
        {
            $model->igazolasIgenyLeiras = $FelhasznaloInfo->igazolasEgyeb;
        }

        $egyhazmegyek = Egyhazmegyek::all();

        $egyhazmegyek_groups = $egyhazmegyek->groupBy(function($item){
            return $item->felekezet;
        });
        $felekezetek = $egyhazmegyek_groups->keys()->all();

        $egyhazmegyek = $egyhazmegyek->ToJson();

        $valasztottEgyhaz = null;

        try{
                $valasztottEgyhaz = UserEgyhazmegye::where('felhasznalo_id',$id)->select(
                "egyhazmegye_id",
                "egyebInputValue",
                "nemTag"
            )->first();
            $valasztottEgyhaz = json_encode($valasztottEgyhaz);
        }
        catch(Throwable $t)
        {
            $valasztottEgyhaz = null;
        }


        $nevelotag = $UserDatas->elotag??'none';
        $allampolgarsagLista = \App\Allampolgarsag::orderBy('allampolgarsag', 'ASC')->get();
        $allampolgarsagLista = $this->getManupulateListOrder($allampolgarsagLista);

       // GetFelhasznaloinfo($id)
      // dd($valasztottEgyhaz);
      if(isset($cpv))
      {
          
          return view('adminisztratorok.profilSzerkesztes',['egyhazmegyek' => $egyhazmegyek,
          'felekezetek' => $felekezetek,
           'valasztottEgyhazMegye' =>  $valasztottEgyhaz,
           'nevelotag' => $nevelotag,
           'szallastIgenyel' => $szallastIgenyel
          ])->with('model',$model)->with('allampolgarsagLista' ,$allampolgarsagLista)->with('cpv',$cpv);
      }
      else
      {
          return view('adminisztratorok.profilSzerkesztes',['egyhazmegyek' => $egyhazmegyek,
          'felekezetek' => $felekezetek,
           'valasztottEgyhazMegye' =>  $valasztottEgyhaz,
           'nevelotag' => $nevelotag,
           'szallastIgenyel' => $szallastIgenyel
          ])->with('model',$model)->with('allampolgarsagLista' ,$allampolgarsagLista);
      }
    }


    /*************************   EXPORT, RIPORT ************************************************************************************* */
    //HIBAS AZ ADATBAZIS KULCS KESZLET!!!! A LEKERDEZESEKET NEM LESZNEK JOK MERT EZ A REDNSZEREZES MIATT VAAAAN
    public function GetFullRiport()
    {

        $felhasznalok = array();
        $users = Riport::GetUser();

        foreach($users as $user)
        {
            $felhasznalo = new ProfilSelector();
            $felhasznalo->email = $user->email;
            $felhasznalo->password = $user->password;
            $felhasznalo->created_at = $user->created_at;
            $felhasznalo->updated_at = $user->updated_at;

            /** felhasznalok tabla */
            $FelhasznaloAdatok = Riport::GetFelhasznalo($user->email);
            //dd($FelhasznaloAdatok);

            if(isset($FelhasznaloAdatok->id))
            {
                $felhasznalo->felhasznalo_id =  $FelhasznaloAdatok->id;
            }


            if(isset($FelhasznaloAdatok->vezeteknev))
            {
                $felhasznalo->Vezeteknev = $FelhasznaloAdatok->vezeteknev;
            }



            if(isset($FelhasznaloAdatok->kozepsonev))
            {
                $felhasznalo->Kozepsonev = $FelhasznaloAdatok->kozepsonev;
            }

            if(isset($FelhasznaloAdatok->keresztnev))
            {
                $felhasznalo->Keresztnev = $FelhasznaloAdatok->keresztnev;
            }

           if(isset($FelhasznaloAdatok->szulIdo))
           {
                $felhasznalo->szulido = $FelhasznaloAdatok->szulIdo;
           }

           if(isset($FelhasznaloAdatok->orszag_id))
           {
                $felhasznalo->orszag_id = $FelhasznaloAdatok->orszag_id;
           }

           if(isset($FelhasznaloAdatok->szulhely))
           {
                $felhasznalo->szulhely = $FelhasznaloAdatok->szulhely;
           }

           if(isset($FelhasznaloAdatok->lakcim))
           {
                $felhasznalo->lakcim = $FelhasznaloAdatok->lakcim;
           }
           if(isset($FelhasznaloAdatok->Telefonszam))
           {
                $felhasznalo->Telefonszam = $FelhasznaloAdatok->telefonszam;
           }

           if(isset($FelhasznaloAdatok->kor))
           {
                $felhasznalo->EletKor = $FelhasznaloAdatok->kor;
           }



            /**  */


            array_push($felhasznalok,$felhasznalo);
        }

        foreach($users as $user)
        {
            $FelhasznaloAdatok = Riport::GetFelhasznalo($user->email);
            //dd($FelhasznaloAdatok);

            if(isset($FelhasznaloAdatok->vezeteknev))
            {
                $user->Vezeteknev = $FelhasznaloAdatok->vezeteknev;
            }



            if(isset($FelhasznaloAdatok->kozepsonev))
            {
                $user->Kozepsonev = $FelhasznaloAdatok->kozepsonev;
            }

            if(isset($FelhasznaloAdatok->keresztnev))
            {
                $user->Keresztnev = $FelhasznaloAdatok->keresztnev;
            }



        }



        dd($felhasznalok);
    }



    public function profilszerk(Request $request)
    {
        $user = auth()->user();
        $id = $user['id'];

 /**validacio sajat.. */
 $cpv = new CustomProfileValidator();
 $cpv->setGenerals($request->input('vezeteknev'),$request->input('kozepsonev'),$request->input('telszam'),
  $request->input('szuletesiIdoEv')
,$request->input('szuletesiIdoHo'),$request->input('szuletesiIdoNap'),$request->input('szulhely'),
$request->input('userneme'),$request->input('mothername'),$request->input('nationality'),$request->input('szemigszam'));

 $cpv->setAllando($request->input('al_lakcim_orszag'), $request->input('al_lakcim_megye'),
 $request->input('al_lakcim_telepules'),$request->input('al_lakcim_irszam'),$request->input('al_lakcim_utca')
 );
// dd($request->input('al_lakcim_irszam'));
     if($request->input('isTartLakcim') != 'TartAzonos')
     {
         $cpv->setTartozkodasi($request->input('tart_lakcim_orszag'),
         $request->input('tart_lakcim_telepules'),$request->input('tart_lakcim_irszam'),$request->input('tart_lakcim_utca'),
         $request->input('tart_lakcim_megye')
         );

     }
     if($request->input('masSzervezetTagja') == 1)
     {
        
         $cpv->setQuestions1($request->input("egyebSzervezet"));
     }
     
     if($request->input('masCivilSzervezetTagja')  == "1")
     {
         $cpv->setQuestions2($request->input("civilSzervezet"));
     }

     if($request->input('fogyatekossag')  == "1" || $request->input('fogyatekossag')  == "0")
     {
         $cpv->setFogy(true);
     } else {$cpv->setFogy(false);}

     $cpv->setRuha($request->input("userpolomeret"));
     
     $ruhatipusa = $request->input('userpolotipusa');
     if($ruhatipusa == "0" || $ruhatipusa == "1")
     {
         $cpv->setRuhaTipusa(true);
     } else  $cpv->setRuhaTipusa(false);

     $felekezet = $request->input('Felekezetek');
     $egyhazmegye = $request->input('egyhazmegyek');
          // dd($fel );
     if(isset($felekezet)){
         //dd($felekezet);
           $cpv->setFelekezet(true); 

           if($egyhazmegye == "none")
           {
             $cpv->setEgyhaz(false); 
           }

           if($felekezet == "Nem tartozom felekezethez")
           {
             $cpv->setFelekezet(true); 
           }
           if($felekezet == "Római Katolikus Egyházmegye")
           {
             $cpv->setFelekezet(true); 
             $cpv->setEgyhaz(true);
           }
           if($felekezet == "Görög Katolikus Egyházmegye")
           {
             $cpv->setFelekezet(true); 
             $cpv->setEgyhaz(true);
           }
           if($felekezet == "Egyéb")
           {
               $egyebinput = $request->input('egyhazinput');
               if(isset($egyebinput))
               {
                 $cpv->EgyhazEgyebInput(true);
               }
               else 
               $cpv->EgyhazEgyebInput(false);
             
           }
          
     }
     else{
         //dd($felekezet);
         $cpv->setFelekezet(false); 
     }
     //else $cpv->setEgyhazKozosseg(false);
     
    
     $ft = $request->input('tevekenyseg');
     if($ft === NULL)
     {
         
         $cpv->setFoteveknyseg(false);
     }
     else 
     {
         if(isset($ft))
         {
             if($request->input("tevekenyseg") == 1)
             {
                 $cpv->setFotevFelsoIskola($request->input('foisk')??'',$request->input('szakneve')??'',intval($request->input('evfolyam')));
             }
             if($request->input("tevekenyseg") == 2)
             {
                 $cpv->setFotevKozepIskola($request->input('kozepisk')??'',intval($request->input('kozepiskoszt')));
             }
             if($request->input("tevekenyseg") == 3)
             {
                 $cpv->setFotevAltIskola($request->input('altisk')??'',intval($request->input('altiskoszt')));
             }
             if($request->input("tevekenyseg") == 4)
             {
                 $cpv->setFotevMunka($request->input('munkakor')??'');
             }
         }
     }
     
     

         $egyebSzerv = $request->input("masSzervezetTagja");
     if(isset($egyebSzerv))
     {
         $cpv->setEgyebszervezet(true);
     }
     else{
         $cpv->setEgyebszervezet(false);
     }
     $civilSzerv = $request->input("masCivilSzervezetTagja");
     if(isset($civilSzerv))
     {
         $cpv->setCivilszervezet(true);
     }
     else
     {
         $cpv->setCivilszervezet(false);
     }

     $isgdpr = $request->input('isgdpr');
     if($isgdpr != 'on')
     {
         $cpv->setAdatkezelesi(false);
     }
     $cpv->setISFormValid();

 //dd($cpv);
 $cpv->ProfilPic($id);

 if(!$cpv->is_FormValid())
 {
     //dd($cpv->getMessage());
     $valid = true;
     $FelhasznaloTable = Felhasznalo::find($id);
     //dd( $UserTable);
     if(!isset($FelhasznaloTable->vezeteknev)) $valid = false;
     if(!isset($FelhasznaloTable->neme)) $valid = false;
     if(!isset($FelhasznaloTable->szulIdo)) $valid = false;
     if(!isset($FelhasznaloTable->szulhely_ID)) $valid = false;
     if(!isset($FelhasznaloTable->telefonszam)) $valid = false;
     
     if($FelhasznaloTable->profilkep != "blank-profile-pic-omr.png")
     {
         $profilkepValid = true;
     }

     if($valid)
     {
         $json = json_encode($cpv);
     
         return back()->withErrors($json, "cpv");
     }
     else
     {
        $inputs = array();
       
         foreach($request->request as $key => $value)
         {
            // $inp[$key] = $value;
            if($key == "nevelotag")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }

             if($key == "telszam")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key == "vezeteknev")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key == "kozepsonev")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key == "keresztnev")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key == "sajatEmailCim")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key == "szuletesiIdoEv")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key == "szuletesiIdoHo")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key == "szuletesiIdoNap")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key == "szulhely")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key == "userneme")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key == "mothername")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }

             if($key == "nationality")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }

             if($key == "szemigszam")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }

             if($key == "al_lakcim_orszag")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key == "al_lakcim_megye")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key == "al_lakcim_telepules")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key == "al_lakcim_irszam")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key == "al_lakcim_utca")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key == "tart_lakcim_orszag")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key == "tart_lakcim_megye")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key == "tart_lakcim_telepules")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key == "tart_lakcim_irszam")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key == "tart_lakcim_utca")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key == "isTartLakcim")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key == "masSzervezetTagja")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key == "egyebSzervezet")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key == "masCivilSzervezetTagja")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key == "civilSzervezet")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key == "Felekezetek")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key == "egyhazmegyek")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key == "tevekenyseg")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key == "egyhazinput")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key == "fogyatekossag")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key == "fogyLeirasa")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key == "userpolomeret")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key == "userpolotipusa")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key == "foisk")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key == "szakneve")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key == "evfolyam")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key == "kozepiskoszt")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key == "kozepisk")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key == "altisk")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key == "altiskoszt")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key == "munkahely")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key == "munkakor")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key=="nyelv1")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key=="nyelv2")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key=="nyelv3")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key=="nyelv4")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key=="nyelv5")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key=="nyelv1szint")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key=="nyelv2szint")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key=="nyelv3szint")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key=="nyelv4szint")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key=="nyelv5szint")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key=="igazolas")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }
             if($key=="etkezes")
             {
                 $inp[$key] = $value;
                 array_push($inputs,$inp);
             }




             
         } //foreach vege
         //dd(json_encode($inputs));
         $json = json_encode($cpv);
         $inputJson = json_encode(end($inputs));
        // $inputJson =  array_merge(json_decode($inputJson, true), json_decode($json, true));
         return back()->withErrors($json, "cpv")->withErrors($inputJson,"oldInputs");
         

     }

     
    
 }

 //validacio vege

 //validacio vege

        $nev = $request->input('userfullname');
        $vezeteknev = ucfirst(mb_convert_case($request->input('vezeteknev'), MB_CASE_TITLE, "UTF-8"));

        $kozepsonev = ucfirst( mb_convert_case($request->input('kozepsonev'), MB_CASE_TITLE, "UTF-8"));
        $keresztnev = ucfirst(mb_convert_case($request->input('keresztnev'), MB_CASE_TITLE, "UTF-8"));

        $usernemeValue = $request->input('userneme');
        $mail = $request->input('sajatEmailCim');
        
        $telszam = null;
        try{
            $telszam = $request->input('telszam');
           
            for($i = 0; $i < strlen($telszam); $i++)
            {
                $character = $telszam[$i];
                if(is_int(intval($character)) == false)
                {
                    throw new Exception();
                }
            }
           
        }
        catch(Exception $e)
        {
            return back()->withErrors("A telefonszám kizárólag számokat tartalmazhat! Pl: 0036305556644","telszam")->withInput();
        }
        

        $szulido = $request->input('szuletesiIdoEv')."-".$request->input('szuletesiIdoHo')."-".$request->input('szuletesiIdoNap');
        /**
         * @var A szuletesi idot szamitja ki a PHP/Carbon segitsegevel
         */
        $years = Carbon::parse($szulido)->age;

        $isLakcim = $request->input('isTartLakcim');

            $al_lakcim_orszag = $request->input('al_lakcim_orszag');
            $al_lakcim_telepules = $request->input('al_lakcim_telepules');

            try
            {
                if(isset($al_lakcim_telepules))
                {
                     if(is_numeric($al_lakcim_telepules))
                    {
                        throw new Exception();
                    }
                    
                }
                
            }
            catch(Exception $e)
            {
                return back()->withErrors("Kérjük érvényes település nevet adjon meg!","lakcim_telepules")->withInput();
            }

            $al_lakcim_irszam = $request->input('al_lakcim_irszam');
            $al_lakcim_utca = $request->input('al_lakcim_utca');
            $al_lakcim_megye = $request->input('al_lakcim_megye')??0;


            $tart_lakcim_orszag = null;
            $tart_lakcim_telepules = null;
            $tart_lakcim_irszam = null;
            $tart_lakcim_utca = null;
            $tart_lakcim_megye = null;

        if($isLakcim == "TartAzonos")
        {
            $tart_lakcim_orszag = $request->input('al_lakcim_orszag');
            $tart_lakcim_telepules = $request->input('al_lakcim_telepules');
            $tart_lakcim_irszam = $request->input('al_lakcim_irszam');
            $tart_lakcim_utca = $request->input('al_lakcim_utca');
            $tart_lakcim_megye = $request->input('al_lakcim_megye')??0;

        }
        else if(!isset($isLakcim))
        {
            $tart_lakcim_orszag = $request->input('tart_lakcim_orszag');
            $tart_lakcim_telepules = $request->input('tart_lakcim_telepules');
            $tart_lakcim_irszam = $request->input('tart_lakcim_irszam');
            $tart_lakcim_utca = $request->input('tart_lakcim_utca');
            $tart_lakcim_megye = $request->input('tart_lakcim_megye')??0;
        }
        else
        {
            //error
        }

        $szulhely = ucfirst(mb_convert_case($request->input('szulhely'), MB_CASE_TITLE, "UTF-8"));


        $tevekenyseg = $request->input('tevekenyseg');
        if(isset($tevekenyseg))
        {
            switch($tevekenyseg)
            {
                case 1:
                    $szakneve = $request->input('szakneve');
                    $foiskneve = $request->input('foisk');
                    $foiskEvfolyam =  $request->input('evfolyam');

                        if(isset($szakneve ) && isset($foiskneve) && isset($foiskEvfolyam))
                        {
                            DB_OMR_Operations::InsertTevekenysegEgyetemFosuli($id,$foiskneve,$szakneve,$foiskEvfolyam);
                        }
                break;

                case 2:
                    $kozepsuliNeve =  ucfirst(strtolower(mb_convert_case($request->input('kozepisk'), MB_CASE_TITLE, "UTF-8")));

                    $kozepsuliOsztaly =  $request->input('kozepiskoszt');

                    if(isset($kozepsuliNeve) && isset($kozepsuliOsztaly))
                    {
                        DB_OMR_Operations::InsertTevekenysegIskola($id,$kozepsuliNeve,$kozepsuliOsztaly,2);
                    }
                break;

                case 3:
                    $altiskNeve =  $request->input('altisk');
                    $altiskOsztaly =  $request->input('altiskoszt');

                    if(isset($altiskNeve) && isset($altiskOsztaly))
                    {
                        DB_OMR_Operations::InsertTevekenysegIskola($id,$altiskNeve,$altiskOsztaly,3);
                    }
                break;

                case 4:
                    $munkahelyNeve = '';//$request->input('munkahely'); keresre kiveve!
                    $munkakor = $request->input('munkakor');

                    if(isset($munkakor))
                    {
                        DB_OMR_Operations::InsertTevekenysegMunkahely($id,$munkahelyNeve,$munkakor);

                    }
                break;
            }
        }



        $fogyatekossag = $request->input('fogyatekossag');
        $userpolomeret = $request->input('userpolomeret');

       

        $masSzervezetTagja = $request->input('masSzervezetTagja');

        if($masSzervezetTagja == "1")
        {
            $szervezetNeve = ucfirst($request->input('egyebSzervezet'));
            DB::table('egyeb_szervezet')->updateOrInsert(['felhasznalo_id' => $id],['szervezet_neve' => $szervezetNeve]);

        }
        else if($masSzervezetTagja == "0")
        {
            
            DB::table('egyeb_szervezet')->updateOrInsert(['felhasznalo_id' => $id],['szervezet_neve' => "Nem"]);

        }
        else
        {
            DB::table('egyeb_szervezet')->where('felhasznalo_id',$id)->update(["szervezet_neve" => 'NULL']);
        }

        $masCivilSzervezetTagja = $request->input('masCivilSzervezetTagja');

        if($masCivilSzervezetTagja == '1')
        {
            $szervezetNeve = ucfirst($request->input('civilSzervezet'));
            DB::table('civil_szervezet')->updateOrInsert(['felhasznalo_id' => $id],['szervezet_neve' => $szervezetNeve]);

        }
        else if($masCivilSzervezetTagja == '0')
        {
           // $szervezetNeve = ucfirst($request->input('civilSzervezet'));
            DB::table('civil_szervezet')->updateOrInsert(['felhasznalo_id' => $id],['szervezet_neve' => "Nem"]);

        }
        else
        {
            DB::table('civil_szervezet')->where('felhasznalo_id',$id)->update(["szervezet_neve" => 'NULL']);
        }

        $fogyLeirasa = $request->input('fogyLeirasa');

        
        DB_OMR_Operations::UpdateAllandoLakcim($id,$al_lakcim_irszam,ucfirst($al_lakcim_telepules),$al_lakcim_orszag,ucfirst($al_lakcim_utca),$al_lakcim_megye);
        //DB_OMR_Operations::UpdateFelhasznalok($id,$vezeteknev,$keresztnev,$kozepsonev,$usernemeValue,'null',$szulido,$szulhely,1,'null',$telszam, $years);
        //uj kodresz = refaktor
        $felhasznalo = Felhasznalo::find( $id );
        $felhasznalo->vezeteknev = $vezeteknev;
        $felhasznalo->keresztnev = $keresztnev;
        $felhasznalo->kozepsonev = $kozepsonev;
        $felhasznalo->neme = $usernemeValue;
        $felhasznalo->email = $mail;
        $felhasznalo->szulIdo = $szulido;
        $felhasznalo->szulhely_ID = $szulhely;$felhasznalo->orszag_ID = null;
        $felhasznalo->lakcim = null;
        $felhasznalo->telefonszam = $telszam;
        $felhasznalo->kor = $years;
        $felhasznalo->save();


        DB_OMR_Operations::UpdateFelhasznaloInfok($id,$tevekenyseg,$userpolomeret,$fogyatekossag,$fogyLeirasa );
        DB_OMR_Operations::UpdateTartozkodasiLakcim($id,$tart_lakcim_irszam,ucfirst($tart_lakcim_telepules),$tart_lakcim_orszag,ucfirst($tart_lakcim_utca),$tart_lakcim_megye);

        $szemigszam = $request->input('szemigszam');
        $anyjaneve = ucfirst(mb_convert_case($request->input('mothername'), MB_CASE_TITLE, "UTF-8"));

        $allampolgarsag = $request->input('nationality');
        DB::table('szemelyesadatok')->updateOrInsert(["felhasznalo_id" => $id],["szemigszam" =>  strtoupper($szemigszam),
            "email" => "",
            "anyjaneve" => $anyjaneve ,
            "allampolgarsag" => $allampolgarsag
             ]);


        $polotipusa = $request->userpolotipusa;

        $felhasznaloinfoModel = FelhasznaloInfo::where('felhasznalo_id',$id)->first();
        $felhasznaloinfoModel->polotipus = $polotipusa;

        $updatedUser = User::find($id);
        $updatedUser->elotag = $request->input('nevelotag');
        $updatedUser->name =  $updatedUser->elotag.' '.$vezeteknev.' '.$kozepsonev.' '.$keresztnev;
        $updatedUser->updated_at = Carbon::now();
        $updatedUser->modifier = $id;
        $updatedUser->save();


        $EtkezesiIgenyLanc = '';


        $normalEtrend = $request->input('normal');
        if(isset($normalEtrend))
        {
            $EtkezesiIgenyLanc = $normalEtrend; unset($normalEtrend);
        }

        $laktozz = $request->input('laktozz');
        if(isset($laktozz))
        {

            if(isset($EtkezesiIgenyLanc))
            {
                $EtkezesiIgenyLanc = $EtkezesiIgenyLanc.",".$laktozz;
            }
            else $EtkezesiIgenyLanc = $EtkezesiIgenyLanc;
            unset($laktozz);
        }

        $gluten = $request->input('gluten');

        if(isset($gluten))
        {

            if(isset($EtkezesiIgenyLanc))
            {
                $EtkezesiIgenyLanc = $EtkezesiIgenyLanc.",".$gluten;
            }
            else $EtkezesiIgenyLanc = $EtkezesiIgenyLanc;

            unset($gluten);
        }

        $vega = $request->input('vega');
        if(isset($vega))
        {

            if(isset($EtkezesiIgenyLanc))
            {
                $EtkezesiIgenyLanc = $EtkezesiIgenyLanc.",".$vega;
            }
            else $EtkezesiIgenyLanc = $EtkezesiIgenyLanc;

            unset($vega);
        }

        $egyeb = $request->input('egyeb');

        if(isset($egyeb))
        {

            if(isset($EtkezesiIgenyLanc))
            {
                $EtkezesiIgenyLanc = $EtkezesiIgenyLanc.",".$egyeb;
            }
            else $EtkezesiIgenyLanc = $EtkezesiIgenyLanc;

            $felhasznaloinfoModel->etkezesIgenyEgyebLeiras = $request->input('egyebIgeny'); //felhasznaloinfo model
            unset($egyeb);
        }
        $felhasznaloinfoModel->etkezesIgenyID = $EtkezesiIgenyLanc;

        $felhasznaloinfoModel->igazolasIgenyID = $request->input('igazolas');

        if($felhasznaloinfoModel->igazolasIgenyID == 4) //egyeb
        {
            $felhasznaloinfoModel->igazolasEgyeb = $request->input('egyedIgIgeny');
        }

        $szallas = $request->input('szallastIgenyel');
        if($szallas == "1")
        {
            $felhasznaloinfoModel->szallastIgenyel = 1;
        }
        if($szallas == "0")
        {
            $felhasznaloinfoModel->szallastIgenyel = 0;
        }
        

        $felhasznaloinfoModel->save();
        
       
        DB::table('ruhaatado_atvetel')->updateOrInsert(['felhasznalo_id' => $id],['polotipus' => $polotipusa]);
        
        $felhasznaloinfoModel = FelhasznaloInfo::where('felhasznalo_id',$id)->first();
        $felhasznaloinfoModel->polotipus = $polotipusa;




        $updatedUser = User::find($id);
        $updatedUser->name =  $vezeteknev.' '.$kozepsonev.' '.$keresztnev;
        $updatedUser->updated_at = Carbon::now();
        $updatedUser->modifier = $id;
        $updatedUser->save();
        DB::table('users')->where('id',$id)->update(['updated_at' => Carbon::now(),'modifier' => $id]);
/*
        if(\DB::table('jogosultsag')->where('felhasznaloszint_id', 1)->where('felhasznalo_id', auth()->user()->id)->first()){
            return redirect('/admin/profilszerkesztes');
        }*/

       

        $felekezet = $request->input('Felekezetek');
       
        $egyhazmegye = null; $egyebInput = null;
        switch((string)$felekezet)
        {


            case "Római Katolikus Egyház":
                    $egyhazmegye = $request->input('egyhazmegyek');//dd($egyhazmegye);
                    $EgyhazmegyeID = Egyhazmegyek::where('nev',$egyhazmegye)->first()->id;
                    $useregyhazmegye = UserEgyhazmegye::updateOrCreate(
                        ['felhasznalo_id' => $id],
                        ['egyhazmegye_id' => $EgyhazmegyeID, 'modosito' => $id]
                    );
                    /*
                    $useregyhazmegye->felhasznalo_id = $user['id'];
                    $useregyhazmegye->egyhazmegye_id = $EgyhazmegyeID;
                    $useregyhazmegye->modosito = $user['id'];
                    $useregyhazmegye->egyebInputValue = null;
                    $useregyhazmegye->nemTag = null;
                    $useregyhazmegye->save();*/
            break;
            case "Görög Katolikus Egyház":
                $egyhazmegye = $request->input('egyhazmegyek');//dd($egyhazmegye);
                $EgyhazmegyeID = Egyhazmegyek::where('nev',$egyhazmegye)->first()->id;
                $useregyhazmegye = UserEgyhazmegye::updateOrCreate(
                    ['felhasznalo_id' => $id],
                    ['egyhazmegye_id' => $EgyhazmegyeID, 'modosito' => $id]
                );
        break;
            case 'Egyéb':
                $egyebInput = $request->input('egyhazinput');
                $EgyhazmegyeID = Egyhazmegyek::where('nev',$egyebInput)->first()->id;
                UserEgyhazmegye::updateOrCreate(
                    ['felhasznalo_id' => $id],
                    ['egyhazmegye_id' => $EgyhazmegyeID, 'modosito' => $id,'egyebInputValue' => $egyebInput ]
                );
            break;
            case  'egyéb':
                $egyebInput = $request->input('egyhazinput');
                $EgyhazmegyeID = Egyhazmegyek::where('nev','Egyéb')->first()->id;
                
                    try{
                        if(!isset($egyebInput ))
                        {
                            throw new Exception();
                        }
                    }
                    catch(Exception $e)
                    {
                        return back()->withErrors("Kérjük írja be, melyik 'egyéb' egyházmegyéhez, felekezethez tartozik! A mező nem lehet üres!","egyebures")->withInput();
                    }
                
                UserEgyhazmegye::updateOrCreate(
                    ['felhasznalo_id' => $id],
                    ['egyhazmegye_id' => $EgyhazmegyeID, 'modosito' => $id,'egyebInputValue' => $egyebInput ]
                );
            break;
            default:
            //$EgyhazmegyeID = Egyhazmegyek::where('nev',$egyebInput)->first()->id;
            UserEgyhazmegye::updateOrCreate(
                ['felhasznalo_id' => $id],
                ['egyhazmegye_id' => 10, 'modosito' => $id,'nemTag' => 1 ]
            );
           /* $useregyhazmegye->felhasznalo_id = $user['id'];
            $useregyhazmegye->egyhazmegye_id = 10;
            $useregyhazmegye->modosito = $user['id'];
            $useregyhazmegye->egyebInputValue = null;
            $useregyhazmegye->nemTag = 1;
            $useregyhazmegye->save();*/
        break;

        }
        unset($egyhazmegye);


        $nyelv1 = $request->input('nyelv1');
        $nyelv2 = $request->input('nyelv2');
        $nyelv3 = $request->input('nyelv3');
        $nyelv4 = $request->input('nyelv4');
        $nyelv5 = $request->input('nyelv5');

        try {

            if(isset($nyelv1))
            {
                $nyelvSzint1 = $request->input('nyelv1szint');
                if(!isset($nyelvSzint1))
                {
                    throw new Exception();
                }
                else
                {
                    $r =  DB::table('nyelvismeret')->updateOrInsert(['felhasznalo_id' => $id, 'sorrend' => 1],['nyelv' => $nyelv1, 'nyelvszint_id' =>  $nyelvSzint1,'sorrend' => 1 ]);
        
                }
            }

           
        }
        catch(Exception $e)
        {
            return back()->withErrors("Validálási hiba! A 'Nyelv 1' mezőnél nem adta meg a nyeltudás szintjét! ",'nyelv1');
        }

        try
        {
            if(isset($nyelv2))
            {
                $nyelvSzint2 = $request->input('nyelv2szint');
                if(!isset($nyelvSzint2))
                {
                    throw new Exception();
                }
                else
                {
                    $r =  DB::table('nyelvismeret')->updateOrInsert(['felhasznalo_id' => $id, 'sorrend' => 2],['nyelv' => $nyelv2, 'nyelvszint_id' =>  $nyelvSzint2,'sorrend' => 2 ]);
        
                }
            }
            
        }
        catch(Exception $e)
        {
            return back()->withErrors("Validálási hiba! A 'Nyelv 2' mezőnél nem adta meg a nyeltudás szintjét! ",'nyelv2');
        }

        try
        {
            if(isset($nyelv3))
            {
                $nyelvSzint3 = $request->input('nyelv3szint');
                if(!isset($nyelvSzint3))
                {
                    throw new Exception();
                }
                else
                {
                    $r =  DB::table('nyelvismeret')->updateOrInsert(['felhasznalo_id' => $id, 'sorrend' => 3],['nyelv' => $nyelv3, 'nyelvszint_id' =>  $nyelvSzint3,'sorrend' => 3 ]);
        
                }
            }
            
        }
        catch(Exception $e)
        {
            return back()->withErrors("Validálási hiba! A 'Nyelv 3' mezőnél nem adta meg a nyeltudás szintjét! ",'nyelv3');
      
        }

        try{
            if(isset($nyelv4))
            {
                $nyelvSzint4 = $request->input('nyelv4szint');
                if(!isset($nyelvSzint4))
                {
                    throw new Exception();
                }
                else
                {
                    $r =  DB::table('nyelvismeret')->updateOrInsert(['felhasznalo_id' => $id, 'sorrend' => 4],['nyelv' => $nyelv4, 'nyelvszint_id' =>  $nyelvSzint4,'sorrend' => 4 ]);
        
                }
            }
           
        }
        catch(Exception $e)
        {
            return back()->withErrors("Validálási hiba! A 'Nyelv 4' mezőnél nem adta meg a nyeltudás szintjét! ",'nyelv4');

        }
       
        try{
            if(isset($nyelv5))
            {
                $nyelvSzint5 = $request->input('nyelv5szint');
                if(!isset($nyelvSzint5))
                {
                    throw new Exception();
                }
                else
                {
                    $r =  DB::table('nyelvismeret')->updateOrInsert(['felhasznalo_id' => $id, 'sorrend' => 5],['nyelv' => $nyelv5, 'nyelvszint_id' =>  $nyelvSzint5,'sorrend' => 5 ]);
        
                }
            }
            
        }
        catch(Exception $e)
        {
            return back()->withErrors("Validálási hiba! A 'Nyelv 5' mezőnél nem adta meg a nyeltudás szintjét! ",'nyelv5');

        }

        

        //dd($request->input('normal'),$request->input('laktozz'));

        try{
            OmrEmail::AlertUserDataChange($user['email']);
            /**
             * @note
             * lásd az admin controllerben leirtat!
             */
        }
        catch(Exception $e)
        {
            return back();
        }

        return redirect('/admin/profilszerkesztes');

    }

        public function logout()
        {
            Auth::logout();
            return redirect('/login');
        }

    /******************************************************************************************************************************************************** */

     /**
     * Seged fgv. a fotevekenyseg html kimenetenek eloallitasahoz
     * @param int
     */
    public function GetHTMLTevekenysegMaker($JelenlegiTevkensegID)
    {
        $get = "def";
        switch($JelenlegiTevkensegID)
        {
            case 1:
                $get = '<option value="1" selected="selected">Felsőoktatásban tanulok</option>
                <option value="2">Középiskolában tanulok</option>
                <option value="3">Általános iskolában tanulok</option>
                <option value="4">Dolgozom</option>
                <option value="5">Munkanélküli vagyok</option>
                <option value="6">Kisgyermeket nevelek otthon</option>
                <option value="7">Háztartásbeli vagyok otthon</option>
                <option value="8">Nyugdíjas vagyok</option>';
                return $get;
            break;

            case 2:
                $get = '<option value="1" >Felsőoktatásban tanulok</option>
                <option value="2" selected="selected">Középiskolában tanulok</option>
                <option value="3">Általános iskolában tanulok</option>
                <option value="4">Dolgozom</option>
                <option value="5">Munkanélküli vagyok</option>
                <option value="6">Kisgyermeket nevelek otthon</option>
                <option value="7">Háztartásbeli vagyok otthon</option>
                <option value="8">Nyugdíjas vagyok</option>';
                return $get;
            break;

            case 3:
                $get = '<option value="1" >Felsőoktatásban tanulok</option>
                <option value="2" >Középiskolában tanulok</option>
                <option value="3" selected="selected">Általános iskolában tanulok</option>
                <option value="4">Dolgozom</option>
                <option value="5">Munkanélküli vagyok</option>
                <option value="6">Kisgyermeket nevelek otthon</option>
                <option value="7">Háztartásbeli vagyok otthon</option>
                <option value="8">Nyugdíjas vagyok</option>';
                return $get;
            break;

            case 4:
                $get = '<option value="1" >Felsőoktatásban tanulok</option>
                <option value="2" >Középiskolában tanulok</option>
                <option value="3" >Általános iskolában tanulok</option>
                <option value="4" selected="selected">Dolgozom</option>
                <option value="5">Munkanélküli vagyok</option>
                <option value="6">Kisgyermeket nevelek otthon</option>
                <option value="7">Háztartásbeli vagyok otthon</option>
                <option value="8">Nyugdíjas vagyok</option>';
                return $get;
            break;

            case 5:
                $get = '<option value="1" >Felsőoktatásban tanulok</option>
                <option value="2" >Középiskolában tanulok</option>
                <option value="3" >Általános iskolában tanulok</option>
                <option value="4">Dolgozom</option>
                <option value="5" selected="selected">Munkanélküli vagyok</option>
                <option value="6">Kisgyermeket nevelek otthon</option>
                <option value="7">Háztartásbeli vagyok otthon</option>
                <option value="8">Nyugdíjas vagyok</option>';
                return $get;
            break;

            case 6:
                $get = '<option value="1" >Felsőoktatásban tanulok</option>
                <option value="2" >Középiskolában tanulok</option>
                <option value="3" >Általános iskolában tanulok</option>
                <option value="4" >Dolgozom</option>
                <option value="5" >Munkanélküli vagyok</option>
                <option value="6" selected="selected">Kisgyermeket nevelek otthon</option>
                <option value="7">Háztartásbeli vagyok otthon</option>
                <option value="8">Nyugdíjas vagyok</option\>';
                return $get;
            break;

            case 7:
                $get = '<option value="1" >Felsőoktatásban tanulok</option>
                <option value="2" >Középiskolában tanulok</option>
                <option value="3" >Általános iskolában tanulok</option>
                <option value="4" >Dolgozom</option>
                <option value="5" >Munkanélküli vagyok</option>
                <option value="6" >Kisgyermeket nevelek otthon</option>
                <option value="7" selected="selected">Háztartásbeli vagyok otthon</option>
                <option value="8">Nyugdíjas vagyok</option>';
                return $get;
            break;

            case 8:
                $get = '<option value="1" >Felsőoktatásban tanulok</option>
                <option value="2" >Középiskolában tanulok</option>
                <option value="3" >Általános iskolában tanulok</option>
                <option value="4" >Dolgozom</option>
                <option value="5" >Munkanélküli vagyok</option>
                <option value="6" >Kisgyermeket nevelek otthon</option>
                <option value="7" >Háztartásbeli vagyok otthon</option>
                <option value="8" selected="selected">Nyugdíjas vagyok</option>';
                return $get;
            break;
            default:
                $get = '<option value="1" >Felsőoktatásban tanulok</option>
                <option value="2" >Középiskolában tanulok</option>
                <option value="3" >Általános iskolában tanulok</option>
                <option value="4" >Dolgozom</option>
                <option value="5" >Munkanélküli vagyok</option>
                <option value="6" >Kisgyermeket nevelek otthon</option>
                <option value="7" >Háztartásbeli vagyok otthon</option>
                <option value="8">Nyugdíjas vagyok</option>';
                return $get;
            break;
        }
    }

    public function getPolomeret($polomeret)
    {
        $get = null;
        switch($polomeret)
        {
            case 'XS':
                    $get = '<option value="XS" selected="selected">XS</option>
                    <option value="S">S</option>
                    <option value="M">M</option>
                    <option value="L">L</option>
                    <option value="XL">XL</option>
                    <option value="XXL">XXL</option> <option value="XXXL">XXXL</option> <option value="XXXXL+">XXXXL vagy nagyobb</option>';
                    return $get;
            break;
            case 'S':
                    $get = '<option value="XS" >XS</option>
                    <option value="S" selected="selected">S</option>
                    <option value="M">M</option>
                    <option value="L">L</option>
                    <option value="XL">XL</option>
                    <option value="XXL">XXL</option><option value="XXXL">XXXL</option> <option value="XXXXL+">XXXXL vagy nagyobb</option>';
                    return $get;
            break;
            case 'M':
                $get = '<option value="XS" >XS</option>
                <option value="S" >S</option>
                <option value="M" selected="selected">M</option>
                <option value="L">L</option>
                <option value="XL">XL</option>
                <option value="XXL">XXL</option><option value="XXXL">XXXL</option> <option value="XXXXL+">XXXXL vagy nagyobb</option>';
                    return $get;
            break;
            case 'L':
                $get = '<option value="XS" >XS</option>
                <option value="S" >S</option>
                <option value="M" >M</option>
                <option value="L" selected="selected">L</option>
                <option value="XL">XL</option>
                <option value="XXL">XXL</option><option value="XXXL">XXXL</option> <option value="XXXXL+">XXXXL vagy nagyobb</option>';
                    return $get;
            break;
            case 'XL':
            $get = '<option value="XS" >XS</option>
            <option value="S" >S</option>
            <option value="M" >M</option>
            <option value="L" >L</option>
            <option value="XL" selected="selected">XL</option>
            <option value="XXL">XXL</option><option value="XXXL">XXXL</option> <option value="XXXXL+">XXXXL vagy nagyobb</option>';
                    return $get;
            break;
            case 'XXL':
            $get = '<option value="XS" >XS</option>
            <option value="S" >S</option>
            <option value="M" >M</option>
            <option value="L" >L</option>
            <option value="XL">XL</option>
            <option value="XXL"  selected="selected">XXL</option><option value="XXXL">XXXL</option> <option value="XXXXL+">XXXXL vagy nagyobb</option>';
                    return $get;
            break;
            case 'XXXL':
            $get = '<option value="XS" >XS</option>
                    <option value="S" >S</option>
                    <option value="M" >M</option>
                    <option value="L" >L</option>
                    <option value="XL">XL</option>
                    <option value="XXL"  >XXL</option><option value="XXXL" selected="selected">XXXL</option> <option value="XXXXL+">XXXXL vagy nagyobb</option>';
                    return $get;
            break;
            case 'XXXXL+':
            $get = '<option value="XS" >XS</option>
                    <option value="S" >S</option>
                    <option value="M" >M</option>
                    <option value="L" >L</option>
                    <option value="XL">XL</option>
                    <option value="XXL"  >XXL</option><option value="XXXL" >XXXL</option> <option value="XXXXL+" selected="selected">XXXXL vagy nagyobb</option>';
                    return $get;
            break;
            default:
                $get = '<option value="XS" >XS</option>
                <option value="S" >S</option>
                <option value="M" >M</option>
                <option value="L" >L</option>
                <option value="XL">XL</option>
                <option value="XXL">XXL</option><option value="XXXL">XXXL</option> <option value="XXXXL+">XXXXL vagy nagyobb</option>';
                        return $get;
            break;
        }


    }


    public function GetNyelvSzintHTML($nyelvszintid)
    {
        $get = null;
        switch($nyelvszintid)
        {
            case '1':
                $get = '<option value="1" selected="selected">Alapfok</option>
                <option value="2">Középfok</option>
                <option value="3">Felsőfok</option>';
                return $get;
            break;

            case '2':
            $get = '<option value="1">Alapfok</option>
            <option value="2"  selected="selected">Középfok</option>
            <option value="3">Felsőfok</option>';
            return $get;
            break;

            case '3':
                $get = '<option value="1">Alapfok</option>
                <option value="2">Középfok</option>
                <option value="3"  selected="selected">Felsőfok</option>';
                return $get;
            break;

            default:
                $get = '<option value="1">Alapfok</option>
                <option value="2">Középfok</option>
                <option value="3">Felsőfok</option>';
                return $get;
            break;

        }
    }


}



class RendezvenyHelyszin
{
    public $id;
    public $telepules;
    public $cim;

    public function __construct($id, $telepules, $cim)
    {
        $this->id = $id;
        $this->telepules = $telepules;
        $this->cim = $cim;
    }
}
