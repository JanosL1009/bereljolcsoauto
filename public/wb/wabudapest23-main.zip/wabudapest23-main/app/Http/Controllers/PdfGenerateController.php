<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Barryvdh\DomPDF\PDF;
use Illuminate\Support\Facades\DB;
use Exception;
use App;
use App\User;
use App\Model\Felhasznalo;
use App\FelhasznaloInfo;
use App\AllandoLakcim;
use App\TartozkodasiLakcim;
use App\SzemelyesAdatok;
use App\Nyelvismeret;
use App\EgyebSzervezetTagja;
use App\CivilSzervezetTagja;

use App\Egyhazmegyek;
use App\Iskola;
use App\UserEgyhazmegye;

use App\EtkezesiIgenyek;
use Illuminate\Support\Carbon;
use App\Ruha;
use App\RuhaAtadoAtvetel;
use App\Ajandekok;
use App\AjandekokAtadoAtvetel;

use Illuminate\Support\Str;

class PdfGenerateController extends Controller
{
    public function profiledownload()
    {
        $user = auth()->user();
        $UserID = $user["id"];
        $pdf = App::make('dompdf.wrapper');
        //$pdf->loadHTML($this->getProfileOutput($UserID));

        $ActUser = User::find($UserID);
        $FelhasznaloTabla = Felhasznalo::find($UserID);
        $SzemAdatok = SzemelyesAdatok::where('felhasznalo_id',$UserID)->first();
        $AllandoLakcim = AllandoLakcim::where('felhasznaloid',$UserID)->first();
        $FelhasznInfo = FelhasznaloInfo::where('felhasznalo_id',$UserID)->first();
        $TartLakcim = TartozkodasiLakcim::where('felhasznaloid',$UserID)->first();
        $neme = null;
        if($FelhasznaloTabla->neme == "1")
        {
            $neme = "Nő";
        } else $neme = "Férfi";

        $CivilSzervezet = CivilSzervezetTagja::where('felhasznalo_id',$UserID)->first();
        $EgyebSzervezet = EgyebSzervezetTagja::where('felhasznalo_id',$UserID)->first();

      
        $Egyhaz = UserEgyhazmegye::where('felhasznalo_id',$UserID)->first();
        $Felekezet =  null;
            $FelekezetNeve =  null;
            $EgyebFelekezet = null;
            $egyhazmegye = null;
        try {
            $egyhazmegye = $this->getEgyhazmegye($Egyhaz->egyhazmegye_id);
            $Felekezet =  $egyhazmegye->felekezet;
            $FelekezetNeve =  $egyhazmegye->nev;
            $EgyebFelekezet = $Egyhaz->egyebInputValue;
        }
        catch(Exception $e)
        {
            $Egyhaz = null;
            $egyhazmegye = null;
            $Felekezet =  null;
            $FelekezetNeve =  null;
            $EgyebFelekezet = null;
            unset( $ActUser);unset( $FelhasznaloTabla);unset( $SzemAdatok);unset( $AllandoLakcim);unset( $AllandFelhasznInfooLakcim);
            unset($TartLakcim);
            return back()->withErrors('A profil letöltés nem sikerült. Ellenőrizd, hogy az Egyházmegye adatait jól töltötted-e ki.','error'); //
        }
       

        $iskola = Iskola::where('felhasznalo_id',$UserID)->first();
        
        $nyelvismeret = Nyelvismeret::where('felhasznalo_id',$UserID)->get();

        $nyelv1 = '';$nyelv2 = '';$nyelv3 = '';$nyelv4 = '';$nyelv5 = '';
        $nyelvszint1 = '';$nyelvszint2 = '';$nyelvszint3 = '';$nyelvszint4 = '';$nyelvszint5 = '';

        foreach($nyelvismeret as $Nyelv)
        {
           if($Nyelv->sorrend == 1)
           {
            $nyelv1 = $Nyelv->nyelv;
            if(isset($nyelv1))
            {
                $nyelvszint1 = $this->getNyelvSzint($Nyelv->nyelvszint_id);
            }
           
           }
           if($Nyelv->sorrend == 2)
           {
            $nyelv2 = $Nyelv->nyelv;
            if(isset($nyelv2))
            {
                $nyelvszint2 = $this->getNyelvSzint($Nyelv->nyelvszint_id);
            }
            
           }
           if($Nyelv->sorrend == 3)
           {
            $nyelv3 = $Nyelv->nyelv;
            if(isset($nyelv3))
            {
                $nyelvszint3 = $this->getNyelvSzint($Nyelv->nyelvszint_id);
            }
            
           }
           if($Nyelv->sorrend == 4)
           {
            
            $nyelv4 = $Nyelv->nyelv;
            if(isset($nyelv4))
            {
                $nyelvszint4 = $this->getNyelvSzint($Nyelv->nyelvszint_id);
            }
            
           }
           if($Nyelv->sorrend == 5)
           {
            $nyelv5 = $Nyelv->nyelv;
            if(isset($nyelv5))
            {
                $nyelvszint5 = $this->getNyelvSzint($Nyelv->nyelvszint_id);
            }
           
           }
        }

        $data = [
            'title' => 'NEK 2020 Önkéntes Jelentkezés',
            'heading' => 'NEK 2020 Önkéntes Jelentkezés',
            'nev' => $ActUser->name,
            'szulhely' => $FelhasznaloTabla->szulhely_ID,
            'szulidocimke' => 'Születési idő:',
            'szulido' => $FelhasznaloTabla->szulIdo,
            'neme' =>  $neme,
            'anyjaneve' => $SzemAdatok->anyjaneve,
            'allampolgarsag' => $SzemAdatok->allampolgarsag,
            'szemigszam' => $SzemAdatok->szemigszam,
            'telefonszam' => $FelhasznaloTabla->telefonszam,
            'email' => $ActUser->email,

            'AllandoL_Orszag' =>  $this->getOrszag((int)$AllandoLakcim->Orszag??0),
            'AllandoL_Megye' =>   $this->getMegye((int)$AllandoLakcim->megyeID??0),
            'AllandoL_Irszam' => $AllandoLakcim->IranyitoSzam,
            'AllandoL_Telepules' => $AllandoLakcim->Telepules,
            'AllandoL_Utca' => $AllandoLakcim->Cim,

            'TartL_Orszag' =>  $this->getOrszag((int)$TartLakcim->OrszagID??0),
            'TartL_Megye' =>   $this->getMegye((int)$TartLakcim->megyeID??0),
            'TartL_Irszam' => $TartLakcim->IranyitoSzam,
            'TartL_Telepules' => $TartLakcim->TelepulesID,
            'TartL_Utca' => $TartLakcim->Cim,

            'CivilSzervezet' => $CivilSzervezet->szervezet_neve??0,
            'EgyebSzervezet' => $EgyebSzervezet->szervezet_neve??0,
            
            'Felekezet' => $Felekezet,
            'FelekezetNeve' => $FelekezetNeve,
            'EgyebFelekezet' => $EgyebFelekezet,
            'TevID' => $FelhasznInfo->tevekenyseg_id,
            'Tevekenyseg' =>  $this->getTevekenyseg($FelhasznInfo->tevekenyseg_id),

            'Iskola' => $iskola->intezmenyneve,
            'Osztaly' => $iskola->evfolyam,

            'FogySzemely' => $FelhasznInfo->fogyatekossag,
            'FogyLeiras' => $FelhasznInfo->fogyLeirasa,
            'polomeret' => $FelhasznInfo->polomeret,
            'polotipusa' => $FelhasznInfo->polotipus,
            'etkezesiIgeny' => $this->getEtekzesiIgeny( $FelhasznInfo->etkezesIgenyID),
            'igazolas' => $FelhasznInfo->igazolasIgenyID,
            'igazolasEgyeb' => $FelhasznInfo->igazolasEgyeb,
            'szallasIgeny' => $FelhasznInfo->szallastIgenyel,
            'nyelv1' => $nyelv1,
            'nyelv2' => $nyelv2,
            'nyelv3' => $nyelv3,
            'nyelv4' => $nyelv4,
            'nyelv5' => $nyelv5,
            'nyelvszint1' =>$nyelvszint1,
            'nyelvszint2' =>$nyelvszint2,
            'nyelvszint3' =>$nyelvszint3,
            'nyelvszint4' =>$nyelvszint4,
            'nyelvszint5' =>$nyelvszint5,

            'letoltesIdeje' => Carbon::now()
        ];
          
          $pdf->loadView('pdf.teszt',$data,array(),'UTF-8');

        return $pdf->download();
    }

    public function getFormaRuhaAtadoElismerveny(Request $request, int $UserId)
    { 
        $user = auth()->user();
      
        $loggedUser = User::find((int)$user["id"]);

        $User = User::find($UserId);

        $RuhaAdatdoAtvetel = RuhaAtadoAtvetel::where('felhasznalo_id',$UserId)->whereNull('visszaVetelezesIdeje')->get();
        $ruhakBladre = array();
        foreach($RuhaAdatdoAtvetel as $ruha)
        {
            $content = $ruha->darabszam.' db '.$ruha->Ruha->ruhaNeve;
            array_push($ruhakBladre, $content);
        }

        $igazolvanyID = null;
        try{
            $igazolvanyID = $User->szemelyesadatok_data->szemigszam;
        }
        catch(Exception $e)
        {
            $igazolvanyID = 'Nincs kitöltve';
        }
        $dt = Carbon::now();

        $data = [
            'title' => 'NEK 2020 Önkéntes Jelentkezés',
            'heading' => 'NEK 2020 Önkéntes Jelentkezés',
            'nev' => $User->name??'Nincs kitöltve',
            'szemigszam' => $igazolvanyID??'Nincs kitöltve',
            'szulido' => $User->felhasznalo_data->szulIdo??'Nincs kitöltve',
            'szulhely' => $User->felhasznalo_data->szulhely_ID??'Nincs kitöltve',
            'ruhak' => $ruhakBladre,
            'atadoneve' => $loggedUser->name,
            'pontosIdo' => $dt->toDateString()
        ];
        $pdf = App::make('dompdf.wrapper');
        $pdf->loadView('pdf.formaruha_atado',$data,array(),'UTF-8');
       // return $pdf->stream("dompdf_out.pdf", array("Attachment" => false));
        return $pdf->download();

    }

    public function getAjandekElismerveny(Request $request, int $UserId)
    { 
        $user = auth()->user();
      
        $loggedUser = User::find((int)$user["id"]);

        $User = User::find($UserId);

        $RuhaAdatdoAtvetel = AjandekokAtadoAtvetel::where('felhasznalo_id',$UserId)
        ->whereNull('visszaVetelezesIdeje')->get();
        $ruhakBladre = array();
        foreach($RuhaAdatdoAtvetel as $ruha)
        {
            $content = $ruha->darabszam.' db '.$ruha->Ajandek->ajandekNeve;
            array_push($ruhakBladre, $content);
        }

        $igazolvanyID = null;
        try{
            $igazolvanyID = $User->szemelyesadatok_data->szemigszam;
        }
        catch(Exception $e)
        {
            $igazolvanyID = 'Nincs kitöltve';
        }
        $dt = Carbon::now();

        $data = [
            'title' => 'NEK 2020 Önkéntes Jelentkezés',
            'doctitle' => 'NEK 2020 Önkéntes Jelentkezés',
            'heading' => 'NEK 2020 Önkéntes Jelentkezés',
            'nev' => $User->name??'Nincs kitöltve',
            'szemigszam' => $igazolvanyID??'Nincs kitöltve',
            'szulido' => $User->felhasznalo_data->szulIdo??'Nincs kitöltve',
            'szulhely' => $User->felhasznalo_data->szulhely_ID??'Nincs kitöltve',
            'ruhak' => $ruhakBladre,
            'atadoneve' => $loggedUser->name,
            'pontosIdo' => $dt->toDateString()
        ];
        $pdf = App::make('dompdf.wrapper');
        $pdf->loadView('pdf.ajandeknyomtatvany',$data,array(),'UTF-8');
        return $pdf->stream("dompdf_out.pdf", array("Attachment" => false));
        return $pdf->download();

    }

    public function getIkszIgazolas(Request $request, int $UserId)
    { 
        $user = auth()->user();
      
        $loggedUser = User::find((int)$user["id"]);

        $User = User::find($UserId);

        $anyjaneve = SzemelyesAdatok::where('felhasznalo_id',$UserId)->first()->anyjaneve;
       
        
        $dt = Carbon::now();

        $oraszam = 0;
        $teljesOraSzam = 0;
        if(isset($User->felhasznalo_data->onkentesOrakSzama))
        {
            $oraszam = $User->felhasznalo_data->onkentesOrakSzama;
            $teljesOraSzam  = $User->felhasznalo_data->onkentesOrakSzama;
            if($User->felhasznalo_data->onkentesOrakSzama > 50)
            {
                $oraszam = 50;
            }
        }
        


        $data = [
            'title' => 'NEK 2020 Önkéntes Jelentkezés',
            'doctitle' => 'NEK 2020 Önkéntes Jelentkezés',
            'heading' => 'NEK 2020 Önkéntes Jelentkezés',
            'nev' => $User->name??'Nincs kitöltve',
            'anyjaneve' => $anyjaneve??'Nincs kitöltve',
            'szulido' => $User->felhasznalo_data->szulIdo??'Nincs kitöltve',
            'teljesOraSzam' =>  $teljesOraSzam,
            'oraszam' =>  $oraszam,
            'pontosIdo' => $dt->toDateString()
        ];
       
        $pdf = App::make('dompdf.wrapper');
        $pdf->loadView('pdf.tanusitvanyok.iksz',$data,array(),'UTF-8');
        //return $pdf->stream("dompdf_out.pdf", array("Attachment" => false));
        return $pdf->download();
       
    }


    public function getAltalnosOnkentesIgazolas(Request $request, int $UserId)
    { 
        $user = auth()->user();
      
        $loggedUser = User::find((int)$user["id"]);

        $User = User::find($UserId);

        $anyjaneve = SzemelyesAdatok::where('felhasznalo_id',$UserId)->first()->anyjaneve;
       
        
        $dt = Carbon::now();

        $data = [
            'title' => 'NEK 2020 Önkéntes Jelentkezés',
            'doctitle' => 'NEK 2020 Önkéntes Jelentkezés',
            'heading' => 'NEK 2020 Önkéntes Jelentkezés',
            'nev' => $User->name??'Nincs kitöltve',
            'anyjaneve' => $anyjaneve??'Nincs kitöltve',
            'szulido' => $User->felhasznalo_data->szulIdo??'Nincs kitöltve',
            'oraszam' => $User->felhasznalo_data->onkentesOrakSzama??0,
            'szulhely' =>$User->felhasznalo_data->szulhely,
            'pontosIdo' => $dt->toDateString()
        ];
       
        $pdf = App::make('dompdf.wrapper');
        $pdf->loadView('pdf.tanusitvanyok.altalanos',$data,array(),'UTF-8');
        //return $pdf->stream("dompdf_out.pdf", array("Attachment" => false));
        return $pdf->download();

    }

    public function getAllIksz(Request $request, int $UserId)
    {
        $user = auth()->user();
      
        $loggedUser = User::find((int)$user["id"]);

        $User = User::find($UserId);

        $anyjaneve = SzemelyesAdatok::where('felhasznalo_id',$UserId)->first()->anyjaneve;
       
        
        $dt = Carbon::now();

        $oraszam = 0;
        $teljesOraSzam = 0;
        if(isset($User->felhasznalo_data->onkentesOrakSzama))
        {
            $oraszam = $User->felhasznalo_data->onkentesOrakSzama;
            $teljesOraSzam  = $User->felhasznalo_data->onkentesOrakSzama;
            if($User->felhasznalo_data->onkentesOrakSzama > 50)
            {
                $oraszam = 50;
            }
        }
        


        $data = [
            'title' => 'NEK 2020 Önkéntes Jelentkezés',
            'doctitle' => 'NEK 2020 Önkéntes Jelentkezés',
            'heading' => 'NEK 2020 Önkéntes Jelentkezés',
            'nev' => $User->name??'Nincs kitöltve',
            'anyjaneve' => $anyjaneve??'Nincs kitöltve',
            'szulido' => $User->felhasznalo_data->szulIdo??'Nincs kitöltve',
            'teljesOraSzam' =>  $teljesOraSzam,
            'oraszam' =>  $oraszam,
            'pontosIdo' => $dt->toDateString()
        ];
       
        $pdf = App::make('dompdf.wrapper');
        $pdf->loadView('pdf.tanusitvanyok.iksz',$data,array(),'UTF-8');
        //return $pdf->stream("dompdf_out.pdf", array("Attachment" => false));
        $output = $pdf->output();
        $slug = $User->name.'_'.$User->id;
        $name = Str::slug( $slug).'.pdf';
        file_put_contents('public/iksz/'.$name, $output);

    }


    public function getBlade()
    {
        $data = [
            'title' => 'NEK 2020 Önkéntes Jelentkezés',
            'heading' => 'NEK 2020 Önkéntes Jelentkezés',
            'nev' => 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industrys standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.'        
              ];
              
        return view('pdf.teszt')->with('data',$data);
    }

    protected function getProfileOutput(int $UserID)
    {
        $htmlOutput = null;
/**
 *  <style>.center{text-align:center;} .inline{style="display:inline;"}
        
        *</style>
 */
        $header = '';
        $title = '<h3 class="center">NEK 2020 Önkéntes Jelentkezés</h3>';

        $personalInfo = '
          
                <div class="inline">
                    <div class="inline">
                    sdfs
                    </div>
                    
                    <div  class="inline">
                    asdas
                    </div>
                </div>
                
           
        ';

        $htmlOutput = $title.$header.$personalInfo;

            return $htmlOutput;
    }

    protected function getOrszag(int $orszagid) : string
    {
        $orszag = DB::table('orszag')->where('id',$orszagid)->first();
        return $orszag->huNev;
    }

    protected function getMegye(int $megye_id) : string
    {
        $megye = DB::table('megyek')->where('megye_id',$megye_id)->first();
        return $megye->megye_neve;
    }

    /**
     * return object
     */
    protected function getEgyhazmegye(int $EgyhazID)
    {
        return Egyhazmegyek::find($EgyhazID);
    }

    protected function getTevekenyseg(int $ID) : string
    {
        return DB::table('tevekenyseg')->where('id',$ID)->first()->tevekenyseg;
    }

    protected function getEtekzesiIgeny(int $ID) : string
    {
        return EtkezesiIgenyek::find($ID)->elnevezes;
    }

    protected function getNyelvSzint(int $id) : string
    {
        $res = null;
        if($id == 1)
        {
            $res = "Alapfok";
        }
        if($id == 2)
        {
            $res = "Középfok";
        }
        if($id == 3)
        {
            $res = "Felsőfok";
        }
        return $res;
    }
 
}
