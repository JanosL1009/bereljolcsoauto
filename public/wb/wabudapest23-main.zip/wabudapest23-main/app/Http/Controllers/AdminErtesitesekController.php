<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\DB_OMR_Operations;
use App\Ertesitesek;
use App\ErtesitesMegtekintese;
use App\ErtesitesProgram;
use App\ErtesitesUsers;
use App\Esemeny;
use App\Terulet;
use App\Csoport;
use App\EsemenySzervezok;
use App\Http\Models\Ertesites\ErtesitesViewModel;
use App\Http\Models\ErtesitesekKezelese;
use App\User;
use App\Model\BeosztasKezeloRepo;
use Exception;
use App\Http\Models\Ertesites;

class AdminErtesitesekController extends Controller
{

    protected $AdminUserID = 0;
    protected $AdminUser = null;

    /**
     * Class constructor.
     */
    public function __construct()
    {
        $this->middleware('checkpermission');
    }

    /**
     * Beallitja a $AdminUserID:int valtozot
     */
    private function setAdminUserID() : void
    {
        if($this->AdminUserID == 0)
        {
            $this->AdminUser = auth()->user();
            $this->AdminUserID = intval($this->AdminUser["id"]);
        }
    }

    public function index($field = null,$order = null)
    {
        $this->setAdminUserID();
        $ertesitekLista = Ertesitesek::orderby('created_at','desc')->paginate(20);


        return view('adminisztratorok.ertesites.index',['ertesitesek' => $ertesitekLista]);
    }

    public function letrehozas(Request $request)
    {
        $this->setAdminUserID();

        $ertesites = new Ertesitesek;
        $esemenyek = Esemeny::all(['id','nev']);


        return view('adminisztratorok.ertesites.letrehozas',
        [
            'esemenyek' => $esemenyek
        ]);
    }

    /**
     * Egy ertesites adatainak es statisztikajanak megtekintese
     * @param int a megtekintendo ertesittes id-ja Erteseites tabla id-ja
     *
     * @return View
     */
    public function ErtesitesMegtekintese(int $id)
    {
         $this->setAdminUserID();
         $model = new ErtesitesViewModel(true);
         $model->profilpic = DB_OMR_Operations::GetProfilkep($this->AdminUserID);
         $ertesitoKezelo = new ErtesitesekKezelese($id);

         $model->LetrehozoNeve = $ertesitoKezelo->getLetrehozoNeve();
         $model->ErtesitesNeve = $ertesitoKezelo->getErtesitesNeve();
         $model->Tartalom  = $ertesitoKezelo->getErtesitesTartalma();
         $model->OnkentesekSzama = $ertesitoKezelo->getErtesitesreFeliratkozottakSzama();
         $model->created_at = $ertesitoKezelo->getErtesitesKikuldve();
         $model->isAdmin = $ertesitoKezelo->isRendszerSzintu();

         $esemenyhezTartozas = $ertesitoKezelo->getEsemenyhezTartozas();

        $model->Program = $esemenyhezTartozas["ProgramNeve"];
        $model->Terulet = $esemenyhezTartozas["TeruletNeve"];
        $model->Csoport = $esemenyhezTartozas["CsoportNeve"];

        $model->megtekintesekSzama = $ertesitoKezelo->getMegtekintesekSzama();

        $model->VezetokAkikLattak = $ertesitoKezelo->getMegtekintettVezetoBeosztasuOnkentesek();
        $model->vezetokAkikNemLattak = $ertesitoKezelo->getVezetokAkikNemTekintettekMegAzErtesitot();

        return view('adminisztratorok.ertesites.megtekintes_stats')->with('model',$model);
    }

    /**
     * POST routehoz
     */
    public function ErtesitesLetrehozasa(Request $request)
    {
        $this->setAdminUserID();
        /*$validatedData = $request->validate([
            'ertesitesNeve' => 'required|max:90',
            'ertesitesTartalma' => 'required|max:250',
        ]);*/

        $ertesitesNeve =  $request->input('ertesitesNeve');
        $ertesitesTartalma = $request->input('ertesitesTartalma');
        $rendszerSzintuUzenet = $request->input('SystemErt');

        $ertesites = new Ertesitesek;
        $ertesites->nev = $ertesitesNeve;
        $ertesites->tartalom = $ertesitesTartalma;
        $ertesites->letrehozo = $this->AdminUserID;
        $ertesites->modosito = 0;
        $ertesites->save();

        $ertesites_program = new ErtesitesProgram;
        if($rendszerSzintuUzenet == "on")
        {
            $ertesites_program->allusers = 1;
            $ertesites_program->ertesites_id = $ertesites->id;
            $ertesites_program->letrehozo = $this->AdminUserID;
            $ertesites_program->modosito = 0;
            $ertesites_program->save();

            //Az osszes usert bepkaoljuk a ertesites_users tablaba
            $users = User::all(['id']);
            foreach($users as $user)
            {
                $ertesitesUsers = new ErtesitesUsers;
                $ertesitesUsers->felhasznalo_id = $user->id;
                $ertesitesUsers->ertesites_id = $ertesites->id;
                $ertesitesUsers->megtekintve = 0;
                $ertesitesUsers->megtekintes_ideje = null;
                $ertesitesUsers->save();
            }

        }
        else
        {
            $programID = $request->input('Programok');
            $ertesites_program->allusers = 0;
            $ertesites_program->ertesites_id = $ertesites->id;
            $ertesites_program->letrehozo = $this->AdminUserID;
            $ertesites_program->modosito = 0;

            $ertesites_program->esemeny_id = $programID;

            $teruletID = $request->input('Teruletek');
            if(isset($teruletID ))
            {
                $ertesites_program->terulet_id = $teruletID ;
            }

            $csoportID = $request->input('Csoportok');
            if(isset($csoportID ))
            {
                $ertesites_program->csoport_id = $csoportID ;
            }

            $ertesites_program->save();

            //userek bepkaolasa a ertesites_users tablaba; csoport tagok
            if(isset($csoportID))
            {
                $beosztas = new BeosztasKezeloRepo($this->AdminUser,$programID,$teruletID,$csoportID);
                $usersID = $beosztas->GetCsoportBeosztas();
                foreach($usersID as $user)
                {
                    $ertesitesUsers = new ErtesitesUsers;
                    $ertesitesUsers->felhasznalo_id = $user->felhasznalo_id;
                    $ertesitesUsers->ertesites_id = $ertesites->id;
                    $ertesitesUsers->megtekintve = 0;
                    $ertesitesUsers->megtekintes_ideje = null;
                    $ertesitesUsers->save();
                }
                unset($beosztas);unset($usersID);
            }
            else
            {
                if(isset($teruletID))
                {
                    $beosztas = new BeosztasKezeloRepo($this->AdminUser,$programID,$teruletID,null);
                    $usersID = $beosztas->getTeruletreBeosztottakListajaID()->pluck('felhasznalo_id')->toArray();
                    $vezetokID = $beosztas->getTeruletVezetokListaja()->pluck('id')->toArray();

                    $usersID = array_merge($usersID,$vezetokID);
                    $e_id = $ertesites->id;

                    foreach($usersID as $user)
                    {
                        $ertesitesUsers = new ErtesitesUsers;
                        $ertesitesUsers->felhasznalo_id = $user;
                        $ertesitesUsers->ertesites_id = $e_id;
                        $ertesitesUsers->megtekintve = 0;
                        $ertesitesUsers->megtekintes_ideje = null;
                        $ertesitesUsers->save();
                    }
                    unset($beosztas);unset($usersID);
                }
                else
                {
                    $beosztas = new BeosztasKezeloRepo($this->AdminUser,$programID,null,null);
                    $usersID = $beosztas->getProgramraBeosztottak(true);
                    $vezetokID = $beosztas->getCsoportVezetokListaja()->pluck('felhasznalo_id')->toArray();
/* ez elvileg nem kell, mert a csoportvezetot ugy csinaltam meg, hogy automatikusan be kerul a csoportba is,
                    $usersID = array_merge($usersID,$vezetokID);*/

                    if(isset($usersID))
                    {
                        foreach($usersID as $user)
                        {
                            $ertesitesUsers = new ErtesitesUsers;
                            $ertesitesUsers->felhasznalo_id = $user;
                            $ertesitesUsers->ertesites_id = $ertesites->id;
                            $ertesitesUsers->megtekintve = 0;
                            $ertesitesUsers->megtekintes_ideje = null;
                            $ertesitesUsers->save();
                        }
                        unset($beosztas);unset($usersID);
                    }
                    else
                        throw new Exception('Nincs jelentkezo...');

                }
            }

        }



        return redirect('/admin/ertesitesek/');
    }

}
