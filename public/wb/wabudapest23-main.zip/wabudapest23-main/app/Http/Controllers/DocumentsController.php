<?php

namespace App\Http\Controllers;

use App\Esemeny;
use App\Http\Models\UserDocuments;
use App\Http\Models\Documents;

use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Http\Models\DocumentsViewModel;

use App\Http\Controllers\DB_OMR_Operations;
use App\PagesDetails;
use App\FelhasznaloInfo;
use App\Model\Felhasznalo;

class DocumentsController extends Controller
{
    public function index($field = null,$order = null)
    {

        $UserId = Auth::id();
        $documents = UserDocuments::where('felhasznalo_id','=',$UserId)->get();
        $alt_documents = Documents::where('visibility_id', 0)->get();
        $model = new DocumentsViewModel($UserId );
        $model->profilpic = DB_OMR_Operations::GetProfilkep($UserId);

        if(isset($field) && isset($order) )
        {
            $fieldValid = false; $orderValid = false;

            /**elfogadhato parametrek, mezok */
            switch($field)
            {
                case 'sajat': //itt kell megadnod, hogy melyik mezot akarod lekerdezni a paramter szerint!
                    $field = "docname"; //ez a tabla mezo lesz, amit lekerdezni
                    //itt mind1, hogy desc vagy asc a rendezés, mert a mező allando (sőt mindkét tablaba, direkt igy lett tervezve)
                    $fieldValid = true; //ez akkor TRUE, ha mezo valid, alapertelmezetten false
                    // azért false, hogy kivulrol ne lehessen hackelni! ha false :: nem csinál lekerdezest
                break;
                /**   a masodik linkhez ... */
                case 'altdocname': //maszkolas feloldasa
                    $field = "docname";  $fieldValid = true;
                break;

                case 'uploaded':
                    $fieldValid = true;$field = "uploaded_at";
                break;
                default:
                    $fieldValid = true;$field = "docname";
                break;
            }

            switch($order)
            {
                case 'asc':
                    $orderValid = true;
                break;
                case 'desc':
                    $orderValid = true;
                break;
                default:
                    $orderValid = true; $order = "desc"; //ez default! ha nem adsz meg parameter vagy visszatorlod akkor is beallitodik!
                break;
            }
            if($fieldValid && $orderValid)
            {

              $documents = UserDocuments::where('felhasznalo_id','=',$UserId)->orderBy($field,$order)->get();
              $alt_documents = Documents::where('visibility_id', 0)->orderBy($field,$order)->get();
            }

        }

        $pagesdetails = PagesDetails::find(7);
        $model->setMagyarazoSzovegek("leiras",$pagesdetails->leiras);

        $iskolas = false;
        $tev =  (int)FelhasznaloInfo::where('felhasznalo_id', $UserId)->first()->tevekenyseg_id??0;

        if($tev == 2)
        {
            $iskolas = true;
        }
        $felhasznalo = Felhasznalo::find($UserId);
        $esemenyek = Esemeny::select('id','nev')->where('statusz_id','!=',1)->orderBy('nev')->get();
        return view('dokumentumok', compact('documents', 'alt_documents'/*, 'fromAdmin'*/))->
        with('model',$model)->with('esemenyek',$esemenyek)->with('iskolas',$iskolas)->with('felhasznalo',$felhasznalo);

    }

    public function upload(Request $request)
    {

        if ($request->hasFile('file')) {
            $program = $request->input('DocToProgram');

            if(is_int((int) $program))
            {
                    $program = (int) $program;
                    //dd("egesz :".$program);
            }
            else $program = -1; //default, altalnos feltoltes kodja


            $document = new UserDocuments();


            $path = 'docs/';
/*
            if(!is_dir($path)) {
                \File::makeDirectory(public_path() . '/' . $path, 0755, true);
            }
*/
            $fileName = time() . $request->file('file')->getClientOriginalName();

            $request->file('file')->move($path, $fileName);

            $document->felhasznalo_id = \Auth::user()->id;
            $document->docname = $path.$fileName;
            $document->active = 1;
            $document->esemeny_id = $program;
            $document->save();

        }

        return back();
    }

    public function delete(Request $request,int $id)
    {

        $document = UserDocuments::where('id', $id)->first();
        $document->active = 0;
        $document->save();

        return back();
    }
}
