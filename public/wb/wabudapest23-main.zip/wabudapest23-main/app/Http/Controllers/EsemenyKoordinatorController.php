<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Esemeny;
use App\EsemenySzervezok;
use App\Terulet;
use App\Csoport;
use App\Model\BeosztasKezeloRepo;
use Illuminate\Support\Facades\DB;
use App\Http\Models\Koordinatorok\EsemenyKoordinatorokViewModel;
use App\Http\Models\Koordinatorok\EsemenySzerkesztoViewModel;
use App\Http\Models\Koordinatorok\KoordinatorTeruletCsoportViewModel;
class EsemenyKoordinatorController extends Controller
{
    public function index()
    {
        $user = auth()->user();
        $model = new EsemenyKoordinatorokViewModel($user['id']);
        $model->profilpic = DB_OMR_Operations::GetProfilkep($user['id']);
        $model->esemenyeim = EsemenySzervezok::where('szint_id',3)->where('felhasznalo_id',$user['id'])->paginate(15);

        return view("onkentes.esemenyszervezok.esemenyeim")->with('model',$model);

    }


    public function esemeny_szerkeszto_adatlap(Request $request,int $esemenyid)
    {
        $user = auth()->user();
        $model = new EsemenySzerkesztoViewModel($user['id']);
        $Esemeny = DB_OMR_Operations::GetEsemenyForId($esemenyid);
       

        $model->esemenyID = $esemenyid;
        $model->esemenyNeve = $Esemeny->nev;
        $model->kezdesDatuma = $Esemeny->kezdesDatum;
        $model->kezdesIdeje = $Esemeny->kezdesIdeje;
        $model->befejezesDatuma = $Esemeny->befejezesDatum;
        $model->befejezesIdeje = $Esemeny->befejezesIdeje;
        $model->Leiras = $Esemeny->Leiras;

        if ($Esemeny->toborzas == 1)
        {
            $model->Toborzas = 'checked';
        }
        else
        {
            $model->Toborzas = null;
        }

        $esemenyhelyszin = DB_OMR_Operations::GetEsemenyTelepules($esemenyid);
        $model->helyszin = array();

        foreach ($esemenyhelyszin as $helyszin)
        {
            //dd($helyszin);
            $Helyszinek = new \App\Http\Models\AdminEsemenyTelepulesViewModel();

            $telepules = DB::table('helyszin')->where('id','=',$helyszin->telepules_id)->get();

            $Helyszinek->Telepulesnev = isset($telepules[0]->Neve)?$telepules[0]->Neve:'-';
           // dd($telepules[0]->Cim);
            $Helyszinek->cim = $telepules&&isset($telepules[0]->Cim)?$telepules[0]->Cim:'-';;
            $Helyszinek->id = $helyszin->es_id;

            array_push($model->helyszin, $Helyszinek);
        }

        $model->Statusz = DB_OMR_Operations::EsemenyStatuszOptionsHTML($Esemeny->statusz_id);
        $model->adminLista = DB::table('users')->join('jogosultsag',"users.id",'=','jogosultsag.felhasznalo_id')->select('users.*')->where('jogosultsag.felhasznaloszint_id','=',1)->get();


        $model->EsemenySzervezok = DB::table('users')->join('esemeny_szervezok','users.id','=','esemeny_szervezok.felhasznalo_id')->select('users.*')->where('esemeny_szervezok.szint_id','=',3)->get();
        DB::table('users')->join('esemeny_szervezok','users.id','=','esemeny_szervezok.felhasznalo_id')->select('users.*')->where('esemeny_szervezok.szint_id','=',3)->count();

        $csoportvezetok = DB_OMR_Operations::getCsoportVezetokListajaEsemenySzerintOsszes($model->esemenyID);
        $teruletvezetok = DB_OMR_Operations::getTeruletVezetokListajaEsemenySzerintOsszes($model->esemenyID);

        $model->teruletek = DB_OMR_Operations::GetTeruletek($esemenyid);

        $beosztasKezelo = new BeosztasKezeloRepo(null,$esemenyid);
        $model->BeosztottakSzama = $beosztasKezelo->GetBeosztottakSzama(true);
        $model->NemBeosztottakSzama = $beosztasKezelo->getNemBeosztottak(true);
        //dd($model->NemBeosztottakSzama);

        /**
         * @version 1.1.0 Csak azok vannak a listaban akik adminok
         */

        return view("onkentes.esemenyszervezok.esemenyszerkesztes")->with('model',$model)->
        with('csoportvezetok',$csoportvezetok)->with('teruletvezetok',$teruletvezetok);
    }


    /**
     * Egy terulet leirasa, adatai és csoportjait jelenit meg.
     * @param Integer Terulet azonosito
     * @return View
     */
    public function Csoportok_lekerdezese($teruletid)
    {
       $user = auth()->user();
       /**
        * NAPLOZAS
        */
       /* $userviews = new UserAdminsViews;
        $userviews->slug = $_SERVER['REQUEST_URI'];
        $userviews->visitTimes = Carbon::now();
        $userviews->felhasznalo_id = $user['id'];
        $userviews->save();*/

       $csoportok = new KoordinatorTeruletCsoportViewModel($user['id']);
       $csoportok->csoport = DB_OMR_Operations::CsoportLista($teruletid);

       $csoportok->profilpic = DB_OMR_Operations::GetProfilkep($user['id']);

        $terulet = Terulet::find($teruletid);
        $beosztaskezelo = new BeosztasKezeloRepo($user,$terulet->esemeny_id,$teruletid);


       $terulet = DB::table('terulet')->where('id','=',$teruletid)->get();

       $csoportok->teruletneve = $terulet[0]->nev;
        $csoportok->teruletKezdesIdopont = $terulet[0]->kezdesIdopont;
        $csoportok->teruletBefejezesIdopont = $terulet[0]->befejezesIdopont;

       $esemeny =   DB::table('esemeny')->where('id','=',$terulet[0]->esemeny_id)->get();
       $csoportok->rendezvenyNeve =  $esemeny[0]->nev;
       $csoportok->rendezvenyKezdesDatuma = $esemeny[0]->kezdesDatum;
       $csoportok->rendezvenyBefejezesDatuma = $esemeny[0]->befejezesDatum;
       $csoportok->teruletid =  $terulet[0]->id;
       $csoportok->esemeny_id =  $terulet[0]->esemeny_id;

        $jelentkezokSzama = $beosztaskezelo->getIdTeruletJelentkezokListaja();
        $jokerJelentkezokSzama = $beosztaskezelo->getJokerJelentkezoIDk();
        $csoportok->jelentkezokSzama = count($jelentkezokSzama) + count($jokerJelentkezokSzama);

        $csoportok->tervezettLetszam = $terulet[0]->tervezettLetszam;
        $csoportok->TeruletAktiv =  $terulet[0]->teruletAktiv;
        $csoportok->teruletLeiras = $terulet[0]->leiras;
        $TeruletHelyszineID  = DB::table('terulet')->where('id','=',$csoportok->teruletid )->select('teruletHelyszineID')->get();

        $helyszin = DB::table('helyszin')->where('id','=', $TeruletHelyszineID[0]->teruletHelyszineID )->get();

        $csoportok->helyszin = $helyszin[0]->Neve;
        $csoportok->cim = $helyszin[0]->Cim;

        $csoportok->jelentkezokLista =  DB::table('users')->join('felhasznalo_feladat',"users.id",'=','felhasznalo_feladat.felhasznalo_id')->select('users.*')->where('felhasznalo_feladat.terulet_id','=',$teruletid)->get();


        $csoportok->TeruletVezetok = $beosztaskezelo->getTeruletVezetokListaja();

        $csoportok->CsoportVezetok = $beosztaskezelo->getCsoportVezetokListaja();

      


        $model = $csoportok;
        return view("onkentes.esemenyszervezok.csoportok")->with('model',$model);
    }

        /**
         * Területbeosztás a programm koordinatornak
         */
    public function OnkentesTeruletBeosztas(Request $resquest,$teruletid)
    {
        $user = auth()->user();

        $csoportok = new KoordinatorTeruletCsoportViewModel($user['id']);
        $csoportok->csoport = DB_OMR_Operations::CsoportLista($teruletid);
        $csoportok->profilpic = DB_OMR_Operations::GetProfilkep($user['id']);
/*NAPLOZAS
        $userviews = new UserAdminsViews;
        $userviews->slug = $_SERVER['REQUEST_URI'];
        $userviews->visitTimes = Carbon::now();
        $userviews->felhasznalo_id = $user['id'];
        $userviews->save();*/

        $terulet = DB::table('terulet')->where('id','=',$teruletid)->get();

        $csoportok->teruletneve = $terulet[0]->nev;
        $rendezvenyNeve =  DB::table('esemeny')->where('id','=',$terulet[0]->esemeny_id)->pluck('nev');
        $csoportok->teruletid =  $terulet[0]->id;
        $csoportok->esemeny_id =  $terulet[0]->esemeny_id;
        $csoportok->rendezvenyNeve = $rendezvenyNeve[0];
        $BeosztasKezelo = new BeosztasKezeloRepo($user,intval($csoportok->esemeny_id),intval($teruletid),null);



         $csoportok->tervezettLetszam = $terulet[0]->tervezettLetszam;
         $csoportok->TeruletAktiv =  $terulet[0]->teruletAktiv;
         $csoportok->teruletLeiras = $terulet[0]->leiras;

         /**
          * @var Array
          */
         $csoportok->jelentkezokLista =  $BeosztasKezelo->getIdTeruletJelentkezokListaja();
         $csoportok->jokerJelentkezoLista = $BeosztasKezelo->getJokerJelentkezoIDk();

       // dd($csoportok->jelentkezokLista,$csoportok->jokerJelentkezoLista);

         //$csoportok->JokerJelentkezokSzama = $BeosztasKezelo->getTeruletJelentkezokJokerekSzama();
         $csoportok->JokerJelentkezokSzama = count($csoportok->jokerJelentkezoLista);

         $csoportok->jelentkezokSzama = count($csoportok->jelentkezokLista);
         $csoportok->BeosztottakSzama = $BeosztasKezelo->getTeruletAktualisBeosztottakSzama();
         $csoportok->beosztottakListaja = $BeosztasKezelo->getTeruletreBeosztottakListajaID();

        // $csoportok->BeoszthatoOnkentesekSzama = $BeosztasKezelo->getBeoszthatoOnkentesekSzama(); //ez a fgv nnem jo



         $usersArr = array();
         foreach($csoportok->jelentkezokLista as $jelentkezo)
         {
            array_push($usersArr,$jelentkezo->felhasznalo_id);
         }
         foreach($csoportok->beosztottakListaja as $jelentkezo)
         {
            array_push($usersArr,$jelentkezo->felhasznalo_id);
         }
         foreach($csoportok->jokerJelentkezoLista as $jelentkezo)
         {
            array_push($usersArr,$jelentkezo->felhasznalo_id);
         }

         $model = $csoportok;
         $users = User::whereIn('id',$usersArr)->get(['id','name']);

         $model->UsersFreeTimes = $BeosztasKezelo->Calendar($usersArr);

        

         return view("onkentes.esemenyszervezok.teruletekbeosztasa")->with('model',$model)->with('users',$users)->
         with('CsoportosJelentkezok',$BeosztasKezelo->GetCsoportosJelentkezok())->
         with('JeligeLista', $BeosztasKezelo->getExistGroups());
     
    }

}
