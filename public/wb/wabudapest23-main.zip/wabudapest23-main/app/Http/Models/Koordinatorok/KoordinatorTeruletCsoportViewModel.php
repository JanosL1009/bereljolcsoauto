<?php
namespace App\Http\Models\Koordinatorok;
use App\Http\Models\CsoportokLekerdezese;

class KoordinatorTeruletCsoportViewModel extends CsoportokLekerdezese
{

}
