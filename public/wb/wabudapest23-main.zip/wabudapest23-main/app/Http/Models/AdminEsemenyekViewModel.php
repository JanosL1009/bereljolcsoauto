<?php
namespace App\Http\Models;

/**
 * Az admin/esemenyek route, admin/esemenyek view dinamikus adtainak model osztalya
 */
class AdminEsemenyekViewModel extends AbstractGeneralProfile
{
    /**
     * @var int Jogosultsag szint
     */
  public $Level;

  /**
   * @var Array A rendezvenyeket tartalmazza egy tombben
   */
  public $rendezveny;

  /**
   * ['neve' => value, 'helyszin' => value, 'kezd_idopont' => value]
   */

   public $teruletek;

   public $SiteNavAndOp;

   public $csoport;

   protected $ModeCode = 0;

    /**
         * Adminisztrator
         * 2: Onkentes
         * 3: Eseményszervezo
         * 4: Teruleti onkentes koordinator
         * 5. Csoportvezeto
         * 6. Felfuggesztett onkentes
         * 7. Ruha átadó jog (a 2. jog egy kiterjesztése, aljoga)
         */
        public $felhasznaloiPoziciok;

        public $adminLista = array();

        public $jelentkezokLista = array();

        public function GetJelentkezokTeljes()
        {
            $union = $this->adminLista->union(collect($this->jelentkezokLista));
            return $union->all();
        }

        public  $EsemenySzervezok;

        protected $mode = null;

        /**
         * Beallitja a mode valtozot. Az erteke all/active/archive lehet. Default: all
         * Az esmenyek megjelenitesi modjanal hasznaljuk
         * @param string Mode
         */
        public function setMode($mode)
        {
            //megviszgaljuk, hogy parameter valid-e
            switch($mode)
            {
                case 'all': $this->mode = $mode;
                break;
                case 'notcomplete': $this->mode = $mode;$this->ModeCode = 1;
                break;
                case 'active': $this->mode = $mode;$this->ModeCode = 2;
                break;
                case 'noteligible': $this->mode = $mode;$this->ModeCode = 3;
                break;
                case 'archive': $this->mode = $mode;$this->ModeCode = 4;
                break;

                default: $this->mode = 'all'; //alapertelmezett parameter. kivetl es/vagy 404 oldal elkerulese
                break;
            }
        }

        /**
         * Viasszter a mode valtozo ertekevel, ha az be van allitva! Ha nincs akko null erkezik!
         *@return string A mode valtozo erteke, ha nincs beallitva akkor null-t kaphatunk.
         */
        public function getMode()
        {
            return $this->mode;
        }

        public function getModeCode()
        {
            return $this->ModeCode;
        }


}
