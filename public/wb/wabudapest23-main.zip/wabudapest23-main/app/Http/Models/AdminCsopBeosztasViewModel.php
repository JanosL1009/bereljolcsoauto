<?php
namespace App\Http\Models;


class AdminCsopBeosztasViewModel  extends AbstractGeneralProfile
{

    public $adminLista = array();

    public $breadcrumblink = null;

    public function GetJelentkezokTeljes()
    {
        $union = $this->adminLista->union(collect($this->jelentkezokLista));
        return $union->all();
    }

    public  $EsemenySzervezok;
    public  $TeruletVezetok;
    public  $CsoportVezetok;
    public $CsoportTagok;

    public $esemeny_id;

    public $teruletID;

    public $csoportID;

    public $BeosztottakSzama = 0;
    public $TervezettCsoportLetszam = 0;

    public $UsersFreeTimes = [];

}
