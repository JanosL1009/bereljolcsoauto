<?php
namespace App\Http\Models;
use App\Http\Models\AbstractGeneralProfile;
use App\Http\Models\I_MagyarazoSzovegek;
use App\Http\Models\TraitMagyarazoSzoveg;

class DocumentsViewModel extends AbstractGeneralProfile implements I_MagyarazoSzovegek
{
    use TraitMagyarazoSzoveg;
}
