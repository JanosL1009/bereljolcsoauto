<?php
namespace App\Http\Models;

/**
 * @version 1.0.1
 * Fields: BeosztottakSzama, NemBeosztottakSzama
 */
class AdminEsemenyViewModel extends AbstractGeneralProfile
{
    public $esemenyID;
    public $esemenyNeve;
    public $kezdesDatuma; public $kezdesIdeje;

    public $befejezesDatuma; public $befejezesIdeje;

    public $helyszin;

    public $igenyeltOnkentesLetszam; public $jelentkezokSzama;

    public $Vezetok;

    public $Leiras;

    public $Toborzas;

    public $Statusz;

    public $Teruletek; //TeruletCsoport lista

    /**
         * Adminisztrator
         * 2: Onkentes
         * 3: Eseményszervezo
         * 4: Teruleti onkentes koordinator
         * 5. Csoportvezeto
         * 6. Felfuggesztett onkentes
         */
        public $felhasznaloiPoziciok;

        public $adminLista = array();

        public $jelentkezokLista = array();

        public function GetJelentkezokTeljes()
        {
            $union = $this->adminLista->union(collect($this->jelentkezokLista));
            return $union->all();
        }

        public  $EsemenySzervezok;

        /** @version 1.0.1 */
        public $BeosztottakSzama = 0;
        public $NemBeosztottakSzama = 0;


        public function getBefejezesIdejeOra()
        {
            $strings = explode(":",$this->befejezesIdeje);
            return $strings[0];
        }

        public function getBefejezesIdejePerc()
        {
            
            $strings = explode(":",$this->befejezesIdeje);
            return $strings[1];
        }

}
