<?php
namespace App\Http\Models;
use App\Http\Models\AbstractGeneralProfile;

use Exception;

class YtViewModel extends AbstractGeneralProfile 
{

}