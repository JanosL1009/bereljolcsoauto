<?php
namespace App\Http\Models\Traits;
use Illuminate\Database\Eloquent\Collection;
use App\Allampolgarsag;

trait TraitAllampolgManipulation
{
    /**
     * Az elso elemnek fogja beallitani a Magyart. Egy rendezett listat fog kapni, amibol a magyart elso helyre kell tenni.
     * @param  List<int,string> id:nev -> Eloquent object
     */
    public function getManupulateListOrder(Collection $NationlityList) 
    {
        $newList = new Collection();
        
        foreach($NationlityList as $nationality)
        {
           
            if($nationality->allampolgarsag == "Magyar")
            {
                $newList->push($nationality);
                break;
            }
        }

        foreach($NationlityList as $nationality)
        {
           
            if($nationality->allampolgarsag != "Magyar")
            {
                $newList->push($nationality);
             
            }
        }
       
        return $newList;
    }


}