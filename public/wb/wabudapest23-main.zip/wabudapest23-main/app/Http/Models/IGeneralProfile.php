<?php
namespace App\Http\Models;

interface IGeneralProfile
{
    public function GetProfilePic();
}
