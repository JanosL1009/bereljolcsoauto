<?php
namespace App\Http\Models;


class AdminDocumentView  extends AbstractGeneralProfile
{

    public $documentsList;
    public $visibilityName;
}
