<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;

class Documents extends Model
{

    protected $table = 'alt_dokumentumok';

}
