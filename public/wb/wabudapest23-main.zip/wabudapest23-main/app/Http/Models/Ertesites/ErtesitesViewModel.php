<?php
namespace App\Http\Models\Ertesites;

use App\Http\Models\AbstractGeneralProfile;
use App\Http\Models\I_Ertesitesek;

class ErtesitesViewModel extends AbstractGeneralProfile
{

    public $isAdmin = false;

    public  $ErtesitesNeve = null;
    public $created_at = null;
    public $LetrehozoNeve;

    public function setAdmin(bool  $isAdmin) : void
    {
        $this->isAdmin =  $isAdmin;
    }

    private function OnkentesProfilEllenorzese() : void
    {
        if(!$this->isAdmin)
        {

        }
    }

    public $Program = null;
    public $Terulet = null;
    public $Csoport = null;

    public $Tartalom = null;


    /**Statisztikahoz */

    /**
     * Akik feliratkoztak, tehat megkaptak az ertesitest
     * @var int
     */
    public $OnkentesekSzama = 0;

    /**
     * @var int
     */
    public $megtekintesekSzama = 0;

    /**
     * @var Collection[User]
     */
    public $VezetokAkikLattak = null;

    /**
     * @var Collection[User]
     */
    public $vezetokAkikNemLattak = null;


}
