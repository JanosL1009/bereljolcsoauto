<?php
namespace App\Http\Models\Ertesites;

use \Exception;
use App\Http\Models\AbstractGeneralProfile;


class OnkentesErtesitesViewModel extends AbstractGeneralProfile
{
    public $esemenyek = null;
    public $teruletek = null;
    public $csoportok = null;


}
