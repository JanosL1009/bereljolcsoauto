<?php
namespace App\Http\Models\JeligeCsoport;

use \Exception;
use App\Http\Models\AbstractGeneralProfile;

class CsoportkezelesViewModel extends AbstractGeneralProfile
{
    public $ActUserID = 0;
    public $JeligeID;
    public $JeligeNeve = null;
    public $CsoportLetrehozoID = 0;
    public $CsoportLetrehozoNeve = null;
    public $isJeligeAdmin = false;

    /**
     * @var AssocArray
     */
    public $CsoportTagok = array();


}
