<?php
namespace App\Http\Models;

use App\FelhasznaloInfo;
use App\Http\Controllers\DB_OMR_Operations;
use Illuminate\Support\Facades\DB;
use Exception;
use App\MyErrorLog;
use Illuminate\Support\Carbon;
use App\User;
use App\Jogosultsag;
use App\Model\Felhasznalo;
use App\UserLogins;
use DateTime;

/**
 * This is a repository class...
 */
class StatisticsModel
{

    public static function getAllUsers() : int
    {
        return User::all()->count();
    }

    public static function getAllVoluntary() : int
    {
        $res = 0;
        try{

            $res = Jogosultsag::where('felhasznaloszint_id',2)->get('id')->count();
        }
        catch(Exception $e)
        {
            $error = new MyErrorLog();
            $error->controller = 'RiportsController';
            $error->methodname = 'getAllVoluntary';
            $error->otherDescribe = 'Ismeretlen';
            $error->exceptionMsg = $e->getMessage();
            $error->felhasznalo_id = 0;
            $error->allAvilableData = $res;
            $error->save();
            $res = -1;
        }
        finally{
            return 0;
        }
        
    }

    public static function getImportedUsersCount() : int
    {
        return DB::table('importhoz')->get('id')->count();
    }

    /**
     * They entered once...
     */
    public static function getImportedValidUsersCount() : int 
    {
        return DB::table('importhoz')->get()->count();
    }

    public static function getDailyNewUsersCount() : int
    {
        $dt = Carbon::now();
        $timestampStart =  $dt->toDateString().' '.'00:00:00';
        $timestampEnd =  $dt->toDateString().' '.'23:59:59';
        unset($dt);
        return User::whereBetween('created_at', [$timestampStart, $timestampEnd])->get('id')->count();

    }

    /**
     * @return array Associative array
     */
    public static function getWeeklyNewUsersCount() : array 
    {
        $dt = Carbon::now();
       // $monday 
        return array();
    }

    public static function getDailyLogins() : int
    {
        $dt = Carbon::now();
        $timestampStart =  $dt->toDateString().' '.'00:00:00';
        $timestampEnd =  $dt->toDateString().' '.'23:59:59';
        unset($dt);
        $res = 0;
        try{
            $res = UserLogins::whereBetween('loginDate', [$timestampStart, $timestampEnd])->get('id')->count();
        }
        catch(Exception $e)
        {
            $error = new MyErrorLog();
            $error->controller = 'RiportsController';
            $error->methodname = 'getDailyLogins';
            $error->otherDescribe = 'Ismeretlen';
            $error->exceptionMsg = $e->getMessage();
            $error->felhasznalo_id = 0;
            $error->allAvilableData = $res;
            $error->save();
            $res = -1;
        }
        finally
        {
            return $res;
        }
       
    }

    /**
     * @return int IF [-1] is error code.
     */
    public static function getImportedUpdatedUsersCount() : int
    {
        //SELECT count(felhasznalok.id) FROM `felhasznalok` inner join importhoz on felhasznalok.id = importhoz.felhasznalo_id where felhasznalok.updated_at > '2021-04-20 00:00:00'
        $res = 0;
        
        try{
            $res = DB::table('felhasznalok')->join('importhoz','felhasznalok.id','=','importhoz.felhasznalo_id','inner')->where('felhasznalok.updated_at','>','2021-04-20 00:00:00')->get()->count();
        }
        catch(Exception $e)
        {
            $error = new MyErrorLog();
            $error->controller = 'RiportsController';
            $error->methodname = 'getImportedUpdatedUsersCount';
            $error->otherDescribe = 'Ismeretlen';
            $error->exceptionMsg = $e->getMessage();
            $error->felhasznalo_id = 0;
            $error->allAvilableData = $res;
            $error->save();
            $res = -1;
        }
        finally{
            return $res;
        }

    }

    public static function getTShirts()
    {
        //$f_info = new FelhasznaloInfo();
        $ferfi = static::getTShirtSize(1);
        $no = static::getTShirtSize(0);

        return array_merge($ferfi,$no);
    }

    protected static function getTShirtSize(int $PoloTipus)
    {
        $xs = DB::table('felhasznaloinfo')->where('polomeret','XS')->where('polotipus',$PoloTipus)->count();
        $s = DB::table('felhasznaloinfo')->where('polomeret','S')->where('polotipus',$PoloTipus)->count();
        $m = DB::table('felhasznaloinfo')->where('polomeret','M')->where('polotipus',$PoloTipus)->count();
        $l = DB::table('felhasznaloinfo')->where('polomeret','L')->where('polotipus',$PoloTipus)->count();
        $xl = DB::table('felhasznaloinfo')->where('polomeret','XL')->where('polotipus',$PoloTipus)->count();
        $xxl = DB::table('felhasznaloinfo')->where('polomeret','XXL')->where('polotipus',$PoloTipus)->count();
        $xxxl = DB::table('felhasznaloinfo')->where('polomeret','XXXL')->where('polotipus',$PoloTipus)->count();
        $xxxxl = DB::table('felhasznaloinfo')->where('polomeret','XXXXL')->where('polotipus',$PoloTipus)->count();

        $result = array();
        if($PoloTipus == 0)
        {
            $result['noi']['xs'] = $xs;
            $result['noi']['s'] = $s;
            $result['noi']['m'] = $m;
            $result['noi']['l'] = $l;
            $result['noi']['xl'] = $xl;
            $result['noi']['xxl'] = $xxl;
            $result['noi']['xxxl'] = $xxxl;
            $result['noi']['xxxxl'] = $xxxxl;
        }
        else{
            $result['ferfi']['xs'] = $xs;
            $result['ferfi']['s'] = $s;
            $result['ferfi']['m'] = $m;
            $result['ferfi']['l'] = $l;
            $result['ferfi']['xl'] = $xl;
            $result['ferfi']['xxl'] = $xxl;
            $result['ferfi']['xxxl'] = $xxxl;
            $result['ferfi']['xxxxl'] = $xxxxl;
        }
        return $result;
    }

    public static function getNewRegisters(DateTime $startDate = null,DateTime $endDate = null)
    {
        $result = null;
        if(isset($startDate) && !isset($endDate))
        {
            $result = User::where('created_at', '>',$startDate)->get();
        }
        else 
        {
            $result = User::where('created_at', '>',$startDate)->where('created_at', '<',$endDate)->get();
        }
        return $result;
    }

    public static function getAllNewRegisteredUser()
    {
        $start = new DateTime('2021-04-20 00:00:00');
        $resultList = static::getNewRegisters($start,null)->count();
        return $resultList;
    }

}
