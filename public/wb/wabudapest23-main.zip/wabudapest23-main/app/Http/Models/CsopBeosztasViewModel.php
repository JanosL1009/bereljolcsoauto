<?php
namespace App\Http\Models;

use  App\Http\Models\Csoport;
use  App\Http\Models\CsoportokLekerdezese;
class CsopBeosztasViewModel extends CsoportokLekerdezese
{
   public $adminok;

   public $jelentkezok;



}
