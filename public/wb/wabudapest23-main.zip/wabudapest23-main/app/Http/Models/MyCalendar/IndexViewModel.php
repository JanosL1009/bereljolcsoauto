<?php
namespace App\Http\Models\MyCalendar;

use \Exception;
use App\Http\Models\AbstractGeneralProfile;

class IndexViewModel extends AbstractGeneralProfile
{
    /**
     * JSON formatumum string lesz az adatbazisbol
     * @var string
     */
    public $Idopontjaim = null;

    public $Config = null;
}
