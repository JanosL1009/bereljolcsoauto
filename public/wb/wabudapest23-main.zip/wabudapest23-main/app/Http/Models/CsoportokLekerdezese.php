<?php
namespace App\Http\Models;

use  App\Http\Models\Csoport;

class CsoportokLekerdezese extends AbstractGeneralProfile
{
        public $csoport;
        public $teruletid;
        public $rendezvenyNeve;
        public $teruletneve;
        public $jelentkezokSzama;
        public $tervezettLetszam;
        public $BeosztottakSzama = 0;
        public $TeruletAktiv;

        public $rendezvenyKezdesDatuma;
        public $rendezvenyBefejezesDatuma;

        public $helyszin;
        public $cim;

        public $teruletLeiras;


        public $UsersFreeTimes = [];

        /**
         * Adminisztrator
         * 2: Onkentes
         * 3: Eseményszervezo
         * 4: Teruleti onkentes koordinator
         * 5. Csoportvezeto
         * 6. Felfuggesztett onkentes
         */
        public $felhasznaloiPoziciok;

        public $adminLista = array();

        public $jelentkezokLista = array();
        public $jokerJelentkezoLista;

        public $teruletKezdesIdopont;
        public $teruletBefejezesIdopont;

        public function GetJelentkezokTeljes()
        {
            $union = $this->adminLista->union(collect($this->jelentkezokLista));
            return $union->all();
        }

        public  $EsemenySzervezok;
        public  $TeruletVezetok;
        public  $CsoportVezetok;

        public $beosztottakListaja;

        public $JokerJelentkezokSzama = 0;
        public $BeoszthatoOnkentesekSzama = 0;

        public function GetKezdesIdopont() : string
        {
            $split = explode(' ', $this->teruletKezdesIdopont);
            return $split[0];
        }

        /**
         * @param string Mit adjon vissza a fgv. 'H' : ora; 'm' : perc, 's':masodperc
         * @return int  Default: 0
         */
        public function GetKezdesIdeje($mode) : int
        {
            $split = explode(' ', $this->teruletKezdesIdopont);
            $secondSplitter = explode(':', $split[1]);
            switch($mode)
            {
                case 'H':
                    return intval($secondSplitter[0]);
                break;
                case 'm':
                    return intval($secondSplitter[1]);
                break;
                case 's':
                    return intval($secondSplitter[2]);
                break;
                default:
                    return 0;
                break;

            }

        }

        public function GetBefejzesIdopont() : string
        {
            $split = explode(' ', $this->teruletBefejezesIdopont);
            return $split[0];
        }

        /**
         * @param string Mit adjon vissza a fgv. 'H' : ora; 'm' : perc, 's':masodperc
         * @return int  Default: 0
         */
        public function GetBefejezesIdeje($mode) : int
        {
            $split = explode(' ', $this->teruletBefejezesIdopont);
            $secondSplitter = explode(':', $split[1]);
            switch($mode)
            {
                case 'H':
                    return intval($secondSplitter[0]);
                break;
                case 'm':
                    return intval($secondSplitter[1]);
                break;
                case 's':
                    return intval($secondSplitter[2]);
                break;
                default:
                    return 0;
                break;

            }

        }


}
