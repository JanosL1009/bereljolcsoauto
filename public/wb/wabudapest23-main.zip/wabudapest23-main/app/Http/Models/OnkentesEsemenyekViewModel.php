<?php
namespace App\Http\Models;
use App\Http\Models\AbstractGeneralProfile;
use App\Http\Models\TraitMagyarazoSzoveg;
use App\Http\Models\I_MagyarazoSzovegek;
class OnkentesEsemenyekViewModel extends AbstractGeneralProfile implements I_MagyarazoSzovegek
{
    use TraitMagyarazoSzoveg;

    public $jogszint;
    public $nev;

    public $esemenyek;

    public $mode;

    public $profilpic;

}
