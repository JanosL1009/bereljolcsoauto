<?php
namespace App\Http\Models;

use  App\Http\Models\Csoport;

class CsoportokLekerdezese extends AbstractGeneralProfile
{
    public $csoport;
        public $JokerJelentkezokSzama = 0;
        public $teruletneve;
        public $jelentkezokSzama;
        public $tervezettLetszam;
        public $TeruletAktiv;

        public $teruletKezdesIdopont;
        public $teruletBefejezesIdopont;

        public function GetKezdesIdopont() : string
        {
            $split = explode(' ', $this->teruletKezdesIdopont);
            return $split[0];
        }

        /**
         * @param string Mit adjon vissza a fgv. 'H' : ora; 'm' : perc, 's':masodperc
         * @return int  Default: 0
         */
        public function GetKezdesIdeje($mode) : int
        {
            $split = explode(' ', $this->teruletKezdesIdopont);
            $secondSplitter = explode(':', $split[1]);
            switch($mode)
            {
                case 'H':
                    return intval($secondSplitter[0]);
                break;
                case 'm':
                    return intval($secondSplitter[1]);
                break;
                case 's':
                    return intval($secondSplitter[2]);
                break;
                default:
                    return 0;
                break;

            }

        }

        public function GetBefejzesIdopont() : string
        {
            $split = explode(' ', $this->teruletBefejezesIdopont);
            return $split[0];
        }

        /**
         * @param string Mit adjon vissza a fgv. 'H' : ora; 'm' : perc, 's':masodperc
         * @return int  Default: 0
         */
        public function GetBefejezesIdeje($mode) : int
        {
            $split = explode(' ', $this->teruletBefejezesIdopont);
            $secondSplitter = explode(':', $split[1]);
            switch($mode)
            {
                case 'H':
                    return intval($secondSplitter[0]);
                break;
                case 'm':
                    return intval($secondSplitter[1]);
                break;
                case 's':
                    return intval($secondSplitter[2]);
                break;
                default:
                    return 0;
                break;

            }

        }


}
