<?php
namespace App\Http\Models\Hirek;

use App\Http\Models\AbstractGeneralProfile;
use App\Http\Models\Hirek\HirTrait;
use App\Http\Models\Hirek\HirSeoTrait;
use App\Http\Models\Hirek\CarouselModel;
use Exception;
use App\Http\Models\Hirek\I_Seo;
use Illuminate\Database\Eloquent\Model;
use App\HirKategoria;
use App\HirKepek;
use App\HirSEO;
use Illuminate\Database\Eloquent\Collection;
class HirekOnkentesViewModel extends AbstractGeneralProfile
{
    private $CarouselItems = 2;

    protected $carousel = [];

    /**
     * Feltolti elemmel a carousel modelt a front-endnek.
     */
    public function setCarousel(Collection $Hirek)
    {
        //dd($Hirek);
       /* $Hirek = $Hirek->all()->toArray();*/

       // $HirKepek = HirKepek->all()->toArray();
       for($i = 0; $i < $this->CarouselItems;$i++)
       {
            $carouselmodel = new CarouselModel();
            $HirSeo = HirSEO::where('hir_id',$Hirek[$i]['h_id'])->first();
            $HirKepek = HirKepek::where('hir_id',$Hirek[$i]['h_id'])->first();
            $carouselmodel->HirID = $Hirek[$i]['h_id'];
            $carouselmodel->HirCime = $Hirek[$i]['hir_cime'];
            $carouselmodel->LetrehozasIdeje = $Hirek[$i]['created_at'];
            $allapot = $Hirek[$i]['allpot'];
            $carouselmodel->setStatusz($allapot);

            $carouselmodel->description = $HirSeo->description;
            $carouselmodel->keywords = $HirSeo->keywords;
            $carouselmodel->title = $HirSeo->title;
            $carouselmodel->og_title = $HirSeo->og_title;
            $carouselmodel->od_desc = $HirSeo->og_desc;
            $carouselmodel->setRobots($HirSeo->robots);
            $carouselmodel->setSeoUrl($HirSeo->og_url);
            $carouselmodel->og_image = $HirKepek->jumbotronImg;
            $carouselmodel->CarouselImg =  $carouselmodel->og_image;
            $carouselmodel->thumbnailImg =  $HirKepek->thumbnailImg;
            array_push($this->carousel,$carouselmodel);
       }

    }

    public function getCarouselModelItems()
    {
        return $this->carousel;
    }

    /**max 4 elem lehet benne */
    protected $NewsTiles = array();

    public function SetNewsTiles($NewsTilesArray)
    {
        if(gettype($NewsTilesArray) == 'array' )
        {
            if(count($NewsTilesArray) <= 4)
            {
                $this->NewsTiles = $NewsTilesArray;
            }
            else
            {
                //dd($NewsTilesArray);
                throw new Exception("Kizárólag 4 elemet tartalmazhat!");}
        }
        else
        {
            //dd($NewsTilesArray);
            throw new Exception("Az objektum csak tömb lehet és pontosan 4 elemet tartalmazhat a cempék miatt!");
        }
    }


        public function GetNewsTilesArray()
        {
            return $this->NewsTiles;
        }

        /**
         * Beallitja a megjelnitheto hirek szamat. A carouselnek
         */
        public function setCarouselItemsCount(int $ItemNumber)
        {
            $this->CarouselItems = $ItemNumber;
        }

        /**
         * Visszater az aktualis elem szammal, amit a carouel fog megjeleniteni. Hirek szamaval
         */
        public function getCarouselItem()
        {
            $this->CarouselItems;
        }

        /**
         * hir_kaegoria tabla category mezoje kell
         * A -1 es ertek jelentese: osszesnel meg kell jeleniteni! egy altalnos hirrol van szo
         */
        private function getProgramNeve(int $HirID)
        {

        }

}

