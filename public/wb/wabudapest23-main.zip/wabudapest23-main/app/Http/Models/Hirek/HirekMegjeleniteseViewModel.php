<?php
namespace App\Http\Models\Hirek;

use App\Http\Models\AbstractGeneralProfile;
use App\Http\Models\Hirek\HirTrait;
use Exception;

class HirekMegjeleniteseViewModel extends AbstractGeneralProfile
{

    use HirTrait;


    public $hirek;




}

