<?php
namespace App\Http\Models\Hirek;
use App\Http\Models\Hirek\HirTrait;
use App\Http\Models\Hirek\I_Seo;
use  App\Http\Models\Hirek\HirSeoTrait;

class CarouselModel implements I_Seo
{
    use HirTrait;
    use HirSeoTrait;

    public $CarouselImg = null;

    protected $ProgramNeve = null;

    public function getSlug()
    {
        return $this->getOG_Url_Slug();
    }

    public function getKeywords(){
       return $this->keywords;
    }

    public function getDescription(){
        return $this->description;
    }

    public function getSiteTitle(){
        return $this->title;
    }


}
