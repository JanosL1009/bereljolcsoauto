<?php
namespace App\Http\Models\RuhaAtado;

use App\Http\Models\AbstractGeneralProfile;


class Altalanos extends AbstractGeneralProfile
{



}
