<?php
namespace App\Http\Models;
use App\Http\Models\AbstractGeneralProfile;
class AdminProfilViewModel extends AbstractGeneralProfile
{
    public  $jogszint;
    public $OnkentesProfilPic;

    public $Vezeteknev;
    public $Kozepsonev;
    public $Keresztnev;
    public $Nem;
    public $Neme_id;
    public $Telefonszam;
    public $email;
    public $szulido;
    public $szulhely;
    public $EletKor;

    public $BeszelhetoNyelvek;

    //lakcimeket lekerni
    public  $all_lakcim_orszag;
    public  $all_lakcim_telepules;
    public  $all_lakcim_irszam;
    public  $all_lakcim_utca;

    public  $tart_lakcim_orszag;
    public  $tart_lakcim_telepules;
    public  $tart_lakcim_irszam;
    public  $tart_lakcim_utca;

    public $foteveknyseg;
    public $foteveknyseg_id;

    public $fogyatekossag;
    public $fogyatekossag_id;
    public $FogyLeirasa;

    public $polomeret;
    public $polomeret_id;

    public $onkentesOrakSzama = 0;

    //nyelveket lekerni
    public $nyelv1;public $nyelv2;public $nyelv3;
    public $nyelv1szint;public $nyelv2szint;public $nyelv3szint;

    public function GetTeljesNev()
    {
        return $this->Vezeteknev." ".$this->Kozepsonev." ".$this->Keresztnev;
    }

    public $fotevekenysegHTML;

    public $profilpic;

    /**
     * @var HTML format
     */
    public $Megye_TartLakcim;

    /**
     * @var HTML format
     */
    public $Megye_AllLakcim;

    public $Orszag_TartLakcim;

    public $Orszag_AllandoLakcim;
    /**
     * @var bool
     */
    public $masSzervezetTagja;


    public $MasSzervezetNeve;

/**
     * @var bool
     */
    public $CivilSzervezetTagja;


    public $CivilSzervezetNeve;

    /**
     * alap ertek, ha 1-es akkor bannolva van a user
     *
     * */
    public $blocked = 0;

    /**
     * Mikor bannoltak
     */
    public $blocked_at = null;

    /**
     * Ki bannolta
     */
    public $WhoBannedForName = null;

    //NEK-es  igenyek
    public $anyjaneve = "", $szemigszam ="", $allampolgarsag = "";

    public $polotipusa;

    public function GetHTMLPolotipusa()
    {
        $output = null;
        if($this->polotipusa == 1 || $this->polotipusa == '1' )
        {
            $output = '<option value="0">Női</option><option value="1" selected>Unisex/Férfi</option>';
        }else if($this->polotipusa == 0 || $this->polotipusa == '0')
        {
            $output = '<option value="0" selected>Női</option><option value="1" >Unisex/Férfi</option>';
        }
        else
        {
            $output = '<option value="0">Női</option><option value="1">Unisex/Férfi</option>';
        }
        return $output;
    }

}
