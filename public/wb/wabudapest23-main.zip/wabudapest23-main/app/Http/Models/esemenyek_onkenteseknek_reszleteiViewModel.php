<?php
namespace App\Http\Models;

use App\Http\Models\AbstractGeneralProfile;
use App\Http\Models\I_MagyarazoSzovegek;
use App\Http\Models\TraitMagyarazoSzoveg;

class esemenyek_onkenteseknek_reszleteiViewModel extends AbstractGeneralProfile implements I_MagyarazoSzovegek
{
    use TraitMagyarazoSzoveg;

    public $id;
    public $esemenyNeve;
    public $kezdesDatuma; public $kezdesIdeje;

    public $befejezesDatuma; public $befejezesIdeje;

    public $helyszin;

    public $igenyeltOnkentesLetszam; public $jelentkezokSzama;

    public $Vezetok;

    public $Leiras;

    public $Teruletek; //TeruletCsoport lista

    public $programKoordinatorok;
}
