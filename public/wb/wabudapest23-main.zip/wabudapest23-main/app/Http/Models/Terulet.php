<?php
namespace App\Http\Models;

class Terulet
{
    protected $id;
    public $esemenyID;
    public $nev;
    public $leiras;
    public $Jelentkeztem = false;

    /**
     * Class constructor.
     */
    public function __construct(int $id)
    {
        $this->id = $id;
    }

    public function GetId()
    {
        return $this->id;
    }

}



