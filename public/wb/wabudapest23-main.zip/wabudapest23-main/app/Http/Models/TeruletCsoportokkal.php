<?php
namespace App\Http\Models;

use App\Http\Models\Terulet;

class TeruletCsoportokkal extends Terulet
{

    /**
     * A Terulet Csoportjait tartalmazza eg  listaban
     * @var Array:Csoport
     */
    public $CsoportLista;

}
