<?php
namespace App\Http\Models\Muszak;

use App\MuszakDatumok;
use App\Munkafelvetel;
use App\Csoport;
use Carbon\Carbon;
use Carbon\CarbonInterval;
use Carbon\CarbonInterface;
use Carbon\CarbonPeriod;

class MuszakFelvetel
{

    /**
     * @var int
     */
        protected $CsoportID = 0;

        /**
         * @var Csoport Eloquent model
         */
        protected $Csoport = null;

        /**
         * @var MuszakDatumok
         */
        protected $MuszakDatumok = null;


        /**
         * @var bool
         */
        protected $isMuszakDatum = false;

    /**
     * Class constructor.
     */
    public function __construct(int $CsoportID)
    {
        $this->CsoportID = $CsoportID;
        $this->Csoport = Csoport::find($this->CsoportID);
        $this->MuszakDatumok = MuszakDatumok::where('csoport_id',$this->CsoportID)->get();

       /* if(count($this->MuszakDatumok) > 0)
        {

            $this->isMuszakDatum = true;
        }*/

    }



    public function getCsoportID() : int
    {
         return  $this->CsoportID;
    }

    public function getCsoportInformaciok()
    {
        return  $this->Csoport;
    }

    public function getMuszakDatumok()
    {
        return $this->MuszakDatumok;
    }

    public function isMuszakDatumLetezik()
    {
        return $this->isMuszakDatum;
    }

    /**
     * Ha még nincs muszak datum letrehozva, akkor ez megcsinalja, igazabol a meglevo csoportok miatt szukseges alkalmazni
     * mert az ujaknal automatan letrejonnek a rekordok
     */
    public function MuszakDatumokEllenorzese() : void
    {

       // if($this->isMuszakDatumLetezik() == false)
       // {
            $datumok = [];
            $carbonAdday = Carbon::create($this->Csoport->befejezesDatuma);
            $period = CarbonPeriod::create($this->Csoport->kezdesDatuma, $carbonAdday->addDay(), CarbonPeriod::EXCLUDE_END_DATE);

            $period->setStartDate($this->Csoport->kezdesDatuma);
            $perioArray = $period->toArray();

            foreach($perioArray as $period)
            {
                $d = explode(" ", $period);
                array_push($datumok, $d[0]);
            }



            foreach($datumok as $date)
            {
                $dbChecking =  MuszakDatumok::where('csoport_id',$this->Csoport->id)->
                where('csoport_date',$date)->first();
                //dd($dbChecking);
                if(!isset($dbChecking->id))
                {
                    $muszakok = new MuszakDatumok;
                    $muszakok->csoport_id = $this->CsoportID;
                    $muszakok->csoport_date = $date;
                    $muszakok->letrehozo = 0;
                    $muszakok->modosito = 0;
                    $muszakok->save();
                }

            }

            $this->isMuszakDatum = true;
       // }

    }

    /**
     * @param int
     */
    public function getValasztottDatum($id)
    {
        return MuszakDatumok::find($id)->csoport_date;
    }




}

/*
foreach (Carbon::parse('2020-06-01')->range('2020-06-17', $weekDayInterval) as $date) {
    // every week day
    echo ' '.$date->day;
}*/
// 1 2 3 4 5 8 9 10 11 12 15 16 17
