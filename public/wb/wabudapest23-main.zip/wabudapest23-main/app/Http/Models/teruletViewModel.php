<?php
namespace App\Http\Models;

class teruletViewModel
{
    public $esemenyNev;
    public $teruletek;


}
