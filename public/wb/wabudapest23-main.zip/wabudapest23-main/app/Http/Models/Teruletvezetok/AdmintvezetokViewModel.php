<?php
namespace App\Http\Models\Teruletvezetok;
use App\Http\Models\AbstractGeneralProfile;
use App\Teruletvezetok;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;


class AdmintvezetokViewModel extends AbstractGeneralProfile
{
    use TraitAdminVezetok;

    protected $TeruletVezetok = null;

    public $megjegyzes = null;

    /**
     * Egyeni beallitas lehetosege.
     * @param Model Teruletvezetok listaja
     *
     * @return void
     */
    public function setTeruletVezetok( $VezetokListaja) : void
    {
        $this->TeruletVezetok = $VezetokListaja;
    }

    public function getTeruletvezetok()
    {
        return $this->TeruletVezetok;
    }
}
