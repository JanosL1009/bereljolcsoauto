<?php
namespace App\Http\Models\Teruletvezetok;

trait TraitAdminVezetok
{
    protected $mode = null;

    public function setMode($mode)
    {
        $this->mode = $mode;
    }

    public function getMode()
    {
        return $this->mode;
    }
}
