<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;
use App\Jogosultsag;

class RedirectIfAuthenticated
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @param  string|null  $guard
     * @return mixed
     */
    public function handle($request, Closure $next, $guard = null)
    {
        if (Auth::guard($guard)->check()) {
            $user = auth()->user();

            /**
             * @var Booelan TRUE:Administrator, FALSE: Onkentes jogszint
             */
            $jog = Jogosultsag::where('felhasznalo_id','=',$user['id'])->
            where('felhasznaloszint_id','=',1)->exists();


            if($jog)
            {
                return redirect('/admin/esemenyek/all'); /** landing page a logint kovetoen, ha admin */
            }
            else
            {
                return redirect('/profil');/** landing page a logint kovetoen, ha onkentes */
            }


        }

        return $next($request);
    }
}
