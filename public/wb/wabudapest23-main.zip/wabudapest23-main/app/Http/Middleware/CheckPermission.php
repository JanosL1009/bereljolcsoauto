<?php

namespace App\Http\Middleware;

use Closure;
use App\User;
use App\Jogosultsag;

/**
 * A user jogszintet ellenorzi. Ha 2-es (onkentes), akkor jogosultsag megtagadast dob.
 * abort:403
 *
 *
 */
class CheckPermission
{
    /**
     * Handle an incoming request. abort(403, 'Unauthorized action.');
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $user = auth()->user();
        $jog = Jogosultsag::where('felhasznalo_id','=',$user['id'])->
        where('felhasznaloszint_id','>',1)->
        first('felhasznaloszint_id');
       // dd($jog->felhasznaloszint_id);
       if(isset($jog->felhasznaloszint_id))
       {
        if(intval($jog->felhasznaloszint_id) > 1)
        {
            abort(403, 'Nincs megfelelő jogosultsági szintje az oldal megtekintéséhez!');
        }
       }


        return $next($request);
    }
}

/**
 * Igy hasznald
 * az admin szintu funkciokra - controllerekre terjeszd ki a web.php-ban vagy api-phpban
 */
