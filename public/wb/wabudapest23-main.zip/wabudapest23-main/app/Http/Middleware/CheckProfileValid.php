<?php

namespace App\Http\Middleware;

use Closure;
use App\FelhasznaloInfo;
use App\Model\Felhasznalo;
use Exception;

class CheckProfileValid
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {

        $valid = false;
        if (auth()->check())
        {
            $valid = true;
            $user = auth()->user();
            $UserID = $user['id'];
            unset($user);

            $FelhasznaloTable = Felhasznalo::find($UserID);
            //dd( $UserTable);
            if(!isset($FelhasznaloTable->vezeteknev)) $valid = false;
            if(!isset($FelhasznaloTable->neme)) $valid = false;
            if(!isset($FelhasznaloTable->szulIdo)) $valid = false;
            if(!isset($FelhasznaloTable->szulhely_ID)) $valid = false;
            if(!isset($FelhasznaloTable->telefonszam)) $valid = false;
            
            try{
                if($FelhasznaloTable->profilkep == 'blank-profile-pic-omr.png')
                { $valid = false;}
            }
            catch(Exception $e)
            {
                $valid = false;
            }
            

            unset($FelhasznaloTable);



            $FelhInfoTable = FelhasznaloInfo::where('felhasznalo_id',$UserID)->first();
            if(!isset($FelhInfoTable->tevekenyseg_id))$valid = false;
            if(!isset($FelhInfoTable->polomeret))$valid = false;
            if(!isset($FelhInfoTable->polotipus))$valid = false;
            unset($FelhInfoTable);

            if(!$valid)
            {
                    $message = 'Töltse ki a fiókja összes kötelező mezőjét, különben a rendszer nem engedi Önt programra jelentkezni!A Profilkép feltöltése kötelező!';

                    return redirect()->route('profil_szerkesztes')->withErrors([$message, 'checkprofile']);
            }


         }


         return $next($request);
    }
}
