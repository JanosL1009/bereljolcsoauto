<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SystemEmails extends Model
{
    protected $table = 'systememails';


}
